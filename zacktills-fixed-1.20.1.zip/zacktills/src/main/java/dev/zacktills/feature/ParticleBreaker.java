package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Tick-driven, bounded auto-break state machine for particle-derived targets. */
final class ParticleBreaker {
    private enum State { IDLE, ACQUIRE, BREAKING, VERIFY, COOLDOWN }

    private static final double REACH_LIMIT = 4.5;
    private static final double CLUSTER_RADIUS = 1.5;
    private static final long FAILURE_BLACKLIST_NANOS = 5_000_000_000L;

    private static State state = State.IDLE;
    private static BlockPos target;
    private static BlockState originalState;
    private static int ticksInState;
    private static int breakTicks;
    private static int verifyTicks;
    private static int cooldownTicks;
    private static int retryCount;
    private static int attackCalls;
    private static boolean attackIssued;
    private static boolean retryPending;
    private static boolean toolSwitchAttempted;
    private static int reachLossTicks;
    private static int restoreDelay;
    private static int restoreSlot = -1;
    private static int selectedByTool = -1;
    private static float lastProgress;
    private static long lastAimNanos;
    private static long freshAfterNanos;

    private ParticleBreaker() { }

    static long freshAfterNanos() { return freshAfterNanos; }

    static void tick(MinecraftClient client, List<BlockPos> targets, ParticleTracker tracker) {
        if (client == null) return;
        serviceToolRestore(client);
        long now = System.nanoTime();
        tracker.expireBlacklists(now);

        PlayerEntity player = client.player;
        ClientPlayerInteractionManager manager = client.interactionManager;
        if (!FeatureSettings.boolValue("particle.auto_break", false)
                || client.world == null || player == null || manager == null || player.isDead()
                || player.isSpectator() || client.currentScreen != null
                || client.options.getPerspective() != Perspective.FIRST_PERSON) {
            cancel(client);
            updateActionBar(client, tracker);
            return;
        }

        if (target != null && state != State.COOLDOWN) {
            if (!client.world.isChunkLoaded(target)) {
                abandon(client);
                updateActionBar(client, tracker);
                return;
            }
            BlockState current = client.world.getBlockState(target);
            if (current.isAir() || !current.equals(originalState)) {
                confirmBroken(client, tracker, now);
                updateActionBar(client, tracker);
                return;
            }
            if (state != State.VERIFY) {
                TargetPoint point = targetPoint(client.world, target, player.getCameraPosVec(1.0F));
                if (point == null) {
                    abandon(client);
                    updateActionBar(client, tracker);
                    return;
                }
                if (point.position.distanceTo(player.getCameraPosVec(1.0F)) > reach(client, manager)) {
                    reachLossTicks++;
                } else {
                    reachLossTicks = 0;
                }
                if (reachLossTicks > 10) {
                    manager.cancelBlockBreaking();
                    abandonAfterCancel();
                    updateActionBar(client, tracker);
                    return;
                }
            }
        }

        if (ticksInState < Integer.MAX_VALUE) ticksInState++;
        switch (state) {
            case IDLE -> {
                if (restoreDelay == 0) {
                    BlockPos candidate = bestTarget(client, targets, tracker);
                    if (candidate != null) beginTarget(client.world, candidate);
                }
            }
            case ACQUIRE -> acquire(client, manager);
            case BREAKING -> breakTick(client, tracker, manager, player, now);
            case VERIFY -> verifyTick(client, tracker, manager);
            case COOLDOWN -> cooldownTick();
        }
        updateActionBar(client, tracker);
    }

    private static void beginTarget(World world, BlockPos pos) {
        target = pos.toImmutable();
        originalState = world.getBlockState(target);
        ticksInState = 0;
        breakTicks = 0;
        verifyTicks = 0;
        cooldownTicks = 0;
        retryCount = 0;
        attackCalls = 0;
        attackIssued = false;
        retryPending = false;
        toolSwitchAttempted = false;
        reachLossTicks = 0;
        lastProgress = 0.0F;
        lastAimNanos = 0L;
        enter(State.ACQUIRE);
    }

    private static void acquire(MinecraftClient client, ClientPlayerInteractionManager manager) {
        manager.cancelBlockBreaking();
        attackIssued = false;
        verifyTicks = 0;
        breakTicks = 0;
        lastProgress = 0.0F;
        reachLossTicks = 0;
        if (!retryPending && !toolSwitchAttempted) {
            toolSwitchAttempted = true;
            if (FeatureSettings.boolValue("particle.auto_tool", false)) switchToBestTool(client);
        }
        retryPending = false;
        // Returning to BREAKING here leaves a complete END_CLIENT_TICK between a slot switch and attackBlock.
        enter(State.BREAKING);
    }

    private static void switchToBestTool(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || target == null || originalState == null) return;
        int currentSlot = player.getInventory().selectedSlot;
        int bestSlot = currentSlot;
        float bestSpeed = player.getInventory().getStack(currentSlot).getMiningSpeedMultiplier(originalState);
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getStack(slot);
            float speed = stack.getMiningSpeedMultiplier(originalState);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }
        if (bestSlot != currentSlot) {
            restoreSlot = currentSlot;
            selectedByTool = bestSlot;
            player.getInventory().selectedSlot = bestSlot;
        }
    }

    private static void breakTick(MinecraftClient client, ParticleTracker tracker,
                                  ClientPlayerInteractionManager manager, PlayerEntity player, long now) {
        if (target == null || client.world == null) {
            abandon(client);
            return;
        }
        ClientPlayerInteractionManagerAccessor access = (ClientPlayerInteractionManagerAccessor) manager;
        float progress = progressFor(access, target);
        if (progress <= 0.0F) {
            BlockPos replacement = closerTarget(client, tracker, target);
            if (replacement != null) {
                manager.cancelBlockBreaking();
                abandonAfterCancel();
                return;
            }
        }

        TargetPoint point = targetPoint(client.world, target, player.getCameraPosVec(1.0F));
        if (point == null) {
            manager.cancelBlockBreaking();
            abandonAfterCancel();
            return;
        }
        aimAt(player, point.position);
        access.zacktills$setBlockBreakingCooldown(0);
        if (!manager.isCurrentlyBreaking(target) && !attackIssued) {
            attackCalls++;
            attackIssued = true;
            manager.attackBlock(target, point.face);
        }
        boolean stopSent = manager.updateBlockBreakingProgress(target, point.face);
        player.swingHand(Hand.MAIN_HAND);
        access.zacktills$setBlockBreakingCooldown(0);

        if (client.world.getBlockState(target).isAir()
                || !client.world.getBlockState(target).equals(originalState)) {
            confirmBroken(client, tracker, now);
            return;
        }
        progress = progressFor(access, target);
        if (progress > lastProgress + 0.0001F) lastProgress = progress;
        if (breakTicks < Integer.MAX_VALUE) breakTicks++;

        if (stopSent || progress >= 1.0F
                || (attackIssued && !access.zacktills$isBreakingBlock()
                    && !manager.isCurrentlyBreaking(target))) {
            verifyTicks = 0;
            enter(State.VERIFY);
            return;
        }
        int maxTicks = Math.max(1, (int) FeatureSettings.number("particle.max_break_ticks"));
        if (breakTicks > maxTicks) {
            manager.cancelBlockBreaking();
            tracker.blacklist(target, FAILURE_BLACKLIST_NANOS);
            log(client, "stuck", target);
            log(client, "blacklisted", target);
            scheduleToolRestore();
            clearTarget();
            enter(State.IDLE);
        }
    }

    private static void verifyTick(MinecraftClient client, ParticleTracker tracker,
                                   ClientPlayerInteractionManager manager) {
        if (target == null || client.world == null) {
            abandon(client);
            return;
        }
        BlockState current = client.world.getBlockState(target);
        if (current.isAir() || !current.equals(originalState)) {
            confirmBroken(client, tracker, System.nanoTime());
            return;
        }
        verifyTicks++;
        if (verifyTicks < 10) return;

        log(client, "VERIFY failed", target);
        manager.cancelBlockBreaking();
        int maxRetries = Math.max(0, (int) FeatureSettings.number("particle.verify_retries"));
        if (retryCount < maxRetries) {
            retryCount++;
            retryPending = true;
            cooldownTicks = 5;
            enter(State.COOLDOWN);
        } else {
            tracker.blacklist(target, FAILURE_BLACKLIST_NANOS);
            log(client, "blacklisted", target);
            scheduleToolRestore();
            clearTarget();
            enter(State.IDLE);
        }
    }

    private static void confirmBroken(MinecraftClient client, ParticleTracker tracker, long now) {
        if (target == null) return;
        BlockPos broken = target.toImmutable();
        tracker.removeWithin(broken, CLUSTER_RADIUS + 1.5);
        double seconds = Math.max(0.1, Math.min(60.0, FeatureSettings.number("particle.blacklist_time")));
        tracker.blacklist(broken, (long) (seconds * 1_000_000_000L));
        freshAfterNanos = now;
        log(client, "confirmed broken", broken);
        log(client, "blacklisted", broken);
        scheduleToolRestore();
        cooldownTicks = 3;
        retryPending = false;
        enter(State.COOLDOWN);
    }

    private static void cooldownTick() {
        if (cooldownTicks > 0) cooldownTicks--;
        if (cooldownTicks > 0) return;
        if (retryPending) {
            enter(State.ACQUIRE);
        } else {
            clearTarget();
            enter(State.IDLE);
        }
    }

    private static BlockPos bestTarget(MinecraftClient client, List<BlockPos> targets, ParticleTracker tracker) {
        if (client.world == null || client.player == null || client.interactionManager == null || targets == null) return null;
        Vec3d eye = client.player.getCameraPosVec(1.0F);
        double reach = reach(client, client.interactionManager);
        return targets.stream()
                .filter(pos -> pos != null && !tracker.isBlacklisted(pos))
                .map(pos -> new TargetDistance(pos, targetPoint(client.world, pos, eye)))
                .filter(entry -> entry.point != null && entry.point.position.distanceTo(eye) <= reach)
                .min(Comparator.comparingDouble(entry -> entry.point.position.squaredDistanceTo(eye)))
                .map(entry -> entry.pos.toImmutable()).orElse(null);
    }

    private static BlockPos closerTarget(MinecraftClient client, ParticleTracker tracker, BlockPos current) {
        if (client.world == null || client.player == null || client.interactionManager == null) return null;
        ClientPlayerInteractionManagerAccessor access = (ClientPlayerInteractionManagerAccessor) client.interactionManager;
        if (progressFor(access, current) > 0.0F) return null;
        Vec3d eye = client.player.getCameraPosVec(1.0F);
        TargetPoint currentPoint = targetPoint(client.world, current, eye);
        if (currentPoint == null) return null;
        double currentDistance = currentPoint.position.distanceTo(eye);
        double reach = reach(client, client.interactionManager);
        List<BlockPos> candidates = ParticleEsp.targetsForBreaker(client, freshAfterNanos);
        return candidates.stream()
                .filter(pos -> !pos.equals(current) && !tracker.isBlacklisted(pos))
                .map(pos -> new TargetDistance(pos, targetPoint(client.world, pos, eye)))
                .filter(entry -> entry.point != null && entry.point.position.distanceTo(eye) <= reach
                        && currentDistance - entry.point.position.distanceTo(eye) >= 1.0)
                .min(Comparator.comparingDouble(entry -> entry.point.position.squaredDistanceTo(eye)))
                .map(entry -> entry.pos.toImmutable()).orElse(null);
    }

    private static double reach(MinecraftClient client, ClientPlayerInteractionManager manager) {
        double value = manager.getReachDistance();
        return Double.isFinite(value) ? Math.max(0.0, Math.min(REACH_LIMIT, value)) : REACH_LIMIT;
    }

    private static TargetPoint targetPoint(World world, BlockPos pos, Vec3d eye) {
        if (!world.isChunkLoaded(pos)) return null;
        BlockState blockState = world.getBlockState(pos);
        if (blockState.isAir()) return null;
        Box local = blockState.getOutlineShape(world, pos).getBoundingBox();
        double minX = local.minX + pos.getX(), minY = local.minY + pos.getY(), minZ = local.minZ + pos.getZ();
        double maxX = local.maxX + pos.getX(), maxY = local.maxY + pos.getY(), maxZ = local.maxZ + pos.getZ();
        if (maxX <= minX || maxY <= minY || maxZ <= minZ) return null;
        double x = MathHelper.clamp(eye.x, minX, maxX);
        double y = MathHelper.clamp(eye.y, minY, maxY);
        double z = MathHelper.clamp(eye.z, minZ, maxZ);
        TargetPoint best = null;
        double bestDistance = Double.POSITIVE_INFINITY;
        TargetPoint[] faces = {
                new TargetPoint(new Vec3d(minX, y, z), Direction.WEST),
                new TargetPoint(new Vec3d(maxX, y, z), Direction.EAST),
                new TargetPoint(new Vec3d(x, minY, z), Direction.DOWN),
                new TargetPoint(new Vec3d(x, maxY, z), Direction.UP),
                new TargetPoint(new Vec3d(x, y, minZ), Direction.NORTH),
                new TargetPoint(new Vec3d(x, y, maxZ), Direction.SOUTH)
        };
        for (TargetPoint face : faces) {
            double distance = eye.squaredDistanceTo(face.position);
            if (distance < bestDistance) {
                best = face;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static float progressFor(ClientPlayerInteractionManagerAccessor access, BlockPos pos) {
        BlockPos current = access.zacktills$getCurrentBreakingPos();
        if (current == null || !current.equals(pos)) return 0.0F;
        float progress = access.zacktills$getCurrentBreakingProgress();
        return Float.isFinite(progress) ? MathHelper.clamp(progress, 0.0F, 1.0F) : 0.0F;
    }

    private static void aimAt(PlayerEntity player, Vec3d point) {
        long now = System.nanoTime();
        if (lastAimNanos == 0L) lastAimNanos = now;
        double dt = Math.max(0.0, Math.min(0.1, (now - lastAimNanos) / 1_000_000_000.0));
        lastAimNanos = now;
        Vec3d eye = player.getCameraPosVec(1.0F);
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float desiredYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float desiredPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        float yawDelta = MathHelper.wrapDegrees(desiredYaw - player.getYaw());
        float pitchDelta = MathHelper.wrapDegrees(desiredPitch - player.getPitch());
        double length = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
        double maxStep = Math.max(0.0, FeatureSettings.number("particle.break_speed")) * dt;
        if (length > maxStep && length > 0.0) {
            float scale = (float) (maxStep / length);
            yawDelta *= scale;
            pitchDelta *= scale;
        }
        player.setYaw(player.getYaw() + yawDelta);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchDelta, -90.0F, 90.0F));
    }

    private static void updateActionBar(MinecraftClient client, ParticleTracker tracker) {
        if (!FeatureSettings.boolValue("particle.debug", false) || client.player == null) return;
        String coordinates = "-,-,-";
        String blockId = "NO_TARGET";
        String distance = "-";
        float progress = 0.0F;
        if (target != null && client.world != null && client.player != null) {
            coordinates = target.getX() + "," + target.getY() + "," + target.getZ();
            blockId = Registries.BLOCK.getId(client.world.getBlockState(target).getBlock()).toString();
            Vec3d eye = client.player.getCameraPosVec(1.0F);
            TargetPoint point = targetPoint(client.world, target, eye);
            if (point != null) distance = String.format(Locale.ROOT, "%.2f", point.position.distanceTo(eye));
            if (client.interactionManager != null) {
                progress = progressFor((ClientPlayerInteractionManagerAccessor) client.interactionManager, target);
            }
        }
        String prefix = state.name() + " | " + coordinates + " | " + blockId + " | " + distance
                + " | " + String.format(Locale.ROOT, "%.0f%%", progress * 100.0F)
                + " | " + ticksInState + " | ";
        Text text = Text.literal(prefix);
        text.append(Text.literal(Integer.toString(attackCalls))
                .formatted(attackCalls > 1 ? Formatting.RED : Formatting.WHITE));
        text.append(Text.literal(" | " + Math.max(0, attackCalls - 1) + " | blacklisted:" + tracker.blacklistCount()));
        client.player.sendMessage(text, true);
    }

    private static void log(MinecraftClient client, String event, BlockPos pos) {
        if (client != null && client.player != null) {
            client.player.sendMessage(Text.literal("[Particle ESP] " + event + " at "
                    + pos.getX() + "," + pos.getY() + "," + pos.getZ()), false);
        }
    }

    private static void abandon(MinecraftClient client) {
        if (client != null && client.interactionManager != null) client.interactionManager.cancelBlockBreaking();
        abandonAfterCancel();
    }

    private static void abandonAfterCancel() {
        scheduleToolRestore();
        clearTarget();
        retryPending = false;
        enter(State.IDLE);
    }

    private static void scheduleToolRestore() {
        if (restoreSlot >= 0 && selectedByTool >= 0) restoreDelay = 2;
    }

    private static void serviceToolRestore(MinecraftClient client) {
        if (restoreDelay <= 0) return;
        restoreDelay--;
        if (restoreDelay != 0) return;
        if (client.player != null && restoreSlot >= 0 && selectedByTool >= 0
                && client.player.getInventory().selectedSlot == selectedByTool) {
            client.player.getInventory().selectedSlot = restoreSlot;
        }
        restoreSlot = -1;
        selectedByTool = -1;
    }

    private static void clearTarget() {
        target = null;
        originalState = null;
        attackIssued = false;
        verifyTicks = 0;
        breakTicks = 0;
        reachLossTicks = 0;
        lastProgress = 0.0F;
        lastAimNanos = 0L;
    }

    private static void enter(State next) {
        if (state != next) {
            state = next;
            ticksInState = 0;
        }
    }

    static void cancel(MinecraftClient client) {
        if (client != null && client.interactionManager != null) client.interactionManager.cancelBlockBreaking();
        if (state != State.IDLE || target != null) abandonAfterCancel();
        lastAimNanos = 0L;
    }

    static void reset(MinecraftClient client) {
        cancel(client);
        target = null;
        originalState = null;
        state = State.IDLE;
        ticksInState = 0;
        retryCount = 0;
        attackCalls = 0;
        retryPending = false;
        freshAfterNanos = 0L;
        restoreDelay = 0;
        restoreSlot = -1;
        selectedByTool = -1;
    }

    private record TargetPoint(Vec3d position, Direction face) { }
    private record TargetDistance(BlockPos pos, TargetPoint point) { }
}
