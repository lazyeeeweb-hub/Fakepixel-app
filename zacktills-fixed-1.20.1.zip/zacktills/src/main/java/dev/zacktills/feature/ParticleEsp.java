package dev.zacktills.feature;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Supplier;

/** Packet-expanded particle evidence, render overlay, and public root integration hooks. */
public final class ParticleEsp {
    private static final int MAX_SPAWNS_PER_PACKET = 256;
    private static final long DEBUG_INTERVAL_NS = 1_000_000_000L;
    private static final ParticleTracker TRACKER = new ParticleTracker();
    private static final List<Spawn> PACKET_SPAWNS = new ArrayList<>();
    private static final Map<String, Long> DEBUG_COUNTS = new TreeMap<>();
    private static ParticleS2CPacket activePacket;
    private static boolean captureSelected;
    private static boolean initialized;
    private static boolean previousDebug;
    private static long nextDebugAt;
    private static int debugCursor;
    private static net.minecraft.client.world.ClientWorld trackedWorld;
    private static boolean wasAlive;

    private ParticleEsp() { }

    /** Root calls once from client initialization. */
    public static void initialize() {
        if (initialized) return;
        initialized = true;
        // Never carry an armed breaker across client startup / a saved configuration load.
        FeatureSettings.setBool("particle.auto_break", false);
        FeatureSettings.save();
        WorldRenderEvents.LAST.register(ParticleEsp::render);
    }

    /** Root calls once per END_CLIENT_TICK. */
    public static void tick(MinecraftClient client) {
        if (client == null) return;
        if (client.world != trackedWorld) {
            if (trackedWorld != null) resetSession(client);
            trackedWorld = client.world;
            wasAlive = client.player != null && !client.player.isDead();
        }
        PlayerEntity player = client.player;
        if (client.world == null || player == null) {
            ParticleBreaker.cancel(client);
            return;
        }
        if (player.isDead()) {
            if (wasAlive) resetSession(client);
            wasAlive = false;
            ParticleBreaker.cancel(client);
            return;
        }
        wasAlive = true;
        TRACKER.beginTick();
        updateDebug(client);
        boolean active = FeatureSettings.on("particle.enabled") || FeatureSettings.boolValue("particle.auto_break", false);
        List<BlockPos> targets = active
                ? TRACKER.findTargets(client.world, player, (int) FeatureSettings.number("particle.min_count"),
                    (int) FeatureSettings.number("particle.max_targets"), windowSeconds(), ParticleBreaker.freshAfterNanos())
                : List.of();
        ParticleBreaker.tick(client, targets, TRACKER);
    }

    /** Current target candidates, using the same freshness gate as the END_CLIENT_TICK pass. */
    static List<BlockPos> targetsForBreaker(MinecraftClient client, long freshAfterNanos) {
        if (client == null || client.world == null || client.player == null) return List.of();
        return TRACKER.findTargets(client.world, client.player,
                (int) FeatureSettings.number("particle.min_count"),
                (int) FeatureSettings.number("particle.max_targets"), windowSeconds(), freshAfterNanos);
    }

    /** Reset transient evidence/debug state; root may call this on disconnect or session changes. */
    public static void reset() {
        resetSession(MinecraftClient.getInstance());
        trackedWorld = MinecraftClient.getInstance().world;
        PlayerEntity player = MinecraftClient.getInstance().player;
        wasAlive = player != null && !player.isDead();
    }

    /** Root binds this to R; the option itself is off by default and saved with other settings. */
    public static void toggleAutoBreak() {
        boolean enabled = !FeatureSettings.boolValue("particle.auto_break", false);
        FeatureSettings.setBool("particle.auto_break", enabled);
        FeatureSettings.save();
        MinecraftClient client = MinecraftClient.getInstance();
        if (!enabled) ParticleBreaker.cancel(client);
        if (client.player != null) {
            client.player.sendMessage(net.minecraft.text.Text.literal(
                    enabled ? "[Particle ESP] Auto-break armed." : "[Particle ESP] Auto-break disarmed."), false);
        }
    }

    /** Called by the mixin after forceMainThread and before vanilla expands the packet. */
    public static void beginPacketCapture(ParticleS2CPacket packet) {
        activePacket = packet;
        PACKET_SPAWNS.clear();
        Identifier id = particleId(packet.getParameters());
        captureSelected = isSelected(id) && (FeatureSettings.on("particle.enabled")
                || FeatureSettings.boolValue("particle.auto_break", false));
    }

    /** Mixin @ModifyArgs observer. The coordinates are passed through unchanged to vanilla. */
    public static void observeVanillaParticle(double x, double y, double z) {
        if (activePacket == null || !captureSelected || PACKET_SPAWNS.size() >= MAX_SPAWNS_PER_PACKET
                || !Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) return;
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (player == null || player.squaredDistanceTo(x, y, z) > ParticleTracker.MAX_RADIUS_SQUARED) return;
        PACKET_SPAWNS.add(new Spawn(x, y, z));
    }

    /** Mixin calls this at handler TAIL on the main thread. */
    public static void onParticle(ParticleS2CPacket packet) {
        if (FeatureSettings.on("particle.debug")) {
            String id = particleId(packet.getParameters()).toString();
            DEBUG_COUNTS.merge(id, (long) Math.max(1, packet.getCount()), Long::sum);
        }
        if (activePacket == packet) {
            if (captureSelected) {
                Identifier id = particleId(packet.getParameters());
                long now = System.nanoTime();
                for (Spawn spawn : PACKET_SPAWNS) TRACKER.add(id, spawn.x, spawn.y, spawn.z, now);
            }
            PACKET_SPAWNS.clear();
            activePacket = null;
            captureSelected = false;
        }
    }

    private static Identifier particleId(ParticleEffect effect) {
        Identifier id = Registries.PARTICLE_TYPE.getId(effect.getType());
        return id == null ? new Identifier("minecraft", "unknown") : id;
    }

    private static Set<Identifier> selectedTypes() {
        Set<Identifier> selected = new HashSet<>();
        String value = FeatureSettings.text("particle.types");
        for (String token : value.split(",")) {
            Identifier id = Identifier.tryParse(token.trim());
            if (id != null) selected.add(id);
        }
        return selected;
    }

    private static boolean isSelected(Identifier id) { return selectedTypes().contains(id); }

    private static double windowSeconds() {
        return Math.max(.1, Math.min(5.0, FeatureSettings.number("particle.window")));
    }

    private static void updateDebug(MinecraftClient client) {
        boolean enabled = FeatureSettings.on("particle.debug");
        if (!enabled) {
            previousDebug = false;
            return;
        }
        if (!previousDebug) {
            DEBUG_COUNTS.clear();
            debugCursor = 0;
            nextDebugAt = 0;
        }
        previousDebug = true;
        long now = System.nanoTime();
        if (client.player == null || now < nextDebugAt || DEBUG_COUNTS.isEmpty()) return;
        List<Map.Entry<String, Long>> entries = new ArrayList<>(DEBUG_COUNTS.entrySet());
        if (debugCursor >= entries.size()) debugCursor = 0;
        Map.Entry<String, Long> entry = entries.get(debugCursor++);
        client.player.sendMessage(net.minecraft.text.Text.literal(
                "[Particle ESP DEBUG] " + entry.getKey() + " = " + entry.getValue()), false);
        nextDebugAt = now + DEBUG_INTERVAL_NS;
    }

    private static void resetSession(MinecraftClient client) {
        TRACKER.reset();
        DEBUG_COUNTS.clear();
        PACKET_SPAWNS.clear();
        activePacket = null;
        captureSelected = false;
        debugCursor = 0;
        nextDebugAt = 0;
        previousDebug = false;
        // reset() is also used by root on JOIN/DISCONNECT; don't persist an armed state across servers.
        FeatureSettings.setBool("particle.auto_break", false);
        FeatureSettings.save();
        ParticleBreaker.reset(client);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!FeatureSettings.on("particle.enabled") || client.world == null || client.player == null) return;
        List<BlockPos> targets = TRACKER.findTargets(client.world, client.player,
                (int) FeatureSettings.number("particle.min_count"),
                (int) FeatureSettings.number("particle.max_targets"), windowSeconds());
        if (targets.isEmpty()) return;

        int rgb = parseColor(FeatureSettings.text("particle.color"));
        Camera camera = context.camera();
        Vec3d cameraPos = camera.getPos();
        MatrixStack matrices = context.matrixStack();
        matrices.push();
        matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        net.minecraft.client.gl.ShaderProgram oldShader = RenderSystem.getShader();
        float[] oldColor = RenderSystem.getShaderColor().clone();
        float oldLineWidth = RenderSystem.getShaderLineWidth();
        boolean oldDepth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean oldCull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        boolean oldBlend = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean oldDepthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int srcRgb = GL11.glGetInteger(GL11.GL_BLEND_SRC);
        int dstRgb = GL11.glGetInteger(GL11.GL_BLEND_DST);
        int srcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        int dstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        try {
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.lineWidth(2.0F);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            RenderSystem.setShaderColor(1, 1, 1, 1);
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            BufferBuilder buffer = new BufferBuilder(2048);
            buffer.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (BlockPos pos : targets) {
                addBlockOutline(buffer, matrix, pos, rgb);
                if (FeatureSettings.on("particle.tracer")) {
                    Vec3d center = Vec3d.ofCenter(pos);
                    line(buffer, matrix, cameraPos.x, cameraPos.y, cameraPos.z,
                            center.x, center.y, center.z, rgb);
                }
            }
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        } finally {
            RenderSystem.depthMask(oldDepthMask);
            if (oldDepth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
            if (oldCull) RenderSystem.enableCull(); else RenderSystem.disableCull();
            if (oldBlend) RenderSystem.enableBlend(); else RenderSystem.disableBlend();
            RenderSystem.blendFuncSeparate(srcRgb, dstRgb, srcAlpha, dstAlpha);
            RenderSystem.lineWidth(oldLineWidth);
            RenderSystem.setShaderColor(oldColor[0], oldColor[1], oldColor[2], oldColor[3]);
            if (oldShader != null) RenderSystem.setShader(() -> oldShader);
            matrices.pop();
        }
        if (FeatureSettings.on("particle.distance")) drawDistanceLabels(context, targets, rgb);
    }

    private static void addBlockOutline(BufferBuilder buffer, Matrix4f matrix, BlockPos pos, int rgb) {
        float x0 = pos.getX() - .002F, y0 = pos.getY() - .002F, z0 = pos.getZ() - .002F;
        float x1 = pos.getX() + 1.002F, y1 = pos.getY() + 1.002F, z1 = pos.getZ() + 1.002F;
        float[][] p = {
                {x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1},
                {x0,y1,z0},{x1,y1,z0},{x1,y1,z1},{x0,y1,z1}
        };
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] edge : edges) {
            float[] a = p[edge[0]], b = p[edge[1]];
            line(buffer, matrix, a[0],a[1],a[2], b[0],b[1],b[2], rgb);
        }
    }

    private static void line(BufferBuilder buffer, Matrix4f matrix,
                            double x0,double y0,double z0,double x1,double y1,double z1,int rgb) {
        int r=(rgb>>16)&255, g=(rgb>>8)&255, b=rgb&255;
        buffer.vertex(matrix,(float)x0,(float)y0,(float)z0).color(r,g,b,255).next();
        buffer.vertex(matrix,(float)x1,(float)y1,(float)z1).color(r,g,b,255).next();
    }

    private static int parseColor(String value) {
        try {
            String hex = value == null ? "" : value.trim().replace("#", "");
            return hex.length() == 6 ? Integer.parseInt(hex, 16) : 0x00FFFF;
        } catch (RuntimeException ignored) { return 0x00FFFF; }
    }

    private static void drawDistanceLabels(WorldRenderContext context, List<BlockPos> targets, int rgb) {
        MinecraftClient client = MinecraftClient.getInstance();
        Camera camera = context.camera();
        Vec3d cameraPos = camera.getPos();
        BufferBuilder textBuffer = new BufferBuilder(256);
        VertexConsumerProvider.Immediate immediate = VertexConsumerProvider.immediate(textBuffer);
        for (BlockPos pos : targets) {
            Vec3d center = Vec3d.ofCenter(pos);
            double distance = cameraPos.distanceTo(center);
            String label = String.format(Locale.ROOT, "%.1fm", distance);
            MatrixStack matrices = new MatrixStack();
            matrices.translate(center.x-cameraPos.x, center.y-cameraPos.y, center.z-cameraPos.z);
            matrices.multiply(camera.getRotation());
            matrices.scale(-.025F,-.025F,.025F);
            matrices.translate(0, -10, 0);
            int color = 0xFF000000 | (rgb & 0xFFFFFF);
            client.textRenderer.draw(label, -client.textRenderer.getWidth(label)/2.0F, 0,
                    color, false, matrices.peek().getPositionMatrix(), immediate,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0, LightmapTextureManager.MAX_LIGHT_COORDINATE);
        }
        immediate.draw();
    }

    private record Spawn(double x, double y, double z) { }
}
