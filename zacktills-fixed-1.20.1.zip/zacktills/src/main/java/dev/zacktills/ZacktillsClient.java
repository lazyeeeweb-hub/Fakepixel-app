package dev.zacktills;

import dev.zacktills.config.ConfigStore;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.AutoLogin;
import dev.zacktills.feature.ItemFeatures;
import dev.zacktills.feature.MenuFeatures;
import dev.zacktills.feature.ParticleEsp;
import dev.zacktills.feature.WallFade;
import dev.zacktills.ui.ConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.LoggerFactory;

public final class ZacktillsClient implements ClientModInitializer {
    public static final String MOD_ID = "zacktills";
    public static KeyBinding lock, copy;

    public static Screen config(Screen parent) {
        return new ConfigScreen(parent, FeatureSettings.CATEGORIES, FeatureSettings.STORE);
    }

    @Override
    public void onInitializeClient() {
        FeatureSettings.STORE = new ConfigStore(FeatureSettings.CATEGORIES);
        FeatureSettings.STORE.load();
        KeyBinding open = key("open_config", GLFW.GLFW_KEY_RIGHT_SHIFT);
        KeyBinding autoBreak = key("auto_break", GLFW.GLFW_KEY_R);
        lock = key("lock_slot", GLFW.GLFW_KEY_L);
        copy = key("copy_nbt", GLFW.GLFW_KEY_C);
        ScreenEvents.AFTER_INIT.register(MenuFeatures::initialize);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) AutoLogin.message(message.getString());
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            AutoLogin.reset();
            ParticleEsp.reset();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            AutoLogin.disconnect();
            ItemFeatures.clearHovered();
            ParticleEsp.reset();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(config(null));
            }
            while (autoBreak.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    ParticleEsp.toggleAutoBreak();
                }
            }
            AutoLogin.tick();
            WallFade.tick();
            ParticleEsp.tick(client);
        });
        WallFade.initialize();
        ParticleEsp.initialize();
    }

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zacktills." + name, InputUtil.Type.KEYSYM, code, "category.zacktills"));
    }

    public static void notifyError(String message) {
        LoggerFactory.getLogger(MOD_ID).error(message);
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal("[Zacktills] " + message), false);
        }
    }
}
