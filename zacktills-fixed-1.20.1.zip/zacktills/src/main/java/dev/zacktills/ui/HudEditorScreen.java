package dev.zacktills.ui;

import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.HudFeatures;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** Normalized coordinates remain shared with the real HUD renderers. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private final String id;
    private final int elementW, elementH;
    private final Button minus, plus, reset, back;
    private Rect toolbar;
    private Widget focus, capture;
    private boolean dragging;
    private double offsetX, offsetY;

    public HudEditorScreen(Screen parent, String id) {
        super(Text.literal("Position: " + id));
        this.parent = parent; this.id = id;
        elementW = id.equals("hotbar") ? 182 : id.equals("offhand") ? 22 : id.equals("copy") ? 80 : 150;
        elementH = id.equals("scoreboard") ? 110 : id.equals("copy") ? 20 : 22;
        minus = new Button("-", () -> resize(-.05));
        plus = new Button("+", () -> resize(.05));
        reset = new Button("Reset", () -> {
            FeatureSettings.pos(id, "x", .5); FeatureSettings.pos(id, "y", .5); FeatureSettings.pos(id, "scale", 1);
        });
        back = new Button("Save / Back", this::close); back.primary = true;
    }
    @Override protected void init() {
        dragging = false;
        if (capture != null) capture.cancel();
        capture = null;
        Rect screen = inset(new Rect(0, 0, width, height), 8);
        toolbar = region(screen, 0, 0, Math.min(360, screen.w()), 64);
        Rect row = region(toolbar, 8, 32, toolbar.w() - 16, 24);
        int gap = Math.min(8, row.w() / 6), available = Math.max(0, row.w() - gap * 3);
        int a = available * 24 / 196, b = available * 24 / 196, d = available * 56 / 196;
        minus.bounds(region(row, 0, 0, a, 24));
        plus.bounds(region(row, a + gap, 0, b, 24));
        reset.bounds(region(row, a + b + gap * 2, 0, d, 24));
        back.bounds(region(row, a + b + d + gap * 3, 0, available - a - b - d, 24));
    }
    private void resize(double delta) { FeatureSettings.pos(id, "scale", FeatureSettings.pos(id, "scale") + delta); }
    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        Rect screen = new Rect(0, 0, width, height);
        drawBackdrop(c, width, height);
        drawGrid(c, screen);
        clip(c, screen);
        if (id.equals("hotbar") || id.equals("offhand")) {
            if (client != null && client.player != null) HudFeatures.hotbar(c);
            else preview(c);
        } else preview(c);
        unclip(c);
        drawPanel(c, toolbar, title.getString());
        clip(c, toolbar);
        for (Widget widget : List.of(minus, plus, reset, back)) widget.render(c, mx, my);
        unclip(c);
        if (height > 104) {
            Rect hint = new Rect(8, Math.max(0, height - 24), Math.max(0, width - 16), 16);
            drawPlaceholder(c, hint);
            centered(c, "Drag to move | +/- or wheel: scale | Arrows: move | Esc: save", hint, MUTED);
        }
    }
    private void preview(DrawContext c) {
        HudFeatures.begin(c, id, elementW, elementH);
        Rect r = new Rect(0, 0, elementW, elementH);
        rounded(c, r, 5, INSET);
        text(c, id.equals("copy") ? "Copy NBT" : id.equals("scoreboard") ? "Scoreboard preview" : id,
                6, 6, elementW - 12, TEXT);
        if (id.equals("scoreboard")) {
            for (int i = 0; i < 8; i++) text(c, "Player / information " + (i + 1), 6, 22 + i * 10, elementW - 12, MUTED);
        }
        c.getMatrices().pop();
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        dragging = false;
        if (capture != null) capture.cancel();
        capture = null;
        for (Widget widget : List.of(minus, plus, reset, back)) {
            if (widget.down(mx, my)) { capture = widget; setFocus(widget); return true; }
        }
        setFocus(null);
        if (toolbar.contains(mx, my)) return true;
        double[] r = HudFeatures.bounds(id, elementW, elementH);
        if (mx >= r[0] && my >= r[1] && mx < r[0] + r[2] && my < r[1] + r[3]) {
            dragging = true; offsetX = mx - r[0]; offsetY = my - r[1]; return true;
        }
        return false;
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0) return false;
        if (capture != null) { capture.drag(mx, my); return true; }
        if (!dragging) return false;
        double scale = FeatureSettings.pos(id, "scale");
        FeatureSettings.pos(id, "x", (mx - offsetX) / Math.max(1, width - elementW * scale));
        FeatureSettings.pos(id, "y", (my - offsetY) / Math.max(1, height - elementH * scale));
        return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0) return false;
        if (capture != null) {
            Widget target = capture; capture = null; target.up(mx, my); return true;
        }
        boolean wasDragging = dragging; dragging = false; return wasDragging;
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) { resize(Math.signum(amount) * .05); return true; }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = List.of(minus, plus, reset, back);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1, current = controls.indexOf(focus);
            setFocus(controls.get(current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size())));
            return true;
        }
        if (key == GLFW.GLFW_KEY_EQUAL || key == GLFW.GLFW_KEY_KP_ADD) { resize(.05); return true; }
        if (key == GLFW.GLFW_KEY_MINUS || key == GLFW.GLFW_KEY_KP_SUBTRACT) { resize(-.05); return true; }
        if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
            String axis = key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT ? "x" : "y";
            double step = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? .1 : .01;
            FeatureSettings.pos(id, axis, FeatureSettings.pos(id, axis)
                    + (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_UP ? -step : step));
            return true;
        }
        return focus != null && focus.key(key, modifiers) || super.keyPressed(key, scan, modifiers);
    }
    @Override public void close() { FeatureSettings.save(); if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        dragging = false; if (capture != null) capture.cancel(); capture = null; super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
