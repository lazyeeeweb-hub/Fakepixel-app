package dev.zacktills.ui;

import dev.zacktills.config.ConfigModel;
import dev.zacktills.config.ConfigStore;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class ConfigScreen extends Screen {
    private final Screen parent;
    private final List<ConfigModel.Category> categories;
    private final ConfigStore store;
    private final CategoryList categoryList = new CategoryList();
    private final ScrollList optionList = new ScrollList();
    private final TextField search;
    private final Button closeButton;
    private Rect panel, heading;
    private Widget focus, capture;
    private Dropdown openDropdown;
    private ScrollList popup;
    private int selected, popupIndex;
    private boolean dirty = true;

    public ConfigScreen(Screen parent, List<ConfigModel.Category> categories, ConfigStore store) {
        super(Text.literal("Zacktills settings"));
        if (categories.isEmpty()) throw new IllegalArgumentException("At least one category required");
        this.parent = parent;
        this.categories = categories;
        this.store = store;
        search = new TextField("", value -> { optionList.scroll = 0; dirty = true; });
        search.placeholder = "Search settings";
        closeButton = new Button("X", this::close) {
            @Override public void render(DrawContext c, int mx, int my) { drawClose(c, bounds, state(mx, my)); }
        };
    }

    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        closePopup();
        panel = panelBounds(width, height, 296, 180, 900, 560);
        closeButton.bounds(region(panel, Math.max(0, panel.w() - 32), 4, 24, 24));
        Rect body = region(panel, 8, 40, panel.w() - 16, panel.h() - 48);
        int gap = Math.min(8, body.w());
        int sideW = Math.min(body.w() * 2 / 5, Math.max(72, body.w() / 4));
        Rect side = region(body, 0, 0, sideW, body.h());
        Rect right = region(body, sideW + gap, 0, body.w() - sideW - gap, body.h());
        categoryList.bounds(region(side, 0, 32, side.w(), side.h() - 32));
        heading = region(right, 0, 0, right.w(), 24);
        int searchW = right.w() < 200 ? right.w() : Math.min(180, right.w() / 2);
        search.bounds(region(heading, right.w() - searchW, 0, searchW, 24));
        optionList.bounds(region(right, 0, 32, right.w(), right.h() - 32));
        dirty = true;
        rebuild();
    }

    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    private void rebuild() {
        if (!dirty) return;
        dirty = false;
        closePopup();
        categoryList.categories(categories, selected, index -> {
            if (selected != index) {
                selected = index;
                optionList.scroll = 0;
                dirty = true;
            }
        });
        List<Widget> rows = new ArrayList<>();
        String query = search.value.toLowerCase(Locale.ROOT).trim();
        append(rows, categories.get(selected).options, query, 0, true);
        optionList.setItems(rows);
        if (focus != search && focus != closeButton) setFocus(null);
    }
    private boolean matches(ConfigModel.Option<?> option, String query) {
        if (query.isEmpty() || (option.label + " " + option.description).toLowerCase(Locale.ROOT).contains(query)) return true;
        if (option instanceof ConfigModel.Folder folder) {
            for (ConfigModel.Option<?> child : folder.children) if (matches(child, query)) return true;
        }
        return false;
    }
    private void append(List<Widget> rows, List<ConfigModel.Option<?>> options, String query, int depth, boolean parentEnabled) {
        for (ConfigModel.Option<?> option : options) {
            if (!matches(option, query)) continue;
            OptionRow row = new OptionRow(option, depth, this::openPopup, () -> dirty = true);
            row.enabled = parentEnabled && option.enabled;
            if (row.control != null) row.control.enabled = row.enabled;
            rows.add(row);
            if (option instanceof ConfigModel.Folder folder && (folder.expanded || !query.isEmpty())) {
                append(rows, folder.children, query, depth + 1, row.enabled);
            }
        }
    }
    private void openPopup(Dropdown dropdown) {
        closePopup();
        openDropdown = dropdown;
        popup = new ScrollList();
        List<Widget> choices = new ArrayList<>();
        for (String choice : dropdown.option.choices) {
            Button button = new Button(choice, () -> { dropdown.option.value = choice; closePopup(); });
            button.selected = choice.equals(dropdown.option.value);
            choices.add(button);
        }
        popup.setItems(choices);
        Rect anchor = dropdown.bounds, area = inset(panel, 8);
        int w = Math.min(Math.max(100, anchor.w() + 28), area.w());
        int h = Math.min(Math.max(0, choices.size() * 32 + 8), Math.min(area.h(), Math.max(48, area.h() / 2)));
        int x = clamp(anchor.x(), area.x(), area.x() + area.w() - w);
        int y = anchor.y() + anchor.h() + 8;
        if (y + h > area.y() + area.h()) y = anchor.y() - h - 8;
        y = clamp(y, area.y(), area.y() + area.h() - h);
        popup.bounds(new Rect(x, y, w, h));
        popupIndex = Math.max(0, dropdown.option.choices.indexOf(dropdown.option.value));
        setFocus(popup.items.get(popupIndex));
        popup.reveal(focus);
    }
    private void closePopup() {
        if (popup != null) {
            popup.cancel();
            if (focus != null && popup.items.contains(focus)) setFocus(openDropdown);
        }
        popup = null;
        openDropdown = null;
    }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        rebuild();
        drawBackdrop(c, width, height);
        drawPanel(c, panel, getTitle().getString());
        clip(c, panel);
        closeButton.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        Rect categoryHeading = region(panel, 8, 40, categoryList.bounds.w(), 24);
        if (categoryHeading.h() >= 9) text(c, "Categories", categoryHeading.x() + 8, categoryHeading.y() + 8,
                categoryHeading.w() - 16, MUTED);
        if (heading.h() >= 9) text(c, categories.get(selected).label, heading.x() + 8, heading.y() + 8,
                Math.max(0, heading.w() - search.bounds.w() - 16), TEXT);
        search.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        categoryList.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        optionList.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        if (optionList.items.isEmpty()) {
            clip(c, optionList.bounds);
            text(c, "No matching options", optionList.bounds.x() + 8, optionList.bounds.y() + 8,
                    optionList.bounds.w() - 16, MUTED);
            unclip(c);
        }
        if (popup != null) {
            drawPlaceholder(c, popup.bounds);
            popup.render(c, mx, my);
        } else if (capture == null && optionList.bounds.contains(mx, my)) {
            for (Widget item : optionList.items) {
                if (item instanceof OptionRow row && row.bounds.contains(mx, my)
                        && mx < row.controlX() && (row.bounds.w() >= 260 || my < row.bounds.y() + 24)) {
                    String hint = row.option.label;
                    if (!row.option.description.equals(hint)) hint += " - " + row.option.description;
                    drawHint(c, inset(panel, 8), hint, mx, my);
                    break;
                }
            }
        }
        unclip(c);
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        rebuild();
        if (capture != null) capture.cancel();
        capture = null;
        if (popup != null) {
            if (popup.bounds.contains(mx, my)) {
                setFocus(popup.focusAt(mx, my));
                int pointerIndex = popup.items.indexOf(focus);
                if (pointerIndex >= 0) popupIndex = pointerIndex;
                if (popup.down(mx, my)) capture = popup;
            } else closePopup();
            return true;
        }
        Widget target = closeButton.bounds.contains(mx, my) ? closeButton
                : search.bounds.contains(mx, my) ? search
                : categoryList.bounds.contains(mx, my) ? categoryList
                : optionList.bounds.contains(mx, my) ? optionList : null;
        setFocus(target == null ? null : target.focusAt(mx, my));
        if (target != null && target.down(mx, my)) { capture = target; return true; }
        return panel.contains(mx, my);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && capture != null) { capture.drag(mx, my); return true; }
        return false;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(mx, my);
        rebuild();
        return true;
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        if (popup != null) return popup.wheel(mx, my, amount) || panel.contains(mx, my);
        return categoryList.wheel(mx, my, amount) || optionList.wheel(mx, my, amount);
    }
    @Override public boolean charTyped(char chr, int modifiers) {
        if (focus != null && focus.character(chr)) { rebuild(); return true; }
        return false;
    }
    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        rebuild();
        if (popup != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { closePopup(); return true; }
            if (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
                popupIndex = Math.floorMod(popupIndex + (key == GLFW.GLFW_KEY_UP ? -1 : 1), popup.items.size());
                setFocus(popup.items.get(popupIndex));
                popup.reveal(focus);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) {
                Widget target = popup.items.get(popupIndex);
                target.key(GLFW.GLFW_KEY_ENTER, modifiers);
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = new ArrayList<>();
            controls.add(search);
            controls.addAll(categoryList.focusables());
            controls.addAll(optionList.focusables());
            controls.add(closeButton);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            int next = current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size());
            setFocus(controls.get(next));
            categoryList.reveal(focus);
            optionList.reveal(focus);
            return true;
        }
        if (focus != null && focus.key(key, modifiers)) { rebuild(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN) {
            optionList.page(key == GLFW.GLFW_KEY_PAGE_UP ? -1 : 1);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }
    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        if (capture != null) capture.cancel();
        closePopup();
        if (!store.save() && client != null && client.player != null) {
            client.player.sendMessage(Text.literal("Zacktills: config save failed; see the log."), false);
        }
        super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
