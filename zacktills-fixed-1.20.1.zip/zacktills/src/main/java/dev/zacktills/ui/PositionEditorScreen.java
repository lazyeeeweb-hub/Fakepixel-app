package dev.zacktills.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class PositionEditorScreen extends Screen {
    private final Screen parent;
    private final Button minus, plus, back;
    private Rect panel, canvas, preview;
    private double normalizedX = 0.5, normalizedY = 0.5, scale = 1;
    private double offsetX, offsetY;
    private boolean dragging;
    private Widget capture, focus;

    public PositionEditorScreen(Screen parent) {
        super(Text.literal("Button position editor - preview"));
        this.parent = parent;
        minus = new Button("-", () -> resizePreview(-0.1));
        plus = new Button("+", () -> resizePreview(0.1));
        back = new Button("Back", this::close);
        back.primary = true;
    }
    @Override protected void init() {
        dragging = false;
        if (capture != null) capture.cancel();
        capture = null;
        panel = panelBounds(width, height, 240, 150, 900, 560);
        canvas = region(panel, 8, 64, panel.w() - 16, panel.h() - 112);
        Rect row = region(panel, 8, Math.max(32, panel.h() - 40), panel.w() - 16, 24);
        int gap = Math.min(8, row.w() / 6), available = Math.max(0, row.w() - gap * 2);
        int small = Math.min(24, available / 4), backW = Math.min(72, Math.max(0, available - small * 2));
        minus.bounds(region(row, 0, 0, small, 24));
        plus.bounds(region(row, small + gap, 0, small, 24));
        back.bounds(region(row, row.w() - backW, 0, backW, 24));
        updatePreview();
    }
    private void resizePreview(double change) {
        scale = Math.max(0.5, Math.min(3, scale + change));
        updatePreview();
    }
    private void updatePreview() {
        int w = Math.min(canvas.w(), Math.max(20, (int) (80 * scale)));
        int h = Math.min(canvas.h(), Math.max(12, (int) (18 * scale)));
        int x = canvas.x() + (int) Math.round(normalizedX * Math.max(0, canvas.w() - w));
        int y = canvas.y() + (int) Math.round(normalizedY * Math.max(0, canvas.h() - h));
        preview = new Rect(x, y, w, h);
    }
    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        drawBackdrop(c, width, height);
        drawPanel(c, panel, getTitle().getString());
        clip(c, panel);
        Rect help = region(panel, 8, 40, panel.w() - 16, 16);
        clip(c, help);
        text(c, "Drag to move | +/- or wheel: size | Preview only", help.x(), help.y(), help.w(), MUTED);
        unclip(c);
        drawGrid(c, canvas);
        clip(c, canvas);
        drawButton(c, preview, "Copy NBT", dragging ? State.PRESSED : preview.contains(mx, my) ? State.HOVER : State.NORMAL, false);
        unclip(c);
        minus.render(c, mx, my);
        plus.render(c, mx, my);
        back.render(c, mx, my);
        text(c, Math.round(scale * 100) + "%", plus.bounds.x() + plus.bounds.w() + 5,
                plus.bounds.y() + 8, Math.max(0, back.bounds.x() - plus.bounds.x() - plus.bounds.w() - 10), TEXT);
        unclip(c);
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (capture != null) capture.cancel();
        capture = null;
        for (Widget widget : List.of(minus, plus, back)) {
            if (widget.down(mx, my)) { capture = widget; setFocus(widget); return true; }
        }
        setFocus(null);
        if (preview.contains(mx, my)) {
            dragging = true;
            offsetX = mx - preview.x();
            offsetY = my - preview.y();
            return true;
        }
        return panel.contains(mx, my);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0) return false;
        if (dragging) {
            normalizedX = Math.max(0, Math.min(1, (mx - offsetX - canvas.x()) / Math.max(1, canvas.w() - preview.w())));
            normalizedY = Math.max(0, Math.min(1, (my - offsetY - canvas.y()) / Math.max(1, canvas.h() - preview.h())));
            updatePreview();
            return true;
        }
        return capture != null;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0) return false;
        if (dragging) { dragging = false; return true; }
        if (capture != null) {
            Widget target = capture;
            capture = null;
            target.up(mx, my);
            return true;
        }
        return false;
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        if (!canvas.contains(mx, my)) return false;
        resizePreview(Math.signum(amount) * .1); return true;
    }
    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = List.of(minus, plus, back);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            int next = current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size());
            setFocus(controls.get(next));
            return true;
        }
        if (key == GLFW.GLFW_KEY_EQUAL || key == GLFW.GLFW_KEY_KP_ADD) { resizePreview(0.1); return true; }
        if (key == GLFW.GLFW_KEY_MINUS || key == GLFW.GLFW_KEY_KP_SUBTRACT) { resizePreview(-0.1); return true; }
        return focus != null && focus.key(key, modifiers) || super.keyPressed(key, scanCode, modifiers);
    }
    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        dragging = false;
        if (capture != null) capture.cancel();
        super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
