package dev.zacktills.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.Button;

/** Small tap keyboard that does not depend on native launcher text input. */
public final class TouchInputScreen extends Screen {
    private final Screen parent;
    private final boolean digits;
    private final Consumer<String> done;
    private final List<Button> keys = new ArrayList<>();
    private final StringBuilder value;
    private boolean symbols;
    private Rect panel, preview;
    private Button pressed;

    public TouchInputScreen(Screen parent, String title, String initial, boolean digits, Consumer<String> done) {
        super(Text.literal(title));
        this.parent = parent;
        this.digits = digits;
        this.done = done;
        value = new StringBuilder(initial);
    }

    @Override protected void init() {
        pressed = null;
        keys.clear();
        int w = Math.max(1, Math.min(width - 12, digits ? 230 : 368));
        int step = Math.min(28, Math.max(12, (height - 63) / 5));
        int h = 57 + 5 * step;
        panel = new Rect((width - w) / 2, Math.max(0, (height - h) / 2), w, h);
        preview = region(panel, 6, 33, w - 12, 19);
        String[] rows = digits ? new String[]{"123", "456", "789", "0"}
                : symbols ? new String[]{"1234567890", "[]{}()<>!?", "-_.:+/=#@%", "&*;,~\\^|'\""}
                : new String[]{"qwertyuiop", "asdfghjkl", "zxcvbnm", "[]/:-_"};
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r];
            for (int j = 0; j < row.length(); j++) {
                char ch = row.charAt(j);
                button(String.valueOf(ch), () -> add(ch), r, j, row.length(), step);
            }
        }
        if (digits) {
            button("Clear", () -> value.setLength(0), 4, 0, 4, step);
            button("Erase", this::erase, 4, 1, 4, step);
            button("Cancel", this::close, 4, 2, 4, step);
            button("Done", this::apply, 4, 3, 4, step);
        } else {
            button(symbols ? "ABC" : "123", () -> { symbols = !symbols; init(); }, 4, 0, 6, step);
            button("Space", () -> add(' '), 4, 1, 6, step);
            button("Erase", this::erase, 4, 2, 6, step);
            button("Clear", () -> value.setLength(0), 4, 3, 6, step);
            button("Cancel", this::close, 4, 4, 6, step);
            button("Done", this::apply, 4, 5, 6, step);
        }
    }

    private void button(String title, Runnable action, int row, int col, int columns, int step) {
        int room = panel.w() - 12;
        int offset = room * col / columns;
        Button b = new Button(title, action);
        b.primary = title.equals("Done");
        b.bounds(region(panel, 6 + offset, 55 + step * row, room * (col + 1) / columns - offset - 2, step - 3));
        keys.add(b);
    }

    private void add(char c) { if (value.length() < (digits ? 9 : 256)) value.append(c); }
    private void erase() { if (!value.isEmpty()) value.setLength(value.offsetByCodePoints(value.length(), -1)); }
    private void apply() {
        done.accept(value.toString());
        if (client != null && client.currentScreen == this) close();
    }

    @Override public void render(DrawContext context, int mx, int my, float delta) {
        drawBackdrop(context, width, height);
        drawPanel(context, panel, title.getString());
        clip(context, panel);
        drawPlaceholder(context, preview);
        String end = trimFitBackwards(value.toString(), Math.max(0, preview.w() - 12));
        text(context, end, preview.x() + 6, preview.y() + 5, preview.w() - 12, TEXT);
        for (Button key : keys) key.render(context, mx, my);
        unclip(context);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (pressed != null) pressed.cancel();
        pressed = null;
        for (Button key : keys) if (key.down(mx, my)) { pressed = key; return true; }
        return false;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || pressed == null) return false;
        Button key = pressed;
        pressed = null;
        key.up(mx, my);
        return true;
    }
    @Override public boolean charTyped(char chr, int modifiers) {
        if (Character.isISOControl(chr) || digits && (chr < '0' || chr > '9')) return false;
        add(chr);
        return true;
    }
    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_BACKSPACE) { erase(); return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { apply(); return true; }
        return super.keyPressed(key, scanCode, modifiers);
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
