# CombatAssist

Client-only Fabric mod for Minecraft **1.20.1**. Build with **JDK 17**:

```sh
./gradlew build
```

On Windows use `gradlew.bat build`. If your unzip tool does not preserve executable permissions, use `sh gradlew build`. The first build downloads Gradle and the pinned dependencies. The installable JAR is `build/libs/combatassist-1.0.0.jar` (not the `-sources.jar`). Install Fabric Loader, Fabric API **0.84.0+1.20.1** and Cloth Config **11.1.118**. Optionally install Mod Menu **7.2.2** for the in-game config screen; Mod Menu is not bundled or required. Cloth Config writes `config/combatassist.json`.

## Controls

- **R:** Toggle Sword AutoAttack. Look at an eligible target and hold your bound attack key. CPS is a tick-paced rate limit; the vanilla weapon cooldown can lower the actual rate. The first-person crosshair turns red and the upper underline changes color when there is a target. Manual clicks outside the assisted case and ordinary block mining remain vanilla.
- **T:** Toggle Bow AutoPull. A bow or crossbow in either hand shows a full-draw reference trajectory. Only a main-hand bow auto-releases: keep the bound use key held, have ammunition (unless vanilla exempts you), and keep the target on the projected path at the configured release tick. If there is no target at that tick, vanilla remains in control of the draw.
- Both keybinds start off on launch and can be rebound in Minecraft's Controls menu. If Bow AutoPull and vanilla Chat share the same keyboard binding (both default to **T**), CombatAssist gives the bow toggle priority during gameplay. Rebind either one in **Options → Controls → Key Binds** to use both independently. Both master switches start enabled and persist via Cloth Config.

The trajectory traces a straight segment for each physics tick and stops at the first collision. It predicts a 3.0-speed shot without random spread or target movement. A shorter draw, a real crossbow shot, or moving targets may not follow the reference line. The included-target options treat monster-class mobs and players as valid by default. Minecraft servers remain authoritative about hit reach, ammunition, PvP and all other gameplay rules. No custom networking is used.

Fabric events handle ticking and overlays. Three small client mixins tint the native crosshair, suppress an initial vanilla melee attack when the sword loop owns it, and resolve the default Chat key conflict.
