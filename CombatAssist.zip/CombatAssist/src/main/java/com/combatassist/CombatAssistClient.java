package com.combatassist;

import com.combatassist.config.CombatAssistConfig;
import com.combatassist.feature.BowAutoPull;
import com.combatassist.feature.SwordAutoAttack;
import com.combatassist.render.CrosshairOverlay;
import com.combatassist.render.TrajectoryRenderer;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class CombatAssistClient implements ClientModInitializer {
    public static final String MOD_ID = "combatassist";
    public static final int TICKS_PER_SECOND = 20;
    public static final SwordAutoAttack SWORD = new SwordAutoAttack();
    public static final BowAutoPull BOW = new BowAutoPull();
    private static final String KEY_CATEGORY = "key.categories.combatassist";
    private static KeyBinding swordToggle;
    private static KeyBinding bowToggle;

    @Override
    public void onInitializeClient() {
        AutoConfig.register(CombatAssistConfig.class, GsonConfigSerializer::new);
        swordToggle = registerKey("toggle_sword", GLFW.GLFW_KEY_R);
        bowToggle = registerKey("toggle_bow", GLFW.GLFW_KEY_T);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean inGame = client.world != null && client.player != null
                    && client.currentScreen == null && client.isWindowFocused();
            while (swordToggle.wasPressed()) {
                if (inGame) SWORD.toggle();
            }
            while (bowToggle.wasPressed()) {
                if (inGame) BOW.toggle();
            }
            CombatAssistConfig settings = CombatAssistConfig.get();
            SWORD.tick(client, settings.sword);
            BOW.tick(client, settings.bow);
        });
        HudRenderCallback.EVENT.register(CrosshairOverlay::render);
        WorldRenderEvents.LAST.register(TrajectoryRenderer::render);
    }

    /** Resolve the requested default T/vanilla Chat overlap before vanilla's single-key dispatch. */
    public static boolean handleKeyboardToggle(MinecraftClient client, int key, int scanCode, int action) {
        if (bowToggle == null || swordToggle == null || action == GLFW.GLFW_RELEASE
                || client.world == null || client.player == null || client.currentScreen != null
                || !client.isWindowFocused()) return false;
        boolean bowKey = bowToggle.matchesKey(key, scanCode);
        if (bowKey && client.options.chatKey.matchesKey(key, scanCode)) {
            if (action == GLFW.GLFW_PRESS) BOW.toggle();
            return true;
        }
        // The keyboard callback can otherwise enqueue synthetic repeats while a key is held.
        return action == GLFW.GLFW_REPEAT && (bowKey || swordToggle.matchesKey(key, scanCode));
    }

    private static KeyBinding registerKey(String id, int keyCode) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.combatassist." + id,
                InputUtil.Type.KEYSYM, keyCode, KEY_CATEGORY));
    }

    public static boolean hasLivePlayer(MinecraftClient client) {
        return client.world != null && client.interactionManager != null && client.player != null
                && client.player.isAlive() && !client.player.isSpectator();
    }

    public static boolean acceptsGameplayInput(MinecraftClient client) {
        return hasLivePlayer(client) && client.currentScreen == null && client.isWindowFocused();
    }
}
