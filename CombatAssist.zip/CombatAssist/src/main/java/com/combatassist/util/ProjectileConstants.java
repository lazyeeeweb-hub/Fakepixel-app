package com.combatassist.util;

// Baseline Minecraft 1.20.1 arrow physics. These are game constants, not tuning options.
public final class ProjectileConstants {
    public static final double FULL_BOW_SPEED = 3.0;
    public static final double AIR_DRAG = 0.99F;
    public static final double WATER_DRAG = 0.60F;
    public static final double GRAVITY_PER_TICK = 0.05F;
    public static final double ARROW_HIT_MARGIN = 0.3F;
    private ProjectileConstants() {}
}
