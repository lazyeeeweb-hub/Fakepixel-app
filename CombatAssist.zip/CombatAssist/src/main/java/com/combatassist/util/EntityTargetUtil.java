package com.combatassist.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public final class EntityTargetUtil {
    // Broad-phase padding for the candidate hit boxes, not a reach bonus.
    private static final double QUERY_PADDING = 1.0;

    private EntityTargetUtil() {}

    public record EntityHit(Entity entity, Vec3d position) {}

    public static boolean isTarget(Entity entity, boolean includePassives) {
        if (entity instanceof PlayerEntity player) return player.isAlive() && !player.isSpectator();
        return entity instanceof MobEntity mob && mob.isAlive()
                && (includePassives || mob.getType().getSpawnGroup() == SpawnGroup.MONSTER);
    }

    public static Vec3d clipToBlock(World world, Entity source, Vec3d start, Vec3d end,
                                     RaycastContext.ShapeType shape) {
        BlockHitResult block = world.raycast(new RaycastContext(start, end, shape,
                RaycastContext.FluidHandling.NONE, source));
        return block.getType() == HitResult.Type.MISS ? end : block.getPos();
    }

    public static EntityHit firstEntity(World world, ClientPlayerEntity source, Vec3d start, Vec3d end,
                                        boolean projectile) {
        Box broadPhase = new Box(start, end).expand(QUERY_PADDING);
        EntityHit closest = null;
        double nearest = start.squaredDistanceTo(end);
        for (Entity entity : world.getOtherEntities(source, broadPhase,
                e -> e.canHit() && !e.isSpectator() && (!projectile || !source.isConnectedThroughVehicle(e)))) {
            // Arrow collision uses a 0.3 block margin; melee uses the entity's vanilla targeting margin.
            double margin = projectile ? ProjectileConstants.ARROW_HIT_MARGIN : entity.getTargetingMargin();
            Box volume = entity.getBoundingBox().expand(margin);
            Vec3d intersection = volume.contains(start) ? start : volume.raycast(start, end).orElse(null);
            if (intersection == null) continue;
            double distance = start.squaredDistanceTo(intersection);
            if (distance <= nearest) {
                nearest = distance;
                closest = new EntityHit(entity, intersection);
            }
        }
        return closest;
    }

    public static LivingEntity findMeleeTarget(ClientPlayerEntity player, double reach, boolean passives) {
        Vec3d start = player.getEyePos();
        Vec3d end = start.add(player.getRotationVector().multiply(reach));
        World world = player.getWorld();
        Vec3d clearEnd = clipToBlock(world, player, start, end, RaycastContext.ShapeType.OUTLINE);
        EntityHit hit = firstEntity(world, player, start, clearEnd, false);
        return hit != null && isTarget(hit.entity(), passives) ? (LivingEntity) hit.entity() : null;
    }
}
