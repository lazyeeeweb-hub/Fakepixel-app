package com.combatassist.feature;

import com.combatassist.CombatAssistClient;
import com.combatassist.config.CombatAssistConfig;
import com.combatassist.util.EntityTargetUtil;
import com.combatassist.util.ProjectileConstants;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class BowAutoPull {
    // Guard for effectively zero movement and an upper bound even in unusual world/velocity states.
    private static final double EPSILON = 1.0e-6;
    private static final int MAX_SIMULATION_TICKS = 256;
    private static final Trajectory EMPTY = new Trajectory(List.of(), null);
    private boolean toggled;
    private ClientWorld sampledWorld;
    private Trajectory preview = EMPTY;

    public record Trajectory(List<Vec3d> points, LivingEntity target) {
        public boolean hasTarget() { return target != null && target.isAlive(); }
    }

    public void toggle() { toggled = !toggled; }
    public boolean active(CombatAssistConfig.Bow settings) { return settings.enabled && toggled; }
    public Trajectory trajectory(ClientWorld world) { return world != null && world == sampledWorld ? preview : EMPTY; }

    public static boolean holdsRangedWeapon(ClientPlayerEntity player) {
        return isRangedWeapon(player.getMainHandStack()) || isRangedWeapon(player.getOffHandStack());
    }

    private static boolean isRangedWeapon(ItemStack stack) { return stack.isOf(Items.BOW) || stack.isOf(Items.CROSSBOW); }

    public void tick(MinecraftClient client, CombatAssistConfig.Bow settings) {
        sampledWorld = client.world;
        if (!active(settings) || !CombatAssistClient.hasLivePlayer(client) || !holdsRangedWeapon(client.player)) {
            preview = EMPTY;
            return;
        }
        ClientPlayerEntity player = client.player;
        preview = predict(client.world, player, settings);
        if (!preview.hasTarget() || !CombatAssistClient.acceptsGameplayInput(client)
                || !client.options.useKey.isPressed() || !player.getMainHandStack().isOf(Items.BOW)) return;

        if (player.isUsingItem()) {
            // Adopt vanilla-started draws. Never release a late or offhand draw automatically.
            if (player.getActiveHand() == Hand.MAIN_HAND && player.getActiveItem().isOf(Items.BOW)
                    && player.getItemUseTime() == settings.releaseTicks()) {
                client.interactionManager.stopUsingItem(player);
            }
        } else {
            // Vanilla normally starts the next draw. This covers a held key while idle.
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        }
    }

    private static Trajectory predict(ClientWorld world, ClientPlayerEntity player, CombatAssistConfig.Bow settings) {
        Vec3d position = player.getEyePos();
        Vec3d movement = player.getVelocity();
        Vec3d velocity = player.getRotationVector().multiply(ProjectileConstants.FULL_BOW_SPEED)
                .add(movement.x, player.isOnGround() ? 0.0 : movement.y, movement.z);
        List<Vec3d> points = new ArrayList<>();
        points.add(position);
        double remaining = settings.trajectoryLength();
        LivingEntity target = null;
        for (int tick = 0; tick < MAX_SIMULATION_TICKS && remaining > EPSILON; tick++) {
            double speed = velocity.length();
            if (speed <= EPSILON) break;
            double step = Math.min(speed, remaining);
            Vec3d end = position.add(velocity.multiply(step / speed));
            Vec3d clearEnd = EntityTargetUtil.clipToBlock(world, player, position, end, RaycastContext.ShapeType.COLLIDER);
            EntityTargetUtil.EntityHit hit = EntityTargetUtil.firstEntity(world, player, position, clearEnd, true);
            if (hit != null) {
                points.add(hit.position());
                if (EntityTargetUtil.isTarget(hit.entity(), settings.target_passives)) target = (LivingEntity) hit.entity();
                break;
            }
            points.add(clearEnd);
            if (!clearEnd.equals(end)) break;
            BlockPos block = BlockPos.ofFloored(position);
            FluidState fluid = world.getFluidState(block);
            boolean inWater = fluid.isIn(FluidTags.WATER) && position.y < block.getY() + fluid.getHeight(world, block);
            double drag = inWater ? ProjectileConstants.WATER_DRAG : ProjectileConstants.AIR_DRAG;
            velocity = velocity.multiply(drag).add(0.0, -ProjectileConstants.GRAVITY_PER_TICK, 0.0);
            remaining -= step;
            position = clearEnd;
        }
        return new Trajectory(List.copyOf(points), target);
    }
}
