package com.combatassist.feature;

import com.combatassist.CombatAssistClient;
import com.combatassist.config.CombatAssistConfig;
import com.combatassist.util.EntityTargetUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public final class SwordAutoAttack {
    private static final int SHOT_CREDIT = CombatAssistClient.TICKS_PER_SECOND;
    private static final float FULL_COOLDOWN = 1.0F;
    private boolean toggled;
    private int credit = SHOT_CREDIT;
    private ClientWorld sampledWorld;
    private LivingEntity target;

    public void toggle() { toggled = !toggled; }
    public boolean active(CombatAssistConfig.Sword settings) { return settings.enabled && toggled; }
    public boolean hasTarget(ClientWorld world) {
        return world != null && sampledWorld == world && target != null && target.isAlive();
    }

    private boolean managingAttack(MinecraftClient client, CombatAssistConfig.Sword settings) {
        return active(settings) && CombatAssistClient.acceptsGameplayInput(client)
                && client.options.attackKey.isPressed() && !client.player.isUsingItem();
    }

    // Evaluated before vanilla's initial press attack; misses still follow vanilla input handling.
    public boolean suppressVanillaAttack(MinecraftClient client) {
        CombatAssistConfig.Sword settings = CombatAssistConfig.get().sword;
        return managingAttack(client, settings)
                && EntityTargetUtil.findMeleeTarget(client.player, settings.reach(), settings.target_passives) != null;
    }

    public void tick(MinecraftClient client, CombatAssistConfig.Sword settings) {
        if (sampledWorld != client.world) credit = SHOT_CREDIT;
        sampledWorld = client.world;
        target = active(settings) && CombatAssistClient.hasLivePlayer(client)
                ? EntityTargetUtil.findMeleeTarget(client.player, settings.reach(), settings.target_passives) : null;

        if (credit < SHOT_CREDIT) credit += settings.clicksPerSecond();
        if (target != null && managingAttack(client, settings) && credit >= SHOT_CREDIT
                && (settings.ignore_cooldown || client.player.getAttackCooldownProgress(0.0F) >= FULL_COOLDOWN)) {
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(Hand.MAIN_HAND);
            credit -= SHOT_CREDIT;
        } else {
            // No backlog of attacks can accumulate while the player or cooldown is not ready.
            credit = Math.min(credit, SHOT_CREDIT);
        }
    }
}
