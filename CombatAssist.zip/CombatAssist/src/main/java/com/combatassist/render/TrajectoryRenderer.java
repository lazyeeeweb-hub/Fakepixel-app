package com.combatassist.render;

import com.combatassist.CombatAssistClient;
import com.combatassist.config.CombatAssistConfig;
import com.combatassist.feature.BowAutoPull;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class TrajectoryRenderer {
    private static final int CHANNEL_MASK = 0xFF;
    private TrajectoryRenderer() {}

    public static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!CombatAssistClient.hasLivePlayer(client) || client.options.hudHidden
                || !BowAutoPull.holdsRangedWeapon(client.player)) return;
        CombatAssistConfig.Bow settings = CombatAssistConfig.get().bow;
        if (!CombatAssistClient.BOW.active(settings)) return;
        BowAutoPull.Trajectory trajectory = CombatAssistClient.BOW.trajectory(context.world());
        List<Vec3d> points = trajectory.points();
        if (points.size() < 2) return;
        int color = trajectory.hasTarget() ? settings.trajectory_color_active : settings.trajectory_color_idle;
        int a = color >>> 24;
        if (a == 0) return;
        int r = (color >>> 16) & CHANNEL_MASK;
        int g = (color >>> 8) & CHANNEL_MASK;
        int b = color & CHANNEL_MASK;
        Vec3d camera = context.camera().getPos();
        Matrix4f matrix = context.matrixStack().peek().getPositionMatrix();

        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        try {
            BufferBuilder buffer = Tessellator.getInstance().getBuffer();
            buffer.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            for (Vec3d point : points) {
                buffer.vertex(matrix, (float) (point.x - camera.x), (float) (point.y - camera.y),
                        (float) (point.z - camera.z)).color(r, g, b, a).next();
            }
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
        }
    }
}
