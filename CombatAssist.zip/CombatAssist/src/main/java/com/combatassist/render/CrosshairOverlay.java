package com.combatassist.render;

import com.combatassist.CombatAssistClient;
import com.combatassist.config.CombatAssistConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class CrosshairOverlay {
    private static final int WIDTH = 12;
    private static final int HEIGHT = 2;
    private static final int OFFSET_Y = 7;
    private static final int GAP = 3;
    private static final int OPAQUE_ALPHA = 0xFF000000;

    private CrosshairOverlay() {}

    public static void render(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!CombatAssistClient.hasLivePlayer(client) || client.options.hudHidden
                || !client.options.getPerspective().isFirstPerson()) return;
        CombatAssistConfig config = CombatAssistConfig.get();
        int x = (context.getScaledWindowWidth() - WIDTH) / 2;
        int y = context.getScaledWindowHeight() / 2 + OFFSET_Y;
        if (CombatAssistClient.SWORD.active(config.sword)) {
            int color = CombatAssistClient.SWORD.hasTarget(client.world)
                    ? config.sword.underline_color_active : config.sword.underline_color_idle;
            underline(context, x, y, color);
            y += HEIGHT + GAP;
        }
        if (CombatAssistClient.BOW.active(config.bow)) {
            int color = CombatAssistClient.BOW.trajectory(client.world).hasTarget()
                    ? config.bow.underline_color_active : config.bow.underline_color_idle;
            underline(context, x, y, color);
        }
    }

    private static void underline(DrawContext context, int x, int y, int rgb) {
        context.fill(x, y, x + WIDTH, y + HEIGHT, OPAQUE_ALPHA | rgb);
    }
}
