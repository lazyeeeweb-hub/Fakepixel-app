package com.combatassist.mixin;

import com.combatassist.CombatAssistClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
abstract class MinecraftClientMixin {
    @Inject(method = "doAttack()Z", at = @At("HEAD"), cancellable = true)
    private void combatassist$gateAttack(CallbackInfoReturnable<Boolean> callback) {
        if (CombatAssistClient.SWORD.suppressVanillaAttack((MinecraftClient) (Object) this)) {
            callback.setReturnValue(false);
        }
    }
}
