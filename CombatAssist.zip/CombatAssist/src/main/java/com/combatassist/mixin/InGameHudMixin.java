package com.combatassist.mixin;

import com.combatassist.CombatAssistClient;
import com.combatassist.config.CombatAssistConfig;
import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(InGameHud.class)
abstract class InGameHudMixin {
    @Redirect(method = "renderCrosshair(Lnet/minecraft/client/gui/DrawContext;)V", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIIIII)V",
            ordinal = 0))
    private void combatassist$tintCrosshair(DrawContext context, Identifier texture, int x, int y,
                                            int u, int v, int width, int height) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!CombatAssistClient.SWORD.active(CombatAssistConfig.get().sword)
                || !CombatAssistClient.SWORD.hasTarget(client.world)) {
            context.drawTexture(texture, x, y, u, v, width, height);
            return;
        }
        float[] previous = RenderSystem.getShaderColor().clone();
        RenderSystem.defaultBlendFunc();
        context.setShaderColor(1.0F, 0.0F, 0.0F, previous[3]);
        try {
            context.drawTexture(texture, x, y, u, v, width, height);
        } finally {
            context.setShaderColor(previous[0], previous[1], previous[2], previous[3]);
            RenderSystem.blendFuncSeparate(SrcFactor.ONE_MINUS_DST_COLOR, DstFactor.ONE_MINUS_SRC_COLOR,
                    SrcFactor.ONE, DstFactor.ZERO);
        }
    }
}
