package com.combatassist.mixin;

import com.combatassist.CombatAssistClient;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
abstract class KeyboardMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(method = "onKey(JIIII)V", at = @At("HEAD"), cancellable = true)
    private void combatassist$handleToggleKey(long window, int key, int scanCode, int action, int modifiers,
                                               CallbackInfo callback) {
        if (window == client.getWindow().getHandle()
                && CombatAssistClient.handleKeyboardToggle(client, key, scanCode, action)) {
            callback.cancel();
        }
    }
}
