package com.combatassist.config;

import com.combatassist.CombatAssistClient;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;
import net.minecraft.util.math.MathHelper;

@Config(name = CombatAssistClient.MOD_ID)
public final class CombatAssistConfig implements ConfigData {
    private static final int WHITE = 0xFFFFFF;
    private static final int RED = 0xFF0000;
    private static final int TRANSLUCENT = 0x88000000;

    @ConfigEntry.Category("sword")
    @ConfigEntry.Gui.TransitiveObject
    public Sword sword = new Sword();

    @ConfigEntry.Category("bow")
    @ConfigEntry.Gui.TransitiveObject
    public Bow bow = new Bow();

    public static CombatAssistConfig get() {
        return AutoConfig.getConfigHolder(CombatAssistConfig.class).getConfig();
    }

    @Override
    public void validatePostLoad() {
        if (sword == null) sword = new Sword();
        if (bow == null) bow = new Bow();
        sword.reach_distance = sword.reach();
        sword.cps = sword.clicksPerSecond();
        bow.trajectory_length = bow.trajectoryLength();
        bow.auto_release_ticks = bow.releaseTicks();
    }

    public static final class Sword {
        private static final double MIN_REACH = 1.0;
        private static final double DEFAULT_REACH = 3.0;
        private static final double MAX_REACH = 6.0;
        private static final int MIN_CPS = 1;
        private static final int MAX_CPS = CombatAssistClient.TICKS_PER_SECOND;

        @ConfigEntry.Gui.Tooltip
        public boolean enabled = true;
        @ConfigEntry.Gui.Tooltip
        public double reach_distance = DEFAULT_REACH;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = MIN_CPS, max = MAX_CPS)
        public int cps = 12;
        @ConfigEntry.Gui.Tooltip
        public boolean ignore_cooldown = false;
        @ConfigEntry.Gui.Tooltip
        public boolean target_passives = false;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker
        public int underline_color_idle = WHITE;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker
        public int underline_color_active = RED;

        public double reach() {
            return Double.isFinite(reach_distance)
                    ? MathHelper.clamp(reach_distance, MIN_REACH, MAX_REACH) : DEFAULT_REACH;
        }
        public int clicksPerSecond() { return MathHelper.clamp(cps, MIN_CPS, MAX_CPS); }
    }

    public static final class Bow {
        private static final int MIN_LENGTH = 10;
        private static final int MAX_LENGTH = 128;
        private static final int MIN_RELEASE = 10;
        private static final int FULL_DRAW_TICKS = 20;

        @ConfigEntry.Gui.Tooltip
        public boolean enabled = true;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = MIN_LENGTH, max = MAX_LENGTH)
        public int trajectory_length = 48;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = MIN_RELEASE, max = FULL_DRAW_TICKS)
        public int auto_release_ticks = FULL_DRAW_TICKS;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker(allowAlpha = true)
        public int trajectory_color_idle = TRANSLUCENT | WHITE;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker(allowAlpha = true)
        public int trajectory_color_active = TRANSLUCENT | RED;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker
        public int underline_color_idle = WHITE;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.ColorPicker
        public int underline_color_active = RED;
        @ConfigEntry.Gui.Tooltip
        public boolean target_passives = false;

        public int trajectoryLength() { return MathHelper.clamp(trajectory_length, MIN_LENGTH, MAX_LENGTH); }
        public int releaseTicks() { return MathHelper.clamp(auto_release_ticks, MIN_RELEASE, FULL_DRAW_TICKS); }
    }
}
