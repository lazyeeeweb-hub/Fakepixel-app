# Easy Building

## Setup

For setup instructions, please see the [Fabric Documentation page](https://docs.fabricmc.net/develop/getting-started/creating-a-project#setting-up) related to the IDE that you are using.

## License

This template is available under the CC0 license. Feel free to learn from it and incorporate it in your own projects.

## Build this patched source

- GitHub: extract the ZIP into your repository root (including `.github/`), commit and push, then download `easy-building-fabric-1.20.1` from the successful Actions run.
- Locally: use JDK 25 to run `bash ./gradlew build` (or `gradlew.bat build` on Windows). The build targets Java 17, and the mod JAR is under `build/libs/`.
- This patch skips drawing the plane-mode preview when the camera ray has no projected block. With a valid projection, the grid still draws as before.
