# Zacktills Client (Minecraft 1.20.1 / Fabric)

This is an experimental client-side source update to the provided config-menu prototype. It contains settings and rendering hooks for configurable HUD elements, clean scoreboard, NBT copy, slot locks, flat dropped-item icons, tooltip scrolling, custom crosshair/viewmodel, swing-through, opt-in chat-triggered login, third-person wall fade, and a file-backed whiteboard.

## Build
Open the project with a Java 17 Gradle environment and run `gradle build`. The resulting mod JAR is expected under `build/libs/`. The current source update has **not** been compiled or game-tested in this environment; verify it in a disposable client profile before use.

## Notes / limitations
- The Sodium integration hides its donation prompt only. It does not suppress driver, GPU, compatibility, or other safety warnings. It targets the Sodium 0.5.x option GUI when the optional class/methods exist.
- Wall fade is experimental, uses a vanilla core-shader dither effect, and is disabled when Sodium or Iris is detected.
- Autologin is off by default and requires an exact server address. The password is kept in memory only until disconnect; only enable it for a trusted server. Chat prompts on unsigned/custom servers may be spoofed.
- Slot lock is a client-side guard for local inventory interactions, not protection against server/plugin changes. Multi-slot inventory operations are conservatively blocked when any local slot is locked.
- NBT copy copies the hovered/held item stack data; it does not provide arbitrary block-entity NBT access.
- Mod Menu 7.2.2 already restores the mod-list scroll position when returning to the same ModsScreen instance; recent mods are not reordered. Other Mod Menu versions or screens that create a fresh ModsScreen are unverified.

Controls: Right Shift opens configuration; B opens the whiteboard; L toggles lock for the hovered player-inventory slot; C copies item NBT while an inventory is open. All settings are configurable in the Zacktills menu.
