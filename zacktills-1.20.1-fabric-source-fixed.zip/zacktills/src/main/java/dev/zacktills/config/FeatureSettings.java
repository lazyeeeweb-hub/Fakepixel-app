package dev.zacktills.config;

import dev.zacktills.ZacktillsClient;
import dev.zacktills.ui.HudEditorScreen;
import dev.zacktills.ui.LoginSecretScreen;
import dev.zacktills.ui.WhiteboardScreen;
import net.minecraft.client.MinecraftClient;
import java.util.*;
import static dev.zacktills.config.ConfigModel.*;

/** The UI and gameplay share these same Option objects; no copied settings. */
public final class FeatureSettings {
    public static final List<Category> CATEGORIES = new ArrayList<>();
    private static final Map<String, Option<?>> OPTIONS = new HashMap<>();
    private static List<Option<?>> current;
    private static String category;
    public static ConfigStore STORE;
    static {
        group("interface", "Menus");
        bool("realms", "Hide Realms", true);
        bool("extras", "Hide feedback, bug report, stats and advancements buttons", true);
        bool("sodium", "Hide Sodium donation prompt (not driver safety warnings)", true);
        bool("modmenu", "Remember Mod Menu scroll position", true);
        group("nbt", "Copy NBT");
        bool("enabled", "Copy item NBT button in inventories", true);
        position("copy", .84, .12);
        action("editor", "Position / resize copy button", () -> edit("copy"));
        group("scoreboard", "Scoreboard");
        bool("enabled", "Clean sidebar (no score numbers)", true);
        range("radius", "Corner radius", 0, 12, 1, 5);
        range("opacity", "Background opacity", 0, 1, .05, .65);
        position("scoreboard", 1, .4);
        action("editor", "Position / resize scoreboard", () -> edit("scoreboard"));
        group("hud", "Hotbar & offhand");
        bool("enabled", "Custom movable hotbar and offhand", true);
        position("hotbar", .5, 1);
        position("offhand", .25, 1);
        action("hotbar_editor", "Position / resize hotbar", () -> edit("hotbar"));
        action("offhand_editor", "Position / resize offhand", () -> edit("offhand"));
        group("inventory", "Items & inventory");
        bool("flat", "Flat, camera-facing dropped items", true);
        bool("slot_lock", "Slot lock (L over a player inventory slot)", true);
        string("locked", "Locked inventory indices (0-40)", "");
        bool("swingthrough", "Attack through non-colliding foliage", true);
        group("tooltip", "Tooltips & crosshair");
        bool("scroll", "Scrollable tooltips; keep their top visible", true);
        bool("crosshair", "Centered crosshair (also third person)", true);
        group("camera", "Camera");
        bool("fade", "Third-person near-wall fade (vanilla renderer)", false);
        range("radius", "Fade distance", .5, 4, .1, 1.6);
        range("strength", "Maximum fade", .1, 1, .05, .85);
        group("login", "Autologin");
        bool("enabled", "Enable chat-triggered login (trusted server only)", false);
        string("server", "Exact server address, including port if used", "");
        string("prompt", "Server message contains (case insensitive)", "Please login");
        string("command", "Command template (no slash; {password} required)", "login {password}");
        action("secret", "Set password for this session (never saved)", () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new LoginSecretScreen(mc.currentScreen));
        });
        group("viewmodel", "Viewmodel");
        bool("enabled", "Enable per-hand transforms", true);
        for (String hand : List.of("main", "off")) {
            for (String axis : List.of("x", "y", "z")) range(hand + "_" + axis, hand + " position " + axis, -2, 2, .05, 0);
            range(hand + "_scale", hand + " scale", .1, 3, .05, 1);
            for (String axis : List.of("rx", "ry", "rz")) range(hand + "_" + axis, hand + " rotation " + axis, -180, 180, 5, 0);
            range(hand + "_speed", hand + " swing animation speed", .25, 4, .05, 1);
        }
        group("whiteboard", "Whiteboard");
        action("open", "Open file-backed whiteboard", () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new WhiteboardScreen(mc.currentScreen));
        });
    }
    private FeatureSettings() {}
    private static void group(String id, String label) {
        category = id; current = new ArrayList<>();
        Category c = new Category(id, label, current);
        CATEGORIES.add(c); current = c.options;
    }
    private static void put(Option<?> option) { current.add(option); OPTIONS.put(category + "." + option.id, option); }
    private static void bool(String id, String label, boolean value) { put(new Bool(id, label, label, value)); }
    private static void range(String id, String label, double min, double max, double step, double value) {
        put(new Range(id, label, label, min, max, step, value, false));
    }
    private static void string(String id, String label, String value) { put(new StringOption(id, label, label, value)); }
    private static void action(String id, String label, Runnable action) { put(new Action(id, label, label, action)); }
    private static void position(String id, double x, double y) {
        range(id + "_x", id + " horizontal anchor", 0, 1, .01, x);
        range(id + "_y", id + " vertical anchor", 0, 1, .01, y);
        range(id + "_scale", id + " scale", .25, 4, .05, 1);
    }
    private static String prefix(String id) { return id.equals("copy") ? "nbt." : id.equals("scoreboard") ? "scoreboard." : "hud."; }
    public static double pos(String id, String property) { return number(prefix(id) + id + "_" + property); }
    public static void pos(String id, String property, double value) { ((Range) OPTIONS.get(prefix(id) + id + "_" + property)).set(value); }
    private static void edit(String id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Persist menu changes before opening a child screen.
        if (STORE != null) STORE.save();
        mc.setScreen(new HudEditorScreen(mc.currentScreen, id));
    }
    public static boolean on(String key) { return ((Bool) OPTIONS.get(key)).value; }
    public static double number(String key) { return ((Range) OPTIONS.get(key)).value; }
    public static String text(String key) { return ((StringOption) OPTIONS.get(key)).value; }
    public static void text(String key, String value) { ((StringOption) OPTIONS.get(key)).value = value; }
    public static void save() {
        if (STORE != null && !STORE.save()) ZacktillsClient.notifyError("Could not save settings; check the game log.");
    }
}
