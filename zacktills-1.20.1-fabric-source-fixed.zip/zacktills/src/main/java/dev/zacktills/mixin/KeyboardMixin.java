package dev.zacktills.mixin;
import dev.zacktills.ZacktillsClient;
import dev.zacktills.feature.ItemFeatures;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Keyboard.class)
public abstract class KeyboardMixin {
    @Inject(method="onKey",at=@At("HEAD"),cancellable=true)
    private void zacktills$key(long window,int key,int scan,int action,int modifiers,CallbackInfo ci) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(window!=mc.getWindow().getHandle() || action!=GLFW.GLFW_PRESS || !(mc.currentScreen instanceof HandledScreen<?>)) return;
        if(mc.currentScreen.getFocused() instanceof net.minecraft.client.gui.widget.TextFieldWidget) return;
        if(ZacktillsClient.lock!=null && ZacktillsClient.lock.matchesKey(key,scan)){ItemFeatures.toggleHovered();ci.cancel();}
        else if(ZacktillsClient.copy!=null && ZacktillsClient.copy.matchesKey(key,scan)){ItemFeatures.copy();ci.cancel();}
    }
}
