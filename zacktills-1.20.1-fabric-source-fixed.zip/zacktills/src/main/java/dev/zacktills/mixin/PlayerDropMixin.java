package dev.zacktills.mixin;
import dev.zacktills.feature.ItemFeatures;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ClientPlayerEntity.class)
public abstract class PlayerDropMixin {
    @Inject(method="dropSelectedItem",at=@At("HEAD"),cancellable=true)
    private void zacktills$drop(boolean entireStack,CallbackInfoReturnable<Boolean> cir) {
        ClientPlayerEntity player=(ClientPlayerEntity)(Object)this;
        if(ItemFeatures.locked(player.getInventory().selectedSlot))cir.setReturnValue(false);
    }
}
