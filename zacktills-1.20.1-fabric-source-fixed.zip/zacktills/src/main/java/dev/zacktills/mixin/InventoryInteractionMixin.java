package dev.zacktills.mixin;
import dev.zacktills.feature.ItemFeatures;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPlayerInteractionManager.class)
public abstract class InventoryInteractionMixin {
    @Inject(method="clickSlot",at=@At("HEAD"),cancellable=true)
    private void zacktills$lock(int syncId,int slotId,int button,SlotActionType type,PlayerEntity player,CallbackInfo ci) {
        if(ItemFeatures.blockClick(slotId,button,type))ci.cancel();
    }
}
