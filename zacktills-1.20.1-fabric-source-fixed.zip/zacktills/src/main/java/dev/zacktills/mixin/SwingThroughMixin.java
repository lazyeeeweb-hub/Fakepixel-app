package dev.zacktills.mixin;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.*;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public abstract class SwingThroughMixin {
    @Inject(method="updateTargetedEntity",at=@At("RETURN"))
    private void zacktills$target(float delta,CallbackInfo ci) {
        var mc=MinecraftClient.getInstance();var player=mc.player;
        if(!FeatureSettings.on("inventory.swingthrough") || player==null || mc.world==null || mc.interactionManager==null
            || mc.getCameraEntity()!=player || !(mc.crosshairTarget instanceof BlockHitResult hit))return;
        if(!mc.world.getBlockState(hit.getBlockPos()).getCollisionShape(mc.world,hit.getBlockPos()).isEmpty())return;
        double reach=mc.interactionManager.hasExtendedReach()?6:Math.min(3,mc.interactionManager.getReachDistance());
        var eye=player.getCameraPosVec(delta);var look=player.getRotationVec(delta);var end=eye.add(look.multiply(reach));
        var solid=mc.world.raycast(new RaycastContext(eye,end,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,player));
        double limit=solid.getType()==HitResult.Type.MISS?reach*reach:eye.squaredDistanceTo(solid.getPos());
        var entity=ProjectileUtil.raycast(player,eye,end,player.getBoundingBox().stretch(look.multiply(reach)).expand(1),e->!e.isSpectator()&&e.canHit(),limit);
        if(entity!=null){mc.crosshairTarget=entity;mc.targetedEntity=entity.getEntity();}
    }
}
