package dev.zacktills.mixin;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.ViewmodelFeatures;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method="renderFirstPersonItem",at=@At("HEAD"))
    private void zacktills$begin(AbstractClientPlayerEntity p,float delta,float pitch,Hand hand,float swing,ItemStack stack,float equip,MatrixStack matrices,VertexConsumerProvider vertices,int light,CallbackInfo ci) {
        matrices.push();if(FeatureSettings.on("viewmodel.enabled"))ViewmodelFeatures.transform(hand,matrices);
    }
    @Inject(method="renderFirstPersonItem",at=@At("RETURN"))
    private void zacktills$end(AbstractClientPlayerEntity p,float delta,float pitch,Hand hand,float swing,ItemStack stack,float equip,MatrixStack matrices,VertexConsumerProvider vertices,int light,CallbackInfo ci) { matrices.pop(); }
    @ModifyVariable(method="renderFirstPersonItem",at=@At("HEAD"),argsOnly=true,ordinal=2)
    private float zacktills$animation(float value,AbstractClientPlayerEntity p,float delta,float pitch,Hand hand,float swing,ItemStack stack,float equip,MatrixStack matrices,VertexConsumerProvider vertices,int light) {
        return ViewmodelFeatures.animation(hand,value);
    }
}
