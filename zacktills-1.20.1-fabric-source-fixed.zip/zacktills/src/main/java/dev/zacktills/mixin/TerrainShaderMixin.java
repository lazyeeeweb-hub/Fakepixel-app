package dev.zacktills.mixin;
import dev.zacktills.feature.WallFade;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.gl.ShaderProgram;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(GameRenderer.class)
public abstract class TerrainShaderMixin {
    @Inject(method="getRenderTypeSolidProgram",at=@At("RETURN"),cancellable=true)
    private static void zacktills$solid(CallbackInfoReturnable<ShaderProgram> cir) { ShaderProgram s=WallFade.shader(0);if(s!=null)cir.setReturnValue(s); }
    @Inject(method="getRenderTypeCutoutProgram",at=@At("RETURN"),cancellable=true)
    private static void zacktills$cutout(CallbackInfoReturnable<ShaderProgram> cir) { ShaderProgram s=WallFade.shader(1);if(s!=null)cir.setReturnValue(s); }
    @Inject(method="getRenderTypeCutoutMippedProgram",at=@At("RETURN"),cancellable=true)
    private static void zacktills$mipped(CallbackInfoReturnable<ShaderProgram> cir) { ShaderProgram s=WallFade.shader(2);if(s!=null)cir.setReturnValue(s); }
}
