package dev.zacktills.mixin;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(HandledScreen.class)
public interface HandledScreenAccess {
    @Accessor("focusedSlot") Slot zacktills$focused();
    @Accessor("x") int zacktills$x();
    @Accessor("y") int zacktills$y();
}
