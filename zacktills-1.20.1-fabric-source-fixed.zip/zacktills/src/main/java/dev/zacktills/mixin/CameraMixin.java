package dev.zacktills.mixin;
import dev.zacktills.feature.WallFade;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Inject(method="clipToSpace",at=@At("RETURN"),cancellable=true)
    private void zacktills$camera(double wanted,CallbackInfoReturnable<Double> cir) {
        cir.setReturnValue(WallFade.camera(wanted,cir.getReturnValue()));
    }
}
