package dev.zacktills.mixin;
import dev.zacktills.feature.TooltipFeatures;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method="onMouseScroll",at=@At("HEAD"),cancellable=true)
    private void zacktills$scroll(long window,double horizontal,double vertical,CallbackInfo ci) {
        var mc=MinecraftClient.getInstance();
        if(window==mc.getWindow().getHandle() && mc.currentScreen!=null && TooltipFeatures.scroll(vertical))ci.cancel();
    }
}
