package dev.zacktills.mixin;
import dev.zacktills.feature.ItemFeatures;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPlayNetworkHandler.class)
public abstract class NetworkDropMixin {
    @Inject(method="sendPacket(Lnet/minecraft/network/packet/Packet;)V",at=@At("HEAD"),cancellable=true)
    private void zacktills$packet(Packet<?> packet,CallbackInfo ci) {
        var player=MinecraftClient.getInstance().player;
        if(player==null || !(packet instanceof PlayerActionC2SPacket p))return;
        var action=p.getAction();
        if((action==PlayerActionC2SPacket.Action.DROP_ITEM || action==PlayerActionC2SPacket.Action.DROP_ALL_ITEMS) && ItemFeatures.locked(player.getInventory().selectedSlot))ci.cancel();
        if(action==PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND && (ItemFeatures.locked(40) || ItemFeatures.locked(player.getInventory().selectedSlot)))ci.cancel();
    }
}
