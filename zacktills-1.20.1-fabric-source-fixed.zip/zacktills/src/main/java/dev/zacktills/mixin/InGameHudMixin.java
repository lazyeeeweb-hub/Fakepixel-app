package dev.zacktills.mixin;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.HudFeatures;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method="renderHotbar",at=@At("HEAD"),cancellable=true)
    private void zacktills$hotbar(float tickDelta,DrawContext c,CallbackInfo ci) {
        var mc=MinecraftClient.getInstance();
        if(FeatureSettings.on("hud.enabled") && mc.player!=null && !mc.player.isSpectator()){HudFeatures.hotbar(c);ci.cancel();}
    }
    @Inject(method="renderScoreboardSidebar",at=@At("HEAD"),cancellable=true)
    private void zacktills$scoreboard(DrawContext c,ScoreboardObjective objective,CallbackInfo ci) {
        if(FeatureSettings.on("scoreboard.enabled")){HudFeatures.scoreboard(c,objective);ci.cancel();}
    }
    @Inject(method="renderCrosshair",at=@At("HEAD"),cancellable=true)
    private void zacktills$crosshair(DrawContext c,CallbackInfo ci) {
        var mc=MinecraftClient.getInstance();
        if(!FeatureSettings.on("tooltip.crosshair") || mc.player==null || mc.player.isSpectator())return;
        int x=mc.getWindow().getScaledWidth()/2,y=mc.getWindow().getScaledHeight()/2;
        c.fill(x-4,y,x+5,y+1,0xFFFFFFFF);c.fill(x,y-4,x+1,y+5,0xFFFFFFFF);ci.cancel();
    }
}
