package dev.zacktills.mixin;
import dev.zacktills.config.FeatureSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Optional Sodium hook: suppresses only the donation prompt/button, never renderer safety warnings. */
@Pseudo
@Mixin(targets="me.jellysquid.mods.sodium.client.gui.SodiumOptionsGUI",remap=false)
public abstract class SodiumDonationMixin {
    @Inject(method="checkPromptTimers()V",at=@At("HEAD"),cancellable=true,require=0,remap=false)
    private void zacktills$skipPrompt(CallbackInfo ci) {
        if(FeatureSettings.on("interface.sodium"))ci.cancel();
    }
    @Inject(method="rebuildGUI()V",at=@At("RETURN"),require=0,remap=false)
    private void zacktills$hideDonation(CallbackInfo ci) {
        if(FeatureSettings.on("interface.sodium"))zacktills$setDonationButtonVisibility(false);
    }
    @Invoker(value="setDonationButtonVisibility",remap=false)
    protected abstract void zacktills$setDonationButtonVisibility(boolean visible);
}
