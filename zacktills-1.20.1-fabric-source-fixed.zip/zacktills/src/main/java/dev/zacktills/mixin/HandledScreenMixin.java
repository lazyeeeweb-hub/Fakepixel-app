package dev.zacktills.mixin;
import dev.zacktills.feature.ItemFeatures;
import dev.zacktills.feature.HudFeatures;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.ScreenHandler;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow @Final protected ScreenHandler handler;
    @Inject(method="render",at=@At("RETURN"))
    private void zacktills$locks(DrawContext c,int mx,int my,float delta,CallbackInfo ci) {
        for(var slot:handler.slots)if(ItemFeatures.locked(slot)) {
            c.getMatrices().push();c.getMatrices().translate(0,0,350);
            HudFeatures.outline(c,x+slot.x-1,y+slot.y-1,18,18,0xFFFFC24A);c.getMatrices().pop();
        }
    }
}
