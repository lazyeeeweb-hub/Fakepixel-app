package dev.zacktills.mixin;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemEntityRenderer.class)
public abstract class FlatItemMixin {
    @Inject(method="render(Lnet/minecraft/entity/ItemEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At("HEAD"),cancellable=true)
    private void zacktills$flat(ItemEntity item,float yaw,float delta,MatrixStack matrices,VertexConsumerProvider consumers,int light,CallbackInfo ci) {
        if(!FeatureSettings.on("inventory.flat"))return;
        var mc=MinecraftClient.getInstance();
        var sprite=mc.getItemRenderer().getModel(item.getStack(),item.getWorld(),null,item.getId()).getParticleSprite();
        matrices.push();matrices.translate(0,.22+Math.sin((item.getItemAge()+delta)/10.0)*.035,0);
        matrices.multiply(mc.getEntityRenderDispatcher().getRotation());matrices.scale(.5f,.5f,.5f);
        Matrix4f m=matrices.peek().getPositionMatrix();var n=matrices.peek().getNormalMatrix();
        VertexConsumer v=consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE));
        v.vertex(m,-.5f,-.5f,0).color(255,255,255,255).texture(sprite.getMinU(),sprite.getMaxV()).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(n,0,0,1).next();
        v.vertex(m,.5f,-.5f,0).color(255,255,255,255).texture(sprite.getMaxU(),sprite.getMaxV()).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(n,0,0,1).next();
        v.vertex(m,.5f,.5f,0).color(255,255,255,255).texture(sprite.getMaxU(),sprite.getMinV()).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(n,0,0,1).next();
        v.vertex(m,-.5f,.5f,0).color(255,255,255,255).texture(sprite.getMinU(),sprite.getMinV()).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(n,0,0,1).next();
        matrices.pop();ci.cancel();
    }
}
