package dev.zacktills.ui;
import dev.zacktills.feature.AutoLogin;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;
public final class LoginSecretScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget password;
    public LoginSecretScreen(Screen parent) { super(Text.literal("Session login password")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(280, width - 16);
        password = new TextFieldWidget(textRenderer, (width-w)/2, height/2-15, w, 20, Text.literal("Password"));
        password.setMaxLength(128);
        password.setRenderTextProvider((value, first) -> Text.literal("*".repeat(value.length())).asOrderedText());
        addDrawableChild(password); setInitialFocus(password);
        addDrawableChild(ButtonWidget.builder(Text.literal("Use until disconnect"), b -> { AutoLogin.password(password.getText()); password.setText(""); close(); }).dimensions((width-w)/2, height/2+12, w, 20).build());
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width/2, height/2-50, 0xFFFFFF);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Not saved to disk. Use a trusted server."), width/2, height/2+45, 0xFFAA55);
        super.render(c, mx, my, delta);
    }
    @Override public void close() { if (password != null) password.setText(""); client.setScreen(parent); }
    @Override public void removed() { if (password != null) password.setText(""); super.removed(); }
    @Override public boolean shouldPause() { return false; }
}
