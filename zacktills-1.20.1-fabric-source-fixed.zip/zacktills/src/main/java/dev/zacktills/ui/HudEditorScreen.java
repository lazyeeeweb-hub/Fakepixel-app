package dev.zacktills.ui;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.HudFeatures;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Coordinates are normalized against usable screen space, shared with actual renderers. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private final String id;
    private final int elementW, elementH;
    private boolean dragging;
    private double offsetX,offsetY;
    public HudEditorScreen(Screen parent,String id) {
        super(Text.literal("Position: "+id)); this.parent=parent; this.id=id;
        elementW=id.equals("hotbar")?182:id.equals("offhand")?22:id.equals("copy")?80:150;
        elementH=id.equals("scoreboard")?110:id.equals("copy")?20:22;
    }
    @Override protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("-"),b->resize(-.05)).dimensions(4,4,24,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"),b->resize(.05)).dimensions(32,4,24,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset"),b->{ FeatureSettings.pos(id,"x",.5); FeatureSettings.pos(id,"y",.5); FeatureSettings.pos(id,"scale",1); }).dimensions(60,4,54,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Save / Back"),b->close()).dimensions(Math.max(118,width-100),4,96,20).build());
    }
    private void resize(double d) { FeatureSettings.pos(id,"scale",FeatureSettings.pos(id,"scale")+d); }
    @Override public void render(DrawContext c,int mx,int my,float delta) {
        c.fill(0,0,width,height,0x70101924);
        for(int x=0;x<width;x+=16)c.fill(x,28,x+1,height,0x303F5870);
        for(int y=32;y<height;y+=16)c.fill(0,y,width,y+1,0x303F5870);
        if(id.equals("copy")) HudFeatures.drawCopy(c);
        else if(id.equals("hotbar") || id.equals("offhand")) {
            if(client.player!=null) HudFeatures.hotbar(c);
            else preview(c);
        } else preview(c);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal(id+" | drag to move | +/- or wheel: scale | Esc: save"),width/2,height-12,0xFFFFFF);
        super.render(c,mx,my,delta);
    }
    private void preview(DrawContext c) {
        HudFeatures.begin(c,id,elementW,elementH);
        HudFeatures.rounded(c,0,0,elementW,elementH,5,0xCE25354B);
        c.drawTextWithShadow(textRenderer,Text.literal(id.equals("scoreboard")?"Scoreboard preview":id),6,5,0xFFFFFF);
        if(id.equals("scoreboard")) for(int i=0;i<8;i++) c.drawTextWithShadow(textRenderer,Text.literal("Player / information "+(i+1)),6,20+i*10,0xCCCCCC);
        c.getMatrices().pop();
    }
    @Override public boolean mouseClicked(double mx,double my,int button) {
        if(super.mouseClicked(mx,my,button))return true;
        double[] r=HudFeatures.bounds(id,elementW,elementH);
        if(button==0 && mx>=r[0] && my>=r[1] && mx<r[0]+r[2] && my<r[1]+r[3]) {
            dragging=true; offsetX=mx-r[0];offsetY=my-r[1];return true;
        } return false;
    }
    @Override public boolean mouseDragged(double mx,double my,int button,double dx,double dy) {
        if(!dragging)return super.mouseDragged(mx,my,button,dx,dy);
        double scale=FeatureSettings.pos(id,"scale");
        FeatureSettings.pos(id,"x",(mx-offsetX)/Math.max(1,width-elementW*scale));
        FeatureSettings.pos(id,"y",(my-offsetY)/Math.max(1,height-elementH*scale));return true;
    }
    @Override public boolean mouseReleased(double mx,double my,int button) { dragging=false;return super.mouseReleased(mx,my,button); }
    @Override public boolean mouseScrolled(double mx,double my,double amount) { resize(Math.signum(amount)*.05);return true; }
    @Override public boolean keyPressed(int key,int scan,int modifiers) {
        if(key==GLFW.GLFW_KEY_EQUAL || key==GLFW.GLFW_KEY_KP_ADD){resize(.05);return true;}
        if(key==GLFW.GLFW_KEY_MINUS || key==GLFW.GLFW_KEY_KP_SUBTRACT){resize(-.05);return true;}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public void close() { FeatureSettings.save();client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
