package dev.zacktills;
import dev.zacktills.config.*;
import dev.zacktills.feature.*;
import dev.zacktills.ui.ConfigScreen;
import dev.zacktills.ui.WhiteboardScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.LoggerFactory;
public final class ZacktillsClient implements ClientModInitializer {
    public static final String MOD_ID = "zacktills";
    public static KeyBinding lock, copy;
    public static Screen config(Screen parent) { return new ConfigScreen(parent, FeatureSettings.CATEGORIES, FeatureSettings.STORE); }
    @Override public void onInitializeClient() {
        FeatureSettings.STORE = new ConfigStore(FeatureSettings.CATEGORIES); FeatureSettings.STORE.load();
        KeyBinding open = key("open_config", GLFW.GLFW_KEY_RIGHT_SHIFT), board = key("whiteboard", GLFW.GLFW_KEY_B);
        lock = key("lock_slot", GLFW.GLFW_KEY_L); copy = key("copy_nbt", GLFW.GLFW_KEY_C);
        ScreenEvents.AFTER_INIT.register(MenuFeatures::initialize);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> { if (!overlay) AutoLogin.message(message.getString()); });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> AutoLogin.reset());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { AutoLogin.disconnect(); ItemFeatures.clearHovered(); });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (open.wasPressed()) if (mc.currentScreen == null) mc.setScreen(config(null));
            while (board.wasPressed()) if (mc.currentScreen == null) mc.setScreen(new WhiteboardScreen(null));
            AutoLogin.tick(); WallFade.tick();
        });
        WallFade.initialize();
    }
    private static KeyBinding key(String name, int code) { return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zacktills." + name, InputUtil.Type.KEYSYM, code, "category.zacktills")); }
    public static void notifyError(String message) {
        LoggerFactory.getLogger(MOD_ID).error(message);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Zacktills] " + message), false);
    }
}
