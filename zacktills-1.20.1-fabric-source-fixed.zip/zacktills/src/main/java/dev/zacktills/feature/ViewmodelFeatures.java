package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
public final class ViewmodelFeatures {
    private static final double[] previous={0,0},start={-1,-1};
    private static String side(Hand hand){return hand==Hand.MAIN_HAND?"main":"off";}
    public static void transform(Hand hand,MatrixStack matrices) {
        String p="viewmodel."+side(hand)+"_";
        matrices.translate(FeatureSettings.number(p+"x"),FeatureSettings.number(p+"y"),FeatureSettings.number(p+"z"));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)FeatureSettings.number(p+"rx")));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)FeatureSettings.number(p+"ry")));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)FeatureSettings.number(p+"rz")));
        float s=(float)FeatureSettings.number(p+"scale");matrices.scale(s,s,s);
    }
    public static float animation(Hand hand,float vanilla) {
        if(!FeatureSettings.on("viewmodel.enabled"))return vanilla;
        double speed=FeatureSettings.number("viewmodel."+side(hand)+"_speed");
        if(Math.abs(speed-1)<.001)return vanilla;
        int i=hand==Hand.MAIN_HAND?0:1;double now=System.nanoTime()/1e9;
        if(vanilla>0 && (previous[i]<=0 || vanilla+.01<previous[i])) start[i]=now-vanilla*.3/speed;
        previous[i]=vanilla;
        if(start[i]<0)return 0;
        double progress=(now-start[i])*speed/.3;
        if(progress>=1){start[i]=-1;return 0;}
        return (float)Math.max(0,progress);
    }
}
