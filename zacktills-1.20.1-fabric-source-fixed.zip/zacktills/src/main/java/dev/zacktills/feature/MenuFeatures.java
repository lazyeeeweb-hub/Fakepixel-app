package dev.zacktills.feature;
import dev.zacktills.ZacktillsClient;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.screen.v1.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.*;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import java.util.Set;
public final class MenuFeatures {
    private static final Set<String> EXTRA = Set.of("menu.sendFeedback", "menu.reportBugs", "gui.advancements", "gui.stats");
    public static void initialize(MinecraftClient mc, Screen screen, int width, int height) {
        if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
            Screens.getButtons(screen).removeIf(button -> {
                if (!(button.getMessage().getContent() instanceof TranslatableTextContent t)) return false;
                String key = t.getKey();
                return FeatureSettings.on("interface.realms") && (key.equals("menu.online") || key.equals("menu.realms"))
                    || FeatureSettings.on("interface.extras") && EXTRA.contains(key);
            });
            Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Zacktills"), b -> mc.setScreen(ZacktillsClient.config(screen))).dimensions(4, 4, 90, 20).build());
        }
        if (screen instanceof HandledScreen<?>) {
            ItemFeatures.clearHovered();
            ScreenEvents.afterRender(screen).register((s, c, x, y, delta) -> ItemFeatures.render(s, c, x, y));
            ScreenMouseEvents.allowMouseClick(screen).register((s, x, y, button) -> !ItemFeatures.click(x, y, button));
        }
    }
}
