package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.HandledScreenAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import java.util.*;
public final class ItemFeatures {
    private static ItemStack hovered = ItemStack.EMPTY;
    public static void clearHovered() { hovered = ItemStack.EMPTY; }
    public static Set<Integer> locks() {
        Set<Integer> result = new HashSet<>();
        for (String token : FeatureSettings.text("inventory.locked").split(",")) {
            try { int index = Integer.parseInt(token.trim()); if (index >= 0 && index <= 40) result.add(index); }
            catch (NumberFormatException ignored) { /* a partially edited token is not a slot */ }
        }
        return result;
    }
    public static boolean locked(int index) { return FeatureSettings.on("inventory.slot_lock") && locks().contains(index); }
    public static boolean locked(Slot slot) { return slot != null && slot.inventory instanceof PlayerInventory && locked(slot.getIndex()); }
    public static boolean blockClick(int slotId, int button, SlotActionType action) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !FeatureSettings.on("inventory.slot_lock")) return false;
        var handler = mc.player.currentScreenHandler;
        if (slotId >= 0 && slotId < handler.slots.size() && locked(handler.slots.get(slotId))) return true;
        if (action == SlotActionType.SWAP && locked(button)) return true;
        // Conservative: vanilla multi-slot algorithms may choose a locked destination.
        return !locks().isEmpty() && (action == SlotActionType.QUICK_MOVE || action == SlotActionType.QUICK_CRAFT || action == SlotActionType.PICKUP_ALL);
    }
    public static void toggleHovered() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!FeatureSettings.on("inventory.slot_lock") || !(mc.currentScreen instanceof HandledScreen<?>)) return;
        Slot slot = ((HandledScreenAccess) mc.currentScreen).zacktills$focused();
        if (slot == null || !(slot.inventory instanceof PlayerInventory)) return;
        Set<Integer> set = locks(); int index = slot.getIndex();
        if (!set.remove(index)) set.add(index);
        FeatureSettings.text("inventory.locked", set.stream().sorted().map(String::valueOf).collect(java.util.stream.Collectors.joining(",")));
        FeatureSettings.save();
    }
    public static void copy() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!FeatureSettings.on("nbt.enabled") || mc.player == null) return;
        ItemStack target = hovered.isEmpty() ? mc.player.getMainHandStack() : hovered;
        if (target.isEmpty()) return;
        mc.keyboard.setClipboard(target.writeNbt(new NbtCompound()).asString());
        mc.player.sendMessage(Text.literal("Copied item NBT to clipboard"), true);
    }
    public static boolean click(double mx, double my, int button) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!(mc.currentScreen instanceof HandledScreen<?>) || !FeatureSettings.on("nbt.enabled") || button != 0) return false;
        double[] r = HudFeatures.bounds("copy", 80, 20);
        if (mx >= r[0] && my >= r[1] && mx < r[0]+r[2] && my < r[1]+r[3]) { copy(); return true; }
        return false;
    }
    public static void render(Screen screen, DrawContext c, int mx, int my) {
        Slot slot = ((HandledScreenAccess) screen).zacktills$focused();
        if (slot != null && slot.hasStack()) hovered = slot.getStack().copy();
        if (FeatureSettings.on("nbt.enabled")) HudFeatures.drawCopy(c);
    }
}
