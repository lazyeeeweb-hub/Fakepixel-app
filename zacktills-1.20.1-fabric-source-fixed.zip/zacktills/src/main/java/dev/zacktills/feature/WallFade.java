package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/** Screen-door transparency avoids opaque-pass alpha/depth sorting artefacts. Vanilla renderer only. */
public final class WallFade {
    private static final ShaderProgram[] shaders=new ShaderProgram[3];
    private static boolean obstructed;
    private static float fade;
    private static final boolean INCOMPATIBLE=FabricLoader.getInstance().isModLoaded("sodium") || FabricLoader.getInstance().isModLoaded("iris");
    public static void initialize() {
        CoreShaderRegistrationCallback.EVENT.register(context -> {
            context.register(new Identifier("zacktills","fade_solid"),VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL,s->shaders[0]=s);
            context.register(new Identifier("zacktills","fade_cutout"),VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL,s->shaders[1]=s);
            context.register(new Identifier("zacktills","fade_cutout_mipped"),VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL,s->shaders[2]=s);
        });
    }
    public static boolean enabled() {
        var mc=MinecraftClient.getInstance();
        return FeatureSettings.on("camera.fade") && !INCOMPATIBLE && mc.world!=null && !mc.options.getPerspective().isFirstPerson()
            && shaders[0]!=null && shaders[1]!=null && shaders[2]!=null;
    }
    public static void tick() {
        float target=enabled() && obstructed?1:0;
        fade+=(target-fade)*.22f;
        if(fade<.001f)fade=0;
        obstructed=false;
    }
    public static double camera(double wanted,double clipped) {
        if(!enabled())return clipped;
        obstructed |= clipped<wanted-.05;
        return clipped+(wanted-clipped)*fade;
    }
    public static ShaderProgram shader(int type) {
        if(!enabled() || fade<=.001f)return null;
        ShaderProgram shader=shaders[type];
        var radius=shader.getUniform("FadeRadius");
        var amount=shader.getUniform("FadeAmount");
        if(radius!=null)radius.set((float)FeatureSettings.number("camera.radius"));
        if(amount!=null)amount.set(fade*(float)FeatureSettings.number("camera.strength"));
        return shader;
    }
}
