package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import java.util.List;

public final class TooltipFeatures {
    private static List<TooltipComponent> components=List.of();
    private static double offset;
    private static long lastRender;
    private static int fingerprint;
    private static int x,y,w,h,viewport,maxOffset;
    public static boolean draw(DrawContext c,TextRenderer font,List<TooltipComponent> parts,int mx,int my) {
        if(!FeatureSettings.on("tooltip.scroll") || parts.isEmpty())return false;
        var win=MinecraftClient.getInstance().getWindow();
        int width=win.getScaledWidth(),height=win.getScaledHeight();
        int contentH=parts.size()==1?-2:0,contentW=0,hash=1;
        for(TooltipComponent part:parts){ contentH+=part.getHeight();contentW=Math.max(contentW,part.getWidth(font)); hash=31*hash+part.hashCode(); }
        if(contentH<=height-12)return false;
        // Vanilla recreates components each frame; dimensions plus rendered text identity is unreliable.
        // Reset after a gap or changed dimensions; moving to another same-sized tooltip keeps its offset.
        int signature=contentH*31+contentW;
        if(signature!=fingerprint || System.currentTimeMillis()-lastRender>200)offset=0;
        fingerprint=signature;components=parts;lastRender=System.currentTimeMillis();
        w=Math.min(width-12,contentW);h=contentH;viewport=Math.max(1,height-16);
        x=Math.max(6,Math.min(mx+12,width-w-6));y=8;maxOffset=Math.max(0,h-viewport);
        offset=Math.max(0,Math.min(maxOffset,offset));
        c.getMatrices().push(); c.getMatrices().translate(0,0,600);
        c.fill(x-4,y-4,x+w+4,y+viewport+4,0xF0100010);
        HudFeatures.outline(c,x-4,y-4,w+8,viewport+8,0xFF75659B);
        c.enableScissor(x,y,x+w,y+viewport);
        int lineY=y-(int)offset;
        for(int i=0;i<parts.size();i++) {
            TooltipComponent p=parts.get(i);p.drawText(font,x,lineY,c.getMatrices().peek().getPositionMatrix(),c.getVertexConsumers());
            lineY+=p.getHeight()+(i==0?2:0);
        }
        c.draw();lineY=y-(int)offset;
        for(int i=0;i<parts.size();i++) { TooltipComponent p=parts.get(i);p.drawItems(font,x,lineY,c);lineY+=p.getHeight()+(i==0?2:0); }
        c.disableScissor();
        int thumb=Math.max(8,viewport*viewport/Math.max(1,h));
        int track=(int)((viewport-thumb)*offset/Math.max(1,maxOffset));
        c.fill(x+w+1,y+track,x+w+3,y+track+thumb,0xFFBDA7FF);
        c.getMatrices().pop();return true;
    }
    public static boolean scroll(double amount) {
        if(!FeatureSettings.on("tooltip.scroll") || System.currentTimeMillis()-lastRender>200 || maxOffset<=0)return false;
        offset=Math.max(0,Math.min(maxOffset,offset-amount*12));return true;
    }
}
