package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import java.util.Locale;
/** Opt-in, exact-server-allowlisted, unsigned server/game messages only. Secret lives in RAM. */
public final class AutoLogin {
    private static String secret = "";
    private static boolean sent;
    private static int pending = -1;
    public static void password(String value) { secret = value; sent = false; pending = -1; }
    public static void reset() { sent = false; pending = -1; }
    public static void disconnect() { reset(); secret = ""; }
    private static boolean allowed() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return FeatureSettings.on("login.enabled") && !secret.isBlank() && mc.getCurrentServerEntry() != null
            && !FeatureSettings.text("login.server").isBlank()
            && mc.getCurrentServerEntry().address.equalsIgnoreCase(FeatureSettings.text("login.server").trim());
    }
    public static void message(String raw) {
        String prompt = FeatureSettings.text("login.prompt").trim().toLowerCase(Locale.ROOT);
        if (!sent && pending < 0 && allowed() && !prompt.isEmpty() && raw.toLowerCase(Locale.ROOT).contains(prompt)) pending = 10;
    }
    public static void tick() {
        if (pending < 0) return;
        if (!allowed()) { pending = -1; return; }
        if (pending-- > 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null || mc.player == null) { pending = -1; return; }
        String template = FeatureSettings.text("login.command").trim();
        if (template.startsWith("/")) template = template.substring(1);
        if (!template.contains("{password}") || template.contains("\n") || template.contains("\r")) { pending = -1; return; }
        String command = template.replace("{password}", secret);
        if (command.length() > 256 || command.contains("\n") || command.contains("\r")) { pending = -1; return; }
        sent = true; pending = -1; mc.getNetworkHandler().sendChatCommand(command);
    }
}
