package dev.zacktills.feature;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;

public final class HudFeatures {
    private static final Identifier WIDGETS = new Identifier("minecraft", "textures/gui/widgets.png");
    public static double[] bounds(String id, int w, int h) {
        var window = MinecraftClient.getInstance().getWindow();
        double scale = FeatureSettings.pos(id, "scale");
        return new double[]{Math.max(0, window.getScaledWidth()-w*scale)*FeatureSettings.pos(id,"x"),
            Math.max(0, window.getScaledHeight()-h*scale)*FeatureSettings.pos(id,"y"), w*scale, h*scale};
    }
    public static void begin(DrawContext c, String id, int w, int h) {
        double[] b = bounds(id,w,h); float scale = (float) FeatureSettings.pos(id,"scale");
        c.getMatrices().push(); c.getMatrices().translate(b[0],b[1],0); c.getMatrices().scale(scale,scale,1);
    }
    public static void drawCopy(DrawContext c) {
        var mc = MinecraftClient.getInstance(); begin(c,"copy",80,20);
        rounded(c,0,0,80,20,4,0xDD25354B);
        c.drawCenteredTextWithShadow(mc.textRenderer,Text.literal("Copy NBT"),40,6,0xFFFFFF); c.getMatrices().pop();
    }
    public static void hotbar(DrawContext c) {
        var mc = MinecraftClient.getInstance(); if (mc.player == null) return;
        begin(c,"hotbar",182,22);
        c.drawTexture(WIDGETS,0,0,0,0,182,22);
        c.drawTexture(WIDGETS,mc.player.getInventory().selectedSlot*20-1,-1,0,22,24,22);
        for (int i=0;i<9;i++) {
            drawStack(c,mc.player.getInventory().getStack(i),3+i*20,3);
            if (ItemFeatures.locked(i)) outline(c,2+i*20,2,18,18,0xFFFFC24A);
        }
        c.getMatrices().pop();
        begin(c,"offhand",22,22); rounded(c,0,0,22,22,3,0xBB202020);
        drawStack(c,mc.player.getOffHandStack(),3,3);
        if (ItemFeatures.locked(40)) outline(c,1,1,20,20,0xFFFFC24A);
        c.getMatrices().pop();
    }
    private static void drawStack(DrawContext c, ItemStack stack, int x,int y) {
        c.drawItem(stack,x,y); c.drawItemInSlot(MinecraftClient.getInstance().textRenderer,stack,x,y);
    }
    public static void scoreboard(DrawContext c, ScoreboardObjective objective) {
        var mc = MinecraftClient.getInstance(); Scoreboard board = objective.getScoreboard();
        List<ScoreboardPlayerScore> scores = new ArrayList<>(board.getAllPlayerScores(objective));
        scores.removeIf(s -> s.getPlayerName() == null || s.getPlayerName().startsWith("#"));
        scores.sort(ScoreboardPlayerScore.COMPARATOR);
        if (scores.size()>15) scores = scores.subList(scores.size()-15,scores.size());
        List<Text> lines = new ArrayList<>(); int w=mc.textRenderer.getWidth(objective.getDisplayName());
        for (int i=scores.size()-1;i>=0;i--) {
            String name = scores.get(i).getPlayerName();
            Text line = Team.decorateName(board.getPlayerTeam(name),Text.literal(name)); lines.add(line);
            w=Math.max(w,mc.textRenderer.getWidth(line));
        }
        w+=12; int h=16+lines.size()*10;
        begin(c,"scoreboard",w,h);
        int alpha=(int)(255*FeatureSettings.number("scoreboard.opacity"));
        rounded(c,0,0,w,h,(int)FeatureSettings.number("scoreboard.radius"),(alpha<<24)|0x171C24);
        c.drawCenteredTextWithShadow(mc.textRenderer,objective.getDisplayName(),w/2,4,0xFFFFFF);
        for (int i=0;i<lines.size();i++) c.drawTextWithShadow(mc.textRenderer,lines.get(i),6,16+i*10,0xFFFFFF);
        c.getMatrices().pop();
    }
    public static void outline(DrawContext c,int x,int y,int w,int h,int color) {
        c.fill(x,y,x+w,y+1,color); c.fill(x,y+h-1,x+w,y+h,color);
        c.fill(x,y,x+1,y+h,color); c.fill(x+w-1,y,x+w,y+h,color);
    }
    public static void rounded(DrawContext c,int x,int y,int w,int h,int radius,int color) {
        int r=Math.max(0,Math.min(radius,Math.min(w,h)/2));
        for(int row=0;row<h;row++) {
            int inset=0;
            if(row<r) inset=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-Math.pow(r-row-.5,2))));
            else if(row>=h-r) inset=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-Math.pow(row-(h-r)+.5,2))));
            c.fill(x+inset,y+row,x+w-inset,y+row+1,color);
        }
    }
}
