#version 150
#moj_import <fog.glsl>
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float FadeRadius;
uniform float FadeAmount;
uniform float AlphaCutoff;
in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;
void main() {
    vec4 color=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;
    if(color.a<AlphaCutoff) discard;
    float proximity=1.0-smoothstep(0.0,max(0.01,FadeRadius),vertexDistance);
    // Stable 4x4 Bayer ordered dithering: no time-varying sparkle and correct depth writes.
    int bx=int(mod(gl_FragCoord.x,4.0)); int by=int(mod(gl_FragCoord.y,4.0));
    int bayer[16]=int[16](0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5);
    float threshold=(float(bayer[by*4+bx])+0.5)/16.0;
    if(threshold<proximity*FadeAmount) discard;
    fragColor=linear_fog(color,vertexDistance,FogStart,FogEnd,FogColor);
}
