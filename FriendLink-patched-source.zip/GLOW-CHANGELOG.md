# Custom glow replacement

Removed EntityGlowMixin and FriendLink's vanilla-glow lookup path. Added independent LAST-event geometry, six cached custom layers, player-pose-only invokers, radial halo texture and marker fallback. Added global/per-friend settings, new-friend default, labeled chat toolbar and accessible dropdown. Existing G keybind is preserved. Added GlowSettingsTest and an in-game acceptance checklist in README.

Validation: deterministic archive/source checks and Yarn 1.20.1 API checks can be performed here. Java/Gradle and a Minecraft graphics runtime are not available in this environment, so no successful compilation, JUnit execution or in-game/Iris rendering test is claimed. Build with the supplied CI or Java 17 + Gradle 8.6: gradle --no-daemon build stageJar.
