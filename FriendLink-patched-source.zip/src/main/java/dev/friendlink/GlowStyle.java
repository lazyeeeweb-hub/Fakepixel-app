package dev.friendlink;

import com.google.gson.annotations.SerializedName;

/** DEFAULT is only a per-friend inheritance value, never a global render style. */
public enum GlowStyle {
    DEFAULT("Default"),
    @SerializedName(value = "OUTLINE", alternate = {"SILHOUETTE"})
    OUTLINE("Outline"), HALO("Halo"), MARKER("Marker");
    private final String label;
    GlowStyle(String label) { this.label = label; }
    @Override public String toString() { return label; }
    public static GlowStyle resolve(GlowStyle local, GlowStyle global) {
        if (local != null && local != DEFAULT) return local;
        return global == null || global == DEFAULT ? MARKER : global;
    }
}
