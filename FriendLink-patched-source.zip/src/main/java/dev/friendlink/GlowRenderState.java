package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import java.util.function.Supplier;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferRenderer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

/** Reusable state guard for the Minecraft-backed Marker/Halo draw. No frame-local buffers. */
final class GlowRenderState {
    private final ByteBuffer mask = BufferUtils.createByteBuffer(4);
    private ShaderProgram shader;
    private final Supplier<ShaderProgram> shaderSupplier = () -> shader;
    private int program, texture, active, activeTexture, texture0, vao, arrayBuffer, elementBuffer;
    private int depthFunc, srcRgb, dstRgb, srcAlpha, dstAlpha, equationRgb, equationAlpha;
    private boolean blend, depth, cull, depthWrite;
    private float r, g, b, a;
    void capture() {
        shader = RenderSystem.getShader(); texture = RenderSystem.getShaderTexture(0);
        float[] rgba = RenderSystem.getShaderColor(); r = rgba[0]; g = rgba[1]; b = rgba[2]; a = rgba[3];
        program = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        active = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
        activeTexture = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        texture0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        GL13.glActiveTexture(active);
        vao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        arrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        elementBuffer = GL11.glGetInteger(GL15.GL_ELEMENT_ARRAY_BUFFER_BINDING);
        blend = GL11.glIsEnabled(GL11.GL_BLEND); depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST); cull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        depthWrite = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK); depthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
        srcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB); dstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        srcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA); dstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        equationRgb = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_RGB); equationAlpha = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_ALPHA);
        mask.clear(); GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK, mask);
    }
    void restore() {
        // BufferRenderer caches its current vertex buffer; invalidate before restoring the prior VAO.
        BufferRenderer.reset();
        RenderSystem.setShader(shaderSupplier); RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShaderColor(r, g, b, a);
        if (blend) RenderSystem.enableBlend(); else RenderSystem.disableBlend();
        if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        if (cull) RenderSystem.enableCull(); else RenderSystem.disableCull();
        RenderSystem.depthFunc(depthFunc); RenderSystem.depthMask(depthWrite);
        RenderSystem.blendFuncSeparate(srcRgb, dstRgb, srcAlpha, dstAlpha);
        GL20.glBlendEquationSeparate(equationRgb, equationAlpha);
        RenderSystem.colorMask(mask.get(0) != 0, mask.get(1) != 0, mask.get(2) != 0, mask.get(3) != 0);
        GL20.glUseProgram(program);
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, arrayBuffer);
        if (vao != 0) GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, elementBuffer);
        GL13.glActiveTexture(GL13.GL_TEXTURE0); GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture0);
        GL13.glActiveTexture(active); GL11.glBindTexture(GL11.GL_TEXTURE_2D, activeTexture);
    }
}
