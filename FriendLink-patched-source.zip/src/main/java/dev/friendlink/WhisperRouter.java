package dev.friendlink;

import dev.friendlink.Models.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** ALLOW_GAME and ALLOW_CHAT run before HUD insertion. Returning true here means suppress. */
public final class WhisperRouter {
    /** Narrow package-private seam: tests exercise the real router without booting a client. */
    interface Host {
        Config config();
        State state();
        Friend friend(String name, UUID uuid);
        String self();
        void touch();
        boolean echo(String name, String body);
        boolean notFound();
        void append(String key, Message message, boolean incoming);
        void inviteNotice(Group group, String sender);
        void receiveInvite(String sender, Protocol.Invite invite);
        default boolean reliable(String sender, String body, boolean outgoing) { return false; }
    }
    private record ModHost(FriendLink mod) implements Host {
        public Config config() { return mod.config; }
        public State state() { return mod.state; }
        public Friend friend(String name, UUID uuid) { return mod.friend(name, uuid); }
        public String self() { return mod.self(); }
        public void touch() { mod.touch(); }
        public boolean echo(String name, String body) { return mod.queue.echo(name, body); }
        public boolean notFound() { return mod.queue.notFound(); }
        public void append(String key, Message message, boolean incoming) { mod.append(key, message, incoming); }
        public void inviteNotice(Group group, String sender) { mod.inviteNotice(group, sender); }
        public void receiveInvite(String sender, Protocol.Invite invite) { mod.receiveInvite(sender, invite); }
        public boolean reliable(String sender, String body, boolean outgoing) { return mod.receipts.receive(sender, body, outgoing); }
    }
    private final Host host;
    private WhisperText textRules;
    private final List<Pattern> errors = new ArrayList<>();
    private final Map<String, Assembly> assemblies = new HashMap<>();
    private Pattern groupPattern;
    private ClientPlayNetworkHandler connection;
    private MessageType incomingType, outgoingType, incomingTeamType, outgoingTeamType;
    private static final class Assembly {
        final String[] chunks;
        final long expires = System.currentTimeMillis() + 60000;
        Assembly(int count) { chunks = new String[count]; }
    }
    public WhisperRouter(FriendLink mod) { this(new ModHost(mod)); }
    WhisperRouter(Host host) { this.host = host; reload(); }
    public void reload() {
        Config config = host.config();
        textRules = new WhisperText(config.dialogueRegex, config.incomingRegex, config.outgoingRegex,
            regex -> FriendLink.LOG.warn("Ignored invalid FriendLink regex: {}", regex));
        errors.clear();
        if (config.notFoundRegex != null) for (String regex : config.notFoundRegex) {
            if (errors.size() == 32) break;
            if (regex == null || regex.length() > 1024 || !Config.validRegex(regex, false)) {
                FriendLink.LOG.warn("Ignored invalid FriendLink regex: {}", regex); continue;
            }
            errors.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
        }
        groupPattern = Protocol.groupPattern(config.groupTag);
    }
    public void tick(long now) { assemblies.values().removeIf(a -> a.expires < now); }
    public void clear() {
        assemblies.clear();
        connection = null;
        incomingType = outgoingType = incomingTeamType = outgoingTeamType = null;
    }
    /** Resolve registry instances once for each connection, never once per message. */
    public void connected(MinecraftClient client) {
        if (client == null || client.player == null) return;
        ClientPlayNetworkHandler handler = client.player.networkHandler;
        if (connection == handler) return;
        clear();
        var types = handler.getRegistryManager().get(RegistryKeys.MESSAGE_TYPE);
        incomingType = types.get(MessageType.MSG_COMMAND_INCOMING);
        outgoingType = types.get(MessageType.MSG_COMMAND_OUTGOING);
        incomingTeamType = types.get(MessageType.TEAM_MSG_COMMAND_INCOMING);
        outgoingTeamType = types.get(MessageType.TEAM_MSG_COMMAND_OUTGOING);
        connection = handler;
    }
    /** Typed whispers belong exclusively to the Mixin; team chat never enters regex parsing. */
    public boolean bypassTextFallback(MessageType.Parameters params) {
        connected(MinecraftClient.getInstance());
        return params != null && (params.type() == incomingType || params.type() == outgoingType
            || params.type() == incomingTeamType || params.type() == outgoingTeamType);
    }
    /** Only called by the signed-chat HEAD Mixin, after vanilla secure-only/blocked checks. */
    public boolean receiveTyped(MessageType.Parameters params, SignedMessage message, GameProfile sender) {
        // Do not resolve identity, update UUIDs, acknowledge sends or file invisible content.
        String body = visibleBody(message);
        if (body == null || params == null) return false;
        connected(MinecraftClient.getInstance());
        boolean outgoing = params.type() == outgoingType;
        if (!outgoing && params.type() != incomingType) return false;
        String name = outgoing ? (params.targetName() == null ? null : params.targetName().getString())
            : sender == null ? null : sender.getName();
        return receiveParticipant(name, outgoing || sender == null ? null : sender.getId(), body, outgoing);
    }
    /** getContent() does NOT apply the filter mask; never persist the original masked characters. */
    static String visibleBody(SignedMessage message) {
        if (message == null || message.isFullyFiltered()) return null;
        String visible = message.filterMask().isPassThrough() ? message.getContent().getString()
            : message.filterMask().filter(message.getSignedContent());
        return visibleBody(false, visible);
    }
    /** Content-only privacy gate: callers supply only already-filtered content, never signed raw text. */
    static String visibleBody(boolean fullyFiltered, String alreadyFilteredContent) {
        return fullyFiltered ? null : alreadyFilteredContent;
    }
    /** Profileless typed chat has raw content but skips processChatMessageInternal entirely. */
    public boolean receiveProfileless(MessageType.Parameters params, Text content) {
        if (params == null || content == null) return false;
        connected(MinecraftClient.getInstance());
        boolean outgoing = params.type() == outgoingType;
        if (!outgoing && params.type() != incomingType) return false;
        Text participant = outgoing ? params.targetName() : params.name();
        return participant != null && receiveParticipant(participant.getString(), null, content.getString(), outgoing);
    }
    /** Shared typed/profileless/text route; suppression is authorized only by an existing friend. */
    boolean receiveParticipant(String display, UUID uuid, String body, boolean outgoing) {
        if (body == null) return false;
        String name = WhisperText.playerName(display);
        Friend friend = host.friend(name, uuid);
        if (friend == null) return false;
        if (!outgoing && uuid != null && !uuid.toString().equalsIgnoreCase(friend.uuid)) {
            friend.uuid = uuid.toString(); host.touch();
        }
        route(friend, name == null ? friend.name : name, WhisperText.strip(body), outgoing);
        return true;
    }
    private void route(Friend friend, String wireName, String body, boolean outgoing) {
        if (outgoing && (host.echo(wireName, body)
            || (!friend.name.equalsIgnoreCase(wireName) && host.echo(friend.name, body)))) return;
        if (host.reliable(friend.name, body, outgoing)) return;
        if (body.startsWith("[FLI:")) {
            if (!outgoing) control(friend.name, body);
            return;
        }
        Matcher group = groupPattern.matcher(body);
        if (group.matches()) {
            if (!outgoing) groupMessage(friend.name, group.group("id"), group.group("message"));
            else {
                Group g = host.state().groups.get(group.group("id"));
                if (g != null && !g.left && !g.pending && FriendLink.contains(g.members, friend.name))
                    host.append("g:" + g.id, new Message(host.self(), group.group("message"), false), false);
            }
            return;
        }
        host.append("f:" + Protocol.key(friend.name), new Message(outgoing ? host.self() : friend.name, body, false), !outgoing);
    }
    /** Fabric ALLOW_GAME / untyped ALLOW_CHAT fallback. No time/body deduplication. */
    public boolean receive(String raw) {
        if (raw == null || raw.length() > 8192 || WhisperText.publicChat(raw)) return false;
        WhisperText.Parsed parsed = textRules.parse(raw, host.self());
        if (parsed != null)
            return receiveParticipant(parsed.name(), null, parsed.body(), parsed.outgoing());
        String text = WhisperText.strip(raw);
        for (Pattern pattern : errors) if (pattern.matcher(text).matches()) return host.notFound();
        return false;
    }
    private void groupMessage(String sender, String id, String text) {
        Group g = host.state().groups.get(id);
        if (g == null) {
            if (host.state().groups.size() >= 128) return;
            g = new Group(); g.id = id; g.owner = sender; g.revision = -1;
            g.members.add(sender);
            if (!sender.equalsIgnoreCase(host.self())) g.members.add(host.self());
            host.state().groups.put(id, g);
            host.inviteNotice(g, sender);
        }
        if (g.left || !FriendLink.contains(g.members, sender) || !FriendLink.contains(g.members, host.self())) return;
        // Pending groups retain a bounded preview, but cannot transmit until explicitly accepted.
        host.append("g:" + id, new Message(sender, text, false), true);
    }
    private void control(String sender, String body) {
        Matcher m = Protocol.CONTROL.matcher(body);
        if (!m.matches() || !Protocol.validId(m.group("id"))) return;
        int count = Integer.parseInt(m.group("count")), part = Integer.parseInt(m.group("part"));
        if (count < 1 || count > 16 || part < 1 || part > count) return;
        String key = Protocol.key(sender) + ":" + m.group("id") + ":" + m.group("token");
        Assembly a = assemblies.get(key);
        if (a == null) {
            if (assemblies.size() >= 32) return;
            a = new Assembly(count); assemblies.put(key, a);
        }
        if (a.chunks.length != count) { assemblies.remove(key); return; }
        a.chunks[part - 1] = m.group("data");
        for (String chunk : a.chunks) if (chunk == null) return;
        assemblies.remove(key);
        try {
            Protocol.Invite i = Protocol.decodeInvite(String.join("", a.chunks));
            if (!Protocol.validInvite(i, host.config().maxGroupSize) || !i.id.equals(m.group("id"))) return;
            host.receiveInvite(sender, i);
        } catch (RuntimeException e) { FriendLink.LOG.debug("Rejected malformed FriendLink invitation", e); }
    }
}
