package dev.friendlink;

import dev.friendlink.Models.Friend;
import dev.friendlink.Models.State;
import java.util.UUID;

/** Name matching remains case-insensitive; a learned UUID also survives a name change. */
public final class FriendIdentity {
    private FriendIdentity() {}
    public static Friend find(State state, String name, UUID uuid) {
        if (uuid != null) {
            String id = uuid.toString();
            for (Friend f : state.friends.values()) if (id.equalsIgnoreCase(f.uuid)) return f;
        }
        return name == null ? null : state.friends.get(Protocol.key(name));
    }
}
