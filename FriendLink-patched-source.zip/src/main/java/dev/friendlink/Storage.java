package dev.friendlink;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import dev.friendlink.Models.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Client-facing saves only serialize immutable strings. All split-storage disk work, migration,
 * delayed saves and receipt barriers use one ordered worker. Callers must publish loaded models
 * on their client thread and set logLoaded themselves. The legacy synchronous read() is retained;
 * use readAsync() instead on a client/render thread.
 */
public final class Storage implements AutoCloseable {
    public static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String STATE_FILE = "state.json", FRIENDS_FILE = "friends.json", GROUPS_FILE = "groups.json";
    private static final long MAX_BYTES = 64L * 1024 * 1024;
    private static final long DEBOUNCE_MS = 150;
    private static final Type FRIENDS_TYPE = new TypeToken<LinkedHashMap<String, Friend>>() {}.getType();
    private static final Type GROUPS_TYPE = new TypeToken<LinkedHashMap<String, Group>>() {}.getType();
    private static final Type LOG_TYPE = new TypeToken<ArrayList<Message>>() {}.getType();
    private static final ExclusionStrategy METADATA_FIELDS = new ExclusionStrategy() {
        @Override public boolean shouldSkipField(FieldAttributes field) {
            return field.getName().equals("messages")
                && (field.getDeclaringClass() == Friend.class || field.getDeclaringClass() == Group.class);
        }
        @Override public boolean shouldSkipClass(Class<?> type) { return false; }
    };
    private static final Gson METADATA_JSON = new GsonBuilder().setPrettyPrinting()
        .addSerializationExclusionStrategy(METADATA_FIELDS)
        .addDeserializationExclusionStrategy(METADATA_FIELDS).create();

    /** This file is also the split migration commit marker and is always written last. */
    private static final class StateMetadata {
        int schema = 1;
        String lastConversation = "";
        int splitStorageVersion;
        StateMetadata() {}
        StateMetadata(State state) {
            schema = state.schema;
            lastConversation = state.lastConversation == null ? "" : state.lastConversation;
            splitStorageVersion = 1;
        }
    }

    private final Path root, base;
    private final ScheduledThreadPoolExecutor io = new ScheduledThreadPoolExecutor(1, r -> {
        Thread t = new Thread(r, "FriendLink-storage"); t.setDaemon(true); return t;
    });
    private final Object submissions = new Object();
    // Guarded by submissions. Merging retains logs captured by an earlier loaded-only save.
    private LinkedHashMap<String, String> pending;
    private ScheduledFuture<?> delayed;
    private boolean closed;
    private boolean warnedDirectoryForce;

    public Storage(Path root) {
        this.root = java.util.Objects.requireNonNull(root, "root");
        this.base = root.toAbsolutePath().normalize(); // no filesystem access
        io.setRemoveOnCancelPolicy(true);
        io.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
    }
    public Path root() { return root; }

    /** Compatibility API: synchronous disk IO. Missing/corrupt input returns fallback. */
    public <T> T read(String file, Class<T> type, T fallback) {
        relativePath(file);
        try {
            T value = readDocument(file, type, JSON, false);
            return value == null ? fallback : value;
        } catch (Exception e) {
            FriendLink.LOG.warn("Could not read FriendLink {}. Using fallback; original/backup retained.", file, e);
            return fallback;
        }
    }
    /** Read/parse on the ordered worker; callbacks must marshal client state to the client thread. */
    public <T> CompletableFuture<T> readAsync(String file, Class<T> type, T fallback) {
        relativePath(file);
        return submit(() -> read(file, type, fallback));
    }
    public void write(String file, Object data) {
        relativePath(file);
        String snapshot = JSON.toJson(data);
        enqueue(() -> atomicWrite(file, snapshot), "save " + file);
    }

    /** First-run split migration and all reads happen off-thread. No conversation log is loaded. */
    public CompletableFuture<State> loadStateAsync(Config config) {
        int max = Math.max(0, java.util.Objects.requireNonNull(config, "config").maxMessages);
        return submit(() -> loadState(max));
    }
    /** Returns a clean, mutable, newest-N list; does not change any parent's logLoaded flag. */
    public CompletableFuture<List<Message>> loadLogAsync(String conversation, int max) {
        String file = logFile(conversation);
        int limit = Math.max(0, max);
        return submit(() -> {
            List<Message> messages = readDocument(file, LOG_TYPE, JSON, false);
            return clean(messages, limit);
        });
    }
    /**
     * Snapshots metadata and ONLY logs whose parent-owned logLoaded flag is true. Coalesces for
     * at most DEBOUNCE_MS; no live model/list is retained. Does not delete absent/unloaded logs.
     * As this API is void, background failures are logged. Use saveLogAsync for a receipt barrier.
     */
    public void saveState(State state) {
        LinkedHashMap<String, String> snapshot = snapshot(java.util.Objects.requireNonNull(state, "state"), false);
        synchronized (submissions) {
            requireOpen();
            if (pending == null) pending = new LinkedHashMap<>();
            pending.putAll(snapshot);
            if (delayed == null) delayed = io.schedule(this::flushDelayed, DEBOUNCE_MS, TimeUnit.MILLISECONDS);
        }
    }
    /**
     * Captures now and writes after all earlier saves. Completes only after file force, atomic
     * rename and directory force where supported. Unsupported atomic moves fail (no unsafe
     * replacement fallback). Failures are logged and complete exceptionally: do not send a receipt.
     */
    public CompletableFuture<Void> saveLogAsync(String key, List<Message> log) {
        String file = logFile(key);
        String snapshot = JSON.toJson(log == null ? new ArrayList<Message>() : log);
        return submit(() -> { atomicWrite(file, snapshot); return null; });
    }
    public void deleteLog(String key) {
        String file = logFile(key);
        enqueue(() -> {
            Path path = checkedPath(file);
            if (Files.deleteIfExists(path)) forceDirectory(path.getParent());
        }, "delete " + file);
    }

    private State loadState(int max) throws IOException {
        // Presence of state.json means migration committed. Never replay stale legacy data over it.
        Path marker = checkedPath(STATE_FILE);
        if (Files.exists(marker, LinkOption.NOFOLLOW_LINKS)) return loadSplit(max);
        Path legacy = checkedPath("conversations.json");
        State state;
        if (Files.exists(legacy, LinkOption.NOFOLLOW_LINKS)) {
            // A durable COPY precedes every split write; never rename/delete the legacy source.
            backupCopy(legacy, ".backup-");
            state = readDocument("conversations.json", State.class, JSON, true);
            state = normalize(state, configWithLimit(max));
            writeBatch(snapshot(state, true)); // all logs, maps, then state.json as commit marker
        } else {
            // Can also recover maps from an interrupted initial (non-legacy) save.
            state = readMaps(false);
            state = normalize(state, configWithLimit(max));
            writeBatch(snapshot(state, false));
        }
        unload(state);
        return state;
    }
    private State loadSplit(int max) throws IOException {
        StateMetadata metadata = readDocument(STATE_FILE, StateMetadata.class, JSON, true);
        if (metadata.splitStorageVersion < 0 || metadata.splitStorageVersion > 1)
            throw new IOException("Unsupported FriendLink split storage version " + metadata.splitStorageVersion);
        State state = readMaps(true);
        state.schema = metadata.schema;
        state.lastConversation = metadata.lastConversation;
        return normalize(state, configWithLimit(max));
    }
    private State readMaps(boolean required) throws IOException {
        State state = new State();
        LinkedHashMap<String, Friend> friends = readDocument(FRIENDS_FILE, FRIENDS_TYPE, METADATA_JSON, required);
        LinkedHashMap<String, Group> groups = readDocument(GROUPS_FILE, GROUPS_TYPE, METADATA_JSON, required);
        if (friends != null) state.friends = friends;
        if (groups != null) state.groups = groups;
        // Metadata Gson ignores messages even if an old/manual metadata file contains that field.
        return state;
    }
    private static void unload(State state) {
        for (Friend friend : state.friends.values()) friend.messages = new ArrayList<>();
        for (Group group : state.groups.values()) group.messages = new ArrayList<>();
        // Do not set logLoaded here or anywhere in storage. Gson ignores the transient field.
    }
    private static Config configWithLimit(int max) {
        Config config = new Config(); config.maxMessages = max; return config;
    }
    private static long activity(List<Message> messages) {
        long latest = 0;
        if (messages != null) for (Message message : messages)
            if (message != null && message.sender != null && message.text != null) latest = Math.max(latest, message.time);
        return latest;
    }
    private static LinkedHashMap<String, String> snapshot(State state, boolean allLogs) {
        LinkedHashMap<String, String> result = new LinkedHashMap<>();
        Map<String, Friend> friends = state.friends == null ? new LinkedHashMap<>() : state.friends;
        Map<String, Group> groups = state.groups == null ? new LinkedHashMap<>() : state.groups;
        JsonObject friendMeta = METADATA_JSON.toJsonTree(friends).getAsJsonObject();
        JsonObject groupMeta = METADATA_JSON.toJsonTree(groups).getAsJsonObject();
        for (var entry : friends.entrySet()) {
            Friend friend = entry.getValue();
            if (friend == null) continue;
            friendMeta.getAsJsonObject(entry.getKey()).addProperty("lastActivity", Math.max(friend.lastActivity, activity(friend.messages)));
            if (allLogs || friend.logLoaded) result.put(logFile("f:" + friend.name), JSON.toJson(friend.messages == null ? List.of() : friend.messages));
        }
        for (var entry : groups.entrySet()) {
            Group group = entry.getValue();
            if (group == null) continue;
            groupMeta.getAsJsonObject(entry.getKey()).addProperty("lastActivity", Math.max(group.lastActivity, activity(group.messages)));
            if (allLogs || group.logLoaded) result.put(logFile("g:" + group.id), JSON.toJson(group.messages == null ? List.of() : group.messages));
        }
        result.put(FRIENDS_FILE, JSON.toJson(friendMeta));
        result.put(GROUPS_FILE, JSON.toJson(groupMeta));
        result.put(STATE_FILE, JSON.toJson(new StateMetadata(state)));
        return result;
    }

    // Submission barriers drain pending debounced snapshots BEFORE queuing newer operations.
    private <T> CompletableFuture<T> submit(Callable<T> operation) {
        synchronized (submissions) {
            if (closed) return CompletableFuture.failedFuture(new IllegalStateException("Storage is closed"));
            flushPendingLocked();
            return CompletableFuture.supplyAsync(() -> {
                try { return operation.call(); }
                catch (Exception e) {
                    FriendLink.LOG.error("FriendLink storage operation failed", e);
                    throw new CompletionException(e);
                }
            }, io);
        }
    }
    @FunctionalInterface private interface DiskOperation { void run() throws IOException; }
    private void enqueue(DiskOperation operation, String description) {
        synchronized (submissions) {
            requireOpen();
            flushPendingLocked();
            io.execute(() -> {
                try { operation.run(); }
                catch (Exception e) { FriendLink.LOG.error("Could not {}", description, e); }
            });
        }
    }
    private void requireOpen() {
        if (closed) throw new IllegalStateException("Storage is closed");
    }
    private LinkedHashMap<String, String> takePendingLocked() {
        if (delayed != null) delayed.cancel(false);
        delayed = null;
        LinkedHashMap<String, String> batch = pending;
        pending = null;
        return batch;
    }
    private void flushPendingLocked() {
        LinkedHashMap<String, String> batch = takePendingLocked();
        if (batch != null) io.execute(() -> writeBatchLogged(batch));
    }
    private void flushDelayed() {
        LinkedHashMap<String, String> batch;
        synchronized (submissions) { batch = takePendingLocked(); }
        if (batch != null) writeBatchLogged(batch);
    }
    private void writeBatchLogged(LinkedHashMap<String, String> batch) {
        try { writeBatch(batch); }
        catch (Exception e) { FriendLink.LOG.error("Could not save FriendLink split state; existing files/legacy backup retained", e); }
    }
    private void writeBatch(LinkedHashMap<String, String> batch) throws IOException {
        for (var entry : batch.entrySet())
            if (!entry.getKey().equals(STATE_FILE) && !entry.getKey().equals(FRIENDS_FILE) && !entry.getKey().equals(GROUPS_FILE))
                atomicWrite(entry.getKey(), entry.getValue());
        if (batch.containsKey(FRIENDS_FILE)) atomicWrite(FRIENDS_FILE, batch.get(FRIENDS_FILE));
        if (batch.containsKey(GROUPS_FILE)) atomicWrite(GROUPS_FILE, batch.get(GROUPS_FILE));
        if (batch.containsKey(STATE_FILE)) atomicWrite(STATE_FILE, batch.get(STATE_FILE));
    }

    private static String logFile(String conversation) {
        if (conversation != null && conversation.startsWith("f:") && Protocol.validName(conversation.substring(2)))
            return "chats/friends/" + Protocol.key(conversation.substring(2)) + ".json";
        if (conversation != null && conversation.startsWith("g:") && Protocol.validId(conversation.substring(2)))
            return "chats/groups/" + conversation.substring(2) + ".json";
        throw new IllegalArgumentException("Invalid FriendLink conversation key: " + conversation);
    }
    /** Lexical validation only; safe on the client thread. */
    private Path relativePath(String file) {
        if (file == null || file.isBlank() || file.indexOf('\\') >= 0)
            throw new IllegalArgumentException("Invalid storage path");
        Path relative = Path.of(file);
        if (relative.isAbsolute()) throw new IllegalArgumentException("Absolute storage path");
        for (Path part : relative) if (part.toString().equals("..") || part.toString().equals("."))
            throw new IllegalArgumentException("Storage path traversal");
        Path resolved = base.resolve(relative).normalize();
        if (resolved.equals(base) || !resolved.startsWith(base)) throw new IllegalArgumentException("Storage path traversal");
        return resolved;
    }
    /** Worker-only symlink checks, in addition to strict conversation identifiers. */
    private Path checkedPath(String file) throws IOException {
        Path path = relativePath(file);
        Path cursor = base.getRoot();
        for (Path part : path) {
            cursor = cursor.resolve(part);
            if (Files.isSymbolicLink(cursor)) throw new IOException("Refusing symbolic-link storage path: " + cursor);
        }
        return path;
    }
    private <T> T readDocument(String file, Type type, Gson gson, boolean required) throws IOException {
        Path path = checkedPath(file);
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            if (required) throw new IOException("Missing required FriendLink file: " + path);
            return null;
        }
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Not a regular file: " + path);
        try {
            if (Files.size(path) > MAX_BYTES) throw new IOException("File exceeds 64 MiB safety limit");
            T value = gson.fromJson(Files.readString(path, StandardCharsets.UTF_8), type);
            if (value == null) throw new IOException("Null/empty JSON document: " + path);
            return value;
        } catch (Exception failure) {
            try { backupCopy(path, ".broken-"); }
            catch (IOException backup) {
                failure.addSuppressed(backup);
                FriendLink.LOG.error("Could not preserve corrupt-file backup for {}", path, backup);
            }
            throw new IOException("Could not read " + path + "; original retained", failure);
        }
    }
    private void backupCopy(Path path, String suffix) throws IOException {
        Path backup = path.resolveSibling(path.getFileName() + suffix + System.currentTimeMillis() + "-" + UUID.randomUUID());
        Files.copy(path, backup); // no REPLACE_EXISTING; keep every corrupt/migration backup
        try (FileChannel channel = FileChannel.open(backup, StandardOpenOption.WRITE)) { channel.force(true); }
        forceDirectory(backup.getParent());
    }
    private void atomicWrite(String file, String snapshot) throws IOException {
        Path destination = checkedPath(file);
        Path parent = destination.getParent();
        // Make each directory entry durable, not just the final JSON rename.
        createDirectories(parent);
        destination = checkedPath(file);
        byte[] bytes = snapshot.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_BYTES) throw new IOException("Snapshot exceeds 64 MiB safety limit: " + file);
        Path temporary = Files.createTempFile(parent, destination.getFileName() + ".", ".tmp");
        try {
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                ByteBuffer buffer = ByteBuffer.wrap(bytes);
                while (buffer.hasRemaining()) channel.write(buffer);
                channel.force(true);
            }
            Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            forceDirectory(parent);
        } finally {
            Files.deleteIfExists(temporary);
        }
    }
    private void createDirectories(Path directory) throws IOException {
        if (Files.isDirectory(directory, LinkOption.NOFOLLOW_LINKS)) return;
        Path parent = directory.getParent();
        if (parent != null) createDirectories(parent);
        try { Files.createDirectory(directory); }
        catch (FileAlreadyExistsException e) {
            if (!Files.isDirectory(directory, LinkOption.NOFOLLOW_LINKS)) throw e;
        }
        if (parent != null) forceDirectory(parent);
    }
    private void forceDirectory(Path directory) throws IOException {
        try (FileChannel channel = FileChannel.open(directory, StandardOpenOption.READ)) { channel.force(true); }
        catch (UnsupportedOperationException | AccessDeniedException e) {
            // Windows/some providers cannot open a directory channel. File force + atomic rename
            // still happen; report the reduced power-loss guarantee instead of hiding it.
            if (!warnedDirectoryForce) {
                warnedDirectoryForce = true;
                FriendLink.LOG.warn("Directory fsync is unavailable at {}; file force and atomic rename remain enabled", directory, e);
            }
        }
    }

    /** Preserve the existing schema/glow migration, without treating unfinished sends as complete. */
    public static State normalize(State s, Config config) {
        if (s == null) s = new State();
        int max = Math.max(0, config == null ? 1000 : config.maxMessages);
        if (s.lastConversation == null) s.lastConversation = "";
        LinkedHashMap<String, Friend> friends = new LinkedHashMap<>();
        if (s.friends != null) for (Friend f : s.friends.values()) {
            if (f == null || !Protocol.validName(f.name) || friends.size() >= 512) continue;
            f.normalizeGlow(); f.unread = Math.max(0, f.unread);
            f.lastActivity = Math.max(Math.max(0, f.lastActivity), activity(f.messages));
            f.messages = clean(f.messages, max);
            friends.putIfAbsent(Protocol.key(f.name), f);
        }
        s.friends = friends;
        if (s.schema < 2) {
            for (Friend f : s.friends.values()) f.glow = true;
            s.schema = 2;
        }
        LinkedHashMap<String, Group> groups = new LinkedHashMap<>();
        if (s.groups != null) for (Group g : s.groups.values()) {
            if (g == null || !Protocol.validId(g.id) || groups.size() >= 128) continue;
            List<String> members = new ArrayList<>();
            if (g.members != null) for (String member : g.members) if (Protocol.validName(member)) members.add(member);
            g.members = members;
            if (g.name == null || g.name.isBlank()) g.name = "Unknown group";
            g.name = g.name.substring(0, Math.min(g.name.length(), 32));
            if (!Protocol.validName(g.owner)) g.owner = g.members.isEmpty() ? "Unknown" : g.members.get(0);
            g.unread = Math.max(0, g.unread);
            g.lastActivity = Math.max(Math.max(0, g.lastActivity), activity(g.messages));
            g.messages = clean(g.messages, max);
            groups.put(g.id, g);
        }
        s.groups = groups;
        return s;
    }
    private static List<Message> clean(List<Message> messages, int max) {
        ArrayList<Message> result = new ArrayList<>();
        if (messages != null) for (Message message : messages)
            if (message != null && message.sender != null && message.text != null) result.add(message);
        int limit = Math.max(0, max);
        if (result.size() > limit) result = new ArrayList<>(result.subList(result.size() - limit, result.size()));
        for (Message message : result) {
            if (message.id == null) message.id = "";
            if (message.receiptId == null) message.receiptId = "";
            if (message.delivery == null) message.delivery = new LinkedHashMap<>();
            message.delivery.entrySet().removeIf(e -> e.getKey() == null || e.getValue() == null);
            for (Delivery delivery : message.delivery.values()) {
                if (delivery.parts == null) delivery.parts = new LinkedHashMap<>();
                delivery.parts.replaceAll((id, stage) -> stage == null || stage < 0 || stage > 4 ? 0 : stage);
                // Never change legacy completed/unconfirmed counters or infer a receipt from disk.
            }
        }
        return result;
    }
    @Override public void close() {
        synchronized (submissions) {
            if (closed) return;
            flushPendingLocked();
            closed = true;
            // Nonblocking for client/render threads. Queued snapshots and barriers drain in order.
            io.shutdown();
        }
    }
}
