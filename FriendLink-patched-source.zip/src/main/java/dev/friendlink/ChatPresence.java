package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.friendlink.Models.Friend;
import java.util.Arrays;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Nearby, capability-gated chat-presence protocol and cached speech-bubble renderer. */
public final class ChatPresence {
    private static final int LIMIT = 256;
    private static final int COLOR = 0xF0E8EEFF;
    private final FriendLink mod;
    private final String[] announced = new String[LIMIT];
    private int announcedCount;
    private final String[] remoteNames = new String[LIMIT];
    private final long[] remoteExpiry = new long[LIMIT];
    private int remoteCount;
    private final Bubble[] bubbles = new Bubble[LIMIT];
    private int bubbleCount;
    private boolean chatOpen, initialized;

    private static final class Bubble {
        String name;
        double x, y, z;
    }

    public ChatPresence(FriendLink mod) {
        this.mod = mod;
        for (int i = 0; i < bubbles.length; i++) bubbles[i] = new Bubble();
    }

    /** Parent calls once during client initialization. */
    public void init() {
        if (initialized) return;
        initialized = true;
        // World-render event hook: draw only the positions and active names prepared by tick().
        WorldRenderEvents.AFTER_ENTITIES.register(this::render);
    }

    /** Called by the parent on client ticks; entity iteration and cache updates stay off the render path. */
    public void tick(MinecraftClient mc, long now) {
        expire(now);
        bubbleCount = 0;
        if (mc.world == null || mc.player == null) return;
        var players = mc.world.getPlayers();
        // Forget peers which left entity render range; an open screen will announce them again if they return.
        for (int i = announcedCount - 1; i >= 0; i--) {
            if (!nearby(players, announced[i])) removeAnnounced(i);
        }
        if (chatOpen) {
            for (int i = 0; i < players.size(); i++) {
                PlayerEntity player = players.get(i);
                if (player == mc.player || player.isRemoved()) continue;
                String name = player.getGameProfile().getName();
                Friend friend = mod.friend(name);
                if (friend == null || !friend.shareChatOpen.resolve(mod.config.shareChatOpen)
                    || !mod.capable(name) || announcedIndex(name) >= 0 || announcedCount == LIMIT) continue;
                if (mod.sendControl(name, "[FLC:O]")) announced[announcedCount++] = name;
            }
        }
        if (!mod.config.chatBubbles) return;
        for (int i = 0; i < players.size() && bubbleCount < bubbles.length; i++) {
            PlayerEntity player = players.get(i);
            if (player == mc.player || player.isRemoved()) continue;
            String name = player.getGameProfile().getName();
            int state = remoteIndex(name);
            if (state < 0 || remoteExpiry[state] <= now) continue;
            Friend friend = mod.friend(name);
            if (friend == null || !friend.shareChatOpen.resolve(mod.config.shareChatOpen)) continue;
            Bubble bubble = bubbles[bubbleCount++];
            bubble.name = name;
            bubble.x = player.getX(); bubble.y = player.getY() + player.getHeight() + .22; bubble.z = player.getZ();
        }
    }

    /** Called by the parent control router after validating a peer's [FLC:O]/[FLC:C] control. */
    public void receive(String sender, boolean open) {
        if (sender == null || sender.isEmpty()) return;
        int index = remoteIndex(sender);
        if (!open) { if (index >= 0) removeRemote(index); return; }
        Friend friend = mod.friend(sender);
        if (friend == null || !friend.shareChatOpen.resolve(mod.config.shareChatOpen)) return;
        if (index < 0) {
            if (remoteCount == LIMIT) return;
            index = remoteCount++;
            remoteNames[index] = sender;
        }
        remoteExpiry[index] = System.currentTimeMillis() + Math.max(1, mod.config.chatOpenTimeoutMs);
    }

    /** Main FriendLink chat screen lifecycle only; child settings screens do not call close. */
    public void screenOpen(boolean open) {
        if (open == chatOpen) return;
        chatOpen = open;
        if (open) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            var players = mc.world.getPlayers();
            for (int i = 0; i < announcedCount; i++) {
                String name = announced[i];
                if (nearby(players, name)) mod.sendControl(name, "[FLC:C]");
            }
        }
        announcedCount = 0;
        Arrays.fill(announced, null);
    }

    /** Parent calls on disconnect/world teardown to discard stale remote presence and announcements. */
    public void clear() {
        chatOpen = false; announcedCount = 0; remoteCount = 0; bubbleCount = 0;
        Arrays.fill(announced, null); Arrays.fill(remoteNames, null); Arrays.fill(remoteExpiry, 0L);
        for (Bubble bubble : bubbles) bubble.name = null;
    }

    private void expire(long now) {
        for (int i = remoteCount - 1; i >= 0; i--) if (remoteExpiry[i] <= now) removeRemote(i);
    }
    private int remoteIndex(String name) {
        for (int i = 0; i < remoteCount; i++) if (remoteNames[i].equalsIgnoreCase(name)) return i;
        return -1;
    }
    private int announcedIndex(String name) {
        for (int i = 0; i < announcedCount; i++) if (announced[i].equalsIgnoreCase(name)) return i;
        return -1;
    }
    private void removeRemote(int index) {
        int last = --remoteCount;
        remoteNames[index] = remoteNames[last]; remoteExpiry[index] = remoteExpiry[last];
        remoteNames[last] = null; remoteExpiry[last] = 0L;
    }
    private void removeAnnounced(int index) {
        int last = --announcedCount;
        announced[index] = announced[last]; announced[last] = null;
    }
    private static boolean nearby(java.util.List<? extends PlayerEntity> players, String name) {
        for (int i = 0; i < players.size(); i++)
            if (players.get(i).getGameProfile().getName().equalsIgnoreCase(name)) return true;
        return false;
    }

    private void render(WorldRenderContext context) {
        if (!mod.config.chatBubbles || bubbleCount == 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Vec3d camera = context.camera().getPos();
        MatrixStack matrices = context.matrixStack();
        float scale = (float) Math.max(.25, Math.min(4.0, mod.config.chatBubbleSize)) * .025f;
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < bubbleCount; i++) {
            Bubble bubble = bubbles[i];
            matrices.push();
            matrices.translate(bubble.x - camera.x, bubble.y - camera.y, bubble.z - camera.z);
            matrices.multiply(context.camera().getRotation());
            matrices.scale(-scale, -scale, scale);
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            // Pixel geometry forms a speech balloon and tail; no text glyphs or frame-local shapes are created.
            rect(buffer, matrix, -4, -3, 4, 2);
            rect(buffer, matrix, -3, -4, 3, -3);
            rect(buffer, matrix, -5, -2, -4, 1);
            rect(buffer, matrix, 4, -2, 5, 1);
            rect(buffer, matrix, -3, 2, 2, 3);
            rect(buffer, matrix, -3, 3, -2, 4);
            rect(buffer, matrix, -2, 3, 0, 4);
            matrices.pop();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableCull(); RenderSystem.disableBlend();
    }

    private static void rect(BufferBuilder buffer, Matrix4f matrix, float left, float top, float right, float bottom) {
        vertex(buffer, matrix, left, top); vertex(buffer, matrix, left, bottom);
        vertex(buffer, matrix, right, bottom); vertex(buffer, matrix, right, top);
    }
    private static void vertex(BufferBuilder buffer, Matrix4f matrix, float x, float y) {
        buffer.vertex(matrix, x, y, 0).color((COLOR >> 16) & 255, (COLOR >> 8) & 255, COLOR & 255, (COLOR >>> 24) & 255).next();
    }
}
