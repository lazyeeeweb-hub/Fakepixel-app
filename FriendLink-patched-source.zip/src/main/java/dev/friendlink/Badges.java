package dev.friendlink;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Shared, tick-prepared counters. Rendering never formats strings or measures fonts. */
public final class Badges {
    private static final String[] LABELS = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "9+"};
    private static final int[] HALF_WIDTH = new int[17];
    static {
        for (int y = -8; y <= 8; y++) HALF_WIDTH[y + 8] = (int) Math.sqrt(64 - y * y);
    }
    private Badges() {}
    public static final class Counter {
        private int value = -1, width;
        private String label = "";
        public void update(TextRenderer renderer, int count) {
            int next = Math.max(0, Math.min(10, count));
            // Measure on every cache update too: resource-pack font reloads can change widths.
            if (next != value) { value = next; label = LABELS[next]; width = renderer.getWidth(label); }
        }
        public boolean visible() { return value > 0; }
        /** cx/cy are the centre, not the top-left corner. */
        public void draw(DrawContext context, TextRenderer renderer, int cx, int cy) {
            if (value <= 0) return;
            for (int y = 0; y < HALF_WIDTH.length; y++) {
                int half = HALF_WIDTH[y];
                context.fill(cx - half, cy + y - 8, cx + half + 1, cy + y - 7, 0xFFE53C4D);
            }
            context.drawText(renderer, label, cx - width / 2, cy - 4, 0xFFFFFFFF, false);
        }
    }
    /** Twelve-pixel speech icon made from geometry, not a font-dependent Unicode glyph. */
    public static void speech(DrawContext context, int x, int y, int color) {
        context.fill(x + 1, y, x + 11, y + 9, color);
        context.fill(x, y + 1, x + 12, y + 8, color);
        context.fill(x + 2, y + 8, x + 5, y + 11, color);
        context.fill(x + 3, y + 2, x + 9, y + 3, 0xFF252A39);
        context.fill(x + 3, y + 5, x + 8, y + 6, 0xFF252A39);
    }
}
