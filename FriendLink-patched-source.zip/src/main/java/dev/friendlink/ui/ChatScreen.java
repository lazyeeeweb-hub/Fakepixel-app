package dev.friendlink.ui;

import dev.friendlink.Faces;
import dev.friendlink.Badges;
import dev.friendlink.FriendLink;
import dev.friendlink.ConversationSelection;
import dev.friendlink.GlowStyle;
import dev.friendlink.Models.*;
import dev.friendlink.Protocol;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Rendering uses prepared rows/OrderedText. Rewrapping and texture/name lookup happen in tick/init. */
public final class ChatScreen extends Screen {
    private final FriendLink mod = FriendLink.INSTANCE;
    private final Screen parent;
    private boolean transientScreen, ready;
    private long selectionGeneration;
    private final List<Row> rows = new ArrayList<>();
    private final List<Line> lines = new ArrayList<>();
    private String selected, heading = "Select a friend or group", error = "", draft = "";
    private TextFieldWidget input;
    private ButtonWidget send, manage, glowButton, colorButton;
    private GlowStyleDropdown glowStyle;
    private Friend glowTarget;
    private static final Text GLOW_ON = Text.literal("✦ Glow: ON"), GLOW_OFF = Text.literal("✦ Glow: OFF");
    private int side, mainX, top = 76, bottom, sidebarScroll, messageScroll;
    private static final int SIDEBAR_TOP = 44;
    private long cachedVersion = -1;
    private static final class Row {
        String key, name;
        final Badges.Counter badge = new Badges.Counter();
        Friend friend;
        Group group;
        Identifier[] faces;
    }
    private record Line(OrderedText text, Identifier face, int color, Message message,
                        int stage, int receiptX, String detail) {}
    private static final Text QUEUED_HINT = Text.literal("Queued"), SENT_HINT = Text.literal("Sent"),
        DELIVERED_HINT = Text.literal("Delivered"), READ_HINT = Text.literal("Read"),
        FAILED_HINT = Text.literal("Failed: left-click to retry; right-click for target details"),
        GROUP_HINT = Text.literal("Click for per-target delivery details");
    public ChatScreen(String selected) { this(selected, null); }
    public ChatScreen(String selected, Screen parent) {
        super(Text.literal("FriendLink"));
        this.parent = parent;
        this.selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
    }
    public String conversation() { return selected; }
    // Screen init/reinit hook: retain parent and drafts, then lazy-load before acknowledging reads.
    @Override protected void init() {
        if (input != null) draft = input.getText();
        selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
        messageScroll = 0;
        side = Math.min(170, Math.max(132, width / 3)); mainX = side + 8; bottom = height - 58;
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> openSubscreen(new PromptScreen(this,
            "Add friend (Java username)", "", mod::addFriend))).dimensions(6, 23, 24, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Group +"), b -> openSubscreen(new GroupScreen(this, null)))
            .dimensions(34, 23, 54, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cfg"), b -> { transientScreen = true; mod.openConfig(this); }).dimensions(92, 23, 32, 18).build());
        int actionWidth = Math.min(60, Math.max(24, (width - mainX - 10) / 2));
        addDrawableChild(ButtonWidget.builder(Text.literal("View"), b -> openSubscreen(new ViewSettingsScreen(this)))
            .dimensions(width - 10 - actionWidth * 2, 22, actionWidth, 18).build());
        manage = addDrawableChild(ButtonWidget.builder(Text.literal("Manage"), b -> manage())
            .dimensions(width - 6 - actionWidth, 22, actionWidth, 18).build());
        input = new TextFieldWidget(textRenderer, mainX, height - 25, Math.max(32, width - mainX - 54), 20, Text.literal("Private message"));
        input.setMaxLength(4096); input.setText(draft); addDrawableChild(input); setInitialFocus(input);
        send = addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> send()).dimensions(width - 46, height - 25, 40, 20).build());
        int available = width - mainX - 6;
        int colorWidth = Math.max(24, Math.min(58, available / 5));
        int toggleWidth = Math.min(98, (available - colorWidth - 8) / 2);
        int styleWidth = available - colorWidth - toggleWidth - 8;
        glowButton = addDrawableChild(ButtonWidget.builder(GLOW_ON, b -> {
            if (glowTarget != null) { glowTarget.glow = !glowTarget.glow; mod.touch(); }
            else { mod.config.glowEnabled = !mod.config.glowEnabled; mod.saveConfig(); }
            refresh();
        }).dimensions(mainX, 48, toggleWidth, 20).build());
        glowStyle = addDrawableChild(new GlowStyleDropdown(mainX + toggleWidth + 4, 48, styleWidth, style -> {
            if (glowTarget != null) { glowTarget.glowStyle = style; mod.touch(); }
            else { mod.config.defaultGlowStyle = style; mod.saveConfig(); }
        }));
        colorButton = addDrawableChild(ButtonWidget.builder(Text.literal("RGB"), b -> {
            if (glowTarget != null) openSubscreen(new ColorScreen(this, glowTarget));
            else openSubscreen(new ColorScreen(this, "Default glow color", mod.config.defaultGlowColor,
                color -> { mod.config.defaultGlowColor = color; mod.saveConfig(); }));
        }).dimensions(mainX + toggleWidth + styleWidth + 8, 48, colorWidth, 20).build());
        colorButton.setTooltip(Tooltip.of(Text.literal("Choose the glow colour with RGB sliders or a hex value.")));
        int bulkWidth = Math.max(1, (side - 18) / 2);
        addDrawableChild(ButtonWidget.builder(Text.literal("Glow all"), b -> { mod.setAllGlow(true); refresh(); })
            .dimensions(6, height - 42, bulkWidth, 18).tooltip(Tooltip.of(Text.literal("Enable glow for every saved friend."))).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Unglow all"), b -> { mod.setAllGlow(false); refresh(); })
            .dimensions(10 + bulkWidth, height - 42, bulkWidth, 18).tooltip(Tooltip.of(Text.literal("Disable glow for every saved friend."))).build());
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(true);
        select(selected);
    }
    // Screen tick hook: never read an unloaded log, and never rebuild message layout in render().
    @Override public void tick() {
        input.tick();
        if (ready) mod.read(selected);
        if (cachedVersion != mod.version) {
            String choice = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
            if (!java.util.Objects.equals(choice, selected)) select(choice); else refresh();
        }
    }
    private void select(String key) {
        selected = key; ready = key == null; messageScroll = 0; error = "";
        long generation = ++selectionGeneration;
        refresh();
        if (key == null) return;
        mod.ensureConversation(key, () -> {
            if (generation != selectionGeneration || !key.equals(selected)) return;
            ready = true; messageScroll = 0;
            // Lazy-load completion is a client-thread callback supplied by the parent.
            if (client.currentScreen == this) { mod.read(key); refresh(); setFocused(input); input.setFocused(true); }
        });
    }
    private void openSubscreen(Screen screen) {
        transientScreen = true;
        client.setScreen(screen);
    }
    // Removal hook: transient child screens keep one logical chat session (no O/C flapping).
    @Override public void removed() {
        draft = input == null ? draft : input.getText();
        if (!transientScreen && mod.presence != null) mod.presence.screenOpen(false);
        super.removed();
    }
    // Escape/back hook: return to the caller, including a pause or inventory screen.
    @Override public void close() {
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(false);
        client.setScreen(parent);
    }
    private void refresh() {
        rows.clear();
        for (Friend f : mod.state.friends.values()) {
            Row r = new Row(); r.key = "f:" + Protocol.key(f.name); r.friend = f;
            r.name = textRenderer.trimToWidth(f.name, side - 55); r.badge.update(textRenderer, f.unread);
            r.faces = new Identifier[] { mod.skins.face(f.name) }; rows.add(r);
        }
        for (Group g : mod.state.groups.values()) {
            if (g.left) continue;
            Row r = new Row(); r.key = "g:" + g.id; r.group = g;
            r.name = textRenderer.trimToWidth((g.pending ? "? " : "") + g.name, side - 45);
            r.badge.update(textRenderer, g.unread);
            r.faces = new Identifier[Math.min(4, g.members.size())];
            for (int i = 0; i < r.faces.length; i++) r.faces[i] = mod.skins.face(g.members.get(i));
            rows.add(r);
        }
        Row active = null;
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).key.equals(selected)) { active = rows.get(i); break; }
        mod.rememberConversation(selected);
        heading = textRenderer.trimToWidth(active == null ? "Select a friend or group" : active.friend != null
            ? active.friend.name : active.group.name + (active.group.pending ? " (pending)" : active.group.muted ? " (muted)" : ""), width - mainX - 6);
        glowTarget = active == null ? null : active.friend;
        boolean enabled = glowTarget == null ? mod.config.glowEnabled : glowTarget.glow;
        glowButton.setMessage(enabled ? GLOW_ON : GLOW_OFF);
        glowButton.setTooltip(Tooltip.of(Text.literal(glowTarget == null
            ? "Master glow toggle. No friend selected: style and colour edit global defaults. Key G also toggles all glow."
            : "Toggle glow for " + glowTarget.name + ". " + (mod.config.glowEnabled
                ? "Master glow is ON." : "Master glow is OFF; press G in-game or use Cfg to enable all glow."))));
        glowStyle.selection(glowTarget == null ? mod.config.defaultGlowStyle : glowTarget.glowStyle, glowTarget != null);
        colorButton.setTooltip(Tooltip.of(Text.literal("Pick " + (glowTarget == null ? "default" : glowTarget.name + "'s")
            + " glow colour (RGB / hex).")));
        manage.active = active != null;
        send.active = ready && active != null && (active.group == null || !active.group.pending);
        input.setEditable(send.active);
        lines.clear();
        List<Message> messages = ready ? mod.messages(selected) : java.util.Collections.emptyList();
        for (int i = 0; i < messages.size(); i++) {
            Message m = messages.get(i);
            if (!m.system) mod.skins.request(m.sender);
            Identifier face = m.system ? null : mod.skins.face(m.sender);
            boolean outbound = !m.system && m.sender.equalsIgnoreCase(mod.self());
            int stage = outbound ? Math.max(0, Math.min(4, m.stage())) : -1;
            String details = outbound ? m.status() : "";
            List<OrderedText> wrapped = textRenderer.wrapLines(Text.literal((m.system ? "• " : m.sender + ": ") + m.text),
                Math.max(20, width - mainX - 52));
            for (int j = 0; j < wrapped.size(); j++) {
                boolean last = outbound && j == wrapped.size() - 1;
                int receiptX = mainX + 22 + textRenderer.getWidth(wrapped.get(j));
                lines.add(new Line(wrapped.get(j), j == 0 ? face : null, m.system ? 0xFFB7B7C8 : 0xFFE8E8F2,
                    last ? m : null, last ? stage : -1, receiptX, last ? details : ""));
            }
        }
        sidebarScroll = Math.min(sidebarScroll, Math.max(0, rows.size() * 32 - (height - SIDEBAR_TOP - 20)));
        messageScroll = Math.min(messageScroll, Math.max(0, lines.size() - visibleLines()));
        if (ready && client.currentScreen == this) mod.read(selected);
        cachedVersion = mod.version;
    }
    private int visibleLines() { return Math.max(1, (bottom - top) / 14); }
    private void send() {
        String result = mod.send(selected, input.getText());
        if (result == null) { input.setText(""); draft = ""; error = ""; messageScroll = 0; }
        else error = textRenderer.trimToWidth(result, Math.max(20, width - mainX - 8));
    }
    private void manage() {
        if (selected == null) return;
        if (selected.startsWith("f:")) {
            Friend f = mod.state.friends.get(selected.substring(2)); if (f != null) openSubscreen(new ColorScreen(this, f));
        } else {
            Group g = mod.state.groups.get(selected.substring(2)); if (g != null) openSubscreen(new GroupScreen(this, g));
        }
    }
    // Keyboard hook: preserve existing send, paging and glow-dropdown shortcuts.
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (glowStyle.isFocused() && glowStyle.keyPressed(key, scan, modifiers)) return true;
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && send.active) { send(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP) { messageScroll = Math.min(Math.max(0, lines.size() - visibleLines()), messageScroll + visibleLines()); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_DOWN) { messageScroll = Math.max(0, messageScroll - visibleLines()); return true; }
        return super.keyPressed(key, scan, modifiers);
    }
    // Wheel hook: scroll the prepared sidebar/message layout only.
    @Override public boolean mouseScrolled(double x, double y, double amount) {
        if (x < side) sidebarScroll = Math.max(0, Math.min(Math.max(0, rows.size() * 32 - (height - SIDEBAR_TOP - 20)), sidebarScroll - (int) (amount * 32)));
        else messageScroll = Math.max(0, Math.min(Math.max(0, lines.size() - visibleLines()), messageScroll + (int) (amount * 3)));
        return true;
    }
    // Mouse hook: receipt hitboxes use the same cached last-line position as rendering.
    @Override public boolean mouseClicked(double x, double y, int button) {
        if (glowStyle.menuClick(x, y, button)) return true;
        if (x < side && y >= SIDEBAR_TOP && y < height - 20) {
            int index = ((int) y - SIDEBAR_TOP + sidebarScroll) / 32;
            if (index >= 0 && index < rows.size()) {
                Row r = rows.get(index);
                if (button == 1) openSubscreen(removalScreen(this, r.key));
                else if (button == 0 && r.friend != null && x >= side - 18) openSubscreen(new ColorScreen(this, r.friend));
                else if (button == 0) select(r.key);
                return true;
            }
        }
        if (x >= mainX && y >= top && y < bottom && (button == 0 || button == 1)) {
            int start = Math.max(0, lines.size() - visibleLines() - messageScroll);
            int index = start + ((int) y - top) / 14;
            if (index < lines.size()) {
                Line line = lines.get(index);
                if (line.message() != null && x >= line.receiptX() - 2 && x < line.receiptX() + 17) {
                    if ((selected != null && selected.startsWith("g:")) || button == 1)
                        openSubscreen(new DeliveryScreen(this, selected, line.message(), line.detail()));
                    else if (line.stage() == 4 && button == 0) { mod.retryMessage(selected, line.message()); refresh(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(x, y, button);
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0xD91C1F29); c.fill(0, 0, side, height, 0xEC151820);
        c.drawText(textRenderer, title, 7, 8, 0xFFFFFFFF, true);
        c.drawText(textRenderer, heading, mainX, 8, 0xFFE4E7FF, true);
        c.enableScissor(0, SIDEBAR_TOP, side, Math.max(SIDEBAR_TOP + 1, height - 20));
        for (int i = 0; i < rows.size(); i++) {
            int y = SIDEBAR_TOP + i * 32 - sidebarScroll;
            if (y + 32 < SIDEBAR_TOP || y >= height - 20) continue;
            Row r = rows.get(i);
            if (r.key.equals(selected)) c.fill(2, y, side - 2, y + 31, 0xFF353B51);
            if (r.faces.length == 1) Faces.draw(c, r.faces[0], 6, y + 4, 24);
            else for (int n = 0; n < r.faces.length; n++) Faces.draw(c, r.faces[n], 6 + (n % 2) * 12, y + 4 + (n / 2) * 12, 12);
            c.drawText(textRenderer, r.name, 34, y + 5, 0xFFE6E6F0, false);
            if (mod.config.unreadFriendBadges) r.badge.draw(c, textRenderer, 26, y + 25);
            if (r.friend != null) {
                c.fill(side - 17, y + 9, side - 5, y + 22, 0xFF000000 | r.friend.color);
            }
        }
        c.disableScissor();
        if (bottom > top) {
            c.enableScissor(mainX, top, width - 4, bottom);
            int start = Math.max(0, lines.size() - visibleLines() - messageScroll), end = Math.min(lines.size(), start + visibleLines());
            for (int i = start; i < end; i++) {
                Line line = lines.get(i); int y = top + (i - start) * 14;
                if (line.face() != null) Faces.draw(c, line.face(), mainX, y - 2, 13);
                c.drawText(textRenderer, line.text(), mainX + 18, y, line.color(), false);
                if (line.stage() >= 0) receipt(c, line.receiptX(), y, line.stage());
            }
            c.disableScissor();
        }
        c.drawText(textRenderer, error, mainX, height - 44, 0xFFFF9999, false);
        c.drawText(textRenderer, "Right-click: remove / delete", 6, height - 16, 0xFF8990AA, false);
        super.render(c, mouseX, mouseY, delta);
        // The dropdown is an overlay and must remain above messages and neighbouring widgets.
        glowStyle.renderMenu(c, mouseX, mouseY);
        if (!glowStyle.isFocused() && mouseX >= mainX && mouseY >= top && mouseY < bottom) {
            int start = Math.max(0, lines.size() - visibleLines() - messageScroll);
            int index = start + (mouseY - top) / 14;
            if (index < lines.size()) {
                Line line = lines.get(index);
                if (line.stage() >= 0 && mouseX >= line.receiptX() - 2 && mouseX < line.receiptX() + 17) {
                    Text hint = line.stage() == 4 ? FAILED_HINT : selected != null && selected.startsWith("g:") ? GROUP_HINT
                        : line.stage() == 0 ? QUEUED_HINT : line.stage() == 1 ? SENT_HINT : line.stage() == 2 ? DELIVERED_HINT : READ_HINT;
                    c.drawTooltip(textRenderer, hint, mouseX, mouseY);
                }
            }
        }
    }
    private void receipt(DrawContext c, int x, int y, int stage) {
        int color = stage == 4 ? 0xFFFF4559 : stage == 3 ? 0xFF000000 | (mod.config.readReceiptColor & 0xFFFFFF) : 0xFF9296A6;
        if (stage == 0) {
            c.fill(x + 2, y, x + 8, y + 1, color); c.fill(x + 2, y + 8, x + 8, y + 9, color);
            c.fill(x + 1, y + 1, x + 2, y + 8, color); c.fill(x + 8, y + 1, x + 9, y + 8, color);
            c.fill(x + 4, y + 2, x + 5, y + 5, color); c.fill(x + 4, y + 4, x + 7, y + 5, color);
        } else if (stage == 4) {
            c.fill(x + 4, y, x + 6, y + 6, color); c.fill(x + 4, y + 8, x + 6, y + 10, color);
        } else {
            tickMark(c, x, y, color);
            if (stage >= 2) tickMark(c, x + 5, y, color);
        }
    }
    private static void tickMark(DrawContext c, int x, int y, int color) {
        c.fill(x, y + 4, x + 2, y + 6, color); c.fill(x + 2, y + 6, x + 4, y + 8, color);
        c.fill(x + 4, y + 4, x + 6, y + 6, color); c.fill(x + 6, y + 2, x + 8, y + 4, color);
    }
    /** Also used by the optional config friend-list editor, so bulk removals never silently erase logs. */
    public static Screen removalScreen(Screen parent, String key) { return new RemovalScreen(parent, key); }
    private static final class RemovalScreen extends Screen {
        private final Screen parent;
        private final String key;
        private List<OrderedText> explanation = java.util.Collections.emptyList();
        RemovalScreen(Screen parent, String key) {
            super(Text.literal(key.startsWith("g:") ? "Delete group?" : "Remove friend?")); this.parent = parent; this.key = key;
        }
        // Confirmation init hook: log retention is a separate, explicit choice, never a default checkbox.
        @Override protected void init() {
            explanation = textRenderer.wrapLines(Text.literal("Keep log preserves the local conversation. Delete log permanently removes it. Group memberships of a removed friend are unchanged."), Math.max(40, Math.min(340, width - 24)));
            int w = Math.min(330, width - 16), x = (width - w) / 2, y = Math.max(80, height / 2 + 24);
            addDrawableChild(ButtonWidget.builder(Text.literal("Keep log"), b -> remove(false)).dimensions(x, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete log"), b -> remove(true)).dimensions(x + w / 2 + 2, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x, y + 24, w, 20).build());
        }
        private void remove(boolean deleteLog) {
            FriendLink mod = FriendLink.INSTANCE;
            if (key.startsWith("f:")) mod.removeFriend(key.substring(2), deleteLog); else mod.deleteGroup(key.substring(2), deleteLog);
            close();
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
            int x = Math.max(12, (width - 340) / 2);
            for (int i = 0; i < explanation.size(); i++) c.drawText(textRenderer, explanation.get(i), x, 44 + i * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        // Back hook: cancelling does not mutate membership or logs.
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    private static final class DeliveryScreen extends Screen {
        private final Screen parent;
        private final String key, detail;
        private final Message message;
        private List<OrderedText> wrapped = java.util.Collections.emptyList();
        private int scroll;
        DeliveryScreen(Screen parent, String key, Message message, String detail) {
            super(Text.literal("Per-target delivery")); this.parent = parent; this.key = key; this.message = message;
            this.detail = detail.isEmpty() ? "Queued; no target acknowledgements yet." : detail;
        }
        // Details init hook: the parent's receipt snapshot is wrapped once, not during rendering.
        @Override protected void init() {
            wrapped = textRenderer.wrapLines(Text.literal(detail), Math.max(40, width - 32));
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close()).dimensions(width / 2 - 100, height - 30, 96, 20).build());
            ButtonWidget retry = addDrawableChild(ButtonWidget.builder(Text.literal("Retry failed"), b -> {
                FriendLink.INSTANCE.retryMessage(key, message); close();
            }).dimensions(width / 2 + 4, height - 30, 96, 20).build());
            retry.active = message.stage() == 4;
            scroll = Math.min(scroll, Math.max(0, wrapped.size() - visible()));
        }
        private int visible() { return Math.max(1, (height - 80) / 12); }
        // Details wheel hook: scroll the cached per-member report.
        @Override public boolean mouseScrolled(double x, double y, double amount) {
            scroll = Math.max(0, Math.min(Math.max(0, wrapped.size() - visible()), scroll - (int) (amount * 3))); return true;
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
            for (int i = scroll, end = Math.min(wrapped.size(), scroll + visible()); i < end; i++)
                c.drawText(textRenderer, wrapped.get(i), 16, 38 + (i - scroll) * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        // Back hook returns to the same chat instance, preserving its caller and draft.
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    @Override public boolean shouldPause() { return false; }
}
