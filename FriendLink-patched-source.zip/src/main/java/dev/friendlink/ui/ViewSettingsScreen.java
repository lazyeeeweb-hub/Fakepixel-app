package dev.friendlink.ui;

import dev.friendlink.FriendLink;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/** Built-in controls, available from chat even when optional Cloth Config is absent. */
public final class ViewSettingsScreen extends Screen {
    private final Screen parent;
    private final FriendLink mod = FriendLink.INSTANCE;
    private SettingSlider strength, maximum;
    public ViewSettingsScreen(Screen parent) { super(Text.literal("FriendLink view settings")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(300, width - 20), x = (width - w) / 2;
        addDrawableChild(ButtonWidget.builder(reopenLabel(), b -> {
            mod.config.reopenLastConversation = !mod.config.reopenLastConversation;
            b.setMessage(reopenLabel()); mod.touch();
        }).dimensions(x, 38, w, 20).build());
        addDrawableChild(ButtonWidget.builder(scaleLabel(), b -> {
            mod.config.glowScaleWithDistance = !mod.config.glowScaleWithDistance;
            strength.active = maximum.active = mod.config.glowScaleWithDistance;
            b.setMessage(scaleLabel()); mod.touch();
        }).dimensions(x, 66, w, 20).build());
        strength = addDrawableChild(new SettingSlider(x, 94, w, mod.config.glowScaleFactor, 0, .05,
            "Scale strength: %.2f%% / block", 100, v -> { mod.config.glowScaleFactor = v; mod.touch(); }));
        maximum = addDrawableChild(new SettingSlider(x, 122, w, mod.config.glowMaxScale, 1, 6,
            "Max scale: %.2fx", 1, v -> { mod.config.glowMaxScale = v; mod.touch(); }));
        strength.active = maximum.active = mod.config.glowScaleWithDistance;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
            .dimensions(x, height - 28, w, 20).build());
    }
    private Text reopenLabel() { return Text.literal("Reopen last conversation: " + (mod.config.reopenLastConversation ? "ON" : "OFF")); }
    private Text scaleLabel() { return Text.literal("Scale with distance: " + (mod.config.glowScaleWithDistance ? "ON" : "OFF")); }
    @Override public void removed() { mod.saveConfig(); }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c);
        c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFF);
        c.drawCenteredTextWithShadow(textRenderer, "Marker: 1x within 10 blocks; smooth growth beyond.", width / 2, 153, 0xB6BFD6);
        super.render(c, mouseX, mouseY, delta);
    }
    private static final class SettingSlider extends SliderWidget {
        private final double min, max, display;
        private final String format;
        private final DoubleConsumer consumer;
        SettingSlider(int x, int y, int width, double current, double min, double max,
                      String format, double display, DoubleConsumer consumer) {
            super(x, y, width, 20, Text.empty(), (current - min) / (max - min));
            this.min = min; this.max = max; this.format = format; this.display = display; this.consumer = consumer;
            updateMessage();
        }
        private double setting() { return min + value * (max - min); }
        @Override protected void updateMessage() { setMessage(Text.literal(String.format(Locale.ROOT, format, setting() * display))); }
        @Override protected void applyValue() { consumer.accept(setting()); }
    }
}
