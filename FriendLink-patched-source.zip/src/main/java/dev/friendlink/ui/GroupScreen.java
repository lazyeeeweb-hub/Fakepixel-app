package dev.friendlink.ui;

import dev.friendlink.Faces;
import dev.friendlink.FriendLink;
import dev.friendlink.Models.Group;
import dev.friendlink.Protocol;
import java.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class GroupScreen extends Screen {
    private final FriendLink mod = FriendLink.INSTANCE;
    private final Screen parent;
    private final Group group;
    private final Set<String> chosen = new HashSet<>();
    private final List<String> names = new ArrayList<>();
    private final List<Identifier> faces = new ArrayList<>();
    private boolean[] selectedRows = new boolean[0];
    private TextFieldWidget name;
    private int scroll, listTop = 82, listBottom, x, panelWidth;
    private boolean owner;
    private String error = "", draft;
    public GroupScreen(Screen parent, Group group) {
        super(Text.literal(group == null ? "Create group" : "Manage group"));
        this.parent = parent; this.group = group; draft = group == null ? "" : group.name;
        if (group != null) for (String n : group.members) chosen.add(Protocol.key(n));
    }
    @Override protected void init() {
        if (name != null) draft = name.getText();
        panelWidth = Math.min(360, width - 20); x = (width - panelWidth) / 2; listBottom = height - 72;
        owner = group == null || (!group.pending && group.owner.equalsIgnoreCase(mod.self()));
        name = new TextFieldWidget(textRenderer, x, 30, panelWidth, 20, Text.literal("Group name"));
        name.setMaxLength(32); name.setText(draft); name.setEditable(owner); addDrawableChild(name);
        names.clear(); faces.clear();
        LinkedHashMap<String, String> candidates = new LinkedHashMap<>();
        if (group != null) for (String n : group.members) if (!n.equalsIgnoreCase(mod.self())) candidates.put(Protocol.key(n), n);
        for (var f : mod.state.friends.values()) candidates.putIfAbsent(Protocol.key(f.name), f.name);
        for (String n : candidates.values()) { names.add(n); mod.skins.request(n); faces.add(mod.skins.face(n)); }
        selectedRows = new boolean[names.size()];
        refreshSelections();
        if (group != null) {
            addDrawableChild(ButtonWidget.builder(Text.literal(group.muted ? "Muted" : "Mute"), b -> {
                group.muted = !group.muted; b.setMessage(Text.literal(group.muted ? "Muted" : "Mute")); mod.touch();
            }).dimensions(x, 56, panelWidth / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(group.sound ? "Sound: on" : "Sound: off"), b -> {
                group.sound = !group.sound; b.setMessage(Text.literal(group.sound ? "Sound: on" : "Sound: off")); mod.touch();
            }).dimensions(x + panelWidth / 2 + 2, 56, panelWidth / 2 - 2, 20).build());
        }
        if (group != null && group.pending) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Accept"), b -> { mod.acceptGroup(group.id, true); close(); })
                .dimensions(x, height - 48, panelWidth / 3 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Decline"), b -> { mod.acceptGroup(group.id, false); close(); })
                .dimensions(x + panelWidth / 3, height - 48, panelWidth / 3 - 2, 20).build());
        } else {
            ButtonWidget save = addDrawableChild(ButtonWidget.builder(Text.literal("Save + sync"), b -> save())
                .dimensions(x, height - 48, panelWidth / 3 - 2, 20).build()); save.active = owner;
            if (group != null) addDrawableChild(ButtonWidget.builder(Text.literal("Leave"), b -> client.setScreen(new ConfirmScreen(ok -> {
                if (ok) { String result = mod.leaveGroup(group); if (result != null) error = textRenderer.trimToWidth(result, panelWidth); }
                client.setScreen(ok && group.left ? parent : this);
            }, Text.literal("Leave group?"), Text.literal(group.owner.equalsIgnoreCase(mod.self()) ? "As owner, this closes the group for everyone reachable." : "You will stop receiving this group."))))
                .dimensions(x + panelWidth / 3, height - 48, panelWidth / 3 - 2, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close()).dimensions(x + panelWidth * 2 / 3, height - 48, panelWidth / 3, 20).build());
    }
    private void save() {
        List<String> selected = new ArrayList<>();
        for (String n : names) if (chosen.contains(Protocol.key(n))) selected.add(n);
        String result = mod.saveGroup(group, name.getText(), selected);
        if (result == null) close(); else error = textRenderer.trimToWidth(result, panelWidth);
    }
    @Override public void tick() {
        name.tick();
        for (int i = 0; i < names.size(); i++) faces.set(i, mod.skins.face(names.get(i)));
        refreshSelections();
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (owner && button == 0 && mx >= x && mx < x + panelWidth && my >= listTop && my < listBottom) {
            int i = ((int) my - listTop + scroll) / 24;
            if (i >= 0 && i < names.size()) { String key = Protocol.key(names.get(i)); if (!chosen.remove(key)) chosen.add(key); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        scroll = Math.max(0, Math.min(Math.max(0, names.size() * 24 - (listBottom - listTop)), scroll - (int) (amount * 24))); return true;
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        if (listBottom > listTop) {
            c.enableScissor(x, listTop, x + panelWidth, listBottom);
            for (int i = 0; i < names.size(); i++) {
                int y = listTop + i * 24 - scroll;
                if (y + 24 < listTop || y >= listBottom) continue;
                boolean selected = selectedRows[i];
                c.fill(x, y, x + panelWidth, y + 23, selected ? 0xAA465780 : 0xAA202530);
                Faces.draw(c, faces.get(i), x + 4, y + 3, 18);
                c.drawText(textRenderer, names.get(i), x + 28, y + 7, 0xFFFFFF, false);
                c.drawText(textRenderer, selected ? "[x]" : "[ ]", x + panelWidth - 24, y + 7, 0xFFFFFF, false);
            }
            c.disableScissor();
        }
        c.drawCenteredTextWithShadow(textRenderer, error, width / 2, height - 66, 0xFF9999);
        c.drawCenteredTextWithShadow(textRenderer, owner ? "Click members; you are included automatically." : "Only the owner can edit membership.", width / 2, height - 20, 0xAAB3CC);
        super.render(c, mouseX, mouseY, delta);
    }
    private void refreshSelections() {
        for (int i = 0; i < names.size(); i++) selectedRows[i] = group != null && !owner
            ? FriendLink.contains(group.members, names.get(i)) : chosen.contains(Protocol.key(names.get(i)));
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
