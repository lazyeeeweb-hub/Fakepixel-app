package dev.friendlink.ui;

import dev.friendlink.GlowStyle;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Actual dropdown (not a cycling button). Its expanded list is drawn above chat. */
public final class GlowStyleDropdown extends ClickableWidget {
    private static final GlowStyle[] VALUES = GlowStyle.values();
    private static final Text[] LABELS = {
        Text.literal("Default"), Text.literal("Outline"), Text.literal("Halo"), Text.literal("Marker")
    };
    private final Consumer<GlowStyle> consumer;
    private boolean inherit, expanded;
    private GlowStyle value = GlowStyle.MARKER;
    private int cursor;
    public GlowStyleDropdown(int x, int y, int width, Consumer<GlowStyle> consumer) {
        super(x, y, width, 20, LABELS[1]); this.consumer = consumer;
        setTooltip(Tooltip.of(Text.literal("Glow style. Default follows the global style. Marker is the shader-pack fallback.")));
    }
    public void selection(GlowStyle value, boolean inherit) {
        this.inherit = inherit;
        this.value = value == null ? (inherit ? GlowStyle.DEFAULT : GlowStyle.MARKER) : value;
        setMessage(LABELS[this.value.ordinal()]); cursor = this.value.ordinal();
    }
    private int first() { return inherit ? 0 : 1; }
    private void choose(int index) {
        value = VALUES[index]; setMessage(LABELS[index]); expanded = false; consumer.accept(value);
    }
    @Override public void onClick(double x, double y) { expanded = !expanded; cursor = value.ordinal(); }
    @Override public boolean mouseClicked(double x, double y, int button) {
        if (expanded && button == 0 && x >= getX() && x < getX() + width
            && y >= getY() + 20 && y < getY() + 20 + (4 - first()) * 20) {
            choose(first() + (int) (y - getY() - 20) / 20); return true;
        }
        if (super.mouseClicked(x, y, button)) return true;
        expanded = false; return false;
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (!isFocused() || !active) return false;
        if (key == GLFW.GLFW_KEY_ESCAPE && expanded) { expanded = false; return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE) {
            if (expanded) choose(cursor); else { expanded = true; cursor = value.ordinal(); }
            return true;
        }
        if (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_UP) {
            expanded = true; cursor = Math.max(first(), Math.min(3, cursor + (key == GLFW.GLFW_KEY_DOWN ? 1 : -1))); return true;
        }
        return false;
    }
    /** Called first by ChatScreen so an open list consumes clicks before messages/other controls. */
    public boolean menuClick(double x, double y, int button) {
        if (!expanded) return false;
        return mouseClicked(x, y, button);
    }
    public boolean menuOpen() { return expanded; }
    @Override protected void renderButton(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(getX(), getY(), getX() + width, getY() + 20, isHovered() || isFocused() ? 0xFF525E80 : 0xFF343D55);
        drawScrollableText(c, MinecraftClient.getInstance().textRenderer, 6, active ? 0xFFFFFFFF : 0xFF888888);
        c.fill(getX() + width - 5, getY() + 8, getX() + width - 2, getY() + 10, 0xFFFFFFFF);
    }
    public void renderMenu(DrawContext c, int mouseX, int mouseY) {
        if (!expanded) return;
        var text = MinecraftClient.getInstance().textRenderer;
        for (int i = first(); i < 4; i++) {
            int y = getY() + 20 + (i - first()) * 20;
            boolean hover = mouseX >= getX() && mouseX < getX() + width && mouseY >= y && mouseY < y + 20;
            c.fill(getX(), y, getX() + width, y + 20, hover || i == cursor ? 0xFF515F85 : 0xFF262D40);
            drawScrollableText(c, text, LABELS[i], getX() + 4, y, getX() + width - 4, y + 20, 0xFFFFFFFF);
        }
    }
    @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) { appendDefaultNarrations(builder); }
}
