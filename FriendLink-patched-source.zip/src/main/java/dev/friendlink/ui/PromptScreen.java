package dev.friendlink.ui;

import java.util.function.Function;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class PromptScreen extends Screen {
    private final Screen parent;
    private final Function<String, String> submit;
    private String value, error = "";
    private TextFieldWidget field;
    public PromptScreen(Screen parent, String title, String initial, Function<String, String> submit) {
        super(Text.literal(title)); this.parent = parent; this.value = initial; this.submit = submit;
    }
    @Override protected void init() {
        if (field != null) value = field.getText();
        int w = Math.min(280, width - 24), x = (width - w) / 2;
        field = new TextFieldWidget(textRenderer, x, height / 2 - 20, w, 20, Text.literal("Value"));
        field.setMaxLength(256); field.setText(value); addDrawableChild(field); setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> save()).dimensions(x, height / 2 + 12, w / 2 - 2, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x + w / 2 + 2, height / 2 + 12, w / 2 - 2, 20).build());
    }
    private void save() {
        String result = submit.apply(field.getText());
        if (result == null) close(); else error = textRenderer.trimToWidth(result, width - 16);
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { save(); return true; }
        return super.keyPressed(key, scan, modifiers);
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 45, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, error, width / 2, height / 2 + 40, 0xFF8888);
        super.render(context, mouseX, mouseY, delta);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
