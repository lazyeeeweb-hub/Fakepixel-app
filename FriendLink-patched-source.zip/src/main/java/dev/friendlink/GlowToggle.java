package dev.friendlink;

/** Tri-state per-friend option. DEFAULT follows the corresponding global setting. */
public enum GlowToggle {
    DEFAULT, ON, OFF;
    public boolean resolve(boolean global) { return this == DEFAULT ? global : this == ON; }
}
