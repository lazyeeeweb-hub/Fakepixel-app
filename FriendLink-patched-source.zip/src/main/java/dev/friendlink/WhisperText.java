package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure, immutable text parser. Construct only on config reload, not for every message. */
public final class WhisperText {
    public static final String DEFAULT_DIALOGUE_REGEX =
        "^From (?<from>.+?) to (?<to>.+?): (?<msg>.*)$";
    private static final Pattern HEX = Pattern.compile("§x(?:§[0-9a-f]){6}", Pattern.CASE_INSENSITIVE);
    private static final Pattern LEGACY = Pattern.compile("§[0-9a-fk-or]", Pattern.CASE_INSENSITIVE);
    // Both boundaries matter: never salvage 16 characters from a 17-character identifier.
    private static final Pattern NAME = Pattern.compile("(?<![A-Za-z0-9_])[A-Za-z0-9_]{3,16}(?![A-Za-z0-9_])");
    private static final Pattern TOKEN = Pattern.compile("[A-Za-z0-9_]+");
    private static final Pattern PUBLIC_CHAT = Pattern.compile("^\\[\\d+\\]\\s+[^:\\r\\n]+:.*$", Pattern.DOTALL);
    public record Parsed(String name, String body, boolean outgoing) {}
    private record Rule(Pattern pattern, boolean twoSided, boolean outgoing) {}
    private final List<Rule> rules;

    public WhisperText(List<String> dialogue, List<String> incoming, List<String> outgoing) {
        this(dialogue, incoming, outgoing, ignored -> {});
    }
    public WhisperText(List<String> dialogue, List<String> incoming, List<String> outgoing,
                       Consumer<String> rejected) {
        List<Rule> compiled = new ArrayList<>();
        compile(compiled, dialogue, true, false, rejected);
        compile(compiled, outgoing, false, true, rejected);
        compile(compiled, incoming, false, false, rejected);
        rules = List.copyOf(compiled);
    }
    private static void compile(List<Rule> target, List<String> source, boolean dialogue,
                                boolean outgoing, Consumer<String> rejected) {
        if (source == null) return;
        int count = 0;
        for (String expression : source) {
            if (count == 32) break;
            boolean twoSided = expression != null && expression.contains("(?<from>")
                && expression.contains("(?<to>")
                && (expression.contains("(?<msg>") || expression.contains("(?<message>"));
            boolean legacy = expression != null && expression.contains("(?<name>")
                && expression.contains("(?<message>");
            if (expression == null || expression.length() > 1024 || (!twoSided && (dialogue || !legacy))) {
                rejected.accept(expression); continue;
            }
            try {
                // Keep existing default formats, but let their conventional name slot include ranks.
                // All surrounding anchors/delimiters/custom restrictions remain unchanged.
                String decorated = expression.replace("(?<name>[A-Za-z0-9_]{3,16})", "(?<name>.+)");
                target.add(new Rule(Pattern.compile(decorated, Pattern.CASE_INSENSITIVE), twoSided, outgoing));
                count++;
            } catch (RuntimeException e) { rejected.accept(expression); }
        }
    }
    /** Hex sequences MUST be removed first, otherwise stripping their digits leaves a stray §x. */
    public static String strip(String text) {
        if (text == null || text.indexOf('§') < 0) return text;
        return LEGACY.matcher(HEX.matcher(text).replaceAll("")).replaceAll("");
    }
    /** The last complete username token in a decorated participant, never a substring of a long name. */
    public static String playerName(String display) {
        if (display == null) return null;
        Matcher matcher = NAME.matcher(strip(display));
        String name = null;
        while (matcher.find()) name = matcher.group();
        return name;
    }
    private static boolean self(String display, String localName) {
        if (display == null) return false;
        Matcher matcher = TOKEN.matcher(strip(display));
        String last = null;
        while (matcher.find()) last = matcher.group();
        return last != null && (last.equalsIgnoreCase("me") || last.equalsIgnoreCase("you")
            || localName != null && last.equalsIgnoreCase(localName));
    }
    private static String group(Matcher matcher, String name) {
        try { return matcher.group(name); } catch (IllegalArgumentException e) { return null; }
    }
    /** Public numeric-prefix chat is vetoed before even a user-supplied permissive regex is tried. */
    public Parsed parse(String raw, String localName) {
        if (raw == null || raw.length() > 8192) return null;
        String text = strip(raw);
        if (PUBLIC_CHAT.matcher(text).matches()) return null;
        for (Rule rule : rules) {
            Matcher matcher = rule.pattern().matcher(text);
            if (!matcher.matches()) continue;
            String body = rule.twoSided() ? group(matcher, "msg") : group(matcher, "message");
            if (body == null && rule.twoSided()) body = group(matcher, "message");
            boolean outgoing = rule.outgoing();
            String display;
            if (rule.twoSided()) {
                String from = group(matcher, "from"), to = group(matcher, "to");
                boolean fromSelf = self(from, localName), toSelf = self(to, localName);
                // Ambiguous or unrelated two-party traffic is not a whisper to/from this client.
                if (fromSelf == toSelf) return null;
                outgoing = fromSelf;
                display = outgoing ? to : from;
            } else display = group(matcher, "name");
            String name = playerName(display);
            return name == null || body == null ? null : new Parsed(name, body, outgoing);
        }
        return null;
    }
    /** Must be evaluated only after parse failed; numeric-prefix public chat cannot become an error either. */
    public static boolean publicChat(String raw) {
        return raw != null && PUBLIC_CHAT.matcher(strip(raw)).matches();
    }
}
