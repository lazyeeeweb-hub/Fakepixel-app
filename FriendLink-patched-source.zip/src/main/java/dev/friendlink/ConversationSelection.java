package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.List;

/** Pure selection policy; inspecting metadata never triggers a lazy log load. */
public final class ConversationSelection {
    private ConversationSelection() {}
    public static boolean exists(State state, String key) {
        if (state == null || key == null) return false;
        if (key.startsWith("f:")) return state.friends != null && state.friends.get(key.substring(2)) != null;
        if (!key.startsWith("g:") || state.groups == null) return false;
        Group g = state.groups.get(key.substring(2));
        return g != null && !g.left;
    }
    public static String choose(State state, String requested, boolean reopen) {
        if (state == null) return null;
        if (exists(state, requested)) return requested;
        if (reopen && exists(state, state.lastConversation)) return state.lastConversation;
        if (state.friends != null) for (Friend f : state.friends.values())
            if (f != null && f.unread > 0) return "f:" + Protocol.key(f.name);
        if (state.groups != null) for (Group g : state.groups.values())
            if (g != null && !g.left && g.unread > 0) return "g:" + g.id;
        String best = null;
        long latest = Long.MIN_VALUE;
        if (state.friends != null) for (Friend f : state.friends.values()) {
            if (f == null) continue;
            long time = Math.max(f.lastActivity, activity(f.messages));
            if (best == null || time > latest) { best = "f:" + Protocol.key(f.name); latest = time; }
        }
        if (state.groups != null) for (Group g : state.groups.values()) if (g != null && !g.left) {
            long time = Math.max(g.lastActivity, activity(g.messages));
            if (best == null || time > latest) { best = "g:" + g.id; latest = time; }
        }
        return best;
    }
    private static long activity(List<Message> messages) {
        long latest = 0;
        if (messages != null) for (Message message : messages)
            if (message != null) latest = Math.max(latest, message.time);
        return latest;
    }
}
