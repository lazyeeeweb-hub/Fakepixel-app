package dev.friendlink.compat;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.friendlink.FriendLink;
import dev.friendlink.ui.PromptScreen;
import net.fabricmc.loader.api.FabricLoader;

/** This entrypoint is queried by Mod Menu, not by Fabric's client initializer. */
public final class ModMenuIntegration implements ModMenuApi {
    @Override public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> FabricLoader.getInstance().isModLoaded("cloth-config") ? ClothScreen.create(parent)
            : new PromptScreen(parent, "Install Cloth Config 11.x for settings", "", value -> null);
    }
}
