package dev.friendlink;

import com.google.gson.Gson;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/** Pure wire helpers. Invites are bounded multipart whispers, NOT encryption or authentication. */
public final class Protocol {
    private static final Gson JSON = new Gson();
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
    private static final Pattern ID = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    public static final Pattern CONTROL = Pattern.compile(
        "^\\[FLI:(?<id>[0-9a-f-]{36}):(?<token>[0-9a-f]{8}):(?<part>[0-9]{1,2}):(?<count>[0-9]{1,2})\\] (?<data>[A-Za-z0-9_-]{1,180})$");
    private Protocol() {}
    public static boolean validName(String s) { return s != null && NAME.matcher(s).matches(); }
    public static boolean validId(String s) { return s != null && ID.matcher(s).matches(); }
    public static String key(String name) { return name.toLowerCase(Locale.ROOT); }
    public static boolean validTag(String s) {
        if (s == null || s.length() > 40 || !s.contains("%s")) return false;
        int at = s.indexOf("%s");
        return at > 0 && at + 2 < s.length() && s.indexOf('%') == at
            && s.lastIndexOf('%') == at && s.chars().allMatch(c -> c >= 32 && c < 127);
    }
    public static Pattern groupPattern(String tag) {
        if (!validTag(tag)) throw new IllegalArgumentException("Tag needs one %s and surrounding delimiters");
        int at = tag.indexOf("%s");
        return Pattern.compile("^" + Pattern.quote(tag.substring(0, at))
            + "(?<id>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
            + Pattern.quote(tag.substring(at + 2)) + " ?(?<message>.*)$");
    }
    public static String prefix(String tag, String id) { return tag.replace("%s", id) + " "; }
    /** Minecraft's command packet accepts at most 256 UTF-16 code units, excluding '/'. */
    public static int bodyLimit(String target) { return 256 - ("msg " + target + " ").length(); }
    public static List<String> split(String text, int limit) {
        if (limit < 2) throw new IllegalArgumentException("No space left in command");
        List<String> parts = new ArrayList<>();
        for (int start = 0; start < text.length();) {
            int end = Math.min(start + limit, text.length());
            if (end < text.length() && Character.isHighSurrogate(text.charAt(end - 1))) end--;
            parts.add(text.substring(start, end)); start = end;
        }
        return parts;
    }
    public static final class Invite {
        public String kind = "sync", id, name, owner;
        public List<String> members;
        public long revision;
    }
    public static boolean validInvite(Invite i, int max) {
        if (i == null || !validId(i.id) || !validName(i.owner) || i.name == null
            || i.name.isBlank() || i.name.length() > 32 || i.name.chars().anyMatch(c -> c < 32 || c == 127)
            || i.members == null || i.members.size() > max || i.members.isEmpty() || i.revision < 0
            || !("sync".equals(i.kind) || "leave".equals(i.kind) || "close".equals(i.kind))) return false;
        HashSet<String> seen = new HashSet<>();
        for (String n : i.members) if (!validName(n) || !seen.add(key(n))) return false;
        return seen.contains(key(i.owner));
    }
    public static List<String> inviteParts(Invite invite) {
        String encoded = Base64.getUrlEncoder().withoutPadding()
            .encodeToString(JSON.toJson(invite).getBytes(StandardCharsets.UTF_8));
        List<String> chunks = split(encoded, 160);
        if (chunks.size() > 16) throw new IllegalArgumentException("Invitation too large");
        String token = UUID.randomUUID().toString().substring(0, 8);
        List<String> result = new ArrayList<>();
        for (int n = 0; n < chunks.size(); n++) result.add("[FLI:" + invite.id + ":" + token
            + ":" + (n + 1) + ":" + chunks.size() + "] " + chunks.get(n));
        return result;
    }
    public static Invite decodeInvite(String data) {
        if (data.length() > 4096) throw new IllegalArgumentException("Invite too large");
        return JSON.fromJson(new String(Base64.getUrlDecoder().decode(data), StandardCharsets.UTF_8), Invite.class);
    }
}
