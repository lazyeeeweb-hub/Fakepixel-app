package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

/** Client-tick transport work only; file completion is marshalled back onto Minecraft's client thread. */
public final class ReceiptService {
    private final FriendLink mod;
    private final Set<String> capable = new HashSet<>(), probed = new HashSet<>(), nearby = new HashSet<>();
    private final LinkedHashMap<String, LinkedHashSet<String>> delivered = new LinkedHashMap<>(), read = new LinkedHashMap<>();
    private final Set<String> filing = new HashSet<>();
    private Pattern groupPattern;
    private long nextBatch;
    public ReceiptService(FriendLink mod) { this.mod = mod; reload(); }
    public void reload() { groupPattern = Protocol.groupPattern(mod.config.groupTag); }
    public boolean capable(String name) { return capable.contains(Protocol.key(name)); }
    public void clear() { capable.clear(); probed.clear(); nearby.clear(); delivered.clear(); read.clear(); nextBatch = 0; }

    /** Receives only already-authorized friend whispers, never public or team-chat text. */
    public boolean receive(String sender, String body, boolean outgoing) {
        if (body.startsWith("[FLC:")) {
            if (outgoing) return true;
            ReliableProtocol.Receipt receipt = ReliableProtocol.receipt(body);
            if (receipt != null) {
                capable.add(Protocol.key(sender));
                for (String id : receipt.ids()) mod.queue.receipt(sender, id, receipt.read());
            } else if (body.equals("[FLC:H]") || body.equals("[FLC:A]")) {
                capable.add(Protocol.key(sender));
                if (body.equals("[FLC:H]")) mod.sendControl(sender, "[FLC:A]");
            } else if (body.equals("[FLC:O]") || body.equals("[FLC:C]")) {
                capable.add(Protocol.key(sender)); mod.presence.receive(sender, body.equals("[FLC:O]"));
            }
            // Malformed reserved controls are suppressed but cannot mutate state.
            return true;
        }
        ReliableProtocol.Tagged tagged = ReliableProtocol.tagged(body);
        if (tagged == null) return false;
        if (outgoing) return true; // A late/mod-origin echo must never create a second visible message.
        capable.add(Protocol.key(sender));
        String key = "f:" + Protocol.key(sender), text = tagged.text();
        Matcher group = groupPattern.matcher(text);
        if (group.matches()) {
            String id = group.group("id");
            Group g = mod.state.groups.get(id);
            if (g == null) {
                if (mod.state.groups.size() >= 128) return true;
                g = new Group(); g.id = id; g.owner = sender; g.revision = -1;
                g.members.add(sender); if (!sender.equalsIgnoreCase(mod.self())) g.members.add(mod.self());
                mod.state.groups.put(id, g); mod.inviteNotice(g, sender);
            }
            if (g.left || !FriendLink.contains(g.members, sender) || !FriendLink.contains(g.members, mod.self())) return true;
            key = "g:" + id; text = group.group("message");
        }
        file(sender, key, tagged.id(), text); return true;
    }
    private void file(String sender, String key, String id, String text) {
        String token = Protocol.key(sender) + ":" + id;
        if (!filing.add(token)) return;
        mod.ensureConversation(key, () -> {
            Message found = null;
            for (Message old : mod.messages(key)) if (id.equals(old.receiptId) && old.sender.equalsIgnoreCase(sender)) { found = old; break; }
            if (found == null) {
                found = new Message(sender, text, false); found.id = id; found.receiptId = id;
                found.receiptRead = mod.visible(key); mod.append(key, found, true);
            } else if (mod.visible(key)) found.receiptRead = true;
            Message filed = found;
            mod.storage.saveLogAsync(key, mod.messages(key)).whenComplete((v, failure) ->
                MinecraftClient.getInstance().execute(() -> {
                    filing.remove(token);
                    if (failure != null) { FriendLink.LOG.error("Could not durably file receipt message {}", id, failure); return; }
                    enqueue(sender, id, filed.receiptRead);
                }));
        });
    }
    private void enqueue(String sender, String id, boolean wasRead) {
        var map = wasRead ? read : delivered;
        String peer = Protocol.key(sender);
        LinkedHashSet<String> ids = map.computeIfAbsent(peer, n -> new LinkedHashSet<>());
        // This is bounded transport state. Repeated sender retries regenerate a lost receipt.
        if (ids.size() < 8192) ids.add(id);
        if (wasRead) {
            var earlier = delivered.get(peer);
            if (earlier != null) earlier.remove(id);
        }
    }
    /** Conversation-open receipt writes precede read controls, including after a restart. */
    public void opened(String key) {
        List<Message> changed = new ArrayList<>();
        for (Message message : mod.messages(key)) if (!message.receiptRead && ReliableProtocol.validId(message.receiptId)
            && !message.sender.equalsIgnoreCase(mod.self())) {
            message.receiptRead = true; changed.add(message);
        }
        if (changed.isEmpty()) return;
        mod.touch();
        mod.storage.saveLogAsync(key, mod.messages(key)).whenComplete((v, failure) -> MinecraftClient.getInstance().execute(() -> {
            if (failure != null) {
                for (Message message : changed) message.receiptRead = false;
                FriendLink.LOG.error("Could not persist read state for {}", key, failure); return;
            }
            for (Message message : changed) enqueue(message.sender, message.receiptId, true);
        }));
    }
    public void tick(MinecraftClient client, long now) {
        if (client.world != null && client.player != null) {
            Set<String> current = new HashSet<>(); // Tick-only, never in rendering callbacks.
            for (AbstractClientPlayerEntity entity : client.world.getPlayers()) {
                if (entity == client.player || client.player.squaredDistanceTo(entity) > 256D * 256D) continue;
                Friend friend = mod.friend(entity.getGameProfile().getName(), entity.getUuid());
                if (friend == null) continue;
                String name = Protocol.key(friend.name); current.add(name);
                if (!nearby.contains(name)) mod.queue.nearby(friend.name);
                if (!probed.contains(name) && mod.sendControl(friend.name, "[FLC:H]")) probed.add(name);
            }
            nearby.clear(); nearby.addAll(current);
        } else nearby.clear();
        if (now < nextBatch) return;
        if (batch(read, true) || batch(delivered, false)) nextBatch = now + 2000;
    }
    private boolean batch(LinkedHashMap<String, LinkedHashSet<String>> map, boolean wasRead) {
        for (var item : map.entrySet()) {
            if (item.getValue().isEmpty()) continue;
            StringBuilder body = new StringBuilder(wasRead ? "[FLC:R:" : "[FLC:D:");
            List<String> sent = new ArrayList<>();
            int limit = Protocol.bodyLimit(item.getKey());
            for (String id : item.getValue()) {
                if (sent.size() == 16 || body.length() + id.length() + 2 > limit) break;
                if (!sent.isEmpty()) body.append(',');
                body.append(id); sent.add(id);
            }
            body.append(']');
            if (!mod.sendControl(item.getKey(), body.toString())) return false;
            item.getValue().removeAll(sent); return true;
        }
        return false;
    }
}
