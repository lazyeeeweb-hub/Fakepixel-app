package dev.friendlink;

/** Scalar-only per-frame math. No vectors, wrappers, collections or other allocations. */
public final class DistanceScaling {
    private DistanceScaling() {}
    public static double multiplier(double distance, boolean enabled, double factor, double maxScale) {
        if (!enabled || distance <= 10) return 1;
        // Ease in over 10..20 blocks, then use 1 + distance * factor exactly.
        // This preserves 1x nearby and approximately 2x at 100 blocks without a discontinuity.
        double t = Math.min(1, (distance - 10) / 10);
        double easedDistance = distance * t * t * (3 - 2 * t);
        return Math.max(1, Math.min(maxScale, 1 + easedDistance * factor));
    }
}
