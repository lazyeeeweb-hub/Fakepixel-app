package dev.friendlink;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Original FriendLink v2 transport. Plain server-visible whispers, not encryption. */
public final class ReliableProtocol {
    private static final Pattern TAG = Pattern.compile("^\\[FLM:([0-9a-f]{12})\\] (.*)$");
    private static final Pattern RECEIPT = Pattern.compile("^\\[FLC:([DR]):([0-9a-f]{12}(?:,[0-9a-f]{12}){0,15})\\]$");
    private static final Pattern ID = Pattern.compile("[0-9a-f]{12}");
    public record Tagged(String id, String text) {}
    public record Receipt(boolean read, String[] ids) {}
    private ReliableProtocol() {}
    public static String newId() { return UUID.randomUUID().toString().replace("-", "").substring(0, 12); }
    public static String prefix(String id) {
        if (!validId(id)) throw new IllegalArgumentException("Invalid message id");
        return "[FLM:" + id + "] ";
    }
    public static boolean validId(String id) { return id != null && ID.matcher(id).matches(); }
    public static Tagged tagged(String body) {
        Matcher m = TAG.matcher(body);
        return m.matches() ? new Tagged(m.group(1), m.group(2)) : null;
    }
    public static Receipt receipt(String body) {
        Matcher m = RECEIPT.matcher(body);
        return m.matches() ? new Receipt(m.group(1).equals("R"), m.group(2).split(",")) : null;
    }
    public static boolean hidden(String body) { return body.startsWith("[FLC:") || body.startsWith("[FLI:"); }
}
