package dev.friendlink.mixin;

import dev.friendlink.FriendLink;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Client-only hook into Mouse.onMouseButton: clicks on our visible toasts open their conversation. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseButton(JIII)V", at = @At("HEAD"), cancellable = true)
    private void friendlink$clickNotice(long window, int button, int action, int mods, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        FriendLink mod = FriendLink.INSTANCE;
        if (mod == null || mod.notifications == null || mc.currentScreen == null || mc.mouse.isCursorLocked()
            || window != mc.getWindow().getHandle() || button != GLFW.GLFW_MOUSE_BUTTON_LEFT || action != GLFW.GLFW_PRESS) return;
        double x = mc.mouse.getX() * mc.getWindow().getScaledWidth() / mc.getWindow().getWidth();
        double y = mc.mouse.getY() * mc.getWindow().getScaledHeight() / mc.getWindow().getHeight();
        if (mod.notifications.click(x, y)) ci.cancel();
    }
}
