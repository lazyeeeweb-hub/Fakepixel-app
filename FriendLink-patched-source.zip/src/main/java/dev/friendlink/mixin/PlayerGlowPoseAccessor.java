package dev.friendlink.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Accesses ONLY PlayerEntityRenderer's pose/transform helpers. No render injection,
 * tracked flags, team colours, status effects or vanilla glow hooks are involved.
 * FriendGlow invokes these in WorldRenderEvents.LAST to reproduce the player pose
 * without re-rendering equipment, names, shadows or invoking the entity dispatcher.
 */
@Mixin(PlayerEntityRenderer.class)
public interface PlayerGlowPoseAccessor {
    @Invoker("setModelPose")
    void friendlink$setModelPose(AbstractClientPlayerEntity player);
    @Invoker("setupTransforms")
    void friendlink$setupTransforms(AbstractClientPlayerEntity player, MatrixStack matrices,
                                    float animationProgress, float bodyYaw, float tickDelta);
    @Invoker("scale")
    void friendlink$scale(AbstractClientPlayerEntity player, MatrixStack matrices, float tickDelta);
}
