package dev.friendlink.mixin;

import com.mojang.authlib.GameProfile;
import dev.friendlink.FriendLink;
import java.time.Instant;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.message.MessageHandler;
import net.minecraft.client.network.message.MessageTrustStatus;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-only hook into MessageHandler's signed-chat processing BEFORE ChatHud,
 * narration and the vanilla chat log. Yarn 1.20.1+build.10 returns boolean here.
 * Only registry-typed friend /msg traffic is consumed; team chat is never routed.
 */
@Mixin(MessageHandler.class)
public abstract class MessageHandlerMixin {
    @Shadow
    private MessageTrustStatus getStatus(SignedMessage message, Text decorated, Instant receptionTimestamp) { throw new AssertionError(); }

    // Hooks vanilla signed-chat dispatch before private /msg HUD insertion.
    @Inject(method = "processChatMessageInternal(Lnet/minecraft/network/message/MessageType$Parameters;Lnet/minecraft/network/message/SignedMessage;Lnet/minecraft/text/Text;Lcom/mojang/authlib/GameProfile;ZLjava/time/Instant;)Z",
        at = @At("HEAD"), cancellable = true)
    private void friendlink$routeWhisper(MessageType.Parameters params, SignedMessage message, Text decorated,
                                        GameProfile sender, boolean onlyShowSecureChat, Instant receptionTimestamp,
                                        CallbackInfoReturnable<Boolean> cir) {
        FriendLink mod = FriendLink.INSTANCE;
        if (mod == null || mod.router == null) return;
        // Authoritative owner of MSG_COMMAND_INCOMING/OUTGOING. Existing ALLOW_CHAT
        // calls bypassTextFallback(params); do NOT add another typed/event hook or body dedup.
        // Let vanilla reject fully filtered messages without filing or acknowledging them.
        if (message.isFullyFiltered()) return;
        // Do not bypass vanilla's secure-only or social-interaction privacy decisions.
        MinecraftClient client = MinecraftClient.getInstance();
        if ((onlyShowSecureChat && getStatus(message, decorated, receptionTimestamp).isInsecure())
            || (sender != null && client.getSocialInteractionsManager().isPlayerBlocked(sender.getId()))) return;
        if (mod.router.receiveTyped(params, message, sender)) cir.setReturnValue(true);
    }

    // Authoritative owner of profileless typed /msg, BEFORE HUD/narration/logging.
    // Other types continue through vanilla; no second Fabric typed listener is installed.
    // Hooks profileless system-chat delivery before vanilla HUD insertion; handles raw plugin messages.
    @Inject(method = "onProfilelessMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageType$Parameters;)V",
        at = @At("HEAD"), cancellable = true)
    private void friendlink$routeProfilelessWhisper(Text content, MessageType.Parameters params, CallbackInfo ci) {
        FriendLink mod = FriendLink.INSTANCE;
        if (mod != null && mod.router != null && mod.router.receiveProfileless(params, content)) ci.cancel();
    }
}
