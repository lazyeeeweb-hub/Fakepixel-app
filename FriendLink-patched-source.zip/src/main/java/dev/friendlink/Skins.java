package dev.friendlink;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;

/** No HTTP, disk reads, or image decoding in render(). All mutable maps belong to the client thread. */
public final class Skins implements AutoCloseable {
    private static final long WEEK = 7L * 24 * 60 * 60 * 1000;
    private final FriendLink mod;
    private final Path folder;
    private final Map<String, Entry> entries = new HashMap<>();
    private final ExecutorService workers = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "FriendLink-skins"); t.setDaemon(true); return t;
    });
    private volatile boolean closed;
    private static final class Entry {
        final String name, key;
        Identifier offline, face;
        boolean busy;
        long nextAttempt;
        Entry(String name) {
            this.name = name; this.key = Protocol.key(name);
            UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            offline = face = DefaultSkinHelper.getTexture(uuid);
        }
    }
    public Skins(FriendLink mod) { this.mod = mod; this.folder = mod.storage.root().resolve("skins"); }
    public void request(String name) {
        if (closed || !Protocol.validName(name)) return;
        String key = Protocol.key(name);
        Entry e = entries.get(key);
        if (e == null) {
            if (entries.size() >= 1024) return;
            e = new Entry(name); entries.put(key, e);
        }
        if (!e.busy && System.currentTimeMillis() >= e.nextAttempt) {
            e.busy = true; Entry target = e;
            workers.execute(() -> resolve(target));
        }
    }
    /** Tick-only lookup: screens/HUD keep the returned Identifier in their own cached rows. */
    public Identifier face(String name) {
        Entry e = name == null ? null : entries.get(Protocol.key(name));
        return e == null ? DefaultSkinHelper.getTexture() : e.face;
    }
    public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (var f : mod.state.friends.values()) request(f.name);
        for (var g : mod.state.groups.values()) if (!g.left) for (String n : g.members) request(n);
        for (Entry e : entries.values()) {
            PlayerListEntry online = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(e.name);
            Identifier texture = online == null ? e.offline : online.getSkinTexture();
            if (!texture.equals(e.face)) { e.face = texture; mod.version++; }
        }
    }
    private void resolve(Entry e) {
        long retry = System.currentTimeMillis() + 5 * 60 * 1000L;
        try {
            Files.createDirectories(folder);
            Path png = folder.resolve(e.key + ".png"), profile = folder.resolve(e.key + ".json");
            boolean cached = Files.isRegularFile(png) && Files.size(png) <= 1024 * 1024;
            if (cached) upload(e, image(Files.readAllBytes(png)));
            boolean fresh = cached && Files.isRegularFile(profile) && System.currentTimeMillis() - Files.getLastModifiedTime(profile).toMillis() < WEEK;
            if (!fresh) {
                JsonObject user = json("https://api.mojang.com/users/profiles/minecraft/" + e.name);
                String uuid = user.get("id").getAsString();
                if (!uuid.matches("[0-9a-fA-F]{32}")) throw new IOException("Invalid UUID response");
                JsonObject session = json("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid);
                String encoded = null;
                for (var p : session.getAsJsonArray("properties")) {
                    JsonObject property = p.getAsJsonObject();
                    if ("textures".equals(property.get("name").getAsString())) { encoded = property.get("value").getAsString(); break; }
                }
                if (encoded == null || encoded.length() > 65536) throw new IOException("No skin property");
                JsonObject textures = JsonParser.parseString(new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8)).getAsJsonObject();
                String url = textures.getAsJsonObject("textures").getAsJsonObject("SKIN").get("url").getAsString();
                // Only official texture endpoints, never arbitrary URLs from a remote JSON response.
                if (!url.matches("https?://textures\\.minecraft\\.net/texture/[0-9a-fA-F]+")) throw new IOException("Untrusted skin URL");
                url = url.replace("http://", "https://");
                byte[] bytes = get(url, 1024 * 1024);
                NativeImage decoded = image(bytes);
                try {
                    atomic(png, bytes);
                    atomic(profile, ("{\"uuid\":\"" + uuid + "\",\"url\":\"" + url + "\"}").getBytes(StandardCharsets.UTF_8));
                } catch (IOException disk) { FriendLink.LOG.warn("Could not cache skin for {}", e.name, disk); }
                upload(e, decoded);
            }
            retry = System.currentTimeMillis() + WEEK;
        } catch (Exception error) { FriendLink.LOG.debug("Skin lookup for {} unavailable; using cached/default head", e.name, error); }
        long next = retry;
        MinecraftClient.getInstance().execute(() -> { e.busy = false; e.nextAttempt = next; });
    }
    private static NativeImage image(byte[] bytes) throws IOException {
        NativeImage image = NativeImage.read(bytes);
        if (image.getWidth() != 64 || (image.getHeight() != 32 && image.getHeight() != 64)) {
            image.close(); throw new IOException("Unsupported skin dimensions");
        }
        if (image.getHeight() == 32) {
            // Only head/hat UVs are used, but normalize legacy 64x32 skins to a 64x64 texture.
            NativeImage padded = new NativeImage(64, 64, false);
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++)
                padded.setColor(x, y, y < 32 ? image.getColor(x, y) : 0);
            image.close(); image = padded;
        }
        return image;
    }
    private void upload(Entry e, NativeImage decoded) {
        MinecraftClient.getInstance().execute(() -> {
            if (closed) { decoded.close(); return; }
            MinecraftClient mc = MinecraftClient.getInstance();
            Identifier id = new Identifier("friendlink", "skins/" + e.key);
            mc.getTextureManager().destroyTexture(id);
            mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(decoded));
            e.offline = id; mod.version++;
        });
    }
    private static JsonObject json(String url) throws IOException {
        return JsonParser.parseString(new String(get(url, 65536), StandardCharsets.UTF_8)).getAsJsonObject();
    }
    private static byte[] get(String url, int cap) throws IOException {
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setConnectTimeout(4000); c.setReadTimeout(6000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent", "FriendLink/1.0 (Minecraft client skin cache)");
        try {
            int status = c.getResponseCode();
            if (status != 200) throw new IOException("HTTP " + status);
            try (InputStream in = c.getInputStream()) {
                byte[] bytes = in.readNBytes(cap + 1);
                if (bytes.length > cap) throw new IOException("Response too large");
                return bytes;
            }
        } finally { c.disconnect(); }
    }
    private static void atomic(Path path, byte[] bytes) throws IOException {
        Path temp = path.resolveSibling(path.getFileName() + ".tmp");
        Files.write(temp, bytes);
        try { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING); }
    }
    @Override public void close() {
        closed = true; workers.shutdownNow();
        var manager = MinecraftClient.getInstance().getTextureManager();
        for (Entry e : entries.values()) if ("friendlink".equals(e.offline.getNamespace())) manager.destroyTexture(e.offline);
        entries.clear();
    }
}
