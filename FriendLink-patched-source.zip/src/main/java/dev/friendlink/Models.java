package dev.friendlink;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Models {
    private Models() {}
    public static final class Delivery {
        /** Legacy counters remain readable by older queue/UI code. Echoes are not receipts. */
        public int total, completed, failed, unconfirmed;
        /** Wire part id -> 0 queued, 1 sent/pending, 2 delivered, 3 read, 4 failed. */
        public LinkedHashMap<String, Integer> parts = new LinkedHashMap<>();

        public int stage() {
            if (failed > 0) return 4;
            if (parts == null || parts.isEmpty()) return total > 0 && completed >= total ? 1 : 0;
            int lowest = 3;
            for (Integer part : parts.values()) {
                int stage = part == null || part < 0 || part > 4 ? 0 : part;
                if (stage == 4) return 4;
                lowest = Math.min(lowest, stage);
            }
            return lowest;
        }
    }
    public static final class Message {
        public long time = System.currentTimeMillis();
        public String sender = "", text = "";
        /** Logical outbound message id, or the inbound wire id. */
        public String id = "";
        /** Inbound wire id to acknowledge only after its log has been saved. */
        public String receiptId = "";
        public boolean receiptRead;
        public boolean system;
        public LinkedHashMap<String, Delivery> delivery = new LinkedHashMap<>();
        public Message() {}
        public Message(String sender, String text, boolean system) {
            this.sender = sender; this.text = text; this.system = system;
        }
        /** Lowest target stage, except that any failure takes precedence. */
        public int stage() {
            if (delivery == null || delivery.isEmpty()) return 0;
            int lowest = 3;
            for (Delivery target : delivery.values()) {
                int stage = target == null ? 0 : target.stage();
                if (stage == 4) return 4;
                lowest = Math.min(lowest, stage);
            }
            return lowest;
        }
        /** Called only while rebuilding a cached screen layout, never in render(). */
        public String status() {
            if (delivery == null || delivery.isEmpty()) return "";
            StringBuilder b = new StringBuilder();
            for (var e : delivery.entrySet()) {
                if (b.length() > 0) b.append(" | ");
                b.append(e.getKey()).append(": ");
                Delivery d = e.getValue();
                if (d == null) { b.append("queued"); continue; }
                if (d.parts == null || d.parts.isEmpty()) {
                    // Preserve legacy status text, but never conceal a failure behind queued work.
                    if (d.failed > 0) b.append("unreachable (").append(d.failed).append(" parts)");
                    else if (d.completed < d.total) b.append("sending... ").append(d.completed).append('/').append(d.total);
                    else if (d.unconfirmed > 0) b.append("unconfirmed");
                    else if (d.total > 0) b.append("✓ sent");
                    else b.append("queued");
                    continue;
                }
                int sent = 0, delivered = 0, read = 0, failed = 0;
                for (Integer part : d.parts.values()) {
                    if (part == null) continue;
                    if (part >= 1 && part <= 3) sent++;
                    if (part == 2 || part == 3) delivered++;
                    if (part == 3) read++;
                    if (part == 4) failed++;
                }
                b.append(switch (d.stage()) {
                    case 1 -> "sent / pending";
                    case 2 -> "delivered";
                    case 3 -> "read";
                    case 4 -> "failed";
                    default -> "queued";
                });
                b.append(" (").append(sent).append('/').append(d.parts.size()).append(" sent, ")
                    .append(delivered).append(" delivered, ").append(read).append(" read");
                if (failed > 0 || d.failed > 0) b.append(", ").append(Math.max(failed, d.failed)).append(" failed");
                b.append(')');
            }
            return b.toString();
        }
    }
    public static final class Friend {
        public String name = "";
        // Learned from the game's player profiles, not an external name lookup.
        public String uuid = "";
        public boolean glow = false;
        public int color = 0xFFFF00, unread;
        public long lastActivity;
        /** Set by the parent only after publishing a successfully loaded log. */
        public transient boolean logLoaded = false;
        public GlowToggle shareChatOpen = GlowToggle.DEFAULT;
        public GlowStyle glowStyle = GlowStyle.DEFAULT;
        public GlowToggle glowThroughWalls = GlowToggle.DEFAULT, glowPulse = GlowToggle.DEFAULT;
        public int glowOpacity = -1, glowMaxDistance = 0;
        public double glowThickness = 0;
        /** Called at load and on cache rebuild, never in the frame loop. */
        public void normalizeGlow() {
            color &= 0xFFFFFF;
            if (glowStyle == null) glowStyle = GlowStyle.DEFAULT;
            if (glowThroughWalls == null) glowThroughWalls = GlowToggle.DEFAULT;
            if (glowPulse == null) glowPulse = GlowToggle.DEFAULT;
            if (shareChatOpen == null) shareChatOpen = GlowToggle.DEFAULT;
            glowOpacity = Config.clamp(glowOpacity, -1, 100);
            glowMaxDistance = Config.clamp(glowMaxDistance, 0, 4096);
            if (!Double.isFinite(glowThickness) || glowThickness <= 0) glowThickness = 0;
            else glowThickness = Math.max(1.04, Math.min(1.08, glowThickness));
        }
        public List<Message> messages = new ArrayList<>();
    }
    public static final class Group {
        public String id = "", name = "Unknown group", owner = "";
        public List<String> members = new ArrayList<>();
        public boolean pending = true, muted, sound = true, left;
        public long revision;
        public int unread;
        public long lastActivity;
        /** Set by the parent only after publishing a successfully loaded log. */
        public transient boolean logLoaded = false;
        public List<Message> messages = new ArrayList<>();
    }
    public static final class State {
        public int schema = 1;
        public String lastConversation = "";
        public LinkedHashMap<String, Friend> friends = new LinkedHashMap<>();
        public LinkedHashMap<String, Group> groups = new LinkedHashMap<>();
    }
}
