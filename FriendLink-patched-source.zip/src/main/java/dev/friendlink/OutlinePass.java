package dev.friendlink;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL;
import org.lwjgl.system.MemoryUtil;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL14.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL21.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.opengl.GL32.*;
import static org.lwjgl.opengl.GL33.GL_SAMPLER_BINDING;
import static org.lwjgl.opengl.GL33.glBindSampler;

/**
 * Original, Minecraft-independent mask/outline pass. Render-thread only.
 * OpenGL 3.3 (Minecraft 1.20.1/LWJGL 3.3.1); GLSL 150, no stencil.
 * Per-frame methods use retained buffers and do not construct Java objects.
 * Call resize from a render-thread tick, never while a pass is active.
 */
public final class OutlinePass implements AutoCloseable {
    public static final int MAX_RADIUS = 6;
    private static final int FLOATS_PER_VERTEX = 5;
    private static final int STRIDE = FLOATS_PER_VERTEX * Float.BYTES;
    private static final int VERTEX_CAPACITY = 65532; // multiple of six

    private final FloatBuffer vertices = MemoryUtil.memAllocFloat(VERTEX_CAPACITY * FLOATS_PER_VERTEX);
    private final FloatBuffer matrix = MemoryUtil.memAllocFloat(16);
    private final FloatBuffer zeros = MemoryUtil.memCallocFloat(4);
    private final float[] quad = new float[4 * FLOATS_PER_VERTEX];
    private final State saved = new State();
    private int fbo, maskTexture, maskVao, screenVao, vbo, maskProgram, outlineProgram;
    private int projectionLocation, skinLocation, useSkinLocation, cutoffLocation;
    private int maskLocation, colorLocation, radiusLocation, fillLocation, originLocation;
    private int width, height, quadCount;
    private boolean active, geometryReady, closed, samplerObjects;

    private static final String MASK_VERTEX = """
        #version 150
        in vec3 Position;
        in vec2 UV;
        uniform mat4 Projection;
        out vec2 texCoord;
        void main() {
            gl_Position = Projection * vec4(Position, 1.0);
            texCoord = UV;
        }
        """;
    private static final String MASK_FRAGMENT = """
        #version 150
        uniform sampler2D Skin;
        uniform int UseSkin;
        uniform float AlphaCutoff;
        in vec2 texCoord;
        out vec4 FragColor;
        void main() {
            if (UseSkin != 0 && texture(Skin, texCoord).a < AlphaCutoff) discard;
            FragColor = vec4(1.0);
        }
        """;
    private static final String SCREEN_VERTEX = """
        #version 150
        void main() {
            vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
            gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
        }
        """;
    private static final String SCREEN_FRAGMENT = """
        #version 150
        uniform sampler2D Mask;
        uniform vec4 Color;
        uniform int Radius;
        uniform float FillOpacity;
        uniform ivec2 ViewportOrigin;
        out vec4 FragColor;
        float occupancy(ivec2 p) {
            ivec2 size = textureSize(Mask, 0);
            if (p.x < 0 || p.y < 0 || p.x >= size.x || p.y >= size.y) return 0.0;
            return texelFetch(Mask, p, 0).a;
        }
        void main() {
            ivec2 p = ivec2(gl_FragCoord.xy) - ViewportOrigin;
            float center = occupancy(p);
            float grown = center;
            for (int y = -6; y <= 6; ++y) {
                for (int x = -6; x <= 6; ++x) {
                    if (x*x + y*y <= Radius*Radius) {
                        grown = max(grown, occupancy(p + ivec2(x,y)));
                    }
                }
            }
            float coverage = max(grown - center, center * FillOpacity);
            if (coverage <= 0.0 || Color.a <= 0.0) discard;
            FragColor = vec4(Color.rgb, Color.a * coverage);
        }
        """;

    /** Allocate/reallocate GL objects on the render thread. Throws on setup errors. */
    public void resize(int newWidth, int newHeight) {
        ensureOpen();
        if (active) throw new IllegalStateException("OutlinePass resize during active pass");
        if (newWidth <= 0 || newHeight <= 0) return;
        if (width == newWidth && height == newHeight && fbo != 0) return;
        samplerObjects = GL.getCapabilities().OpenGL33 || GL.getCapabilities().GL_ARB_sampler_objects;
        saved.capture(samplerObjects);
        try {
            initializeObjects();
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, maskTexture);
            glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, newWidth, newHeight,
                    0, GL_RGBA, GL_UNSIGNED_BYTE, (ByteBuffer) null);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                    GL_TEXTURE_2D, maskTexture, 0);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                    GL_TEXTURE_2D, 0, 0);
            glDrawBuffer(GL_COLOR_ATTACHMENT0);
            int status = glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER);
            if (status != GL_FRAMEBUFFER_COMPLETE) {
                width = height = 0;
                throw new IllegalStateException("Outline mask framebuffer incomplete: 0x" + Integer.toHexString(status));
            }
            width = newWidth;
            height = newHeight;
        } finally {
            saved.restore();
        }
    }

    /**
     * Begin one friend's mask. Does not resize or compile shaders.
     * Returns false on unavailable resources, size/viewport mismatch or invalid depth target.
     * The destination is the draw framebuffer bound on entry.
     * Main depth must be an ordinary, same-size GL_TEXTURE_2D when throughWalls=false.
     */
    public boolean begin(int renderWidth, int renderHeight, int mainDepthTexture, boolean throughWalls) {
        ensureOpen();
        if (active) throw new IllegalStateException("OutlinePass already active");
        if (fbo == 0 || width <= 0 || height <= 0 || width != renderWidth || height != renderHeight) return false;
        saved.capture(samplerObjects);
        active = true;
        geometryReady = false;
        quadCount = 0;
        vertices.clear();
        try {
            if (saved.drawFbo == fbo || saved.viewportW != width || saved.viewportH != height) {
                cancel();
                return false;
            }
            glActiveTexture(GL_TEXTURE0);
            if (samplerObjects) glBindSampler(0, 0);
            if (!throughWalls) {
                if (mainDepthTexture <= 0 || !glIsTexture(mainDepthTexture)) {
                    cancel();
                    return false;
                }
                glBindTexture(GL_TEXTURE_2D, mainDepthTexture);
                if (glGetTexLevelParameteri(GL_TEXTURE_2D, 0, GL_TEXTURE_WIDTH) != width
                        || glGetTexLevelParameteri(GL_TEXTURE_2D, 0, GL_TEXTURE_HEIGHT) != height) {
                    cancel();
                    return false;
                }
            }
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                    GL_TEXTURE_2D, throughWalls ? 0 : mainDepthTexture, 0);
            if (glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
                cancel();
                return false;
            }
            glViewport(0, 0, width, height);
            glDisable(GL_BLEND);
            glDisable(GL_CULL_FACE);
            glDisable(GL_SCISSOR_TEST);
            glDisable(GL_STENCIL_TEST);
            glDisable(GL_RASTERIZER_DISCARD);
            glDisable(GL_POLYGON_OFFSET_FILL);
            glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);
            glDisable(GL_SAMPLE_COVERAGE);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glColorMask(true, true, true, true);
            glDepthMask(false);
            setEnabled(GL_DEPTH_TEST, !throughWalls);
            glDepthFunc(GL_LEQUAL);
            // No depth or stencil clear. glClearBufferfv does not change glClearColor.
            zeros.clear();
            glClearBufferfv(GL_COLOR, 0, zeros);
            return true;
        } catch (RuntimeException | Error failure) {
            cancel();
            throw failure;
        }
    }

    /** Convenience entry for this class's retained raw-geometry renderer. */
    public boolean begin(int renderWidth, int renderHeight, int mainDepthTexture,
                         boolean throughWalls, Matrix4fc projection) {
        if (!begin(renderWidth, renderHeight, mainDepthTexture, throughWalls)) return false;
        try {
            beginMask(projection);
            return true;
        } catch (RuntimeException | Error failure) {
            cancel();
            throw failure;
        }
    }

    /** Positions supplied to vertex() must already have their model/view transform applied. */
    public void beginMask(Matrix4fc projection) {
        requireActive();
        if (geometryReady) flush();
        matrix.clear();
        projection.get(matrix);
        glUseProgram(maskProgram);
        glUniformMatrix4fv(projectionLocation, false, matrix);
        glUniform1i(skinLocation, 0);
        glUniform1i(useSkinLocation, 0);
        glUniform1f(cutoffLocation, 0.1f);
        glBindVertexArray(maskVao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        geometryReady = true;
    }

    /** Optional alpha-cutout skin support. Zero selects a solid, untextured mask. */
    public void setMaskTexture(int skinTexture) {
        requireGeometry();
        if (quadCount != 0) throw new IllegalStateException("Skin changed inside a quad");
        flush();
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, skinTexture);
        glUniform1i(useSkinLocation, skinTexture == 0 ? 0 : 1);
    }

    /** Submit consecutive QUADS; every four calls are converted to two triangles. */
    public void vertex(float x, float y, float z) {
        vertex(x, y, z, 0.0f, 0.0f);
    }

    /** Submit a quad vertex with skin UV. Requires setMaskTexture for alpha testing. */
    public void vertex(float x, float y, float z, float u, float v) {
        requireGeometry();
        int p = quadCount * FLOATS_PER_VERTEX;
        quad[p] = x;
        quad[p + 1] = y;
        quad[p + 2] = z;
        quad[p + 3] = u;
        quad[p + 4] = v;
        if (++quadCount == 4) {
            if (vertices.remaining() < 6 * FLOATS_PER_VERTEX) flush();
            appendQuadVertex(0); appendQuadVertex(1); appendQuadVertex(2);
            appendQuadVertex(0); appendQuadVertex(2); appendQuadVertex(3);
            quadCount = 0;
        }
    }

    /** Upload and draw complete collected triangles. Retained GPU storage is not resized. */
    public void flush() {
        requireActive();
        if (vertices.position() == 0) return;
        int vertexCount = vertices.position() / FLOATS_PER_VERTEX;
        vertices.flip();
        glBindVertexArray(maskVao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferSubData(GL_ARRAY_BUFFER, 0L, vertices);
        glDrawArrays(GL_TRIANGLES, 0, vertexCount);
        vertices.clear();
    }

    /**
     * Composite this friend's outline then restore all state touched by this class.
     * Colors/opacity/fill are [0,1]; radius is rounded and clamped to 0..6 physical pixels.
     * fillOpacity=0 gives outline only. Opacity multiplies both outline and fill.
     */
    public void finish(float red, float green, float blue, float opacity,
                       float thicknessPixels, float fillOpacity) {
        requireActive();
        try {
            if (quadCount != 0) throw new IllegalStateException("Incomplete final outline quad");
            flush();
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, 0, 0);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, saved.drawFbo);
            glViewport(saved.viewportX, saved.viewportY, saved.viewportW, saved.viewportH);
            glDisable(GL_DEPTH_TEST);
            glDepthMask(false);
            glDisable(GL_CULL_FACE);
            glDisable(GL_SCISSOR_TEST);
            glDisable(GL_STENCIL_TEST);
            glDisable(GL_RASTERIZER_DISCARD);
            glDisable(GL_POLYGON_OFFSET_FILL);
            glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);
            glDisable(GL_SAMPLE_COVERAGE);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glColorMask(true, true, true, true);
            glEnable(GL_BLEND);
            glBlendEquationSeparate(GL_FUNC_ADD, GL_FUNC_ADD);
            glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
            glUseProgram(outlineProgram);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, maskTexture);
            if (samplerObjects) glBindSampler(0, 0);
            glUniform1i(maskLocation, 0);
            glUniform4f(colorLocation, clamp01(red), clamp01(green), clamp01(blue), clamp01(opacity));
            glUniform1i(radiusLocation, Math.max(0, Math.min(MAX_RADIUS, Math.round(thicknessPixels))));
            glUniform1f(fillLocation, clamp01(fillOpacity));
            glUniform2i(originLocation, saved.viewportX, saved.viewportY);
            glBindVertexArray(screenVao);
            glDrawArrays(GL_TRIANGLES, 0, 3);
        } finally {
            cancel();
        }
    }

    /** Discard unfinished work, detach borrowed depth and restore entry state. Safe if inactive. */
    public void cancel() {
        if (!active) return;
        try {
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, 0, 0);
        } finally {
            active = false;
            geometryReady = false;
            quadCount = 0;
            vertices.clear();
            saved.restore();
        }
    }

    public boolean isReady(int renderWidth, int renderHeight) {
        return !closed && fbo != 0 && width > 0 && height > 0 && width == renderWidth && height == renderHeight;
    }

    /** GL context must still be current. Call only when this pass is not externally bound. */
    @Override
    public void close() {
        if (closed) return;
        cancel();
        if (maskProgram != 0) glDeleteProgram(maskProgram);
        if (outlineProgram != 0) glDeleteProgram(outlineProgram);
        if (maskVao != 0) glDeleteVertexArrays(maskVao);
        if (screenVao != 0) glDeleteVertexArrays(screenVao);
        if (vbo != 0) glDeleteBuffers(vbo);
        if (fbo != 0) glDeleteFramebuffers(fbo);
        if (maskTexture != 0) glDeleteTextures(maskTexture);
        maskProgram = outlineProgram = maskVao = screenVao = vbo = fbo = maskTexture = 0;
        width = height = 0;
        MemoryUtil.memFree(vertices);
        MemoryUtil.memFree(matrix);
        MemoryUtil.memFree(zeros);
        saved.close();
        closed = true;
    }

    private void initializeObjects() {
        if (maskProgram == 0) {
            maskProgram = createProgram(MASK_VERTEX, MASK_FRAGMENT, true);
            projectionLocation = uniform(maskProgram, "Projection");
            skinLocation = uniform(maskProgram, "Skin");
            useSkinLocation = uniform(maskProgram, "UseSkin");
            cutoffLocation = uniform(maskProgram, "AlphaCutoff");
        }
        if (outlineProgram == 0) {
            outlineProgram = createProgram(SCREEN_VERTEX, SCREEN_FRAGMENT, false);
            maskLocation = uniform(outlineProgram, "Mask");
            colorLocation = uniform(outlineProgram, "Color");
            radiusLocation = uniform(outlineProgram, "Radius");
            fillLocation = uniform(outlineProgram, "FillOpacity");
            originLocation = uniform(outlineProgram, "ViewportOrigin");
        }
        if (maskVao == 0) maskVao = glGenVertexArrays();
        if (screenVao == 0) screenVao = glGenVertexArrays();
        if (vbo == 0) {
            vbo = glGenBuffers();
            glBindVertexArray(maskVao);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, (long) VERTEX_CAPACITY * STRIDE, GL_STREAM_DRAW);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, false, STRIDE, 0L);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, false, STRIDE, 3L * Float.BYTES);
        }
        if (maskTexture == 0) {
            maskTexture = glGenTextures();
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, maskTexture);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
        }
        if (fbo == 0) fbo = glGenFramebuffers();
        if (maskVao == 0 || screenVao == 0 || vbo == 0 || maskTexture == 0 || fbo == 0) {
            throw new IllegalStateException("Unable to allocate outline GL objects");
        }
    }

    private static int createProgram(String vertexSource, String fragmentSource, boolean attributes) {
        int vs = 0, fs = 0, program = 0;
        try {
            vs = compile(GL_VERTEX_SHADER, vertexSource);
            fs = compile(GL_FRAGMENT_SHADER, fragmentSource);
            program = glCreateProgram();
            if (program == 0) throw new IllegalStateException("Unable to create outline program");
            glAttachShader(program, vs);
            glAttachShader(program, fs);
            if (attributes) {
                glBindAttribLocation(program, 0, "Position");
                glBindAttribLocation(program, 1, "UV");
            }
            glBindFragDataLocation(program, 0, "FragColor");
            glLinkProgram(program);
            if (glGetProgrami(program, GL_LINK_STATUS) == GL_FALSE) {
                throw new IllegalStateException("Outline shader link failed: " + glGetProgramInfoLog(program));
            }
            return program;
        } catch (RuntimeException | Error failure) {
            if (program != 0) glDeleteProgram(program);
            throw failure;
        } finally {
            if (vs != 0) glDeleteShader(vs);
            if (fs != 0) glDeleteShader(fs);
        }
    }

    private static int compile(int type, String source) {
        int shader = glCreateShader(type);
        if (shader == 0) throw new IllegalStateException("Unable to create outline shader");
        try {
            glShaderSource(shader, source);
            glCompileShader(shader);
            if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
                throw new IllegalStateException("Outline shader compilation failed: " + glGetShaderInfoLog(shader));
            }
            return shader;
        } catch (RuntimeException | Error failure) {
            glDeleteShader(shader);
            throw failure;
        }
    }

    private static int uniform(int program, String name) {
        int location = glGetUniformLocation(program, name);
        if (location < 0) throw new IllegalStateException("Missing outline uniform: " + name);
        return location;
    }

    private void appendQuadVertex(int i) {
        int p = i * FLOATS_PER_VERTEX;
        vertices.put(quad[p]).put(quad[p + 1]).put(quad[p + 2]).put(quad[p + 3]).put(quad[p + 4]);
    }

    private static float clamp01(float x) {
        if (!(x > 0.0f)) return 0.0f; // also handles NaN
        return Math.min(x, 1.0f);
    }

    private void ensureOpen() {
        if (closed) throw new IllegalStateException("OutlinePass is closed");
    }

    private void requireActive() {
        ensureOpen();
        if (!active) throw new IllegalStateException("OutlinePass has not begun");
    }

    private void requireGeometry() {
        requireActive();
        if (!geometryReady) throw new IllegalStateException("Call beginMask(projection) before vertex()");
    }

    private static void setEnabled(int capability, boolean enabled) {
        if (enabled) glEnable(capability); else glDisable(capability);
    }

    /** Captures raw driver state, restoring it without touching RenderSystem caches. */
    private static final class State implements AutoCloseable {
        private final IntBuffer ints = MemoryUtil.memAllocInt(16);
        private final ByteBuffer bools = MemoryUtil.memAlloc(4);
        int drawFbo, readFbo, viewportX, viewportY, viewportW, viewportH;
        int program, vao, arrayBuffer, unpackBuffer, activeTexture, texture0, sampler0;
        int depthFunc, srcRgb, dstRgb, srcAlpha, dstAlpha, eqRgb, eqAlpha, polygonFront, polygonBack;
        boolean blend, depth, depthWrite, cull, scissor, stencil, rasterDiscard, samplerObjects;
        boolean polygonOffsetFill, alphaToCoverage, sampleCoverage, red, green, blue, alpha;

        void capture(boolean hasSamplerObjects) {
            samplerObjects = hasSamplerObjects;
            drawFbo = integer(GL_DRAW_FRAMEBUFFER_BINDING);
            readFbo = integer(GL_READ_FRAMEBUFFER_BINDING);
            ints.clear(); glGetIntegerv(GL_VIEWPORT, ints);
            viewportX = ints.get(0); viewportY = ints.get(1);
            viewportW = ints.get(2); viewportH = ints.get(3);
            program = integer(GL_CURRENT_PROGRAM);
            vao = integer(GL_VERTEX_ARRAY_BINDING);
            arrayBuffer = integer(GL_ARRAY_BUFFER_BINDING);
            unpackBuffer = integer(GL_PIXEL_UNPACK_BUFFER_BINDING);
            activeTexture = integer(GL_ACTIVE_TEXTURE);
            glActiveTexture(GL_TEXTURE0);
            texture0 = integer(GL_TEXTURE_BINDING_2D);
            sampler0 = samplerObjects ? integer(GL_SAMPLER_BINDING) : 0;
            glActiveTexture(activeTexture);
            depthFunc = integer(GL_DEPTH_FUNC);
            srcRgb = integer(GL_BLEND_SRC_RGB); dstRgb = integer(GL_BLEND_DST_RGB);
            srcAlpha = integer(GL_BLEND_SRC_ALPHA); dstAlpha = integer(GL_BLEND_DST_ALPHA);
            eqRgb = integer(GL_BLEND_EQUATION_RGB); eqAlpha = integer(GL_BLEND_EQUATION_ALPHA);
            ints.clear(); glGetIntegerv(GL_POLYGON_MODE, ints);
            polygonFront = ints.get(0); polygonBack = ints.get(1);
            bools.clear(); glGetBooleanv(GL_COLOR_WRITEMASK, bools);
            red = bools.get(0) != 0; green = bools.get(1) != 0;
            blue = bools.get(2) != 0; alpha = bools.get(3) != 0;
            bools.clear(); glGetBooleanv(GL_DEPTH_WRITEMASK, bools);
            depthWrite = bools.get(0) != 0;
            blend = glIsEnabled(GL_BLEND); depth = glIsEnabled(GL_DEPTH_TEST);
            cull = glIsEnabled(GL_CULL_FACE); scissor = glIsEnabled(GL_SCISSOR_TEST);
            stencil = glIsEnabled(GL_STENCIL_TEST);
            rasterDiscard = glIsEnabled(GL_RASTERIZER_DISCARD);
            polygonOffsetFill = glIsEnabled(GL_POLYGON_OFFSET_FILL);
            alphaToCoverage = glIsEnabled(GL_SAMPLE_ALPHA_TO_COVERAGE);
            sampleCoverage = glIsEnabled(GL_SAMPLE_COVERAGE);
        }

        void restore() {
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, drawFbo);
            glBindFramebuffer(GL_READ_FRAMEBUFFER, readFbo);
            glViewport(viewportX, viewportY, viewportW, viewportH);
            glUseProgram(program);
            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, arrayBuffer);
            glBindBuffer(GL_PIXEL_UNPACK_BUFFER, unpackBuffer);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, texture0);
            if (samplerObjects) glBindSampler(0, sampler0);
            glActiveTexture(activeTexture);
            glDepthFunc(depthFunc);
            glDepthMask(depthWrite);
            glBlendEquationSeparate(eqRgb, eqAlpha);
            glBlendFuncSeparate(srcRgb, dstRgb, srcAlpha, dstAlpha);
            glColorMask(red, green, blue, alpha);
            if (polygonFront == polygonBack) glPolygonMode(GL_FRONT_AND_BACK, polygonFront);
            else { // only compatibility contexts can have differing front/back modes
                glPolygonMode(GL_FRONT, polygonFront);
                glPolygonMode(GL_BACK, polygonBack);
            }
            setEnabled(GL_BLEND, blend); setEnabled(GL_DEPTH_TEST, depth);
            setEnabled(GL_CULL_FACE, cull); setEnabled(GL_SCISSOR_TEST, scissor);
            setEnabled(GL_STENCIL_TEST, stencil);
            setEnabled(GL_RASTERIZER_DISCARD, rasterDiscard);
            setEnabled(GL_POLYGON_OFFSET_FILL, polygonOffsetFill);
            setEnabled(GL_SAMPLE_ALPHA_TO_COVERAGE, alphaToCoverage);
            setEnabled(GL_SAMPLE_COVERAGE, sampleCoverage);
        }

        private int integer(int name) {
            ints.clear(); glGetIntegerv(name, ints); return ints.get(0);
        }

        @Override public void close() {
            MemoryUtil.memFree(ints);
            MemoryUtil.memFree(bools);
        }
    }
}
