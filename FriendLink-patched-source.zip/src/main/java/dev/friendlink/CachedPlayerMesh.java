package dev.friendlink;

import java.util.Arrays;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/**
 * Local cuboid positions are captured once per renderer/model, on a client tick.
 * Render uses the live vanilla pose fields but no ModelPart.render(), streams,
 * MatrixStack.push(), temporary vectors or temporary quaternions. This includes
 * the six base skin parts and all six visible hat/jacket/sleeve/trouser overlays.
 */
final class CachedPlayerMesh {
    final PlayerEntityModel<AbstractClientPlayerEntity> model;
    private final Part[] parts;
    private final Matrix4f posed = new Matrix4f();

    CachedPlayerMesh(PlayerEntityModel<AbstractClientPlayerEntity> model) {
        this.model = model;
        ModelPart[] source = {model.head, model.hat, model.body, model.jacket,
            model.rightArm, model.rightSleeve, model.leftArm, model.leftSleeve,
            model.rightLeg, model.rightPants, model.leftLeg, model.leftPants};
        parts = new Part[source.length];
        for (int i = 0; i < parts.length; i++) parts[i] = new Part(source[i]);
    }

    void render(Matrix4f base, VertexConsumer consumer) {
        for (int i = 0; i < parts.length; i++) {
            Part mesh = parts[i];
            ModelPart part = mesh.part;
            if (!part.visible || part.hidden) continue;
            posed.set(base).translate(part.pivotX / 16f, part.pivotY / 16f, part.pivotZ / 16f)
                .rotateZYX(part.roll, part.yaw, part.pitch).scale(part.xScale, part.yScale, part.zScale);
            float[] xyz = mesh.xyz;
            for (int j = 0; j < xyz.length; j += 3) {
                float x = xyz[j], y = xyz[j + 1], z = xyz[j + 2];
                consumer.vertex(posed.m00() * x + posed.m10() * y + posed.m20() * z + posed.m30(),
                    posed.m01() * x + posed.m11() * y + posed.m21() * z + posed.m31(),
                    posed.m02() * x + posed.m12() * y + posed.m22() * z + posed.m32());
                consumer.color(255, 255, 255, 255).next();
            }
        }
    }

    private static final class Part {
        final ModelPart part;
        final float[] xyz;
        Part(ModelPart part) {
            this.part = part;
            float px = part.pivotX, py = part.pivotY, pz = part.pivotZ;
            float pitch = part.pitch, yaw = part.yaw, roll = part.roll;
            float sx = part.xScale, sy = part.yScale, sz = part.zScale;
            boolean visible = part.visible, hidden = part.hidden;
            Recorder recorder = new Recorder();
            try {
                part.pivotX = part.pivotY = part.pivotZ = 0;
                part.pitch = part.yaw = part.roll = 0;
                part.xScale = part.yScale = part.zScale = 1;
                part.visible = true; part.hidden = false;
                part.render(new MatrixStack(), recorder, 0, 0);
            } finally {
                part.pivotX = px; part.pivotY = py; part.pivotZ = pz;
                part.pitch = pitch; part.yaw = yaw; part.roll = roll;
                part.xScale = sx; part.yScale = sy; part.zScale = sz;
                part.visible = visible; part.hidden = hidden;
            }
            xyz = Arrays.copyOf(recorder.vertices, recorder.count);
        }
    }

    /** Used only during the one-time local geometry capture, never in rendering. */
    private static final class Recorder implements VertexConsumer {
        private float[] vertices = new float[96];
        private int count;
        @Override public VertexConsumer vertex(double x, double y, double z) {
            if (count + 3 > vertices.length) vertices = Arrays.copyOf(vertices, vertices.length * 2);
            vertices[count++] = (float) x; vertices[count++] = (float) y; vertices[count++] = (float) z;
            return this;
        }
        @Override public VertexConsumer color(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer texture(float u, float v) { return this; }
        @Override public VertexConsumer overlay(int u, int v) { return this; }
        @Override public VertexConsumer light(int u, int v) { return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { return this; }
        @Override public void next() { }
        @Override public void fixedColor(int r, int g, int b, int a) { }
        @Override public void unfixColor() { }
    }
}
