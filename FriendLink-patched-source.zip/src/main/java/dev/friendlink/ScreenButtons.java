package dev.friendlink;

import dev.friendlink.ui.ChatScreen;
import java.util.List;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

/** Adds a collision-aware speech shortcut on pause and player-inventory screens. */
public final class ScreenButtons {
    private static final Tooltip TIP = Tooltip.of(Text.literal("FriendLink chat"));
    private static boolean initialized;
    private ScreenButtons() {}

    /** Parent calls once on client initialization. */
    public static void init() {
        if (initialized) return;
        initialized = true;
        // Screen event hook: recompute against the live screen widgets on every init/resize.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> addButton(screen));
    }

    private static void addButton(Screen screen) {
        FriendLink mod = FriendLink.INSTANCE;
        if (mod == null || mod.config == null) return;
        boolean pause = screen instanceof GameMenuScreen;
        boolean inventory = screen instanceof InventoryScreen || screen instanceof CreativeInventoryScreen;
        if ((!pause || !mod.config.pauseMenuButton) && (!inventory || !mod.config.inventoryButton)) return;
        int[] position = findFreePosition(screen, mod.config.screenButtonCorner);
        if (position == null) return;
        screen.addDrawableChild(new ChatButton(screen, position[0], position[1]));
    }

    private static int[] findFreePosition(Screen screen, Config.Anchor anchor) {
        boolean left = anchor == Config.Anchor.TOP_LEFT || anchor == Config.Anchor.BOTTOM_LEFT;
        boolean top = anchor == Config.Anchor.TOP_LEFT || anchor == Config.Anchor.TOP_RIGHT;
        int xLeft = 4, xRight = screen.width - 24, yTop = 4, yBottom = screen.height - 24;
        int preferredX = left ? xLeft : xRight;
        int preferredY = top ? yTop : yBottom;
        int[] found = candidate(screen, preferredX, preferredY);
        if (found != null) return found;
        int yStart = top ? yTop + 24 : yBottom - 24, yStep = top ? 24 : -24;
        for (int y = yStart; y >= 4 && y <= screen.height - 24; y += yStep) {
            found = candidate(screen, preferredX, y); if (found != null) return found;
        }
        int otherX = left ? xRight : xLeft;
        found = candidate(screen, otherX, preferredY); if (found != null) return found;
        yStart = top ? yTop + 24 : yBottom - 24;
        for (int y = yStart; y >= 4 && y <= screen.height - 24; y += yStep) {
            found = candidate(screen, otherX, y); if (found != null) return found;
        }
        int xStart = left ? xLeft + 24 : xRight - 24, xStep = left ? 24 : -24;
        for (int x = xStart; x >= 4 && x <= screen.width - 24; x += xStep) {
            found = candidate(screen, x, preferredY); if (found != null) return found;
        }
        int oppositeY = top ? yBottom : yTop;
        for (int x = xStart; x >= 4 && x <= screen.width - 24; x += xStep) {
            found = candidate(screen, x, oppositeY); if (found != null) return found;
        }
        return null;
    }

    private static int[] candidate(Screen screen, int x, int y) {
        if (x < 0 || y < 0 || x + 20 > screen.width || y + 20 > screen.height) return null;
        List<? extends Element> children = screen.children();
        for (int i = 0; i < children.size(); i++) {
            Element element = children.get(i);
            if (element instanceof ClickableWidget widget && intersects(x, y, 20, 20,
                widget.getX(), widget.getY(), widget.getWidth(), widget.getHeight())) return null;
            // RecipeBookWidget is a non-widget child. Reserve its vanilla inventory-panel footprint.
            if (element.getClass().getSimpleName().contains("RecipeBookWidget")
                && intersects(x, y, 20, 20, screen.width / 2 - 88 - 147, screen.height / 2 - 83, 147, 166)) return null;
        }
        return new int[] {x, y};
    }

    private static boolean intersects(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    private static final class ChatButton extends ClickableWidget {
        private final Screen parent;
        private final Badges.Counter unread = new Badges.Counter();
        ChatButton(Screen parent, int x, int y) {
            super(x, y, 20, 20, Text.empty()); this.parent = parent; setTooltip(TIP);
        }
        @Override protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
            int bg = isHovered() ? 0xFF505A78 : 0xFF30364A;
            context.fill(getX(), getY(), getX() + 20, getY() + 20, 0xFF111521);
            context.fill(getX() + 1, getY() + 1, getX() + 19, getY() + 19, bg);
            Badges.speech(context, getX() + 4, getY() + 4, 0xFFE9EDFF);
            FriendLink mod = FriendLink.INSTANCE;
            if (mod != null) {
                var renderer = MinecraftClient.getInstance().textRenderer;
                unread.update(renderer, mod.totalUnread());
                if (mod.config.unreadTotalBadge) unread.draw(context, renderer, getX() + 18, getY() + 2);
            }
        }
        @Override public void onClick(double mouseX, double mouseY) {
            FriendLink mod = FriendLink.INSTANCE;
            if (mod != null) MinecraftClient.getInstance().setScreen(new ChatScreen(null, parent));
        }
        @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) { appendDefaultNarrations(builder); }
    }
}
