package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class Faces {
    private Faces() {}
    /** Square 8x8 face plus translucent 8x8 hat layer; texture cache is normalized to 64x64. */
    public static void draw(DrawContext context, Identifier skin, int x, int y, int size) {
        if (skin == null) return;
        RenderSystem.enableBlend();
        context.drawTexture(skin, x, y, size, size, 8F, 8F, 8, 8, 64, 64);
        context.drawTexture(skin, x, y, size, size, 40F, 8F, 8, 8, 64, 64);
        RenderSystem.disableBlend();
    }
}
