package dev.friendlink;

import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProtocolTest {
    @Test void validatesNamesAndIds() {
        assertTrue(Protocol.validName("Alex_123"));
        assertFalse(Protocol.validName("ab")); assertFalse(Protocol.validName("Not A Name"));
        assertFalse(Protocol.validName("../../bad")); assertFalse(Protocol.validName(null));
        assertTrue(Protocol.validId(UUID.randomUUID().toString())); assertFalse(Protocol.validId("../../bad"));
    }
    @Test void tagsAreLiteralAndRoundTrip() {
        String id = UUID.randomUUID().toString();
        var matcher = Protocol.groupPattern("[FL:%s]").matcher(Protocol.prefix("[FL:%s]", id) + "hello");
        assertTrue(matcher.matches()); assertEquals(id, matcher.group("id")); assertEquals("hello", matcher.group("message"));
        assertFalse(Protocol.validTag("%s")); assertFalse(Protocol.validTag("[%s%s]")); assertFalse(Protocol.validTag("[FL:%n]"));
        assertFalse(Protocol.validTag("[FL:%s]\n"));
    }
    @Test void chunksFitCommandPacketAndPreserveSurrogates() {
        String name = "SixteenCharName12";
        String text = "one ".repeat(100) + "😀".repeat(200);
        int limit = Protocol.bodyLimit(name) - 42;
        List<String> chunks = Protocol.split(text, limit);
        assertEquals(text, String.join("", chunks));
        for (String chunk : chunks) {
            assertTrue(("msg " + name + " " + "x".repeat(42) + chunk).length() <= 256);
            assertFalse(Character.isHighSurrogate(chunk.charAt(chunk.length() - 1)));
        }
    }
    @Test void multipartInvitesFitAndRoundTrip() {
        Protocol.Invite i = new Protocol.Invite(); i.id = UUID.randomUUID().toString(); i.name = "Friends playing together";
        i.owner = "Player_One"; i.members = List.of("Player_One", "Player_Two", "Player_Three", "Player_Four", "Player_Five", "Player_Six", "Player_Seven", "Player_Eight"); i.revision = 1;
        StringBuilder joined = new StringBuilder();
        for (String part : Protocol.inviteParts(i)) {
            assertTrue(("msg SixteenCharName12 " + part).length() <= 256);
            var matcher = Protocol.CONTROL.matcher(part); assertTrue(matcher.matches()); joined.append(matcher.group("data"));
        }
        Protocol.Invite decoded = Protocol.decodeInvite(joined.toString());
        assertTrue(Protocol.validInvite(decoded, 8)); assertEquals(i.members, decoded.members); assertEquals(i.name, decoded.name);
        assertFalse(Protocol.validInvite(decoded, 7));
    }
    @Test void rejectsDuplicateAndMalformedMembers() {
        Protocol.Invite i = new Protocol.Invite(); i.id = UUID.randomUUID().toString(); i.name = "Test"; i.owner = "Alex";
        i.members = List.of("Alex", "aLeX"); assertFalse(Protocol.validInvite(i, 8));
        i.members = List.of("Steve"); assertFalse(Protocol.validInvite(i, 8));
        i.members = List.of("Alex"); i.kind = "execute"; assertFalse(Protocol.validInvite(i, 8));
    }
    @Test void builtInWhisperPatternsHaveRequiredCaptures() {
        Config c = new Config();
        var in = java.util.regex.Pattern.compile(c.incomingRegex.get(0)).matcher("Alex whispers to you: hi");
        assertTrue(in.matches()); assertEquals("Alex", in.group("name")); assertEquals("hi", in.group("message"));
        var out = java.util.regex.Pattern.compile(c.outgoingRegex.get(0)).matcher("You whisper to Alex: hi");
        assertTrue(out.matches()); assertEquals("Alex", out.group("name"));
    }
}
