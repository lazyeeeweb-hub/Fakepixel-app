package dev.friendlink;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReliableProtocolTest {
    @Test void compactPrefixRoundTripsAndLegacyStaysUntagged() {
        String id = ReliableProtocol.newId(); assertTrue(ReliableProtocol.validId(id));
        assertEquals(12, id.length());
        var parsed = ReliableProtocol.tagged(ReliableProtocol.prefix(id) + "hello ☺");
        assertNotNull(parsed); assertEquals(id, parsed.id()); assertEquals("hello ☺", parsed.text());
        assertNull(ReliableProtocol.tagged("untagged legacy whisper"));
        assertEquals(19, ReliableProtocol.prefix(id).length());
    }
    @Test void controlsAreBoundedAndStrict() {
        var r = ReliableProtocol.receipt("[FLC:R:0123456789ab,ffffffffffff]");
        assertNotNull(r); assertTrue(r.read()); assertEquals(2, r.ids().length);
        assertNull(ReliableProtocol.receipt("[FLC:R:../escape]"));
        assertNull(ReliableProtocol.receipt("[FLC:D:]"));
        assertNull(ReliableProtocol.receipt("[FLC:R:" + "0123456789ab,".repeat(16) + "0123456789ab]"));
        assertTrue(ReliableProtocol.hidden("[FLC:O]"));
    }
    @Test void taggedGroupFitsVanillaCommandBudgetAndPreservesUnicode() {
        String target = "SixteenCharName_", group = "12345678-1234-1234-1234-123456789abc";
        String prefix = ReliableProtocol.prefix("0123456789ab") + Protocol.prefix("[FL:%s]", group);
        String text = "hello 😀 ".repeat(50);
        StringBuilder combined = new StringBuilder();
        for (String part : Protocol.split(text, Protocol.bodyLimit(target) - prefix.length())) {
            assertTrue(("msg " + target + " " + prefix + part).length() <= 256);
            assertFalse(Character.isHighSurrogate(part.charAt(part.length() - 1)));
            combined.append(part);
        }
        assertEquals(text, combined.toString());
    }
}
