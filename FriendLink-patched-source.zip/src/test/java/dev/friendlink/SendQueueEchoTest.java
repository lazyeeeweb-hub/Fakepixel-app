package dev.friendlink;

import dev.friendlink.Models.*;
import java.lang.reflect.Field;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SendQueueEchoTest {
    private FriendLink host() {
        FriendLink mod = new FriendLink(); mod.config = new Config(); mod.state = new State(); return mod;
    }
    @SuppressWarnings("unchecked")
    private List<SendQueue.Entry> entries(SendQueue q) throws Exception {
        Field f = SendQueue.class.getDeclaredField("entries"); f.setAccessible(true);
        return (List<SendQueue.Entry>) f.get(q);
    }
    private void expire(SendQueue queue, SendQueue.Entry entry, long now) throws Exception {
        Field active = SendQueue.class.getDeclaredField("active"); active.setAccessible(true); active.set(queue, entry);
        var defer = SendQueue.class.getDeclaredMethod("defer", SendQueue.Entry.class, long.class);
        defer.setAccessible(true); defer.invoke(queue, entry, now);
    }
    private SendQueue.Job job(Message m, String peer, String id) {
        return new SendQueue.Job(peer, ReliableProtocol.prefix(id) + "hello", "f:steve", m);
    }
    @Test void outgoingEchoAcknowledgesWithoutAddingMessageAndOnlyOnce() {
        FriendLink mod = host(); SendQueue queue = new SendQueue(mod);
        Message message = new Message("Me", "hello", false);
        var job = job(message, "Steve", "0123456789ab");
        assertTrue(queue.offer(List.of(job))); assertEquals(0, message.stage());
        assertTrue(queue.echo("sTeVe", job.body())); assertEquals(1, message.stage());
        assertTrue(queue.echo("Steve", job.body())); assertEquals(1, message.delivery.get("Steve").completed);
        assertFalse(queue.echo("Other", job.body()));
    }
    @Test void timeoutRetainsOneTickAndLateEchoStopsRetries() throws Exception {
        FriendLink mod = host(); SendQueue queue = new SendQueue(mod);
        Message message = new Message("Me", "hello", false);
        var job = job(message, "Steve", "0123456789ab"); queue.offer(List.of(job));
        var entry = entries(queue).get(0); entry.attempts = 1;
        long now = System.currentTimeMillis(); expire(queue, entry, now);
        assertEquals(1, message.stage()); assertFalse(entry.confirmed);
        assertEquals(now + mod.config.retryDelayMs, entry.nextAt);
        assertTrue(queue.echo("Steve", job.body())); assertTrue(entry.confirmed);
        queue.receipt("Steve", "0123456789ab", true); assertEquals(3, message.stage());
        queue.echo("Steve", job.body()); assertEquals(3, message.stage());
    }
    @Test void receiptsRequireExactPeerAndCannotDowngradeRead() {
        FriendLink mod = host(); SendQueue queue = new SendQueue(mod);
        Message m = new Message("Me", "hello", false);
        queue.offer(List.of(job(m, "Steve", "0123456789ab")));
        queue.receipt("Other", "0123456789ab", true); assertEquals(0, m.stage());
        queue.receipt("Steve", "ffffffffffff", true); assertEquals(0, m.stage());
        queue.receipt("Steve", "0123456789ab", false); assertEquals(2, m.stage());
        queue.receipt("Steve", "0123456789ab", true); assertEquals(3, m.stage());
        queue.receipt("Steve", "0123456789ab", false); assertEquals(3, m.stage());
    }
    @Test void groupAndMultipartOverallIsLowestStatus() {
        FriendLink mod = host(); SendQueue queue = new SendQueue(mod);
        Message m = new Message("Me", "hello", false);
        queue.offer(List.of(job(m, "Steve", "0123456789ab"), job(m, "Alex", "0123456789ab"), job(m, "Steve", "0123456789ac")));
        queue.receipt("Steve", "0123456789ab", true); assertEquals(0, m.stage());
        queue.receipt("Alex", "0123456789ab", false); assertEquals(0, m.stage());
        queue.receipt("Steve", "0123456789ac", true); assertEquals(2, m.stage());
        queue.receipt("Alex", "0123456789ab", true); assertEquals(3, m.stage());
    }
    @Test void cappedAttemptsFailButDisconnectDoesNotDiscardPending() throws Exception {
        FriendLink mod = host(); mod.config.retryMaxAttempts = 2;
        SendQueue queue = new SendQueue(mod); Message m = new Message("Me", "hello", false);
        queue.offer(List.of(job(m, "Steve", "0123456789ab")));
        var e = entries(queue).get(0); e.attempts = 2;
        expire(queue, e, System.currentTimeMillis()); assertEquals(4, m.stage());
        queue.cancel("Disconnected"); assertEquals(1, queue.snapshot().entries.size());
        assertEquals(4, queue.snapshot().entries.get(0).stage);
    }
    @Test void queueSnapshotDoesNotContainLiveMessageOrPresence() {
        FriendLink mod = host(); SendQueue queue = new SendQueue(mod);
        Message m = new Message("Me", "hello", false);
        queue.offer(List.of(job(m, "Steve", "0123456789ab"), new SendQueue.Job("Steve", "[FLC:O]", "", null)));
        String json = Storage.JSON.toJson(queue.snapshot());
        assertFalse(json.contains("[FLC:O]")); assertFalse(json.contains("\"message\":"));
        assertTrue(json.contains("0123456789ab"));
    }
}
