package dev.friendlink;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DistanceScalingTest {
    @Test void defaultsAndDisabledScaling() {
        Config c = new Config();
        assertTrue(c.reopenLastConversation); assertTrue(c.glowScaleWithDistance);
        assertEquals(.01, c.glowScaleFactor); assertEquals(3, c.glowMaxScale);
        assertEquals(1, DistanceScaling.multiplier(100, false, .01, 3));
    }
    @Test void nearSafetyAndExactFarFormula() {
        for (double distance = 0; distance <= 10; distance += .1)
            assertEquals(1, DistanceScaling.multiplier(distance, true, .01, 3), 1e-12);
        assertEquals(2, DistanceScaling.multiplier(100, true, .01, 3), 1e-12);
        assertEquals(3, DistanceScaling.multiplier(200, true, .01, 3), 1e-12);
        assertEquals(3, DistanceScaling.multiplier(4096, true, .01, 3), 1e-12);
    }
    @Test void smoothMonotonicTransitionAndCap() {
        double previous = 1;
        for (int i = 0; i <= 40000; i++) {
            double current = DistanceScaling.multiplier(i / 100.0, true, .01, 3);
            assertTrue(current >= previous); assertTrue(current <= 3);
            assertTrue(current - previous < .001);
            previous = current;
        }
        assertEquals(1, DistanceScaling.multiplier(10.000001, true, .01, 3), 1e-10);
        assertEquals(1.2, DistanceScaling.multiplier(20, true, .01, 3), 1e-12);
    }
    @Test void normalizeUntrustedJsonValues() {
        Config c = new Config(); c.glowScaleFactor = Double.NaN; c.glowMaxScale = Double.POSITIVE_INFINITY;
        c.normalize(); assertEquals(.01, c.glowScaleFactor); assertEquals(3, c.glowMaxScale);
        c.glowScaleFactor = -1; c.glowMaxScale = 0; c.normalize();
        assertEquals(0, c.glowScaleFactor); assertEquals(1, c.glowMaxScale);
        c.glowScaleFactor = 10; c.glowMaxScale = 100; c.normalize();
        assertEquals(.05, c.glowScaleFactor); assertEquals(6, c.glowMaxScale);
    }
}
