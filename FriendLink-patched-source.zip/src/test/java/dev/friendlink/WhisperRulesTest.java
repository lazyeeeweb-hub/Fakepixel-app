package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WhisperRulesTest {
    private void matches(List<String> regexes, String text, String name, String body) {
        int count = 0;
        for (String regex : regexes) {
            var match = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
            if (match.matches()) {
                assertEquals(name, match.group("name")); assertEquals(body, match.group("message")); count++;
            }
        }
        assertEquals(1, count, text);
    }
    @Test void allRequestedPluginFormatsAndVanillaFallback() {
        Config c = new Config();
        matches(c.incomingRegex, "[Steve -> me] hello", "Steve", "hello");
        matches(c.incomingRegex, "From Steve: hello", "Steve", "hello");
        matches(c.outgoingRegex, "[me -> Steve] hello", "Steve", "hello");
        matches(c.outgoingRegex, "To Steve: hello", "Steve", "hello");
        matches(c.incomingRegex, "Steve whispers to you: hello", "Steve", "hello");
        matches(c.outgoingRegex, "You whisper to Steve: hello", "Steve", "hello");
        matches(c.incomingRegex, "fRoM sTeVe: hello", "sTeVe", "hello");
    }
    @Test void nameOrUuidIdentityAndStrangers() {
        State s = new State(); Friend f = new Friend(); f.name = "Steve";
        UUID uuid = UUID.randomUUID(); f.uuid = uuid.toString(); s.friends.put("steve", f);
        assertSame(f, FriendIdentity.find(s, "sTeVe", null));
        assertSame(f, FriendIdentity.find(s, "Renamed", uuid));
        assertSame(f, FriendIdentity.find(s, "Steve", UUID.randomUUID()));
        assertNull(FriendIdentity.find(s, "Stranger", UUID.randomUUID()));
    }
    @Test void groupTagParsesOnlyBodyAndPreservesPayload() {
        String id = "00000000-0000-0000-0000-000000000001";
        var matcher = Protocol.groupPattern(new Config().groupTag).matcher("[FL:" + id + "] hello");
        assertTrue(matcher.matches()); assertEquals(id, matcher.group("id")); assertEquals("hello", matcher.group("message"));
        assertFalse(Protocol.groupPattern(new Config().groupTag).matcher("Steve whispers: [FL:" + id + "] hello").matches());
    }
    @Test void sentStatusUsesASingleTick() {
        Message m = new Message("Me", "hello", false); Delivery d = new Delivery(); d.total = d.completed = 1;
        m.delivery.put("Steve", d); assertEquals("Steve: \u2713 sent", m.status());
    }

    private WhisperText parser() {
        Config c = new Config();
        return new WhisperText(List.of(WhisperText.DEFAULT_DIALOGUE_REGEX), c.incomingRegex, c.outgoingRegex);
    }
    private void parsed(String text, String name, String body, boolean outgoing) {
        WhisperText.Parsed result = parser().parse(text, "LocalPlayer");
        assertNotNull(result, text);
        assertEquals(name, result.name()); assertEquals(body, result.body()); assertEquals(outgoing, result.outgoing());
    }
    @Test void exactColouredTwoSidedSamplesAndCaseInsensitiveMe() {
        parsed("§dFrom Me §dto §7DyLol§7: §fyou go to end?", "DyLol", "you go to end?", true);
        parsed("§dFrom §7DyLol §dto Me§7: §ftes", "DyLol", "tes", false);
        parsed("From mE to DyLol: hi", "DyLol", "hi", true);
        parsed("From DyLol to mE: hi", "DyLol", "hi", false);
        parsed("From LocalPlayer to DyLol: hi", "DyLol", "hi", true);
        parsed("From DyLol to LocalPlayer: hi", "DyLol", "hi", false);
    }
    @Test void hexMustDisappearBeforeLegacyAndPreserveBodyWhitespace() {
        String hex = "§x§1§A§2§b§3§C";
        assertEquals("From Me to DyLol: hi", WhisperText.strip(hex + "From §dMe to §7DyLol: §fhi"));
        parsed(hex + "From Me to " + hex + "DyLol: §f  hi  ", "DyLol", "  hi  ", true);
        assertEquals("hi", WhisperText.strip("§X§A§B§C§D§E§F§rhi"));
        assertEquals("", WhisperText.strip("§0§1§2§3§4§5§6§7§8§9§a§B§c§D§e§F§k§L§m§N§o§R"));
    }
    @Test void commonFormatsStillAcceptDecoratedNames() {
        parsed("[★[MVP+] Steve -> me] hello", "Steve", "hello", false);
        parsed("From [VIP] ★ Steve: hello", "Steve", "hello", false);
        parsed("[me -> [VIP] ★ Steve] hello", "Steve", "hello", true);
        parsed("To [VIP] ★ Steve: hello", "Steve", "hello", true);
        parsed("<[VIP] ★ Steve> whispers to you: hello", "Steve", "hello", false);
        parsed("[VIP] ★ Steve whispers: hello", "Steve", "hello", false);
        parsed("You whisper to <[VIP] ★ Steve>: hello", "Steve", "hello", true);
        parsed("From [VIP] ★ Steve to [MVP+] mE: hello", "Steve", "hello", false);
    }
    @Test void wholeUsernameTokensOnlyAndLastTokenWins() {
        assertEquals("Steve", WhisperText.playerName("§a[VIP] ★ Steve ✦"));
        assertEquals("Name_123", WhisperText.playerName("[Admin] OldName / Name_123"));
        assertEquals("abcdefghijklmnop", WhisperText.playerName("abcdefghijklmnop"));
        assertNull(WhisperText.playerName("abcdefghijklmnopq"));
        assertNull(WhisperText.playerName("_abcdefghijklmnop"));
        assertNull(WhisperText.playerName("ab"));
        assertNull(parser().parse("From Me to abcdefghijklmnopq: hi", "LocalPlayer"));
    }
    @Test void twoSidedRulesDetermineDirectionEvenInLegacyLists() {
        String rule = "^PM (?<from>.+?) => (?<to>.+?): (?<msg>.*)$";
        WhisperText in = new WhisperText(List.of(), List.of(rule), List.of());
        WhisperText out = new WhisperText(List.of(), List.of(), List.of(rule));
        for (WhisperText p : List.of(in, out)) {
            assertTrue(p.parse("PM Me => Steve: body", "LocalPlayer").outgoing());
            assertFalse(p.parse("PM Steve => Me: body", "LocalPlayer").outgoing());
            assertNull(p.parse("PM Steve => Alex: body", "LocalPlayer"));
            assertNull(p.parse("PM Me => Me: body", "LocalPlayer"));
        }
        WhisperText alias = new WhisperText(List.of(rule.replace("?<msg>", "?<message>")), List.of(), List.of());
        assertEquals("body", alias.parse("PM Steve => Me: body", "LocalPlayer").body());
    }
    @Test void customizationHonoursAnchorsAndRejectsPublicChatBeforeEveryRule() {
        WhisperText custom = new WhisperText(List.of("^DM (?<from>.+?) / (?<to>.+?): (?<msg>.*)$"),
            List.of("^\\[.*?\\] (?<name>.+?): (?<message>.*)$"), List.of());
        assertTrue(custom.parse("DM Me / Steve: hello", "LocalPlayer").outgoing());
        assertNull(custom.parse("From Me to Steve: hello", "LocalPlayer"));
        assertNull(custom.parse("[78] Steve: hello", "LocalPlayer"));
        assertNull(custom.parse("§d[78] §7Steve: §fhello", "LocalPlayer"));
        WhisperText permissiveDialogue = new WhisperText(
            List.of("^\\[78\\] (?<from>.+?): (?<to>Me)(?<msg>.*)$"), List.of(), List.of());
        assertNull(permissiveDialogue.parse("[78] Steve: Me", "LocalPlayer"));
        WhisperText permissiveOutgoing = new WhisperText(List.of(), List.of(),
            List.of("^\\[78\\] (?<name>.+?): (?<message>.*)$"));
        assertNull(permissiveOutgoing.parse("[78] Steve: hello", "LocalPlayer"));
    }
    @Test void invalidRulesAreSkippedAndCompiledRulesAreSnapshots() {
        java.util.ArrayList<String> mutable = new java.util.ArrayList<>(List.of(WhisperText.DEFAULT_DIALOGUE_REGEX));
        WhisperText p = new WhisperText(mutable, List.of("[", "^(?<name>.+)$"), null);
        mutable.clear();
        assertNotNull(p.parse("From Steve to Me: hello", "LocalPlayer"));
        assertNull(p.parse("From Steve to Alex: hello", "LocalPlayer"));
        assertNull(p.parse("From Me to Me: hello", "LocalPlayer"));
        assertNull(p.parse(null, "LocalPlayer"));
        assertNull(p.parse("x".repeat(8193), "LocalPlayer"));
    }
}
