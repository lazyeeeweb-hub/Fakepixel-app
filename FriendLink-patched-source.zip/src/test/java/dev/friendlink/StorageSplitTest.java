package dev.friendlink;

import com.google.gson.JsonObject;
import dev.friendlink.Models.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class StorageSplitTest {
    private static final String GROUP = "00000000-0000-0000-0000-000000000001";
    @TempDir Path root;

    private static <T> T await(CompletableFuture<T> future) throws Exception { return future.get(10, TimeUnit.SECONDS); }
    private static Message message(String text, long time) {
        Message message = new Message("Steve", text, false); message.time = time; return message;
    }
    private static State state() {
        State state = new State(); state.schema = 2;
        Friend friend = new Friend(); friend.name = "Steve"; state.friends.put("steve", friend);
        Group group = new Group(); group.id = GROUP; group.name = "Team"; group.owner = "Steve";
        group.members.add("Steve"); state.groups.put(GROUP, group);
        return state;
    }
    private void barrier(Storage storage) throws Exception { await(storage.readAsync("absent.json", Object.class, null)); }
    private JsonObject object(String name) throws Exception { return Storage.JSON.fromJson(Files.readString(root.resolve(name)), JsonObject.class); }
    private long backups(String prefix) throws Exception {
        try (var stream = Files.list(root)) { return stream.filter(p -> p.getFileName().toString().startsWith(prefix)).count(); }
    }
    private void legacy(State state) throws Exception { Files.writeString(root.resolve("conversations.json"), Storage.JSON.toJson(state)); }

    @Test void modelDefaultsAndTransientLoadedFlagsRemainCompatible() {
        Friend friend = new Friend(); Group group = new Group(); Message message = new Message();
        assertInstanceOf(ArrayList.class, friend.messages); assertInstanceOf(ArrayList.class, group.messages);
        assertEquals(GlowToggle.DEFAULT, friend.shareChatOpen); assertFalse(friend.logLoaded); assertFalse(group.logLoaded);
        assertEquals("", message.id); assertEquals("", message.receiptId); assertFalse(message.receiptRead);
        friend.logLoaded = true;
        assertFalse(Storage.JSON.toJson(friend).contains("logLoaded"));
        assertFalse(Storage.JSON.fromJson(Storage.JSON.toJson(friend), Friend.class).logLoaded);
    }
    @Test void partAndTargetStagesUseLowestWithFailurePrecedence() {
        Delivery a = new Delivery(); a.parts.put("a", 3); a.parts.put("b", 2); assertEquals(2, a.stage());
        a.parts.put("c", 0); assertEquals(0, a.stage()); a.parts.put("d", 4); assertEquals(4, a.stage());
        Message message = new Message(); Delivery b = new Delivery(); b.parts.put("b", 0);
        message.delivery.put("Steve", b); message.delivery.put("Alex", a);
        assertEquals(4, message.stage()); assertTrue(message.status().contains("Alex: failed"));
        a.parts.remove("d"); assertEquals(0, message.stage());
        a.parts.clear(); a.failed = 1; assertEquals(4, message.stage());
    }
    @Test void legacyCountersStillReportSendingSentAndUnconfirmed() {
        Message message = new Message(); Delivery delivery = new Delivery(); delivery.total = 2;
        message.delivery.put("Steve", delivery);
        assertEquals(0, message.stage()); assertEquals("Steve: sending... 0/2", message.status());
        delivery.completed = 2; assertEquals(1, message.stage()); assertEquals("Steve: ✓ sent", message.status());
        delivery.unconfirmed = 1; assertEquals("Steve: unconfirmed", message.status());
        delivery.completed = 0; delivery.failed = 1;
        assertEquals(4, message.stage()); assertTrue(message.status().contains("unreachable"));
    }
    @Test void normalizePreservesPendingCountersAndGlowMigration() {
        State state = state(); state.schema = 1; Friend friend = state.friends.get("steve"); friend.shareChatOpen = null;
        Message message = message("pending", 9); Delivery delivery = new Delivery(); delivery.total = 3; delivery.completed = 1;
        delivery.unconfirmed = 1; delivery.parts = null; message.delivery.put("Steve", delivery);
        friend.messages = List.of(message);
        Storage.normalize(state, new Config());
        assertEquals(2, state.schema); assertTrue(friend.glow); assertEquals(GlowToggle.DEFAULT, friend.shareChatOpen);
        assertEquals(1, delivery.completed); assertEquals(1, delivery.unconfirmed); assertNotNull(delivery.parts);
        assertEquals(0, delivery.stage()); assertEquals(9, friend.lastActivity);
        friend.messages.add(message("mutable", 10));
    }
    @Test void firstRunReturnsMetadataOnlyAndCreatesCommitMarker() throws Exception {
        try (Storage storage = new Storage(root)) {
            State state = await(storage.loadStateAsync(new Config()));
            assertEquals(2, state.schema); assertTrue(state.friends.isEmpty()); assertTrue(state.groups.isEmpty());
            assertTrue(Files.exists(root.resolve("friends.json"))); assertTrue(Files.exists(root.resolve("groups.json")));
            assertEquals(1, object("state.json").get("splitStorageVersion").getAsInt());
            assertTrue(await(storage.loadLogAsync("f:Steve", 10)).isEmpty());
        }
    }
    @Test void migrationBacksUpAndSplitsWithoutLoadingEveryLog() throws Exception {
        State original = state(); original.schema = 1; original.lastConversation = "g:" + GROUP;
        Friend friend = original.friends.get("steve"); friend.unread = 7; friend.shareChatOpen = GlowToggle.OFF;
        friend.messages.add(message("one", 10)); friend.messages.add(message("two", 20)); friend.messages.add(message("three", 30));
        original.groups.get(GROUP).messages.add(message("group", 40)); original.groups.get(GROUP).unread = 4;
        legacy(original); String bytes = Files.readString(root.resolve("conversations.json"));
        Config config = new Config(); config.maxMessages = 2;
        try (Storage storage = new Storage(root)) {
            State loaded = await(storage.loadStateAsync(config));
            Friend meta = loaded.friends.get("steve");
            assertEquals(bytes, Files.readString(root.resolve("conversations.json"))); assertEquals(1, backups("conversations.json.backup-"));
            assertTrue(meta.messages.isEmpty()); assertFalse(meta.logLoaded); assertTrue(meta.glow);
            assertEquals(7, meta.unread); assertEquals(30, meta.lastActivity); assertEquals(GlowToggle.OFF, meta.shareChatOpen);
            assertEquals(4, loaded.groups.get(GROUP).unread); assertEquals(40, loaded.groups.get(GROUP).lastActivity);
            assertEquals("g:" + GROUP, loaded.lastConversation);
            assertFalse(object("friends.json").getAsJsonObject("steve").has("messages"));
            assertFalse(object("groups.json").getAsJsonObject(GROUP).has("messages"));
            List<Message> log = await(storage.loadLogAsync("f:STEVE", 10));
            assertEquals(List.of("two", "three"), log.stream().map(m -> m.text).toList());
            assertEquals("group", await(storage.loadLogAsync("g:" + GROUP, 10)).get(0).text);
            assertFalse(meta.logLoaded);
        }
        Files.writeString(root.resolve("conversations.json"), "not JSON");
        try (Storage restarted = new Storage(root)) {
            assertEquals(7, await(restarted.loadStateAsync(config)).friends.get("steve").unread);
            assertEquals(1, backups("conversations.json.backup-"));
        }
    }
    @Test void failedMigrationLeavesLegacyAndNoMarkerThenRetries() throws Exception {
        State state = state(); state.friends.get("steve").messages.add(message("safe", 1)); legacy(state);
        String original = Files.readString(root.resolve("conversations.json"));
        Files.createDirectory(root.resolve("groups.json"));
        try (Storage storage = new Storage(root)) {
            assertThrows(ExecutionException.class, () -> await(storage.loadStateAsync(new Config())));
            assertFalse(Files.exists(root.resolve("state.json"))); assertEquals(original, Files.readString(root.resolve("conversations.json")));
            assertEquals(1, backups("conversations.json.backup-"));
        }
        Files.delete(root.resolve("groups.json"));
        try (Storage restarted = new Storage(root)) {
            await(restarted.loadStateAsync(new Config()));
            assertEquals("safe", await(restarted.loadLogAsync("f:steve", 10)).get(0).text);
            assertTrue(Files.exists(root.resolve("state.json"))); assertEquals(2, backups("conversations.json.backup-"));
        }
    }
    @Test void saveStateSnapshotsLoadedLogsButNeverOverwritesUnloadedLogs() throws Exception {
        try (Storage storage = new Storage(root)) {
            await(storage.saveLogAsync("f:steve", List.of(message("disk only", 1))));
            State state = state(); Friend friend = state.friends.get("steve"); friend.unread = 9; friend.lastActivity = 77;
            storage.saveState(state); friend.unread = 0; friend.lastActivity = 0;
            barrier(storage);
            assertEquals("disk only", await(storage.loadLogAsync("f:steve", 10)).get(0).text);
            State loaded = await(storage.loadStateAsync(new Config()));
            assertEquals(9, loaded.friends.get("steve").unread); assertEquals(77, loaded.friends.get("steve").lastActivity);
            friend.logLoaded = true; Message message = message("captured", 80); friend.messages.add(message);
            storage.saveState(state); message.text = "mutated"; friend.messages.clear();
            barrier(storage);
            assertEquals("captured", await(storage.loadLogAsync("f:steve", 10)).get(0).text);
            assertEquals(80, object("friends.json").getAsJsonObject("steve").get("lastActivity").getAsLong());
        }
    }
    @Test void debouncedStateSnapshotsCoalesceWithoutRetainingLiveModels() throws Exception {
        try (Storage storage = new Storage(root)) {
            State state = state(); state.friends.get("steve").unread = 1; storage.saveState(state);
            state.friends.get("steve").unread = 2; state.lastConversation = "f:steve"; storage.saveState(state);
            state.friends.get("steve").unread = 3; state.lastConversation = "bad"; barrier(storage);
            assertEquals(2, object("friends.json").getAsJsonObject("steve").get("unread").getAsInt());
            assertEquals("f:steve", object("state.json").get("lastConversation").getAsString());
        }
    }
    @Test void durableBarrierFlushesEarlierDebounceBeforeReceiptSnapshot() throws Exception {
        try (Storage storage = new Storage(root)) {
            State state = state(); Friend friend = state.friends.get("steve"); friend.logLoaded = true;
            friend.messages.add(message("older", 1)); storage.saveState(state);
            Message receipt = message("receipt", 2); receipt.id = "logical"; receipt.receiptId = "wire"; receipt.receiptRead = true;
            Delivery delivery = new Delivery(); delivery.parts.put("wire", 3); receipt.delivery.put("Steve", delivery);
            CompletableFuture<Void> saved = storage.saveLogAsync("f:steve", List.of(receipt));
            receipt.text = "late mutation"; await(saved);
            assertTrue(Files.readString(root.resolve("chats/friends/steve.json")).contains("receipt"));
            Message restored = await(storage.loadLogAsync("f:steve", 10)).get(0);
            assertEquals("receipt", restored.text); assertEquals("logical", restored.id); assertEquals("wire", restored.receiptId);
            assertTrue(restored.receiptRead); assertEquals(3, restored.stage());
            barrier(storage); assertEquals("receipt", await(storage.loadLogAsync("f:steve", 10)).get(0).text);
        }
    }
    @Test void multipleLogBarriersKeepSubmissionOrder() throws Exception {
        try (Storage storage = new Storage(root)) {
            List<CompletableFuture<Void>> writes = new ArrayList<>();
            for (int i = 0; i < 25; i++) writes.add(storage.saveLogAsync("f:steve", List.of(message("v" + i, i))));
            for (var future : writes) await(future);
            assertEquals("v24", await(storage.loadLogAsync("f:steve", 5)).get(0).text);
        }
    }
    @Test void lazyReadCleansCapsAndDoesNotPromoteDelivery() throws Exception {
        Message pending = message("pending", 3); Delivery delivery = new Delivery(); delivery.total = 3; delivery.completed = 1;
        delivery.unconfirmed = 1; delivery.parts.put("p", 1); pending.delivery.put("Steve", delivery);
        pending.id = null; pending.receiptId = null;
        Message bad = message("bad", 2); bad.sender = null;
        try (Storage storage = new Storage(root)) {
            await(storage.saveLogAsync("f:steve", Arrays.asList(null, message("old", 0), bad, message("ok", 1), pending)));
            List<Message> list = await(storage.loadLogAsync("f:steve", 2));
            assertEquals(2, list.size()); assertEquals("ok", list.get(0).text); Message restored = list.get(1);
            assertEquals("", restored.id); assertEquals("", restored.receiptId);
            assertEquals(1, restored.delivery.get("Steve").completed); assertEquals(1, restored.delivery.get("Steve").unconfirmed);
            assertEquals(1, restored.stage()); list.add(message("mutable", 4));
            assertTrue(await(storage.loadLogAsync("f:steve", 0)).isEmpty());
            assertTrue(await(storage.loadLogAsync("f:steve", -1)).isEmpty());
        }
    }
    @Test void corruptLogsPreserveUniqueBackupsAndFailTheRead() throws Exception {
        Path path = root.resolve("chats/friends/steve.json"); Files.createDirectories(path.getParent()); Files.writeString(path, "{broken");
        try (Storage storage = new Storage(root)) {
            for (int i = 0; i < 2; i++) assertThrows(ExecutionException.class, () -> await(storage.loadLogAsync("f:steve", 10)));
            assertEquals("{broken", Files.readString(path));
            try (var stream = Files.list(path.getParent())) {
                assertEquals(2, stream.filter(p -> p.getFileName().toString().startsWith("steve.json.broken-")).count());
            }
        }
    }
    @Test void corruptMetadataNeverReplaysLegacyOverCommittedLogs() throws Exception {
        legacy(state());
        try (Storage storage = new Storage(root)) {
            await(storage.loadStateAsync(new Config())); await(storage.saveLogAsync("f:steve", List.of(message("new", 8))));
            Files.writeString(root.resolve("state.json"), "{broken");
            assertThrows(ExecutionException.class, () -> await(storage.loadStateAsync(new Config())));
            assertEquals(1, backups("state.json.broken-"));
            assertEquals("new", await(storage.loadLogAsync("f:steve", 10)).get(0).text);
        }
    }
    @Test void failedSaveLogCompletesExceptionallyAndCleansTemporaryFile() throws Exception {
        Path path = root.resolve("chats/friends/steve.json"); Files.createDirectories(path);
        try (Storage storage = new Storage(root)) {
            assertThrows(ExecutionException.class, () -> await(storage.saveLogAsync("f:steve", List.of(message("no", 1)))));
            assertTrue(Files.isDirectory(path));
            try (var stream = Files.list(path.getParent())) { assertFalse(stream.anyMatch(p -> p.toString().endsWith(".tmp"))); }
        }
    }
    @Test void deleteIsOrderedAfterPendingSave() throws Exception {
        try (Storage storage = new Storage(root)) {
            State state = state(); Friend friend = state.friends.get("steve"); friend.logLoaded = true; friend.messages.add(message("old", 1));
            storage.saveState(state); storage.deleteLog("f:STEVE"); barrier(storage);
            assertFalse(Files.exists(root.resolve("chats/friends/steve.json")));
            assertTrue(await(storage.loadLogAsync("f:steve", 10)).isEmpty());
        }
    }
    @Test void invalidConversationKeysAndGenericTraversalAreRejectedWithoutIO() throws Exception {
        try (Storage storage = new Storage(root)) {
            for (String key : new String[] {"f:../x", "g:../../bad", "f:/tmp", "g:" + GROUP + "/..", "f:ab", "other"}) {
                assertThrows(IllegalArgumentException.class, () -> storage.loadLogAsync(key, 10));
                assertThrows(IllegalArgumentException.class, () -> storage.saveLogAsync(key, List.of()));
                assertThrows(IllegalArgumentException.class, () -> storage.deleteLog(key));
            }
            assertThrows(IllegalArgumentException.class, () -> storage.write("../escape.json", new State()));
            assertThrows(IllegalArgumentException.class, () -> storage.readAsync("x/../../escape", State.class, new State()));
            assertThrows(IllegalArgumentException.class, () -> storage.write("x\\..\\escape.json", "bad"));
            try (var stream = Files.list(root)) { assertEquals(0, stream.count()); }
        }
    }
    @Test void symlinkedLogDirectoriesAreRejected() throws Exception {
        Path elsewhere = Files.createTempDirectory(root, "elsewhere"); Files.createDirectories(root.resolve("chats"));
        try { Files.createSymbolicLink(root.resolve("chats/friends"), elsewhere); }
        catch (UnsupportedOperationException | java.io.IOException e) { org.junit.jupiter.api.Assumptions.assumeTrue(false, "Symlinks unavailable: " + e); }
        try (Storage storage = new Storage(root)) {
            assertThrows(ExecutionException.class, () -> await(storage.saveLogAsync("f:steve", List.of(message("no", 1)))));
            assertThrows(ExecutionException.class, () -> await(storage.loadLogAsync("f:steve", 10)));
            try (var stream = Files.list(elsewhere)) { assertEquals(0, stream.count()); }
        }
    }
    @Test void legacyReadWriteAndCorruptFallbackStillWork() throws Exception {
        try (Storage storage = new Storage(root)) {
            Config config = new Config(); config.maxMessages = 777; storage.write("nested/config.json", config);
            assertEquals(777, await(storage.readAsync("nested/config.json", Config.class, new Config())).maxMessages);
            Files.writeString(root.resolve("nested/config.json"), "{bad");
            Config fallback = new Config(); assertSame(fallback, await(storage.readAsync("nested/config.json", Config.class, fallback)));
            assertEquals("{bad", Files.readString(root.resolve("nested/config.json"))); assertEquals(root, storage.root());
        }
    }
    @Test void closeFlushesPendingSnapshotsWithoutBlockingAndIsIdempotent() throws Exception {
        Storage storage = new Storage(root); State state = state(); storage.saveState(state); storage.close(); storage.close();
        assertThrows(ExecutionException.class, () -> await(storage.loadLogAsync("f:steve", 1)));
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
        while (!Files.exists(root.resolve("state.json")) && System.nanoTime() < deadline) Thread.sleep(5);
        assertTrue(Files.exists(root.resolve("state.json")));
        assertThrows(IllegalStateException.class, () -> storage.saveState(state));
    }
    @Test void selectionUsesMetadataThenInMemoryFallbackWithoutLoadingLogs() {
        State state = state(); Friend friend = state.friends.get("steve"); Group group = state.groups.get(GROUP);
        friend.lastActivity = 80; group.lastActivity = 90; assertEquals("g:" + GROUP, ConversationSelection.choose(state, null, false));
        friend.messages.add(message("new", 100)); assertEquals("f:steve", ConversationSelection.choose(state, null, false));
        friend.messages.clear(); group.left = true; assertEquals("f:steve", ConversationSelection.choose(state, null, false));
        assertFalse(friend.logLoaded); assertFalse(group.logLoaded);
    }
}
