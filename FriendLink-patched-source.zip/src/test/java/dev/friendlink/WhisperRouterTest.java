package dev.friendlink;

import dev.friendlink.Models.*;
import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.network.message.FilterMask;
import net.minecraft.network.message.SignedMessage;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WhisperRouterTest {
    private static final String ID = "00000000-0000-0000-0000-000000000001";
    private record Filed(String key, Message message, boolean incoming) {}
    private static final class TestHost implements WhisperRouter.Host {
        final Config config = new Config();
        final State state = new State();
        final FriendLink mod = new FriendLink();
        final SendQueue queue = new SendQueue(mod);
        final List<Filed> filed = new ArrayList<>();
        final List<Protocol.Invite> invites = new ArrayList<>();
        int notices, errors;
        TestHost() {
            mod.config = config; mod.state = state; mod.queue = queue;
            config.dialogueRegex = new ArrayList<>(List.of(WhisperText.DEFAULT_DIALOGUE_REGEX));
            Friend friend = new Friend(); friend.name = "DyLol"; state.friends.put("dylol", friend);
        }
        public Config config() { return config; }
        public State state() { return state; }
        public Friend friend(String name, UUID uuid) { return FriendIdentity.find(state, name, uuid); }
        public String self() { return "Me"; }
        public void touch() { mod.touch(); }
        public boolean echo(String name, String body) { return queue.echo(name, body); }
        public boolean notFound() { errors++; return queue.notFound(); }
        public void append(String key, Message message, boolean incoming) { filed.add(new Filed(key, message, incoming)); }
        public void inviteNotice(Group group, String sender) { notices++; }
        public void receiveInvite(String sender, Protocol.Invite invite) { invites.add(invite); }
    }
    private void arm(SendQueue queue, SendQueue.Job job) throws Exception {
        assertTrue(queue.offer(List.of(job)));
        Field waiting = SendQueue.class.getDeclaredField("waiting"); waiting.setAccessible(true);
        ((ArrayDeque<?>) waiting.get(queue)).remove();
        Field active = SendQueue.class.getDeclaredField("active"); active.setAccessible(true); active.set(queue, job);
    }
    @Test void exactSamplesAreFiledWithCorrectDirectionAndNoFormatting() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertTrue(r.receive("§dFrom Me §dto §7DyLol§7: §fyou go to end?"));
        assertTrue(r.receive("§dFrom §7DyLol §dto Me§7: §ftes"));
        assertEquals(2, h.filed.size());
        assertEquals("f:dylol", h.filed.get(0).key());
        assertEquals("Me", h.filed.get(0).message().sender); assertFalse(h.filed.get(0).incoming());
        assertEquals("you go to end?", h.filed.get(0).message().text);
        assertEquals("DyLol", h.filed.get(1).message().sender); assertTrue(h.filed.get(1).incoming());
        assertEquals("tes", h.filed.get(1).message().text);
    }
    @Test void onlyFriendsAreSuppressedIncludingProtocolLookingMessages() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        for (String body : List.of("hello", "[FL:" + ID + "] hello", "[FLI:" + ID + ":12345678:1:1] abc")) {
            assertFalse(r.receive("From Stranger to Me: " + body));
            assertFalse(r.receive("From Me to Stranger: " + body));
            assertFalse(r.receiveParticipant("[VIP] Stranger", null, body, false));
        }
        assertTrue(h.filed.isEmpty()); assertTrue(h.state.groups.isEmpty()); assertTrue(h.invites.isEmpty());
    }
    @Test void publicChatNeverRoutesWithPermissiveCustomRegexOrErrorRegex() {
        TestHost h = new TestHost();
        h.config.incomingRegex = List.of("^\\[.*?\\] (?<name>.+?): (?<message>.*)$");
        h.config.notFoundRegex = List.of(".*");
        WhisperRouter r = new WhisperRouter(h);
        assertFalse(r.receive("[78] DyLol: hello"));
        assertFalse(r.receive("§x§a§b§c§d§e§f[78] §7DyLol: hello"));
        assertTrue(h.filed.isEmpty()); assertEquals(0, h.errors);
    }
    @Test void intentionalRepeatedIncomingAndManualOutgoingAreNotDeduplicated() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        for (int i = 0; i < 2; i++) assertTrue(r.receive("From DyLol to Me: same"));
        for (int i = 0; i < 2; i++) assertTrue(r.receive("From Me to DyLol: same"));
        assertEquals(4, h.filed.size());
    }
    @Test void queueEchoIsAcknowledgedBeforeAppendAndDuplicateEchoDoesNotAppend() throws Exception {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        Message message = new Message("Me", "hello", false);
        arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        assertTrue(r.receive("§dFrom Me to §7DyLol: §fhello"));
        assertTrue(r.receive("From Me to DyLol: hello"));
        assertEquals(1, message.delivery.get("DyLol").completed);
        assertEquals(0, message.delivery.get("DyLol").unconfirmed);
        assertTrue(h.filed.isEmpty()); assertEquals("DyLol: ✓ sent", message.status());
    }
    @Test void participantSeamNormalizesTypedAndProfilelessNamesAndBodiesBeforeRouting() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        UUID id = UUID.randomUUID();
        assertTrue(r.receiveParticipant("§x§1§2§3§4§5§6[MVP+] ★ DyLol", id, "§dhello", false));
        assertTrue(r.receiveParticipant("§7[VIP] DyLol", null, "§fhello", true));
        assertEquals(id.toString(), h.state.friends.get("dylol").uuid);
        assertEquals("hello", h.filed.get(0).message().text);
        assertEquals("hello", h.filed.get(1).message().text);
        assertFalse(r.receiveParticipant("abcdefghijklmnopq", null, "hello", false));
        // A real whisper may legitimately contain text looking like public chat.
        assertTrue(r.receiveParticipant("DyLol", null, "[78] DyLol: quoted", false));
        assertEquals("[78] DyLol: quoted", h.filed.get(2).message().text);
    }
    @Test void uuidIdentityCanResolveRenamedFriendAndEchoCanonicalTarget() throws Exception {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        UUID id = UUID.randomUUID(); h.state.friends.get("dylol").uuid = id.toString();
        assertTrue(r.receiveParticipant("Renamed", id, "hi", false));
        assertEquals("DyLol", h.filed.get(0).message().sender);
        h.filed.clear();
        // The wire name differs only by decorations in ordinary outgoing typed/profileless traffic.
        Message message = new Message("Me", "hello", false);
        arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        assertTrue(r.receiveParticipant("[VIP] DyLol", null, "§fhello", true));
        assertEquals(1, message.delivery.get("DyLol").completed); assertTrue(h.filed.isEmpty());
    }
    @Test void groupPayloadUsesSameStrippedRouteAndDoesNotBecomeDirectMessage() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertTrue(r.receive("§dFrom DyLol to Me: §x§1§2§3§4§5§6[FL:" + ID + "] §fhello"));
        assertEquals(1, h.notices); assertEquals(1, h.filed.size());
        assertEquals("g:" + ID, h.filed.get(0).key()); assertEquals("hello", h.filed.get(0).message().text);
        assertTrue(r.receiveParticipant("[VIP] DyLol", null, "§a[FL:" + ID + "] §btyped", false));
        assertEquals("typed", h.filed.get(1).message().text); assertEquals(1, h.notices);
    }
    @Test void decoratedMultipartInviteAndMalformedControlShareRouteWithoutFiling() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        Protocol.Invite invite = new Protocol.Invite();
        invite.id = ID; invite.name = "Test group"; invite.owner = "DyLol";
        invite.members = List.of("DyLol", "Me_"); invite.revision = 1;
        List<String> parts = Protocol.inviteParts(invite);
        for (int i = 0; i < parts.size(); i++) {
            String coloured = "§x§A§b§C§d§E§f" + parts.get(i);
            if (i % 2 == 0) assertTrue(r.receive("§dFrom [VIP] DyLol to Me: " + coloured));
            else assertTrue(r.receiveParticipant("§7DyLol", null, coloured, false));
        }
        assertEquals(1, h.invites.size()); assertEquals(ID, h.invites.get(0).id);
        assertTrue(r.receive("From DyLol to Me: §r[FLI:malformed] rubbish"));
        assertEquals(1, h.invites.size()); assertTrue(h.filed.isEmpty());
    }
    @Test void fullyFilteredContentNeverFilesAndMaskedContentDoesNotLeakRawText() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertNull(WhisperRouter.visibleBody(true, "secret"));
        String visible = WhisperRouter.visibleBody(false, "s•••••");
        assertEquals("s•••••", visible);
        assertNotEquals("secret", visible);
        // Missing signed payload returns before registry/client/UUID access or routing side effects.
        assertFalse(r.receiveTyped(null, null, null));
        assertTrue(h.filed.isEmpty()); assertTrue(h.invites.isEmpty());
    }

    @Test void cacheChangesOnlyOnReloadAndClearDropsPartialControlAssembly() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        h.config.dialogueRegex.clear(); h.config.incomingRegex.clear(); h.config.outgoingRegex.clear();
        assertTrue(r.receive("From DyLol to Me: before reload"));
        r.reload(); assertFalse(r.receive("From DyLol to Me: after reload"));
        h.config.dialogueRegex.add(WhisperText.DEFAULT_DIALOGUE_REGEX); r.reload();
        assertTrue(r.receiveParticipant("DyLol", null, "[FLI:" + ID + ":12345678:1:2] YQ", false));
        r.clear();
        assertTrue(r.receiveParticipant("DyLol", null, "[FLI:" + ID + ":12345678:2:2] Yg", false));
        assertTrue(h.invites.isEmpty());
    }
}
