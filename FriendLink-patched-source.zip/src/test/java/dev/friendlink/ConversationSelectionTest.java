package dev.friendlink;

import com.google.gson.Gson;
import dev.friendlink.Models.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ConversationSelectionTest {
    private State state() {
        State s = new State();
        Friend a = new Friend(); a.name = "Steve";
        Friend b = new Friend(); b.name = "Alex";
        Group g = new Group(); g.id = "00000000-0000-0000-0000-000000000001";
        s.friends.put("steve", a); s.friends.put("alex", b); s.groups.put(g.id, g);
        return s;
    }
    @Test void remembersFriendAndGroupAcrossJsonRestart() {
        State s = state();
        for (String key : new String[] {"f:alex", "g:" + s.groups.values().iterator().next().id}) {
            s.lastConversation = key;
            Gson json = new Gson();
            State loaded = json.fromJson(json.toJson(s), State.class);
            assertEquals(key, ConversationSelection.choose(loaded, null, true));
        }
    }
    @Test void explicitNotificationWinsEvenWithRememberDisabled() {
        State s = state(); s.lastConversation = "f:steve";
        assertEquals("f:alex", ConversationSelection.choose(s, "f:alex", true));
        assertEquals("f:alex", ConversationSelection.choose(s, "f:alex", false));
    }
    @Test void deletedFriendFallsBackToFirstUnread() {
        State s = state(); s.lastConversation = "f:deleted";
        s.friends.get("alex").unread = 2;
        assertEquals("f:alex", ConversationSelection.choose(s, null, true));
        s.friends.get("steve").unread = 1;
        assertEquals("f:steve", ConversationSelection.choose(s, null, true));
    }
    @Test void leftGroupIsNotReopenedAndLatestActivityWinsWithoutUnread() {
        State s = state(); Group g = s.groups.values().iterator().next();
        g.left = true; g.unread = 8; s.lastConversation = "g:" + g.id;
        Message older = new Message("Steve", "old", false); older.time = 10;
        Message newer = new Message("Alex", "new", false); newer.time = 20;
        s.friends.get("steve").messages.add(older); s.friends.get("alex").messages.add(newer);
        assertEquals("f:alex", ConversationSelection.choose(s, null, true));
    }
    @Test void unreadGroupAndEmptyState() {
        State s = state(); Group g = s.groups.values().iterator().next(); g.unread = 1;
        assertEquals("g:" + g.id, ConversationSelection.choose(s, null, true));
        assertNull(ConversationSelection.choose(new State(), null, true));
    }
    @Test void disabledRememberUsesNormalFallbackInsteadOfSavedSelection() {
        State s = state(); s.lastConversation = "f:alex";
        assertEquals("f:steve", ConversationSelection.choose(s, null, false));
    }
}
