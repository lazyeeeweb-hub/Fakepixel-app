package dev.zacktills.ui;

import dev.zacktills.config.ConfigModel;
import dev.zacktills.config.ConfigStore;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.CrosshairShape;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** ZUI-inspired Minecraft hub using the shared Zacktills settings model. */
public final class ConfigScreen extends Screen {
    private static final int TOP_H = 34, MIN_W = 290, MIN_H = 170;
    private static final String[] CHIP_LABELS = {"All", "Enabled", "Disabled"};

    private final Screen parent;
    private final List<ConfigModel.Category> categories;
    private final ConfigStore store;
    private final CategoryList categoryList = new CategoryList();
    private final ScrollList optionList = new ScrollList();
    private final TextField search;
    private final Button closeButton, minimizeButton;
    private final Chip[] chips = new Chip[3];
    private Rect panel, rail, topbar, header, searchBox, grip;
    private boolean placed, minimized;
    private int windowX, windowY, windowW, windowH, viewW, viewH;
    private int dragMode;
    private double dragX, dragY;
    private int startX, startY, startW, startH;
    private Widget focus, capture;
    private Dropdown openDropdown;
    private ScrollList popup;
    private int selected, popupIndex, filter;
    private boolean dirty = true;
    private float scale = 1f;

    public ConfigScreen(Screen parent, List<ConfigModel.Category> categories, ConfigStore store) {
        super(Text.literal("Zacktills settings"));
        if (categories.isEmpty()) throw new IllegalArgumentException("At least one category required");
        this.parent = parent;
        this.categories = categories;
        this.store = store;
        optionList.framed = false;
        optionList.pad = 2;
        optionList.bar = 4;
        optionList.barGap = 6;
        optionList.rowGap = 6;
        search = new TextField("", value -> { optionList.scroll = 0; dirty = true; });
        closeButton = new Button("X", this::close);
        minimizeButton = new Button("-", () -> {
            minimized = !minimized;
            minimizeButtonState();
        });
        for (int i = 0; i < chips.length; i++) {
            final int mode = i;
            chips[i] = new Chip(CHIP_LABELS[i], () -> {
                if (filter != mode) { filter = mode; optionList.scroll = 0; dirty = true; }
            });
        }
    }

    private static float configuredScale() {
        try {
            return (float) Math.max(.5, Math.min(1.5, FeatureSettings.number("interface.ui_scale")));
        } catch (RuntimeException ignored) {
            return 1f;
        }
    }

    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        dragMode = 0;
        closePopup();
        int oldViewW = viewW, oldViewH = viewH;
        scale = configuredScale();
        viewW = Math.max(1, (int) Math.floor(width / scale));
        viewH = Math.max(1, (int) Math.floor(height / scale));
        if (!placed) {
            windowW = Math.min(480, viewW - 16);
            windowH = Math.min(310, viewH - 16);
            windowX = (viewW - windowW) / 2;
            windowY = (viewH - windowH) / 2;
            placed = true;
        } else {
            windowX += (viewW - oldViewW) / 2;
            windowY += (viewH - oldViewH) / 2;
        }
        layoutHub();
        dirty = true;
        rebuild();
    }

    private void minimizeButtonState() {
        closePopup();
        minimizeButton.label = minimized ? "+" : "-";
        setFocus(minimizeButton);
        layoutHub();
    }

    private void layoutHub() {
        windowW = clamp(windowW, Math.min(MIN_W, viewW), viewW);
        windowH = clamp(windowH, Math.min(MIN_H, viewH), viewH);
        // Keep the expanded window on screen even while its body is collapsed.
        windowX = clamp(windowX, 0, viewW - windowW);
        windowY = clamp(windowY, 0, viewH - windowH);
        panel = new Rect(windowX, windowY, windowW, minimized ? Math.min(TOP_H, windowH) : windowH);
        topbar = region(panel, 8, 1, panel.w() - 16, TOP_H - 2);
        closeButton.bounds(region(topbar, topbar.w() - 24, 5, 24, 22));
        minimizeButton.bounds(region(topbar, topbar.w() - 52, 5, 24, 22));
        grip = minimized ? region(panel, 0, 0, 0, 0) : region(panel, panel.w() - 16, panel.h() - 16, 15, 15);
        if (minimized) return;

        int sidebarW = Math.min(104, panel.w() / 3);
        rail = region(panel, 1, TOP_H + 1, sidebarW, panel.h() - TOP_H - 5);
        categoryList.bounds(rail);
        int contentX = sidebarW + 9, contentY = TOP_H + 9;
        Rect content = region(panel, contentX, contentY, panel.w() - contentX - 9, panel.h() - contentY - 16);
        header = region(content, 2, 0, content.w() - 4, 16);
        searchBox = region(content, 0, 20, content.w(), 22);
        search.bounds(region(searchBox, 22, 0, Math.max(0, searchBox.w() - 22), 22));
        int chipX = 0;
        for (Chip chip : chips) {
            int w = textWidth(chip.label) + 14;
            chip.bounds(region(content, chipX, 47, w, 16));
            chipX += w + 4;
        }
        optionList.bounds(region(content, 0, 69, content.w(), content.h() - 69));
    }

    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }

    private void rebuild() {
        if (!dirty) return;
        dirty = false;
        closePopup();
        search.placeholder = "Search " + categories.get(selected).options.size() + " settings";
        categoryList.categories(categories, selected, index -> {
            if (selected != index) {
                selected = index;
                optionList.scroll = 0;
                dirty = true;
            }
        });
        for (int i = 0; i < chips.length; i++) chips[i].selected = i == filter;
        List<Widget> rows = new ArrayList<>();
        String query = search.value.toLowerCase(Locale.ROOT).trim();
        ConfigModel.Category category = categories.get(selected);
        append(rows, category.options, query, 0, true);
        if (filter == 0 && category.id.equals("tooltip") && (query.isEmpty() || "crosshair".contains(query) || query.contains("crosshair"))) {
            rows.add(new CrosshairPreview());
        }
        optionList.setItems(rows);
        if (focus != search && focus != closeButton && focus != minimizeButton) setFocus(null);
    }

    private static final class CrosshairPreview extends Widget {
        @Override public int height() { return 82; }
        @Override public List<Widget> focusables() { return List.of(); }
        @Override public Widget focusAt(double x, double y) { return null; }
        @Override public boolean down(double x, double y) { return false; }
        @Override public void render(DrawContext c, int mx, int my) {
            rounded(c, bounds, 6, INSET);
            text(c, "LIVE PREVIEW", bounds.x() + 10, bounds.y() + 7, bounds.w() - 20, ACCENT_HOVER);
            Rect sample = region(bounds, 8, 21, bounds.w() - 16, bounds.h() - 29);
            framed(c, sample, 5, PANEL, BORDER);
            clip(c, sample);
            if (FeatureSettings.on("tooltip.crosshair")) {
                CrosshairShape.draw(c, sample.x() + sample.w() / 2, sample.y() + sample.h() / 2,
                        (int) FeatureSettings.number("tooltip.crosshair_thickness"),
                        (int) FeatureSettings.number("tooltip.crosshair_length"), WHITE);
            } else centered(c, "Custom crosshair off", sample, MUTED);
            unclip(c);
        }
    }

    private boolean matches(ConfigModel.Option<?> option, String query) {
        if (query.isEmpty() || (option.label + " " + option.description).toLowerCase(Locale.ROOT).contains(query)) return true;
        if (option instanceof ConfigModel.Folder folder) {
            for (ConfigModel.Option<?> child : folder.children) if (matches(child, query)) return true;
        }
        return false;
    }

    private void append(List<Widget> rows, List<ConfigModel.Option<?>> options, String query, int depth, boolean parentEnabled) {
        for (ConfigModel.Option<?> option : options) {
            if (!matches(option, query)) continue;
            if (filter != 0) {
                if (option instanceof ConfigModel.Folder folder) {
                    append(rows, folder.children, query, depth, parentEnabled && option.enabled);
                } else if (option instanceof ConfigModel.Bool bool && bool.value == (filter == 1)) {
                    OptionRow row = new OptionRow(option, depth, this::openPopup, () -> dirty = true);
                    row.enabled = parentEnabled && option.enabled;
                    if (row.control != null) row.control.enabled = row.enabled;
                    rows.add(row);
                }
                continue;
            }
            OptionRow row = new OptionRow(option, depth, this::openPopup, () -> { if (option instanceof ConfigModel.Folder) dirty = true; });
            row.enabled = parentEnabled && option.enabled;
            if (row.control != null) row.control.enabled = row.enabled;
            rows.add(row);
            if (option instanceof ConfigModel.Folder folder && (folder.expanded || !query.isEmpty())) {
                append(rows, folder.children, query, depth + 1, row.enabled);
            }
        }
    }

    private void openPopup(Dropdown dropdown) {
        closePopup();
        openDropdown = dropdown;
        popup = new ScrollList();
        List<Widget> choices = new ArrayList<>();
        for (String choice : dropdown.option.choices) {
            Button button = new Button(choice, () -> { dropdown.option.value = choice; closePopup(); });
            button.selected = choice.equals(dropdown.option.value);
            choices.add(button);
        }
        popup.setItems(choices);
        Rect anchor = dropdown.bounds, area = inset(panel, 8);
        int w = Math.min(Math.max(100, anchor.w() + 28), area.w());
        int h = Math.min(Math.max(0, choices.size() * 32 + 8), Math.min(area.h(), Math.max(48, area.h() / 2)));
        int x = clamp(anchor.x(), area.x(), area.x() + area.w() - w);
        int y = anchor.y() + anchor.h() + 8;
        if (y + h > area.y() + area.h()) y = anchor.y() - h - 8;
        y = clamp(y, area.y(), area.y() + area.h() - h);
        popup.bounds(new Rect(x, y, w, h));
        popupIndex = Math.max(0, dropdown.option.choices.indexOf(dropdown.option.value));
        setFocus(popup.items.get(popupIndex));
        popup.reveal(focus);
    }

    private void closePopup() {
        if (popup != null) {
            popup.cancel();
            if (focus != null && popup.items.contains(focus)) setFocus(openDropdown);
        }
        popup = null;
        openDropdown = null;
    }

    @Override public void render(DrawContext c, int rawX, int rawY, float delta) {
        if (capture == null && dragMode == 0 && popup == null && Math.abs(configuredScale() - scale) > 0.001f) init();
        rebuild();
        drawBackdrop(c, width, height);
        int mx = Math.round(rawX / scale), my = Math.round(rawY / scale);
        int hx = popup == null ? mx : -10000, hy = popup == null ? my : -10000;
        c.getMatrices().push();
        c.getMatrices().scale(scale, scale, 1f);
        DrawUtil.scale = scale;
        try {
            hubFrame(c, panel, TOP_H);
            int titleW = Math.max(0, minimizeButton.bounds.x() - topbar.x() - 8);
            rounded(c, region(topbar, 3, 10, 3, 12), 2, TITLE);
            text(c, "Zacktills", topbar.x() + 13, topbar.y() + 12, titleW - 13, TEXT);
            minimizeButton.render(c, hx, hy);
            closeButton.render(c, hx, hy);
            if (minimized) return;
            rounded(c, rail, 6, RAIL);
            categoryList.render(c, hx, hy);

            ConfigModel.Category category = categories.get(selected);
            text(c, category.label.toUpperCase(Locale.ROOT), header.x(), header.y() + 2, header.w(), ACCENT_HOVER);
            fill(c, region(header, 0, 14, header.w(), 1), BORDER);

            framed(c, searchBox, 6, PANEL, BORDER);
            drawMagnifier(c, searchBox.x() + 7, searchBox.y() + 6, MUTED, PANEL);
            search.render(c, hx, hy);
            for (Chip chip : chips) chip.render(c, hx, hy);
            optionList.render(c, hx, hy);
            int gripColor = grip.contains(hx, hy) || dragMode == 2 ? ACCENT_HOVER : MUTED;
            fill(c, region(grip, 9, 9, 2, 2), gripColor);
            fill(c, region(grip, 5, 9, 2, 2), gripColor);
            fill(c, region(grip, 9, 5, 2, 2), gripColor);
            if (optionList.items.isEmpty()) {
                clip(c, optionList.bounds);
                text(c, "No matching options", optionList.bounds.x() + 10, optionList.bounds.y() + 10,
                        optionList.bounds.w() - 20, MUTED);
                unclip(c);
            }
            if (popup != null) {
                drawPlaceholder(c, popup.bounds);
                popup.render(c, mx, my);
            } else if (capture == null && dragMode == 0) {
                boolean shown = false;
                for (Widget item : categoryList.items) {
                    if (item instanceof TabButton button && rail.contains(mx, my) && button.bounds.contains(mx, my)
                            && textWidth(button.label) > button.bounds.w() - 13) {
                        drawHint(c, inset(panel, 8), button.label, mx, my);
                        shown = true;
                        break;
                    }
                }
                if (!shown && optionList.bounds.contains(mx, my)) {
                    for (Widget item : optionList.items) {
                        if (item instanceof OptionRow row && row.bounds.contains(mx, my) && !((row.control != null) && row.control.bounds.contains(mx, my))) {
                            String hint = row.option.label;
                            if (!row.option.description.equals(hint)) hint += " - " + row.option.description;
                            drawHint(c, inset(panel, 8), hint, mx, my);
                            break;
                        }
                    }
                }
            }
        } finally {
            DrawUtil.scale = 1f;
            c.getMatrices().pop();
        }
    }

    private Widget hit(double mx, double my) {
        if (closeButton.bounds.contains(mx, my)) return closeButton;
        if (minimizeButton.bounds.contains(mx, my)) return minimizeButton;
        if (minimized) return null;
        if (search.bounds.contains(mx, my)) return search;
        for (Chip chip : chips) if (chip.bounds.contains(mx, my)) return chip;
        if (categoryList.bounds.contains(mx, my)) return categoryList;
        if (optionList.bounds.contains(mx, my)) return optionList;
        return null;
    }

    @Override public boolean mouseClicked(double rawX, double rawY, int button) {
        if (button != 0) return false;
        double mx = rawX / scale, my = rawY / scale;
        rebuild();
        if (capture != null) capture.cancel();
        capture = null;
        if (popup != null) {
            if (popup.bounds.contains(mx, my)) {
                setFocus(popup.focusAt(mx, my));
                int pointerIndex = popup.items.indexOf(focus);
                if (pointerIndex >= 0) popupIndex = pointerIndex;
                if (popup.down(mx, my)) capture = popup;
            } else closePopup();
            return true;
        }
        Widget target = hit(mx, my);
        if ((target == null && topbar.contains(mx, my)) || grip.contains(mx, my)) {
            dragMode = grip.contains(mx, my) ? 2 : 1;
            dragX = mx; dragY = my;
            startX = windowX; startY = windowY;
            startW = windowW; startH = windowH;
            setFocus(null);
            return true;
        }
        setFocus(target == null ? null : target.focusAt(mx, my));
        if (target != null && target.down(mx, my)) { capture = target; return true; }
        return panel.contains(mx, my);
    }

    @Override public boolean mouseDragged(double rawX, double rawY, int button, double dx, double dy) {
        if (button == 0 && dragMode != 0) {
            int moveX = (int) Math.round(rawX / scale - dragX);
            int moveY = (int) Math.round(rawY / scale - dragY);
            if (dragMode == 1) {
                windowX = startX + moveX;
                windowY = startY + moveY;
            } else {
                windowW = clamp(startW + moveX, Math.min(MIN_W, viewW), viewW - startX);
                windowH = clamp(startH + moveY, Math.min(MIN_H, viewH), viewH - startY);
            }
            layoutHub();
            return true;
        }
        if (button == 0 && capture != null) { capture.drag(rawX / scale, rawY / scale); return true; }
        return false;
    }

    @Override public boolean mouseReleased(double rawX, double rawY, int button) {
        if (button != 0) return false;
        if (dragMode != 0) { dragMode = 0; return true; }
        if (capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(rawX / scale, rawY / scale);
        rebuild();
        return true;
    }

    @Override public boolean mouseScrolled(double rawX, double rawY, double amount) {
        double mx = rawX / scale, my = rawY / scale;
        if (popup != null) return popup.wheel(mx, my, amount) || panel.contains(mx, my);
        return !minimized && (categoryList.wheel(mx, my, amount) || optionList.wheel(mx, my, amount));
    }

    @Override public boolean charTyped(char chr, int modifiers) {
        if (focus != null && focus.character(chr)) { rebuild(); return true; }
        return false;
    }

    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        rebuild();
        if (popup != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { closePopup(); return true; }
            if (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
                popupIndex = Math.floorMod(popupIndex + (key == GLFW.GLFW_KEY_UP ? -1 : 1), popup.items.size());
                setFocus(popup.items.get(popupIndex));
                popup.reveal(focus);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) {
                Widget target = popup.items.get(popupIndex);
                target.key(GLFW.GLFW_KEY_ENTER, modifiers);
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = new ArrayList<>();
            controls.add(minimizeButton);
            controls.add(closeButton);
            if (!minimized) {
                controls.add(search);
                for (Chip chip : chips) controls.add(chip);
                controls.addAll(categoryList.focusables());
                controls.addAll(optionList.focusables());
            }
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            int next = current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size());
            setFocus(controls.get(next));
            categoryList.reveal(focus);
            optionList.reveal(focus);
            return true;
        }
        if (focus != null && focus.key(key, modifiers)) { rebuild(); return true; }
        if (!minimized && (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN)) {
            optionList.page(key == GLFW.GLFW_KEY_PAGE_UP ? -1 : 1);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }

    @Override public void removed() {
        DrawUtil.scale = 1f;
        if (capture != null) capture.cancel();
        capture = null;
        dragMode = 0;
        closePopup();
        if (!store.save() && client != null && client.player != null) {
            client.player.sendMessage(Text.literal("Zacktills: config save failed; see the log."), false);
        }
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }
}
