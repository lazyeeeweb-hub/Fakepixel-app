package dev.zacktills.ui;

import dev.zacktills.config.ConfigModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static dev.zacktills.ui.DrawUtil.*;

public final class Widgets {
    private Widgets() {}

    public abstract static class Widget {
        public Rect bounds = new Rect(0, 0, 0, 0);
        public boolean enabled = true, pressed, focused;
        public void bounds(Rect value) { bounds = value; }
        public int height() { return 24; }
        public int heightFor(int width) { return height(); }
        public State state(double mx, double my) {
            return !enabled ? State.DISABLED : pressed ? State.PRESSED
                    : focused || bounds.contains(mx, my) ? State.HOVER : State.NORMAL;
        }
        public abstract void render(DrawContext c, int mx, int my);
        public boolean down(double mx, double my) {
            pressed = enabled && bounds.contains(mx, my);
            return pressed;
        }
        public void drag(double mx, double my) {}
        public void up(double mx, double my) { pressed = false; }
        public void cancel() { pressed = false; }
        public boolean immediateDrag() { return false; }
        public boolean key(int key, int modifiers) { return false; }
        public boolean character(char chr) { return false; }
        public boolean wheel(double mx, double my, double amount) { return false; }
        public Widget focusAt(double mx, double my) { return enabled && bounds.contains(mx, my) ? this : null; }
        public List<Widget> focusables() { return enabled ? List.of(this) : List.of(); }
        public boolean owns(Widget widget) { return this == widget; }
    }

    public static class Button extends Widget {
        public String label;
        public boolean selected, primary;
        protected final Runnable action;
        public Button(String label, Runnable action) { this.label = label; this.action = action; }
        @Override public void render(DrawContext c, int mx, int my) {
            if (primary) drawPrimary(c, bounds, label, state(mx, my));
            else drawButton(c, bounds, label, state(mx, my), selected);
        }
        @Override public void up(double mx, double my) {
            boolean activate = enabled && pressed && bounds.contains(mx, my);
            pressed = false;
            if (activate) action.run();
        }
        @Override public boolean key(int key, int modifiers) {
            if (enabled && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_KP_ENTER)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    public static final class Toggle extends Button {
        private final Supplier<Boolean> value;
        private double progress;
        private long lastFrame = System.nanoTime();
        public Toggle(ConfigModel.Bool option, Runnable changed) {
            super("", () -> { option.value = !option.value; changed.run(); });
            value = () -> option.value;
            progress = option.value ? 1 : 0;
        }
        @Override public void render(DrawContext c, int mx, int my) {
            long now = System.nanoTime();
            double dt = Math.min(.05, Math.max(0, (now - lastFrame) / 1_000_000_000.0));
            lastFrame = now;
            progress += ((value.get() ? 1 : 0) - progress) * (1 - Math.exp(-dt * 20));
            drawToggle(c, bounds, progress, state(mx, my));
        }
    }

    public static final class Slider extends Widget {
        private final ConfigModel.Range option;
        public Slider(ConfigModel.Range option) { this.option = option; }
        private void update(double mx) {
            int track = sliderTrackWidth(bounds.w()), diameter = Math.min(12, Math.min(bounds.h(), track));
            int travel = Math.max(1, track - diameter);
            double fraction = Math.max(0, Math.min(1, (mx - bounds.x() - diameter / 2.0) / travel));
            option.set(option.min + fraction * (option.max - option.min));
        }
        @Override public void render(DrawContext c, int mx, int my) {
            drawSlider(c, bounds, (option.value - option.min) / (option.max - option.min), option.display(), state(mx, my));
        }
        @Override public boolean down(double mx, double my) {
            if (!super.down(mx, my)) return false;
            update(mx);
            return true;
        }
        @Override public void drag(double mx, double my) { if (pressed) update(mx); }
        @Override public boolean immediateDrag() { return true; }
        @Override public boolean key(int key, int modifiers) {
            if (!enabled) return false;
            if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT) {
                option.set(option.value + (key == GLFW.GLFW_KEY_LEFT ? -option.step : option.step));
                return true;
            }
            return false;
        }
    }

    public static final class Dropdown extends Widget {
        public final ConfigModel.Choice option;
        private final Consumer<Dropdown> opener;
        public Dropdown(ConfigModel.Choice option, Consumer<Dropdown> opener) { this.option = option; this.opener = opener; }
        @Override public void render(DrawContext c, int mx, int my) { drawDropdown(c, bounds, option.value, state(mx, my), focused); }
        @Override public void up(double mx, double my) {
            boolean activate = enabled && pressed && bounds.contains(mx, my);
            pressed = false;
            if (activate) opener.accept(this);
        }
        @Override public boolean key(int key, int modifiers) {
            if (enabled && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE)) {
                opener.accept(this);
                return true;
            }
            return false;
        }
    }

    public static final class Folder extends Button {
        private final ConfigModel.Folder option;
        public Folder(ConfigModel.Folder option, Runnable changed) {
            super(option.label, () -> { option.expanded = !option.expanded; changed.run(); });
            this.option = option;
        }
        @Override public void render(DrawContext c, int mx, int my) {
            drawFolder(c, bounds, label, option.expanded, state(mx, my));
        }
    }

    public static final class TextField extends Widget {
        public String value;
        public static final int MAX_LENGTH = 8192;
        public int maxLength = MAX_LENGTH;
        public boolean masked;
        public String placeholder = "";
        private int caret, anchor, start;
        private final Consumer<String> changed;
        public TextField(String value, Consumer<String> changed) {
            this.value = value;
            this.caret = this.anchor = value.length();
            this.changed = changed;
        }
        @Override public void render(DrawContext c, int mx, int my) {
            ensureCaret();
            drawTextField(c, bounds, display(), caret, anchor, start, focused, state(mx, my));
            if (value.isEmpty() && !focused && bounds.h() >= 9) {
                clip(c, bounds);
                text(c, placeholder, bounds.x() + 8, bounds.y() + (bounds.h() - 8) / 2, bounds.w() - 16, MUTED);
                unclip(c);
            }
        }
        private String display() { return masked ? "*".repeat(value.length()) : value; }
        public void clear() { value = ""; caret = anchor = start = 0; changed.accept(value); }
        private void ensureCaret() {
            caret = clamp(caret, 0, value.length()); anchor = clamp(anchor, 0, value.length());
            start = clamp(start, 0, caret);
            String before = display().substring(start, caret);
            int room = Math.max(0, bounds.w() - 18);
            if (textWidth(before) > room) start = caret - font().trimToWidth(before, room, true).length();
        }
        private int indexAt(double mx) {
            ensureCaret();
            double x = bounds.x() + 8;
            String shown = display();
            for (int i = start; i < value.length(); i++) {
                int width = textWidth(shown.substring(i, i + 1));
                if (mx < x + width / 2.0) return i;
                x += width;
            }
            return value.length();
        }
        @Override public boolean down(double mx, double my) {
            if (!super.down(mx, my)) return false;
            caret = anchor = indexAt(mx);
            return true;
        }
        @Override public boolean immediateDrag() { return true; }
        @Override public void drag(double mx, double my) { if (pressed) caret = indexAt(mx); }
        private void insert(String text) {
            int a = Math.min(caret, anchor), b = Math.max(caret, anchor);
            StringBuilder clean = new StringBuilder();
            for (int i = 0; i < text.length(); i++) {
                char chr = text.charAt(i);
                if (chr >= 32 && chr != 127 && chr != '\u00a7') clean.append(chr);
            }
            int available = Math.max(0, Math.max(0, maxLength) - (value.length() - (b - a)));
            String added = clean.substring(0, Math.min(clean.length(), available));
            value = value.substring(0, a) + added + value.substring(b);
            caret = anchor = a + added.length();
            changed.accept(value);
            ensureCaret();
        }
        @Override public boolean character(char chr) {
            if (!enabled || !focused || chr < 32 || chr == 127 || chr == '\u00a7') return false;
            insert(Character.toString(chr));
            return true;
        }
        @Override public boolean key(int key, int modifiers) {
            if (!enabled || !focused) return false;
            boolean control = Screen.hasControlDown();
            boolean shift = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
            var keyboard = MinecraftClient.getInstance().keyboard;
            if (control && key == GLFW.GLFW_KEY_A) { anchor = 0; caret = value.length(); return true; }
            if (control && (key == GLFW.GLFW_KEY_C || key == GLFW.GLFW_KEY_X)) {
                if (!masked) keyboard.setClipboard(value.substring(Math.min(anchor, caret), Math.max(anchor, caret)));
                if (key == GLFW.GLFW_KEY_X && anchor != caret) insert("");
                return true;
            }
            if (control && key == GLFW.GLFW_KEY_V) { insert(keyboard.getClipboard()); return true; }
            if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_HOME || key == GLFW.GLFW_KEY_END) {
                if (key == GLFW.GLFW_KEY_HOME) caret = 0;
                else if (key == GLFW.GLFW_KEY_END) caret = value.length();
                else if (!shift && anchor != caret) caret = key == GLFW.GLFW_KEY_LEFT ? Math.min(anchor, caret) : Math.max(anchor, caret);
                else caret = clamp(caret + (key == GLFW.GLFW_KEY_LEFT ? -1 : 1), 0, value.length());
                if (!shift) anchor = caret;
                ensureCaret();
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
                if (caret == anchor) {
                    if (key == GLFW.GLFW_KEY_BACKSPACE && caret > 0) anchor = caret - 1;
                    if (key == GLFW.GLFW_KEY_DELETE && caret < value.length()) anchor = caret + 1;
                }
                insert("");
                return true;
            }
            return key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER;
        }
    }

    public static final class OptionRow extends Widget {
        public final ConfigModel.Option<?> option;
        public final Widget control;
        private final int depth;
        public OptionRow(ConfigModel.Option<?> option, int depth, Consumer<Dropdown> opener, Runnable changed) {
            this.option = option;
            this.depth = depth;
            control = switch (option.kind) {
                case BOOL -> new Toggle((ConfigModel.Bool) option, changed);
                case RANGE -> new Slider((ConfigModel.Range) option);
                case ENUM -> new Dropdown((ConfigModel.Choice) option, opener);
                case STRING -> new TextField(((ConfigModel.StringOption) option).value,
                        value -> ((ConfigModel.StringOption) option).value = value);
                case ACTION -> actionButton((ConfigModel.Action) option);
                case FOLDER -> new Folder((ConfigModel.Folder) option, changed);
                case PLACEHOLDER -> null;
            };
            enabled = option.enabled;
            if (control != null) control.enabled = enabled;
        }
        private static Button actionButton(ConfigModel.Action action) {
            Button button = new Button("Open", action.value);
            button.primary = true;
            return button;
        }
        @Override public int heightFor(int width) { return option.kind == ConfigModel.Kind.RANGE ? 42 : 34; }
        @Override public void bounds(Rect rect) {
            super.bounds(rect);
            int indent = Math.min(depth * 10, rect.w() / 4);
            Rect content = region(rect, indent, 0, rect.w() - indent, rect.h());
            if (control == null) return;
            if (option.kind == ConfigModel.Kind.RANGE) {
                control.bounds(region(content, 10, 22, content.w() - 20, 16));
                return;
            }
            if (option.kind == ConfigModel.Kind.FOLDER) { control.bounds(region(content, 0, 3, content.w(), rect.h() - 6)); return; }
            int available = Math.max(0, content.w() - 20);
            int w = switch (option.kind) {
                case BOOL -> Math.min(38, available);
                case ACTION -> Math.min(60, available);
                case RANGE, STRING -> Math.min(150, available * 45 / 100);
                default -> Math.min(110, available * 45 / 100);
            };
            int h = option.kind == ConfigModel.Kind.BOOL ? 20 : 22;
            control.bounds(region(content, content.w() - w - 10, (rect.h() - h) / 2, w, h));
        }
        private int labelX() { return bounds.x() + Math.min(depth * 10, bounds.w() / 4) + 10; }
        private int labelWidth() { return Math.max(0, (option.kind == ConfigModel.Kind.RANGE
                ? bounds.x() + bounds.w() : controlX()) - labelX() - 10); }
        @Override public void render(DrawContext c, int mx, int my) {
            if (option.kind == ConfigModel.Kind.PLACEHOLDER) return;
            boolean hover = enabled && option.kind != ConfigModel.Kind.FOLDER && bounds.contains(mx, my);
            rounded(c, bounds, 6, hover ? HOVER : INSET);
            clip(c, bounds);
            if (option.kind != ConfigModel.Kind.FOLDER && bounds.h() >= 9) {
                int x = labelX(), width = labelWidth();
                String first = option.label;
                String second = option.description.equals(option.label) ? "" : option.description;
                if (textWidth(first) > width && width > 24) {
                    String fit = font().trimToWidth(first, width);
                    int cut = fit.lastIndexOf(' ');
                    if (cut > 0 && fit.length() < first.length()) {
                        second = first.substring(cut + 1);
                        first = first.substring(0, cut);
                    }
                }
                int ink = enabled ? TEXT : DISABLED_TEXT;
                if (option.kind == ConfigModel.Kind.RANGE) {
                    text(c, option.label, x, bounds.y() + 8, width, ink);
                } else if (second.isEmpty()) {
                    text(c, first, x, bounds.y() + (bounds.h() - 8) / 2, width, ink);
                } else {
                    text(c, first, x, bounds.y() + 5, width, ink);
                    text(c, second, x, bounds.y() + 16, width, MUTED);
                }
            }
            if (control != null) control.render(c, mx, my);
            unclip(c);
        }
        public int controlX() {
            return control == null || option.kind == ConfigModel.Kind.FOLDER ? bounds.x() + bounds.w() : control.bounds.x();
        }
        @Override public boolean down(double mx, double my) {
            return control != null && control.down(mx, my);
        }
        @Override public void drag(double mx, double my) { if (control != null) control.drag(mx, my); }
        @Override public void up(double mx, double my) { if (control != null) control.up(mx, my); }
        @Override public void cancel() { if (control != null) control.cancel(); }
        @Override public boolean immediateDrag() { return control != null && control.immediateDrag(); }
        @Override public Widget focusAt(double mx, double my) { return control == null ? null : control.focusAt(mx, my); }
        @Override public List<Widget> focusables() { return control == null ? List.of() : control.focusables(); }
        @Override public boolean owns(Widget widget) { return widget == this || widget == control; }
    }

    public static final class TabButton extends Button {
        public TabButton(String label, Runnable action) { super(label, action); }
        @Override public int heightFor(int width) { return 26; }
        @Override public void render(DrawContext c, int mx, int my) { drawTab(c, bounds, label, state(mx, my), selected); }
    }

    public static final class Chip extends Button {
        public Chip(String label, Runnable action) { super(label, action); }
        @Override public void render(DrawContext c, int mx, int my) {
            drawChip(c, bounds, label, state(mx, my), selected);
        }
    }

    public static class ScrollList extends Widget {
        public final List<Widget> items = new ArrayList<>();
        public double scroll;
        private double startY, startScroll, thumbOffset;
        private boolean panning, thumbDragging;
        private Widget candidate;
        public int pad = 8, bar = 4, barGap = 8, rowGap = 8;
        public boolean framed = true;
        private Rect viewport() { return inset(bounds, pad); }
        private boolean hasBar() { return maxScroll() > 0; }
        private int itemWidth() { return Math.max(0, viewport().w() - bar - barGap); }
        public void setItems(List<? extends Widget> values) {
            cancel(); items.clear(); items.addAll(values); layout();
        }
        public int contentHeight() {
            int result = Math.max(0, items.size() - 1) * rowGap;
            for (Widget item : items) result += item.heightFor(itemWidth());
            return result;
        }
        private int viewHeight() { return viewport().h(); }
        private double maxScroll() { return Math.max(0, contentHeight() - viewHeight()); }
        private Rect track() {
            Rect v = viewport();
            int w = Math.min(bar, v.w());
            return new Rect(v.x() + v.w() - w, v.y(), w, v.h());
        }
        private Rect thumb() {
            Rect t = track();
            int h = Math.min(t.h(), Math.max(12, (int) ((double) viewHeight() * viewHeight() / Math.max(1, Math.max(viewHeight(), contentHeight())))));
            int y = t.y() + (int) Math.round(maxScroll() == 0 ? 0 : scroll / maxScroll() * (t.h() - h));
            return new Rect(t.x(), y, t.w(), h);
        }
        @Override public void bounds(Rect value) { super.bounds(value); layout(); }
        public void layout() {
            scroll = Math.max(0, Math.min(maxScroll(), scroll));
            Rect v = viewport();
            int y = v.y() - (int) Math.round(scroll);
            for (Widget item : items) {
                int h = item.heightFor(itemWidth());
                item.bounds(new Rect(v.x(), y, itemWidth(), h));
                y += h + rowGap;
            }
        }
        @Override public void render(DrawContext c, int mx, int my) {
            layout();
            if (framed) drawList(c, bounds);
            Rect v = viewport();
            clip(c, new Rect(v.x(), v.y(), itemWidth(), v.h()));
            boolean inside = enabled && viewport().contains(mx, my) && !track().contains(mx, my);
            for (Widget item : items) {
                if (item.bounds.y() + item.bounds.h() > v.y() && item.bounds.y() < v.y() + v.h()) {
                    item.render(c, inside ? mx : -10000, inside ? my : -10000);
                }
            }
            unclip(c);
            if (!enabled) fill(c, bounds, 0x88000000);
            drawScrollbar(c, track(), thumb(), !enabled || maxScroll() == 0 ? State.DISABLED : thumbDragging ? State.PRESSED
                    : track().contains(mx, my) ? State.HOVER : State.NORMAL);
        }
        @Override public Widget focusAt(double mx, double my) {
            if (!enabled || !viewport().contains(mx, my) || track().contains(mx, my)) return null;
            for (Widget item : items) {
                if (item.bounds.contains(mx, my)) return item.focusAt(mx, my);
            }
            return null;
        }
        @Override public List<Widget> focusables() {
            List<Widget> result = new ArrayList<>();
            if (enabled) for (Widget item : items) result.addAll(item.focusables());
            return result;
        }
        public void reveal(Widget target) {
            int top = 0;
            for (Widget item : items) {
                if (item.owns(target)) {
                    if (top < scroll) scroll = top;
                    else if (top + item.heightFor(itemWidth()) > scroll + viewHeight()) scroll = top + item.heightFor(itemWidth()) - viewHeight();
                    layout();
                    return;
                }
                top += item.heightFor(itemWidth()) + rowGap;
            }
        }
        @Override public boolean down(double mx, double my) {
            if (!enabled || !bounds.contains(mx, my)) return false;
            cancel();
            startY = my;
            startScroll = scroll;
            if (hasBar() && track().contains(mx, my)) {
                Rect t = thumb();
                thumbDragging = true;
                thumbOffset = t.contains(mx, my) ? my - t.y() : t.h() / 2.0;
                drag(mx, my);
                return true;
            }
            for (Widget item : items) {
                if (viewport().contains(mx, my) && item.bounds.contains(mx, my) && item.down(mx, my)) { candidate = item; break; }
            }
            pressed = true;
            return true;
        }
        @Override public void drag(double mx, double my) {
            if (thumbDragging) {
                Rect track = track(), thumb = thumb();
                scroll = (my - track.y() - thumbOffset) / Math.max(1, track.h() - thumb.h()) * maxScroll();
                layout();
                return;
            }
            if (!pressed) return;
            if (candidate != null && candidate.immediateDrag()) { candidate.drag(mx, my); return; }
            if (!panning && Math.abs(my - startY) >= 3) {
                panning = true;
                if (candidate != null) candidate.cancel();
            }
            if (panning) {
                scroll = startScroll - (my - startY);
                layout();
            }
        }
        @Override public void up(double mx, double my) {
            Widget target = candidate;
            boolean activate = !panning && !thumbDragging && viewport().contains(mx, my);
            candidate = null;
            pressed = panning = thumbDragging = false;
            if (target != null) {
                if (activate) target.up(mx, my);
                else target.cancel();
            }
        }
        @Override public void cancel() {
            if (candidate != null) candidate.cancel();
            candidate = null;
            pressed = panning = thumbDragging = false;
        }
        @Override public boolean wheel(double mx, double my, double amount) {
            if (!enabled || !bounds.contains(mx, my)) return false;
            cancel();
            scroll -= amount * 24;
            layout();
            return true;
        }
        public void page(int direction) { scroll += direction * viewHeight() * 0.9; layout(); }
    }

    public static final class CategoryList extends ScrollList {
        public CategoryList() { pad = 6; bar = 0; barGap = 0; rowGap = 4; framed = false; }
        public void categories(List<ConfigModel.Category> categories, int selected, Consumer<Integer> change) {
            List<Widget> buttons = new ArrayList<>();
            for (int i = 0; i < categories.size(); i++) {
                final int index = i;
                ConfigModel.Category category = categories.get(i);
                TabButton button = new TabButton(category.label, () -> change.accept(index));
                button.selected = i == selected;
                buttons.add(button);
            }
            setItems(buttons);
        }
    }
}
