# Zacktills Client (Minecraft 1.20.1 / Fabric)

This is an experimental client-side source update to the provided config-menu prototype. It contains settings and rendering hooks for configurable HUD elements, clean scoreboard, NBT copy, slot locks, flat dropped-item icons, tooltip scrolling, custom crosshair/viewmodel, swing-through, opt-in chat-triggered login, third-person wall fade.

## Build
Open the project with a Java 17 Gradle environment and run `gradle build`. The resulting mod JAR is expected under `build/libs/`. The current source update has **not** been compiled or game-tested in this environment; verify it in a disposable client profile before use.

## Notes / limitations
- The Sodium integration hides its donation prompt only. It does not suppress driver, GPU, compatibility, or other safety warnings. It targets the Sodium 0.5.x option GUI when the optional class/methods exist.
- Wall fade is experimental, uses a vanilla core-shader dither effect, and is disabled when Sodium or Iris is detected.
- Autologin is off by default and requires an exact server address. The password is kept in memory only until disconnect; only enable it for a trusted server. Chat prompts on unsigned/custom servers may be spoofed.
- Slot lock is a client-side guard for local inventory interactions, not protection against server/plugin changes. Multi-slot inventory operations are conservatively blocked when any local slot is locked.
- NBT copy copies the hovered/held item stack data; it does not provide arbitrary block-entity NBT access.
- Mod Menu 7.2.2 already restores the mod-list scroll position when returning to the same ModsScreen instance; recent mods are not reordered. Other Mod Menu versions or screens that create a fresh ModsScreen are unverified.

Controls: Right Shift opens configuration; L toggles lock for the hovered player-inventory slot; C copies item NBT while an inventory is open. All settings are configurable in the Zacktills menu.

## ZUI-style hub
- Right Shift still opens settings. Pick a named tab on the left. Search, filters, tooltips, keyboard navigation, and all existing setting IDs are retained.
- Drag the title bar to move the hub or the dotted lower-right grip to resize it. `−` collapses the hub; `+` expands it. `X` or Escape closes it and saves settings. Window placement and collapse state are not written to the config.
- Under **Tooltips & crosshair**, **Crosshair thickness** (1–9) and **Crosshair arm length** (1–20) work independently, in scaled GUI pixels. Arm length is measured outward from the center square. The preview uses the same geometry as the HUD. The 1/4 defaults reproduce the old 9×9 crosshair. Turning off the custom crosshair leaves the vanilla renderer in control.
