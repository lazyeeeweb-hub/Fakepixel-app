package dev.cleanentities.render;

import java.util.Random;
import static dev.cleanentities.render.OcclusionMath.*;

/** No Minecraft, Fabric, JUnit, GL or world required. Run with gradle geometryTest. */
public final class OcclusionMathTest {
    private static int assertions;
    private static void check(boolean b,String name){assertions++;if(!b)throw new AssertionError(name);}
    private static boolean intersects(Point eye,Point target,Bounds box) {
        double near=0,far=1;
        for(int a=0;a<3;a++) {
            double d=target.axis(a)-eye.axis(a);
            if(Math.abs(d)<1e-12){if(eye.axis(a)<box.min(a)||eye.axis(a)>box.max(a))return false;continue;}
            double t1=(box.min(a)-eye.axis(a))/d,t2=(box.max(a)-eye.axis(a))/d;
            near=Math.max(near,Math.min(t1,t2));far=Math.min(far,Math.max(t1,t2));
            if(near>far)return false;
        }
        return near<far&&far>0&&near<1;
    }
    public static void main(String[] args) {
        Point eye=new Point(0,0,0);
        Bounds block=new Bounds(4,-1,-1,5,1,1);
        check(hidden(eye,new Bounds(8,-.2,-.2,9,.2,.2),block),"center hidden");
        check(!hidden(eye,new Bounds(1,-.2,-.2,2,.2,.2),block),"target in front");
        check(!hidden(new Point(4.5,0,0),new Bounds(8,-.2,-.2,9,.2,.2),block),"camera in blocker");
        check(!hidden(eye,new Bounds(8,1.99,-.2,9,2.2,.2),block),"edge fail open");
        check(hidden(new Point(10,0,0),new Bounds(0,-.1,-.1,1,.1,.1),block),"reverse X");
        check(hidden(eye,new Bounds(-.2,8,-.2,.2,9,.2),new Bounds(-1,4,-1,1,5,1)),"Y face");
        check(hidden(eye,new Bounds(-.2,-.2,8,.2,.2,9),new Bounds(-1,-1,4,1,1,5)),"Z face");
        check(!hidden(eye,new Bounds(3,-.2,-.2,6,.2,.2),block),"target crosses blocker plane");
        Random r=new Random(0xCE1201);int proven=0;
        for(int i=0;i<10000;i++) {
            double y=r.nextDouble()*8-4,z=r.nextDouble()*8-4,s=r.nextDouble()+.001;
            Bounds target=new Bounds(8,y-s,z-s,10,y+s,z+s);
            if(!hidden(eye,target,block))continue;
            proven++;
            for(int j=0;j<50;j++) {
                Point p=new Point(8+2*r.nextDouble(),target.minY()+(target.maxY()-target.minY())*r.nextDouble(),target.minZ()+(target.maxZ()-target.minZ())*r.nextDouble());
                check(intersects(eye,p,block),"certificate must intersect blocker");
            }
        }
        check(proven>100,"nontrivial proof coverage");
        System.out.println("OcclusionMath: "+assertions+" assertions passed; "+proven+" random boxes certified.");
    }
}
