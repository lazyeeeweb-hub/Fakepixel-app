package dev.cleanentities.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.profile.RenderProfiler.Category;
import dev.cleanentities.render.RenderPolicy;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @WrapOperation(method="render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/Entity;FFFFFF)V"))
    private void ce$feature(FeatureRenderer<?,?> renderer,MatrixStack matrices,VertexConsumerProvider vertices,int light,Entity entity,float limbAngle,float limbDistance,float delta,float animation,float yaw,float pitch,Operation<Void> original) {
        // A skull can BE the entire Fakepixel mob. Never drop the head feature wholesale.
        boolean head=renderer instanceof HeadFeatureRenderer;
        if(!head&&RenderPolicy.INSTANCE.featureLod(entity))return;
        long start=CleanEntitiesClient.PROFILER.start();
        try{original.call(renderer,matrices,vertices,light,entity,limbAngle,limbDistance,delta,animation,yaw,pitch);}
        finally{
            CleanEntitiesClient.PROFILER.add(Category.FEATURE,start);
            if(head)CleanEntitiesClient.PROFILER.add(Category.HEAD,start);
        }
    }
}
