package dev.cleanentities.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.profile.RenderProfiler.Category;
import dev.cleanentities.render.RenderPolicy;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @WrapOperation(method="renderEntity",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/EntityRenderDispatcher;render(Lnet/minecraft/entity/Entity;DDDFFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"))
    private void ce$entity(EntityRenderDispatcher dispatcher,Entity e,double x,double y,double z,float yaw,float delta,MatrixStack matrices,VertexConsumerProvider vertices,int light,Operation<Void> original) {
        var p=RenderPolicy.INSTANCE;
        if(p.skipEntity(e)){CleanEntitiesClient.PROFILER.culled();return;}
        CleanEntitiesClient.PROFILER.submitted(e);
        Entity previous=p.currentEntity;p.currentEntity=e;
        long start=CleanEntitiesClient.PROFILER.start();
        try {original.call(dispatcher,e,x,y,z,yaw,delta,matrices,vertices,light);}
        finally{CleanEntitiesClient.PROFILER.add(Category.ENTITY,start);p.currentEntity=previous;}
    }
}
