package dev.cleanentities.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import dev.cleanentities.render.RenderPolicy;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.world.WorldView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityRenderDispatcher.class)
public abstract class DispatcherMixin {
    @WrapOperation(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/EntityRenderDispatcher;renderShadow(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/entity/Entity;FFLnet/minecraft/world/WorldView;F)V"))
    private void ce$shadow(MatrixStack matrices,VertexConsumerProvider vertices,Entity entity,float opacity,float delta,WorldView world,float radius,Operation<Void> original) {
        if(!RenderPolicy.INSTANCE.shadowLod(entity))original.call(matrices,vertices,entity,opacity,delta,world,radius);
    }
}
