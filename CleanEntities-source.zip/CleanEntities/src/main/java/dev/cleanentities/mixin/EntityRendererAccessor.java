package dev.cleanentities.mixin;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(EntityRenderer.class)
public interface EntityRendererAccessor {
    @Invoker("hasLabel") boolean ce$hasLabel(Entity entity);
}
