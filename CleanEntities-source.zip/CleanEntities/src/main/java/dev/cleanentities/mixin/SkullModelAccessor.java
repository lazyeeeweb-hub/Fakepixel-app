package dev.cleanentities.mixin;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.SkullEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(SkullEntityModel.class)
public interface SkullModelAccessor {
    @Accessor("root") ModelPart ce$root();
}
