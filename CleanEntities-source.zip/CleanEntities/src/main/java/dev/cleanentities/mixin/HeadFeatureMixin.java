package dev.cleanentities.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import com.mojang.authlib.GameProfile;
import dev.cleanentities.config.CEConfig;
import dev.cleanentities.render.*;
import net.minecraft.block.SkullBlock;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.*;
import net.minecraft.client.render.block.entity.SkullBlockEntityRenderer;
import net.minecraft.client.render.entity.feature.HeadFeatureRenderer;
import net.minecraft.client.render.block.entity.SkullBlockEntityModel;
import net.minecraft.client.render.entity.model.SkullEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(HeadFeatureRenderer.class)
public abstract class HeadFeatureMixin {
    private static final String CE_RENDER="render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V";
    @WrapOperation(method=CE_RENDER,at=@At(value="INVOKE",target="Lnet/minecraft/client/render/block/entity/SkullBlockEntityRenderer;getRenderLayer(Lnet/minecraft/block/SkullBlock$SkullType;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/client/render/RenderLayer;"))
    private RenderLayer ce$layer(SkullBlock.SkullType type,GameProfile profile,Operation<RenderLayer> original) {
        CEConfig c=CEConfig.INSTANCE;
        if(c.enabled&&c.skullCache&&type==SkullBlock.Type.PLAYER&&RenderPolicy.INSTANCE.currentEntity instanceof ArmorStandEntity)
            return RenderCaches.layer(profile,()->original.call(type,profile));
        return original.call(type,profile);
    }
    @WrapOperation(method=CE_RENDER,at=@At(value="INVOKE",target="Lnet/minecraft/client/render/block/entity/SkullBlockEntityRenderer;renderSkull(Lnet/minecraft/util/math/Direction;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/block/entity/SkullBlockEntityModel;Lnet/minecraft/client/render/RenderLayer;)V"))
    private void ce$hat(Direction direction,float yaw,float animation,MatrixStack matrices,VertexConsumerProvider vertices,int light,SkullBlockEntityModel model,RenderLayer layer,Operation<Void> original) {
        ModelPart hat=null;
        if(RenderPolicy.INSTANCE.skullHatLod(RenderPolicy.INSTANCE.currentEntity)&&model instanceof SkullEntityModel skull) {
            ModelPart root=((SkullModelAccessor)skull).ce$root();
            if(root.hasChild("hat"))hat=root.getChild("hat");
            else if(root.hasChild("head")&&root.getChild("head").hasChild("hat"))hat=root.getChild("head").getChild("hat");
        }
        boolean old=hat!=null&&hat.visible;
        if(hat!=null)hat.visible=false;
        try{original.call(direction,yaw,animation,matrices,vertices,light,model,layer);}
        finally{if(hat!=null)hat.visible=old;}
    }
}
