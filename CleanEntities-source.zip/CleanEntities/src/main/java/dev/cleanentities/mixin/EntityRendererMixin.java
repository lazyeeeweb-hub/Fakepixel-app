package dev.cleanentities.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.config.CEConfig;
import dev.cleanentities.profile.RenderProfiler.Category;
import dev.cleanentities.render.*;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.text.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
    @WrapOperation(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/EntityRenderer;renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"))
    private void ce$tag(EntityRenderer<?> renderer,Entity entity,Text text,MatrixStack matrices,VertexConsumerProvider vertices,int light,Operation<Void> original) {
        if(!RenderPolicy.INSTANCE.allowLabel(entity))return;
        long start=CleanEntitiesClient.PROFILER.start();
        try{original.call(renderer,entity,text,matrices,vertices,light);}
        finally{CleanEntitiesClient.PROFILER.add(Category.NAMETAG,start);}
    }
    @WrapOperation(method="renderLabelIfPresent",at=@At(value="INVOKE",target="Lnet/minecraft/client/font/TextRenderer;getWidth(Lnet/minecraft/text/StringVisitable;)I"))
    private int ce$width(TextRenderer renderer,StringVisitable visitable,Operation<Integer> original) {
        // Vanilla computes width once, after its own distance check, for either label pass mode.
        CleanEntitiesClient.PROFILER.tag();
        CEConfig c=CEConfig.INSTANCE;
        if(c.enabled&&c.textCache&&visitable instanceof Text text)return RenderCaches.text(text,renderer).width();
        return original.call(renderer,visitable);
    }
    @WrapOperation(method="renderLabelIfPresent",at=@At(value="INVOKE",target="Lnet/minecraft/client/font/TextRenderer;draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I"))
    private int ce$text(TextRenderer renderer,Text text,float x,float y,int color,boolean shadow,Matrix4f matrix,VertexConsumerProvider vertices,TextRenderer.TextLayerType layer,int background,int light,Operation<Integer> original) {
        CEConfig c=CEConfig.INSTANCE;Entity e=RenderPolicy.INSTANCE.currentEntity;
        if(e!=null&&RenderPolicy.INSTANCE.skipBackground(e))background=0;
        if(c.enabled&&c.textCache)return renderer.draw(RenderCaches.text(text,renderer).ordered(),x,y,color,shadow,matrix,vertices,layer,background,light);
        return original.call(renderer,text,x,y,color,shadow,matrix,vertices,layer,background,light);
    }
}
