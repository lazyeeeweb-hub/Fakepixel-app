package dev.cleanentities.ui;

import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.config.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class SettingsScreen extends Screen {
    private final Screen parent;
    private int page;
    public SettingsScreen(Screen parent) { super(Text.literal("CleanEntities")); this.parent=parent; }
    public static Screen create(Screen parent) {
        if (FabricLoader.getInstance().isModLoaded("cloth-config")) return ClothScreen.create(parent);
        return new SettingsScreen(parent);
    }
    @Override protected void init() {
        int x = width/2-150, y=58;
        CEConfig c = CEConfig.INSTANCE;
        Option[] options = Option.values();
        int py=Math.min(height-76,218);
        int perPage=Math.max(1,Math.min(6,(py-y-4)/24));
        page=Math.min(page,(options.length-1)/perPage);
        for (int i=page*perPage; i<Math.min(options.length,(page+1)*perPage); i++) {
            Option o=options[i];
            if (o.toggle) {
                addDrawableChild(ButtonWidget.builder(label(o,c), b -> {
                    o.set(c,1-o.get(c)); b.setMessage(label(o,c)); CleanEntitiesClient.resetPolicy();
                }).dimensions(x,y,300,20).build());
            } else {
                addDrawableChild(new SliderWidget(x,y,300,20,label(o,c),(o.get(c)-o.min)/(double)(o.max-o.min)) {
                    @Override protected void updateMessage() { setMessage(label(o,c)); }
                    @Override protected void applyValue() {
                        o.set(c,(int)Math.round(o.min+value*(o.max-o.min)));
                        updateMessage(); CleanEntitiesClient.resetPolicy();
                    }
                });
            }
            y+=24;
        }
        CEConfig.Preset[] presets=CEConfig.Preset.values();
        for (int i=0;i<presets.length;i++) {
            CEConfig.Preset p=presets[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(p.name()), b->{
                c.preset(p); CleanEntitiesClient.resetPolicy(); clearAndInit();
            }).dimensions(width/2-150+i*76,py,72,20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Previous"),b->{page--;clearAndInit();})
            .dimensions(x,py+24,90,20).build()).active=page>0;
        addDrawableChild(ButtonWidget.builder(Text.literal("Save / Done"),b->close())
            .dimensions(x+100,py+24,100,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next"),b->{page++;clearAndInit();})
            .dimensions(x+210,py+24,90,20).build()).active=(page+1)*perPage<options.length;
    }
    private static Text label(Option o, CEConfig c) {
        return Text.literal(o.label+": "+(o.toggle?(o.get(c)==1?"ON":"OFF"):o.get(c)));
    }
    @Override public void close() { CEConfig.INSTANCE.save(); CleanEntitiesClient.resetPolicy(); client.setScreen(parent); }
    @Override public void render(DrawContext d,int mx,int my,float delta) {
        renderBackground(d);
        d.drawCenteredTextWithShadow(textRenderer,title,width/2,12,0xffffff);
        d.drawCenteredTextWithShadow(textRenderer,"Default: profiler only. F8 overlay / F9 A-B / F10 settings",width/2,28,0xcccccc);
        d.drawCenteredTextWithShadow(textRenderer,"Distance/tag/LOD changes can be visible. No tick throttling.",width/2,40,0xffcc66);
        super.render(d,mx,my,delta);
    }
}
