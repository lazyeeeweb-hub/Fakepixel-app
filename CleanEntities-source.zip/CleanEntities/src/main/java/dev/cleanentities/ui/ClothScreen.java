package dev.cleanentities.ui;

import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.config.*;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Only linked after checking Cloth is loaded. */
public final class ClothScreen {
    private ClothScreen() {}
    public static Screen create(Screen parent) {
        CEConfig c=CEConfig.INSTANCE;
        ConfigBuilder b=ConfigBuilder.create().setParentScreen(parent).setTitle(Text.literal("CleanEntities"));
        var cat=b.getOrCreateCategory(Text.literal("Rendering (visual trade-offs are opt-in)"));
        var entries=b.entryBuilder();
        for (Option o:Option.values()) {
            if (o.toggle) cat.addEntry(entries.startBooleanToggle(Text.literal(o.label),o.get(c)!=0)
                .setDefaultValue(o.get(new CEConfig())!=0).setSaveConsumer(v->o.set(c,v?1:0)).build());
            else cat.addEntry(entries.startIntSlider(Text.literal(o.label),o.get(c),o.min,o.max)
                .setDefaultValue(o.get(new CEConfig())).setSaveConsumer(v->o.set(c,v)).build());
        }
        // Presets are immediate commands or the native screen, not deferred Cloth entry values.
        cat.addEntry(entries.startTextDescription(Text.literal("Presets: /cleanentities preset off|balanced|aggressive|raid_mode. " +
            "Named/equipped stands are protected by default. Turning that off weakens custom-boss detection. " +
            "Entity tick throttling and animation freezing are deliberately not implemented.")).build());
        b.setSavingRunnable(()->{c.save();CleanEntitiesClient.resetPolicy();});
        return b.build();
    }
}
