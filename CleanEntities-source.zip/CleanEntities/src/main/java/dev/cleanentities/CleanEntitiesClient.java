package dev.cleanentities;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cleanentities.config.CEConfig;
import dev.cleanentities.profile.RenderProfiler;
import dev.cleanentities.render.*;
import dev.cleanentities.ui.SettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.*;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import org.lwjgl.glfw.GLFW;
import java.util.Locale;

public final class CleanEntitiesClient implements ClientModInitializer {
    public static final RenderProfiler PROFILER=new RenderProfiler();
    private Object previousWorld;
    private boolean previousEnabled;
    public static void chat(String s){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.inGameHud!=null)mc.inGameHud.getChatHud().addMessage(Text.literal("[CleanEntities] "+s));
    }
    public static void resetPolicy(){RenderPolicy.INSTANCE.reset();}
    @Override public void onInitializeClient() {
        CEConfig.load();
        var overlay=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cleanentities.overlay",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_F8,"key.categories.cleanentities"));
        var toggle=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cleanentities.toggle",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_F9,"key.categories.cleanentities"));
        var config=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cleanentities.config",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_F10,"key.categories.cleanentities"));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{
            if(mc.world!=previousWorld){previousWorld=mc.world;RenderPolicy.INSTANCE.worldChanged();PROFILER.reset();}
            while(overlay.wasPressed())PROFILER.overlay=!PROFILER.overlay;
            while(toggle.wasPressed()){
                CEConfig.INSTANCE.enabled=!CEConfig.INSTANCE.enabled;resetPolicy();
                chat("Render optimizations "+(CEConfig.INSTANCE.enabled?"ON":"OFF")+" (individual options unchanged; profiler independent).");
            }
            while(config.wasPressed())mc.setScreen(SettingsScreen.create(mc.currentScreen));
        });
        WorldRenderEvents.START.register(ctx->{
            if(previousEnabled!=CEConfig.INSTANCE.enabled){previousEnabled=CEConfig.INSTANCE.enabled;resetPolicy();}
            PROFILER.begin();
        });
        WorldRenderEvents.AFTER_SETUP.register(ctx->RenderPolicy.INSTANCE.prepare(ctx.frustum(),ctx.camera().getPos()));
        WorldRenderEvents.END.register(ctx->PROFILER.end());
        HudRenderCallback.EVENT.register((draw,delta)->{
            var mc=MinecraftClient.getInstance();if(!PROFILER.overlay||mc.world==null)return;
            int y=6;for(String s:PROFILER.lines()){draw.drawTextWithShadow(mc.textRenderer,s,6,y,0xffffff);y+=10;}
        });
        AttackEntityCallback.EVENT.register((player,world,hand,entity,hit)->{
            if(world.isClient&&player==MinecraftClient.getInstance().player)RenderPolicy.INSTANCE.lastAttacked=entity.getUuid();
            return ActionResult.PASS; // Observe only; never cancel, rewrite or send packets.
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,access)->dispatcher.register(literal("cleanentities")
            .executes(ctx->{chat("F8 profiler; F9 render toggle; F10 config. /cleanentities profile|config|reload|preset <name>");return 1;})
            .then(literal("profile").executes(ctx->{if(MinecraftClient.getInstance().world==null){chat("Join a world first.");return 0;}PROFILER.beginRecording();return 1;}))
            .then(literal("config").executes(ctx->{MinecraftClient mc=MinecraftClient.getInstance();mc.send(()->mc.setScreen(SettingsScreen.create(mc.currentScreen)));return 1;}))
            .then(literal("reload").executes(ctx->{CEConfig.load();resetPolicy();chat("Config reloaded.");return 1;}))
            .then(literal("preset").then(argument("name",StringArgumentType.word())
                .suggests((ctx,b)->{for(var p:CEConfig.Preset.values())b.suggest(p.name().toLowerCase(Locale.ROOT));return b.buildFuture();})
                .executes(ctx->{
                    try {var p=CEConfig.Preset.valueOf(StringArgumentType.getString(ctx,"name").toUpperCase(Locale.ROOT));
                        CEConfig.INSTANCE.preset(p);CEConfig.INSTANCE.save();resetPolicy();chat("Preset "+p+". Aggressive/Raid may visibly reduce distant detail.");return 1;
                    }catch(IllegalArgumentException ex){chat("Choose off, balanced, aggressive, raid_mode.");return 0;}
                })))));
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener(){
            @Override public Identifier getFabricId(){return new Identifier("cleanentities","caches");}
            @Override public void reload(ResourceManager manager){RenderCaches.clear();}
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc->OcclusionEngine.INSTANCE.close());
    }
}
