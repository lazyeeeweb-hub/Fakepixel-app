package dev.cleanentities.render;

import dev.cleanentities.config.CEConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.block.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import org.slf4j.LoggerFactory;

/** Main thread snapshots immutable values; worker NEVER reads world/entities/renderer/GL. */
public final class OcclusionEngine {
    public static final OcclusionEngine INSTANCE=new OcclusionEngine();
    private final ExecutorService worker=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"CleanEntities-geometry");t.setDaemon(true);return t;});
    private final AtomicReference<Batch> pending=new AtomicReference<>();
    private final Map<UUID,Certificate> certificates=new HashMap<>();
    private final Map<UUID,Long> hiddenSince=new HashMap<>();
    private Future<?> job;
    private long epoch;
    private int cursor;
    private volatile boolean failed;
    private static final boolean DELEGATE=FabricLoader.getInstance().isModLoaded("entityculling");
    private static final boolean SHADERS=FabricLoader.getInstance().isModLoaded("iris");
    // Strict whitelist avoids invisible/modded/translucent/partial block geometry.
    private static final Set<Block> BLOCKERS=Set.of(Blocks.STONE,Blocks.COBBLESTONE,Blocks.DEEPSLATE,
        Blocks.DIRT,Blocks.GRASS_BLOCK,Blocks.BEDROCK,Blocks.BRICKS,Blocks.STONE_BRICKS,Blocks.NETHERRACK);
    private record Certificate(UUID id,BlockPos block,BlockState state,OcclusionMath.Bounds bounds,long sampled) {}
    private record Query(Certificate cert,OcclusionMath.Point camera,OcclusionMath.Bounds target) {}
    private record Batch(long epoch,List<Certificate> values) {}
    public static String status(){
        if(DELEGATE)return "delegated to Entity Culling (its protections/settings are separate)";
        if(SHADERS)return "disabled with Iris (unverified shader geometry)";
        if(INSTANCE.failed)return "disabled after worker error; see log";
        return CEConfig.INSTANCE.occlusion?"single-face proof, opt-in":"off";
    }
    public boolean available(){return !DELEGATE&&!SHADERS&&!failed;}
    private static OcclusionMath.Point point(Vec3d v){return new OcclusionMath.Point(v.x,v.y,v.z);}
    private static OcclusionMath.Bounds bounds(Box b){return new OcclusionMath.Bounds(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
    // Large envelope includes vanilla body, labels and features; custom resource packs still require testing.
    private static Box envelope(Entity e){return e.getBoundingBox().expand(1.5,2.5,1.5);}
    public void update(List<Entity> candidates,Vec3d camera) {
        if(!available())return;
        Batch ready=pending.getAndSet(null);
        if(ready!=null&&ready.epoch==epoch){
            for(Certificate c:ready.values)certificates.put(c.id,c);
        }
        if(job!=null&&!job.isDone())return;
        MinecraftClient mc=MinecraftClient.getInstance();if(mc.world==null||candidates.isEmpty())return;
        long now=System.nanoTime();
        certificates.values().removeIf(c->now-c.sampled>300_000_000L);
        hiddenSince.keySet().retainAll(certificates.keySet());
        var queries=new ArrayList<Query>();
        int count=Math.min(CEConfig.INSTANCE.occlusionBudget,candidates.size());
        for(int i=0;i<count;i++) {
            Entity e=candidates.get(Math.floorMod(cursor++,candidates.size()));
            if(RenderPolicy.INSTANCE.protectedEntity(e))continue;
            var hit=mc.world.raycast(new RaycastContext(camera,e.getBoundingBox().getCenter(),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));
            if(hit.getType()!=HitResult.Type.BLOCK)continue;
            BlockPos p=hit.getBlockPos().toImmutable();BlockState state=mc.world.getBlockState(p);
            if(!BLOCKERS.contains(state.getBlock())||!state.isOpaqueFullCube(mc.world,p))continue;
            Box block=new Box(p).contract(.001); // shrink proof to avoid coplanar edge uncertainty
            Certificate c=new Certificate(e.getUuid(),p,state,bounds(block),now);
            queries.add(new Query(c,point(camera),bounds(envelope(e))));
        }
        final long generation=epoch;
        job=worker.submit(()->{
            try {
                var proven=new ArrayList<Certificate>();
                for(Query q:queries)if(OcclusionMath.hidden(q.camera,q.target,q.cert.bounds))proven.add(q.cert);
                pending.set(new Batch(generation,List.copyOf(proven)));
            }catch(Throwable error){
                failed=true;
                LoggerFactory.getLogger("CleanEntities").error("Occlusion worker failed; failing open",error);
            }
        });
    }
    public boolean hidden(Entity e,Vec3d camera) {
        if(!available())return false;
        MinecraftClient mc=MinecraftClient.getInstance();Certificate c=certificates.get(e.getUuid());long now=System.nanoTime();
        boolean valid=c!=null&&now-c.sampled<300_000_000L&&mc.world!=null
            &&mc.world.isChunkLoaded(c.block.getX()>>4,c.block.getZ()>>4)
            &&mc.world.getBlockState(c.block).equals(c.state)
            &&OcclusionMath.hidden(point(camera),bounds(envelope(e)),c.bounds);
        // Current camera/entity geometry and blocker state are revalidated EVERY use.
        if(!valid){hiddenSince.remove(e.getUuid());return false;}
        long since=hiddenSince.computeIfAbsent(e.getUuid(),id->now);
        return now-since>=CEConfig.INSTANCE.occlusionGraceMs*1_000_000L;
    }
    public void reset(){epoch++;certificates.clear();hiddenSince.clear();pending.set(null);cursor=0;}
    public void close(){reset();worker.shutdownNow();}
}
