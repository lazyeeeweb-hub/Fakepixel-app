package dev.cleanentities.render;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import dev.cleanentities.config.CEConfig;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.text.OrderedText;
import java.util.*;
import java.util.function.Supplier;

/** Render-thread caches. Keys copy mutable Text and include complete signed texture properties. */
public final class RenderCaches {
    private RenderCaches() {}
    private static <K,V> LinkedHashMap<K,V> lru() {
        return new LinkedHashMap<>(128,.75f,true) {
            @Override protected boolean removeEldestEntry(Map.Entry<K,V> e){return size()>CEConfig.INSTANCE.cacheEntries;}
        };
    }
    public record Layout(OrderedText ordered,int width) {}
    private record Layer(RenderLayer value,long created) {}
    private static final Map<Text,Layout> TEXT=lru();
    private static final Map<String,Layer> LAYERS=lru();
    public static Layout text(Text text,TextRenderer renderer) {
        Layout v=TEXT.get(text);
        if(v==null){Text copy=text.copy();OrderedText ordered=copy.asOrderedText();v=new Layout(ordered,renderer.getWidth(ordered));TEXT.put(copy,v);}
        return v;
    }
    public static RenderLayer layer(GameProfile profile,Supplier<RenderLayer> resolve) {
        // Never cache a fallback before asynchronous skin/profile completion.
        if(profile==null||!profile.getProperties().containsKey("textures"))return resolve.get();
        var props=new ArrayList<String>();
        for(Property p:profile.getProperties().get("textures")) props.add(p.getValue()+"|"+p.getSignature());
        Collections.sort(props);
        String key=profile.getId()+"/"+profile.getName()+"/"+String.join(";",props);
        long now=System.nanoTime();Layer old=LAYERS.get(key);
        if(old!=null&&now-old.created<2_000_000_000L)return old.value;
        RenderLayer value=resolve.get();LAYERS.put(key,new Layer(value,now));return value;
    }
    public static void clear(){TEXT.clear();LAYERS.clear();}
}
