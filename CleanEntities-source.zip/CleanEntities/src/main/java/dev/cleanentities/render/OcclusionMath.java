package dev.cleanentities.render;

/** Pure immutable geometry; no Minecraft/world/client access. */
public final class OcclusionMath {
    private OcclusionMath() {}
    public record Point(double x,double y,double z) {
        public double axis(int a){return a==0?x:a==1?y:z;}
    }
    public record Bounds(double minX,double minY,double minZ,double maxX,double maxY,double maxZ) {
        public double min(int a){return a==0?minX:a==1?minY:minZ;}
        public double max(int a){return a==0?maxX:a==1?maxY:maxZ;}
    }
    /**
     * Proof for ONE opaque rectangular face: target entirely beyond its backing plane,
     * all eight AABB corners project strictly inside that same face. Perspective division
     * has positive denominator throughout the AABB; linear-fractional extrema are at
     * vertices, so the whole box is in its shadow. Not the unsafe multi-block 8-ray test.
     */
    public static boolean hidden(Point camera,Bounds target,Bounds block) {
        final double margin=.015625;
        for(int a=0;a<3;a++) {
            double eye=camera.axis(a),face;
            if(eye<block.min(a)-margin&&target.min(a)>block.max(a)+margin)face=block.min(a);
            else if(eye>block.max(a)+margin&&target.max(a)<block.min(a)-margin)face=block.max(a);
            else continue;
            boolean inside=true;
            for(int bits=0;bits<8&&inside;bits++) {
                double[] v={ (bits&1)==0?target.minX:target.maxX,
                    (bits&2)==0?target.minY:target.maxY,(bits&4)==0?target.minZ:target.maxZ };
                double t=(face-eye)/(v[a]-eye);
                if(!(t>0&&t<1)){inside=false;break;}
                for(int d=0;d<3;d++)if(d!=a){
                    double projected=camera.axis(d)+t*(v[d]-camera.axis(d));
                    if(projected<=block.min(d)+margin||projected>=block.max(d)-margin){inside=false;break;}
                }
            }
            if(inside)return true;
        }
        return false;
    }
}
