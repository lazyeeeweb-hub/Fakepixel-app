package dev.cleanentities.render;

import dev.cleanentities.CleanEntitiesClient;
import dev.cleanentities.config.CEConfig;
import dev.cleanentities.mixin.*;
import dev.cleanentities.profile.RenderProfiler.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.entity.*;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.EnderDragonPart;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.*;
import java.util.*;

public final class RenderPolicy {
    public static final RenderPolicy INSTANCE=new RenderPolicy();
    public enum Gate { ARMOR, TAG, BACKGROUND, FEATURE, HAT }
    private final Map<UUID,EnumMap<Gate,Boolean>> far=new HashMap<>();
    private final Set<UUID> nearest=new HashSet<>(), labels=new HashSet<>();
    private final List<Entity> anchors=new ArrayList<>();
    private final Set<UUID> live=new HashSet<>();
    public UUID lastAttacked;
    public Entity currentEntity;
    private Vec3d camera=Vec3d.ZERO;
    private Frustum frustum;
    private double crowdScale=1;
    private long lastPlan;
    private boolean planned;
    public void prepare(Frustum frustum,Vec3d camera) {
        long timer=CleanEntitiesClient.PROFILER.start();
        try {
            this.frustum=frustum;this.camera=camera;planned=false;
            nearest.clear();labels.clear();anchors.clear();live.clear();
            MinecraftClient mc=MinecraftClient.getInstance();
            if(mc.world==null||frustum==null)return;
            CEConfig c=CEConfig.INSTANCE;
            if(!c.enabled&&!CleanEntitiesClient.PROFILER.active())return;
            var candidates=new ArrayList<Entity>();
            // Vanilla shouldRender applies its own distance/frustum policy; do not reveal extra entities.
            var dispatcher=mc.getEntityRenderDispatcher();
            for(Entity e:mc.world.getEntities()) {
                live.add(e.getUuid());
                if(dispatcher.shouldRender(e,frustum,camera.x,camera.y,camera.z)) {
                    candidates.add(e);CleanEntitiesClient.PROFILER.candidate(e);
                }
                if(isAnchor(e))anchors.add(e);
            }
            far.keySet().retainAll(live);
            candidates.sort(Comparator.comparingDouble((Entity e)->distanceSquared(e)).thenComparingInt(Entity::getId));
            // Invisible empty placeholders do not consume the full-quality quota.
            int kept=0;
            for(Entity e:candidates)if(!emptyStand(e)&&kept<c.nearestFull){nearest.add(e.getUuid());kept++;}
            long now=System.nanoTime();
            double dt=lastPlan==0?0.016:Math.min(.1,(now-lastPlan)/1e9);lastPlan=now;
            double target=c.enabled&&c.crowd&&candidates.size()>c.crowdThreshold
                ?Math.max(c.crowdMinimumPercent/100.0,Math.sqrt(c.crowdThreshold/(double)candidates.size())):1;
            crowdScale+=(target-crowdScale)*(1-Math.exp(-dt/1.0));
            int admitted=0;
            for(Entity e:candidates) {
                if(!((EntityRendererAccessor)dispatcher.getRenderer(e)).ce$hasLabel(e))continue;
                if(protectedEntity(e)){labels.add(e.getUuid());continue;}
                if(c.enabled&&c.nametags&&(beyond(e,Gate.TAG,c.tagDistance)||!labelOnScreen(e)))continue;
                if(admitted<c.tagCap){labels.add(e.getUuid());admitted++;}
            }
            planned=true;
            if(c.enabled&&c.occlusion)OcclusionEngine.INSTANCE.update(candidates,camera);
        }finally{CleanEntitiesClient.PROFILER.add(Category.PLANNING,timer);}
    }
    private boolean isAnchor(Entity e) {
        MinecraftClient mc=MinecraftClient.getInstance();
        return e instanceof PlayerEntity||e instanceof WitherEntity||e instanceof EnderDragonEntity||e instanceof EnderDragonPart
            ||e==mc.targetedEntity||e.getUuid().equals(lastAttacked)||isCustomBoss(e);
    }
    private boolean isCustomBoss(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        if(c.bossEntityTypes.contains(Registries.ENTITY_TYPE.getId(e.getType()).toString()))return true;
        for(String tag:c.bossScoreboardTags)if(e.getCommandTags().contains(tag))return true;
        if(!e.hasCustomName())return false;
        String name=e.getName().getString().toLowerCase(Locale.ROOT);
        for(String needle:c.bossNameContains)if(!needle.isBlank()&&name.contains(needle.toLowerCase(Locale.ROOT)))return true;
        var bars=((BossBarHudAccessor)MinecraftClient.getInstance().inGameHud.getBossBarHud()).ce$bossBars();
        for(var bar:bars.values()) {
            String title=bar.getName().getString().toLowerCase(Locale.ROOT);
            if(name.length()>=4&&(title.contains(name)||name.contains(title)&&title.length()>=4))return true;
        }
        return false;
    }
    public boolean protectedEntity(Entity e) {
        if(e==null)return true;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(e instanceof PlayerEntity||e instanceof WitherEntity||e instanceof EnderDragonEntity||e instanceof EnderDragonPart
            ||e==mc.targetedEntity||e.getUuid().equals(lastAttacked)||nearest.contains(e.getUuid())||isCustomBoss(e))return true;
        // Distance to both player AND camera (third person/spectator do not weaken the 8-block rule).
        if(e.squaredDistanceTo(camera)<=64||mc.player==null||e.squaredDistanceTo(mc.player)<=64)return true;
        if(e instanceof ArmorStandEntity a&&CEConfig.INSTANCE.protectAmbiguousStands&&(a.hasCustomName()||equipped(a)))return true;
        // Fakepixel models/holograms can be separate stands around a protected anchor.
        if(e instanceof ArmorStandEntity)for(Entity anchor:anchors)if(e.squaredDistanceTo(anchor)<=16)return true;
        return false;
    }
    public static boolean equipped(ArmorStandEntity a) {
        for(EquipmentSlot s:EquipmentSlot.values())if(!a.getEquippedStack(s).isEmpty())return true;
        return false;
    }
    private static boolean emptyStand(Entity e) {
        return e instanceof ArmorStandEntity a&&a.isInvisible()&&!a.hasCustomName()&&!equipped(a);
    }
    public boolean skipEntity(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        if(!c.enabled||!planned||protectedEntity(e))return false;
        if(e.isGlowing()||e.hasPassengers()||e.hasVehicle())return false; // Do not remove outlines or mounted assemblies.
        if(c.armorCulling&&e instanceof ArmorStandEntity) {
            if(emptyStand(e)&&!e.isOnFire())return true;
            if(beyond(e,Gate.ARMOR,c.armorDistance))return true;
        }
        return c.occlusion&&OcclusionEngine.INSTANCE.hidden(e,camera);
    }
    public boolean allowLabel(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        if(!c.enabled||!c.nametags||!planned||protectedEntity(e))return true;
        if(!labels.contains(e.getUuid())||beyond(e,Gate.TAG,c.tagDistance)||!labelOnScreen(e))return false;
        return !c.occlusion||!OcclusionEngine.INSTANCE.hidden(e,camera);
    }
    private boolean labelOnScreen(Entity e) {
        if(frustum==null)return true;
        MinecraftClient mc=MinecraftClient.getInstance();
        int pixels=CEConfig.INSTANCE.textCache?RenderCaches.text(e.getDisplayName(),mc.textRenderer).width():mc.textRenderer.getWidth(e.getDisplayName());
        double half=Math.max(1,pixels*.0125+0.25);
        double y=e.getY()+e.getHeight()+.5;
        return frustum.isVisible(new Box(e.getX()-half,y-.75,e.getZ()-half,e.getX()+half,y+.75,e.getZ()+half));
    }
    public boolean skipBackground(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        return c.enabled&&c.nametags&&!protectedEntity(e)&&beyond(e,Gate.BACKGROUND,c.tagBackgroundDistance);
    }
    public boolean featureLod(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        return c.enabled&&c.featureLod&&planned&&!protectedEntity(e)&&!e.isGlowing()&&beyond(e,Gate.FEATURE,c.lodDistance);
    }
    public boolean shadowLod(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        return c.enabled&&c.shadows&&planned&&!protectedEntity(e)&&beyond(e,Gate.FEATURE,c.lodDistance);
    }
    public boolean skullHatLod(Entity e) {
        CEConfig c=CEConfig.INSTANCE;
        return c.enabled&&c.skullHat&&planned&&e instanceof ArmorStandEntity&&!protectedEntity(e)&&beyond(e,Gate.HAT,c.skullHatDistance);
    }
    private double distanceSquared(Entity e){return e.squaredDistanceTo(camera);}
    private boolean beyond(Entity e,Gate gate,double configuredDistance) {
        CEConfig c=CEConfig.INSTANCE;
        double limit=configuredDistance*(c.crowd?crowdScale:1),h=c.hysteresisBlocks;
        EnumMap<Gate,Boolean> state=far.computeIfAbsent(e.getUuid(),k->new EnumMap<>(Gate.class));
        boolean old=state.getOrDefault(gate,false);
        double threshold=Math.max(8,limit+(old?-h:h));
        boolean result=distanceSquared(e)>threshold*threshold;
        state.put(gate,result);return result;
    }
    public void reset(){far.clear();nearest.clear();labels.clear();anchors.clear();live.clear();currentEntity=null;planned=false;crowdScale=1;lastPlan=0;OcclusionEngine.INSTANCE.reset();RenderCaches.clear();}
    public void worldChanged(){reset();lastAttacked=null;}
}
