package dev.cleanentities.profile;

import dev.cleanentities.CleanEntitiesClient;
import net.minecraft.entity.*;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import java.util.*;

/** Render-thread only. Timings are nested inclusive CPU submission times, NOT GPU times. */
public final class RenderProfiler {
    public enum Category { ENTITY, NAMETAG, HEAD, FEATURE, PLANNING }
    private final long[] nanos = new long[Category.values().length];
    private final int[] candidates = new int[5], submitted = new int[5];
    private int heads, names, tags, culled;
    public boolean overlay;
    private long lastFrame, interval;
    private boolean recording, frameActive, measured;
    private long recordingStart;
    private final List<Sample> samples = new ArrayList<>();
    private Sample latest = new Sample(new long[5],new int[5],new int[5],0,0,0,0,0);
    public record Sample(long[] ns,int[] candidates,int[] submitted,int heads,int names,int tags,int culled,long interval) {}
    public boolean active() { return frameActive && measured; }
    public long start() { return active() ? System.nanoTime() : 0; }
    public void add(Category c,long start) { if (start!=0) nanos[c.ordinal()]+=System.nanoTime()-start; }
    public void begin() {
        long now=System.nanoTime(); interval=lastFrame==0?0:now-lastFrame; lastFrame=now;
        frameActive=true; measured=overlay||recording;
        Arrays.fill(nanos,0);Arrays.fill(candidates,0);Arrays.fill(submitted,0);
        heads=names=tags=culled=0;
    }
    private static int type(Entity e) {
        return e instanceof ArmorStandEntity?0:e instanceof PlayerEntity?2:e instanceof MobEntity?1:e instanceof ItemEntity?3:4;
    }
    public void candidate(Entity e) {
        if (!active()) return;
        candidates[type(e)]++;
        if(e instanceof ArmorStandEntity a) {
            if(a.getEquippedStack(EquipmentSlot.HEAD).isOf(Items.PLAYER_HEAD))heads++;
            if(a.hasCustomName())names++;
        }
    }
    public void submitted(Entity e){if(active())submitted[type(e)]++;}
    public void tag(){if(active())tags++;}
    public void culled(){if(active())culled++;}
    public void beginRecording() {
        if(recording){CleanEntitiesClient.chat("A recording is already running.");return;}
        recording=true;recordingStart=System.nanoTime();samples.clear();
        CleanEntitiesClient.chat("Recording 10 seconds. Keep camera/settings fixed; F8 may be off.");
    }
    public void end() {
        if(active()) {
            latest=new Sample(nanos.clone(),candidates.clone(),submitted.clone(),heads,names,tags,culled,interval);
            if(recording) samples.add(latest);
        }
        frameActive=false;
        if(recording && System.nanoTime()-recordingStart>=10_000_000_000L) finish();
    }
    public void reset() {
        if(recording)CleanEntitiesClient.chat("Profile aborted: world changed. No mixed-world summary.");
        recording=false;frameActive=false;lastFrame=0;samples.clear();
    }
    public List<String> lines() {
        Sample s=latest;
        var out=new ArrayList<String>();
        out.add("CleanEntities | changes "+(dev.cleanentities.config.CEConfig.INSTANCE.enabled?"ON":"OFF")+(recording?" | recording":""));
        out.add("Candidates stand/mob/player/item/other: "+Arrays.toString(s.candidates));
        out.add("Submitted stand/mob/player/item/other: "+Arrays.toString(s.submitted));
        out.add("Stands: player heads "+s.heads+" | custom names "+s.names+" | tags submitted "+s.tags+" | culled "+s.culled);
        for(Category c:Category.values())out.add(String.format(Locale.ROOT,"%s %.3f ms",c,s.ns[c.ordinal()]/1e6));
        out.add("CPU inclusive: HEAD is inside FEATURE; tags/features inside ENTITY. Do NOT add.");
        out.add("Occlusion: "+dev.cleanentities.render.OcclusionEngine.status());
        return out;
    }
    private void finish() {
        recording=false;
        if(samples.isEmpty()){CleanEntitiesClient.chat("No rendered world frames recorded.");return;}
        int n=samples.size();
        double elapsed=(System.nanoTime()-recordingStart)/1e9;
        CleanEntitiesClient.chat(String.format(Locale.ROOT,"%.2fs / %d frames / %.1f observed FPS",elapsed,n,n/elapsed));
        long[] intervals=samples.stream().mapToLong(Sample::interval).filter(v->v>0).sorted().toArray();
        if(intervals.length>0)CleanEntitiesClient.chat(String.format(Locale.ROOT,"Frame intervals median %.2f / p95 %.2f / p99 %.2f ms",pct(intervals,.5)/1e6,pct(intervals,.95)/1e6,pct(intervals,.99)/1e6));
        long[] totals=new long[5];
        double[] avgCounts=new double[5];double avgHeads=0,avgNames=0,avgTags=0,avgCulled=0;
        for(Sample s:samples){
            for(int i=0;i<5;i++){totals[i]+=s.ns[i];avgCounts[i]+=s.candidates[i]/(double)n;}
            avgHeads+=s.heads/(double)n;avgNames+=s.names/(double)n;avgTags+=s.tags/(double)n;avgCulled+=s.culled/(double)n;
        }
        for(Category c:Category.values()){
            int i=c.ordinal();long[] v=samples.stream().mapToLong(s->s.ns[i]).sorted().toArray();
            CleanEntitiesClient.chat(String.format(Locale.ROOT,"%s avg %.3f / p95 %.3f ms per frame",c,totals[i]/(n*1e6),pct(v,.95)/1e6));
        }
        CleanEntitiesClient.chat("Mean candidates [stand,mob,player,item,other]: "+Arrays.toString(Arrays.stream(avgCounts).map(v->Math.round(v*10)/10.0).toArray()));
        CleanEntitiesClient.chat(String.format(Locale.ROOT,"Mean player-head stands %.1f; named stands %.1f; tags %.1f; culled %.1f",avgHeads,avgNames,avgTags,avgCulled));
        long head=totals[Category.HEAD.ordinal()],feature=totals[Category.FEATURE.ordinal()],tag=totals[Category.NAMETAG.ordinal()];
        long otherFeatures=Math.max(0,feature-head);
        String winner=head>=otherFeatures&&head>=tag?"worn skull/head features":otherFeatures>=tag?"other feature renderers":"nametags";
        CleanEntitiesClient.chat("Largest measured child bucket: "+winner+". ENTITY includes these; GPU, base-model and driver work are not separately measured.");
        samples.clear();
    }
    private static long pct(long[] v,double p){return v[Math.max(0,(int)Math.ceil(p*v.length)-1)];}
}
