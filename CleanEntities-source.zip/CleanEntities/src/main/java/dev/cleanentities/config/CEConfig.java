package dev.cleanentities.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;

public final class CEConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("cleanentities.json");
    public static CEConfig INSTANCE = new CEConfig();
    public boolean enabled = false; // Phase 0 first: unmodified rendering by default.
    public boolean armorCulling = false, nametags = false, textCache = false;
    public boolean skullCache = false, skullHat = false, featureLod = false;
    public boolean shadows = false, crowd = false, occlusion = false;
    // These remain true in ALL presets. Server-defined boss stand identity is not reliable.
    public boolean protectAmbiguousStands = true;
    public int armorDistance = 48, tagDistance = 24, tagCap = 40, tagBackgroundDistance = 16;
    public int lodDistance = 32, skullHatDistance = 32, crowdThreshold = 80, nearestFull = 25;
    public int crowdMinimumPercent = 55, hysteresisBlocks = 4, occlusionGraceMs = 250;
    public int occlusionBudget = 8, cacheEntries = 1024;
    public List<String> bossNameContains = new ArrayList<>(List.of("boss", "slayer", "goblin king"));
    public List<String> bossEntityTypes = new ArrayList<>();
    public List<String> bossScoreboardTags = new ArrayList<>();

    public enum Preset { OFF, BALANCED, AGGRESSIVE, RAID_MODE }
    public void preset(Preset p) {
        enabled = p != Preset.OFF;
        armorCulling = textCache = skullCache = enabled;
        nametags = skullHat = featureLod = shadows = crowd = occlusion = false;
        armorDistance = 48; tagDistance = 24; tagCap = 40; tagBackgroundDistance = 16;
        lodDistance = skullHatDistance = 32; crowdThreshold = 80; nearestFull = 25;
        crowdMinimumPercent = 55; hysteresisBlocks = 4; occlusionGraceMs = 250; occlusionBudget = 8;
        protectAmbiguousStands = true;
        if (p == Preset.AGGRESSIVE || p == Preset.RAID_MODE) {
            nametags = skullHat = featureLod = shadows = crowd = true;
        }
        if (p == Preset.RAID_MODE) {
            armorDistance = 40; tagDistance = 20; tagCap = 30; lodDistance = 28;
            crowdMinimumPercent = 45;
        }
        // Occlusion must be separately opted into after a local visual test.
        sanitize();
    }
    public void sanitize() {
        for (Option o : Option.values()) o.clamp(this);
        nearestFull = Math.max(25, nearestFull);
        if (bossNameContains == null) bossNameContains = new ArrayList<>();
        if (bossEntityTypes == null) bossEntityTypes = new ArrayList<>();
        if (bossScoreboardTags == null) bossScoreboardTags = new ArrayList<>();
        bossNameContains.removeIf(Objects::isNull);
        bossEntityTypes.removeIf(Objects::isNull);
        bossScoreboardTags.removeIf(Objects::isNull);
    }
    public static void load() {
        try {
            if (Files.exists(PATH)) {
                CEConfig c = GSON.fromJson(Files.readString(PATH), CEConfig.class);
                if (c != null) INSTANCE = c;
            }
            INSTANCE.sanitize();
        } catch (Exception ex) {
            LoggerFactory.getLogger("CleanEntities").error("Cannot load {}; using safe defaults (bad file left untouched)", PATH, ex);
            INSTANCE = new CEConfig();
        }
    }
    public void save() {
        sanitize();
        try {
            Files.createDirectories(PATH.getParent());
            Path temp = PATH.resolveSibling("cleanentities.json.tmp");
            Files.writeString(temp, GSON.toJson(this));
            try { Files.move(temp, PATH, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, PATH, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            LoggerFactory.getLogger("CleanEntities").error("Cannot save {}", PATH, ex);
            throw new IllegalStateException("CleanEntities config could not be saved: " + PATH, ex);
        }
    }
}
