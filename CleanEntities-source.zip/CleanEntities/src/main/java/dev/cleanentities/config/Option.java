package dev.cleanentities.config;

import java.lang.reflect.Field;

/** Single option catalogue shared by native and optional Cloth screens. */
public enum Option {
    ENABLED("enabled", "Enable rendering changes"),
    ARMOR("armorCulling", "Armor stand culling"),
    ARMOR_DISTANCE("armorDistance", "Armor stand distance", 16, 128),
    TAGS("nametags", "Nametag budgets (visual trade-off)"),
    TAG_DISTANCE("tagDistance", "Nametag distance", 8, 96),
    TAG_CAP("tagCap", "Unprotected nametags / frame", 1, 200),
    TAG_BG("tagBackgroundDistance", "Background box distance", 8, 96),
    TEXT("textCache", "Cache tag ordering and widths"),
    SKULL("skullCache", "Cache resolved skull render layers"),
    CACHE_SIZE("cacheEntries", "Maximum entries per cache", 64, 4096),
    HAT("skullHat", "Distant skull hat LOD (visual trade-off)"),
    HAT_DISTANCE("skullHatDistance", "Skull hat distance", 16, 96),
    FEATURES("featureLod", "Distant feature LOD (visual trade-off)"),
    LOD_DISTANCE("lodDistance", "Feature/shadow LOD distance", 16, 96),
    SHADOWS("shadows", "Distant shadow LOD (visual trade-off)"),
    CROWD("crowd", "Adaptive crowd distances"),
    CROWD_N("crowdThreshold", "Crowd threshold", 30, 300),
    NEAREST("nearestFull", "Nearest full-quality entities", 25, 100),
    CROWD_MIN("crowdMinimumPercent", "Minimum crowd distance %", 25, 100),
    HYSTERESIS("hysteresisBlocks", "Distance hysteresis blocks", 1, 16),
    OCCLUSION("occlusion", "Experimental conservative occlusion"),
    OCC_GRACE("occlusionGraceMs", "Continuous hidden grace ms", 100, 2000),
    OCC_BUDGET("occlusionBudget", "Occlusion snapshots / frame", 1, 32),
    AMBIGUOUS("protectAmbiguousStands", "Protect named/equipped stands (recommended)");
    public final String field, label;
    public final boolean toggle;
    public final int min, max;
    Option(String f, String l) { field=f; label=l; toggle=true; min=0; max=1; }
    Option(String f, String l, int a, int b) { field=f; label=l; toggle=false; min=a; max=b; }
    private Field reflected() {
        try { return CEConfig.class.getField(field); }
        catch (NoSuchFieldException ex) { throw new AssertionError(ex); }
    }
    public int get(CEConfig c) {
        try { return toggle ? (reflected().getBoolean(c) ? 1 : 0) : reflected().getInt(c); }
        catch (IllegalAccessException ex) { throw new AssertionError(ex); }
    }
    public void set(CEConfig c, int value) {
        try {
            value = Math.max(min, Math.min(max, value));
            if (toggle) reflected().setBoolean(c, value != 0); else reflected().setInt(c, value);
        } catch (IllegalAccessException ex) { throw new AssertionError(ex); }
    }
    public void clamp(CEConfig c) { set(c, get(c)); }
}
