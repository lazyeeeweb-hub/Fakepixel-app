# CleanEntities — Fabric 1.20.1

Client-only Java 17 / Yarn `1.20.1+build.10` source project. Phase 0 is the default: **no render changes until enabled**. It measures CPU render submission costs before suggesting trade-offs. This is not a benchmark result or a promise of FPS gains.

## Important scope and honest limitations

The original requirements contain conflicts. Removing distant geometry, outer skull layers, shadows or labels cannot be pixel-identical to vanilla. Hysteresis prevents repeated threshold flicker; **it does not make a distance cut invisible**. No alpha fade is injected into arbitrary vanilla/custom/shader render layers, because doing that safely across renderers is not generic. If absolutely unchanged appearance is required, stay with Off/profiler or the conservative Balanced preset and leave all visual LOD options disabled.

**Entity ticks are never throttled.** Client entity ticking maintains interpolation, passengers, effects, sounds and other state. Cancelling ticks is not render-only. Limb-animation freezing is also omitted: freezing pose updates changes appearance, and does not reliably save skinning cost. There are no fake toggles for these unsupported functions.

A server can implement a boss using an ordinary armor stand with no standard boss flag or entity-to-bossbar association. CleanEntities protects vanilla bosses; configured type/name/scoreboard-tag matches; matching bossbar names; and, by default, **all named/equipped armor stands**. All presets retain that last safety setting. This deliberately limits gains on armor-stand mobs/holograms. Disabling `protectAmbiguousStands` permits more stand/tag/hat LOD but weakens custom-boss safety: do not disable it when an absolute boss guarantee matters. Additional unnamed custom mob bosses cannot be identified generically either. Server-specific identification needs verified server conventions.

No client can certify that a server considers a mod allowed. Check Fakepixel's current rules. This project does not send/modify packets, change attacks, reveal hidden entities, track undisclosed entities or alter client entity simulation. The attack callback only remembers the entity the player attempted to attack and returns PASS.

## Build and install

1. Install a Java 17 JDK and Gradle **8.6**. The project pins Loom 1.6.12, Fabric Loader 0.14.25 (a 0.14+ release), Fabric API 0.92.2+1.20.1, and includes MixinExtras 0.3.5.
2. In the project root run `gradle build` and `gradle geometryTest`.
3. Install the remapped `build/libs/cleanentities-0.1.0.jar`, NOT the sources/dev jar, into a Minecraft 1.20.1 Fabric client with Loader >=0.14.25 and Fabric API for 1.20.1.
4. Optional: Mod Menu 7.2.2 and Cloth Config 11.1.118. Without either, F10 opens the built-in screen. With Cloth, its screen is used; with Mod Menu, a Configure button is registered. These dependencies are compile-only, not bundled.
5. Gradle wrapper binaries are not vendored. Optionally run `gradle wrapper --gradle-version 8.6` locally, then use `./gradlew` (Windows `gradlew.bat`). A Gradle/Loom build and real client launch are required before treating any source archive as installable.

The running config lives at `.minecraft/config/cleanentities.json`. Saving a settings screen or applying a preset writes it atomically where supported. `config/cleanentities.example.json` supplies every initial field. Invalid JSON is logged and safe defaults are loaded; the bad file is left intact until a later explicit save. Numeric ranges are clamped. Boss matching lists are JSON-only; rendering switches and numeric budgets are available in both screens. F9 is a temporary A/B toggle unless the config is subsequently saved.

## Controls / commands

| Control | Action |
|---|---|
| F8 | Toggle debug overlay; independent of optimizations |
| F9 | Enable/disable rendering changes immediately, retaining individual option choices |
| F10 | Settings; rebind all keys in Minecraft Controls if needed |
| `/cleanentities profile` | Record approximately 10 seconds of rendered world frames, then chat summary |
| `/cleanentities config` | Open settings |
| `/cleanentities reload` | Reload JSON and clear policy/caches |
| `/cleanentities preset off` | Disable changes |
| `/cleanentities preset balanced` | Enable empty/distant eligible stand culling plus text/skull caches |
| `/cleanentities preset aggressive` | Also enable tag/feature/hat/shadow LOD and crowd scaling |
| `/cleanentities preset raid_mode` | Aggressive; stand 40, tag 20, tag cap 30, feature 28 blocks |

A fresh install has all optimization switches OFF. F9 alone on that configuration intentionally does not select optimizations: choose Balanced first, then use F9 for A/B. Native screen preset buttons apply immediately. On Cloth, presets are available through the commands, not a deferred enum setting that would overwrite edited sliders.

## Phase 0: reading the measurements

Counters reset at each world-render START. Planning occurs AFTER_SETUP, when the frustum is available. END snapshots the frame; the HUD displays the most recently completed world frame.

* **Candidates [stand, mob, player, item, other]**: loaded client entities that pass vanilla dispatcher's distance/frustum test, before CleanEntities' skip decision. These are not the total server population. Player is counted before generic mob; item means dropped ItemEntity; other includes projectiles and miscellaneous entities. Invisible candidates can still have a head or tag.
* **Submitted**: calls forwarded to EntityRenderDispatcher through WorldRenderer's normal entity path; other mods may still cancel downstream. This is not a GPU visibility count.
* **Player-head stands / named stands**: candidate armor stands wearing a PLAYER_HEAD and candidate stands with custom names. Counts can overlap.
* **Tags submitted**: vanilla base-label width/layout submissions after vanilla's own distance check; counted once even if the label has two draw passes. This is not a count of individual glyphs or guaranteed visible pixels. Custom mods with independent label renderers are not covered.
* **ENTITY**: dispatcher entity call, including model, feature, tag and shadow CPU work.
* **NAMETAG**: base `renderLabelIfPresent` CPU work. Tiny rejected vanilla distance checks can contribute even when no tag submits.
* **FEATURE**: all forwarded feature-renderer calls.
* **HEAD**: HeadFeatureRenderer calls (worn heads/skulls, including resolution work); a **subset of FEATURE**, not every placed skull block/item GUI render.
* **PLANNING**: CleanEntities candidate enumeration, nearest sorting, label planning, main-thread occlusion snapshots and policy maintenance.

Times use System.nanoTime around calls. These are **inclusive CPU submission times, not GPU time**. Do not add ENTITY + FEATURE + HEAD + NAMETAG. HEAD is already in FEATURE; FEATURE and NAMETAG are already in ENTITY. Other-feature cost is approximately FEATURE minus HEAD. The summary compares HEAD / other features / tags, and prints averages and p95; it does not falsely call ENTITY's inclusive total a separate competing cost category. Vanilla already caches some text ordering and skin lookups, so the added caches may provide little gain: measure.

The 10-second run also prints median/p95/p99 START-to-START world-frame intervals and mean counts. Intervals include normal frame scheduling, vsync/CPU/GPU stalls and presentation delay; they are not a GPU timer or a full PresentMon capture. Disconnect/world changes abort rather than mix worlds. If no world frames render, the command cannot produce a meaningful world-frame sample. Keep profiling conditions identical between A/B runs; timers and planning themselves add overhead. F8 off and no recording means no System.nanoTime timing in the category wrappers.

## Rendering policy

Protection is checked before **every** CleanEntities cull/visual downgrade: crosshair target; remembered last attack target; entities within 8 blocks of either player or camera; players; bosses as detectable above; nearest >=25 eligible render candidates. Nearby armor stands within 4 blocks of protected player/target/boss anchors are also protected for multi-entity server models. Empty invisible nameless unequipped placeholder stands do not consume the nearest quota. The player's own first-person held-item renderer is never targeted. Protection bypasses tag caps, so more than 40 total labels can legitimately be drawn. Vanilla or another mod may still cull a protected entity; this mod does not override their decisions or reveal behind-wall information.

1. **Armor stands**: skip invisible, nameless, equipment-free stands only if not protected, burning, glowing, mounted or carrying passengers. Eligible other stands get a configurable 48-block distance gate. With +/-4-block hysteresis they leave at >52 and reappear at <=44, before crowd scaling. Distance culling of visible stands is a visual trade-off, not free.
2. **Tags**: vanilla-eligible candidates are sorted by camera distance (entity id breaks ties), and up to 40 unprotected candidates are admitted, plus all protected labels. Distance default 24; background omitted beyond 16; generous label AABB frustum check. Distance hysteresis and crowd scaling apply. Occlusion applies only if the separate occlusion switch is on. Strict nearest-first membership can still change in a moving crowd; there is no promise that a hard cap is visually invisible. A vanilla label that later fails vanilla's own final check can leave an unused slot; the budget is an upper bound, not a fill guarantee.
3. **Text cache**: bounded access-order LRU of copied formatted Text -> OrderedText + measured width. Style, font and sibling text are part of Text equality; numbers that change get new keys; resource reload/world changes clear caches. It caches ordering/width, **not glyph meshes or framebuffer images**. Unusual animated/custom font mods need testing.
4. **Skulls**: head-feature-only bounded cache for texture-bearing player profiles; full signed texture properties + UUID + name in the key, 2-second revalidation and resource/world clearing. Missing/unresolved profiles bypass caching. Vanilla SkinProvider still owns actual texture loading/resolution: this does not claim zero resolutions forever. Hat LOD checks for the model's real `hat` child, changes visibility only during one armor-stand skull call, then restores it in finally. Models without that child fail open. It never affects a player's worn head or first-person held item.
5. **LOD**: beyond 32 +/- hysteresis blocks, skip eligible non-head features and/or shadows. Never drop the entire head feature, since the skull may BE the server mob. No limb or tick cancellation. Cosmetics/armor/held items can visibly disappear on unprotected distant entities; disabled in Balanced.
6. **Crowd**: above 80 vanilla render candidates, target scale `max(minimumPercent/100, sqrt(80/count))`, smoothed with a ~1-second exponential response; nearest full-quality entities bypass it. This scales distances, not the tag cap. Large player crowds count toward pressure but players remain protected.
7. **Occlusion**: opt-in, conservative and intentionally low-yield. Main thread raycasts at most 8 candidate centers per frame to find a whitelisted full opaque vanilla block; snapshots only immutable geometry/state. One worker proves that an entire expanded entity AABB projects inside **one** opaque face. It does not infer full occlusion from eight rays hitting different blocks. Render thread revalidates the current camera, current expanded box, chunk and block state before every use; stale/invalid/missing results render immediately. 250ms continuous hidden grace before culling. Fails open after worker error, at block edges or unsupported blocks. A 1.5-horizontal / 2.5-vertical expansion is conservative for normal models but not a proof for arbitrarily oversized custom resource-pack geometry. Remove the optimization if custom models exceed that envelope. This is not a replacement for Entity Culling's mature implementation and cannot promise all modpacks are pop-in-free.

## Mixin targets and why

No @Overwrite or @Redirect is used. Chained MixinExtras @WrapOperation hooks call the original operation, with try/finally around timing and temporary model state. Compared to separate HEAD/RETURN injections, this avoids leaking timing/model state on exceptions and permits wrappers to compose. Accessors/invokers only expose existing render data. Essential invocation hooks fail loudly (defaultRequire=1) instead of silently producing misleading profiling.

| Mixin | Exact owning method / call | Purpose |
|---|---|---|
| WorldRendererMixin | WorldRenderer.renderEntity -> EntityRenderDispatcher.render(Entity,DDD,FF,MatrixStack,VertexConsumerProvider,int) | Per-entity protected cull decision, submitted counts, inclusive ENTITY timing, scoped current entity |
| LivingEntityRendererMixin | LivingEntityRenderer.render(LivingEntity,FF,MatrixStack,VertexConsumerProvider,int) -> FeatureRenderer.render(MatrixStack,VertexConsumerProvider,int,**Entity**,FFFFFF) | FEATURE and HEAD timing; optional non-head feature LOD. The call's erased type is Entity, not LivingEntity |
| EntityRendererMixin | EntityRenderer.render -> renderLabelIfPresent; inside label method TextRenderer.getWidth(StringVisitable) and TextRenderer.draw(Text,...) | Budget labels, count actual base label layout submissions, time labels, bounded layout/width cache, background removal |
| DispatcherMixin | EntityRenderDispatcher.render -> static renderShadow(MatrixStack,VertexConsumerProvider,Entity,FF,WorldView,F) | Per-entity shadow LOD without toggling global renderer state |
| HeadFeatureMixin | HeadFeatureRenderer.render(MatrixStack,VertexConsumerProvider,int,LivingEntity,FFFFFF) -> SkullBlockEntityRenderer.getRenderLayer / renderSkull | Scoped layer cache and reversible hat-only LOD; no global skull modification |
| SkullModelAccessor | SkullEntityModel.root field | Locate actual optional hat part without guessing a nonexistent player-head model class |
| EntityRendererAccessor | EntityRenderer.hasLabel(Entity) invoker | Preselect only vanilla-eligible labels, not arbitrary hidden metadata |
| BossBarHudAccessor | BossBarHud.bossBars field | Read existing client bossbar names for conservative protection; no packet hooks |

Yarn API reference: https://maven.fabricmc.net/docs/yarn-1.20.1+build.10/ . See especially WorldRenderer, EntityRenderer, FeatureRenderer, HeadFeatureRenderer, EntityRenderDispatcher, TextRenderer and SkullEntityModel. Mapping names are deliberately pinned, not claimed to support every Minecraft version.

## Compatibility policy, not a certification

Sodium/Iris/ImmediatelyFast/Entity Culling are optional, not required dependencies. No server mixins, terrain pipeline replacements, GL queries or global renderer switches are used. Wrappers compose where the other mods preserve the targeted calls. Different mod versions can replace those calls, and only an actual launch matrix verifies compatibility. When Entity Culling is loaded, CleanEntities' own occlusion engine is disabled/delegated; Entity Culling's separate configuration and exemptions still apply. Own occlusion is also disabled whenever Iris is installed, even with shaders off. This sacrifices performance rather than assume shader geometry/depth behavior. Text optimization should be individually disabled if ImmediatelyFast/custom-font testing shows differences. A failed required injection is an incompatibility to fix, not something to hide with require=0.

## Project structure

```
CleanEntities/
  settings.gradle, build.gradle, gradle.properties, LICENSE, README.md
  config/cleanentities.example.json
  src/main/resources/
    fabric.mod.json
    cleanentities.mixins.json
    assets/cleanentities/lang/en_us.json
  src/main/java/dev/cleanentities/
    CleanEntitiesClient.java
    config/{CEConfig,Option}.java
    profile/RenderProfiler.java
    render/{RenderPolicy,RenderCaches,OcclusionEngine,OcclusionMath}.java
    ui/{SettingsScreen,ClothScreen,ModMenuIntegration}.java
    mixin/{WorldRendererMixin,LivingEntityRendererMixin,EntityRendererMixin,
           DispatcherMixin,HeadFeatureMixin,SkullModelAccessor,
           EntityRendererAccessor,BossBarHudAccessor}.java
  src/test/java/dev/cleanentities/render/OcclusionMathTest.java
```

## Testing checklist — finish here before trusting a raid result

### Build / load / safety

- [ ] `gradle build` on Java 17; verify refmap and nested MixinExtras in remapped jar. Launch a real Fabric 1.20.1 client, not just javac. Check latest.log for injection failures.
- [ ] Test without optional dependencies; with Mod Menu only; with Cloth only; with both. Test native UI at GUI scales/window sizes you use. Verify malformed config logs an error, does not crash loading, and ranges clamp.
- [ ] Exercise F8/F9/F10 and every option, JSON reload, resource-pack reload, disconnect/rejoin, dimension/world switch. F9 OFF must bypass all rendering changes immediately.
- [ ] Confirm player model, other players, held first-person items, crosshair target, last attack target, vanilla bosses and entities within 8 blocks never receive CleanEntities LOD/culling. Test third person. Test multipart Fakepixel mobs with names/heads on separate stands.
- [ ] Leave ambiguous-stand protection ON unless you have independently verified boss conventions and accept weaker guarantees. Walk along every distance threshold and crowd threshold; hysteresis prevents flicker but cannot hide a real cut. Reject visible changes if your requirement is strict.
- [ ] Occlusion: test corners, thin walls, glass/leaves, moving entities, fast camera turns, teleport, breaking/placing blockers and chunk unload. They should fail open; test the actual resource pack. Do not turn off core gameplay ticks to chase FPS.
- [ ] Launch the mod matrix: vanilla Fabric; +Sodium; +Sodium/Iris (shaders off/on); +ImmediatelyFast; +Entity Culling; then the full stack. Versions matter. Check labels, skulls, armor and outline passes visually. Third-party culling exemptions are not overridden by this mod.

### Goblin-raid A/B procedure

1. Fix resolution, resource/shader packs, render/simulation distance, camera/FOV, entity distance, Java heap, vsync/FPS cap and all other mods. Disable FPS caps/vsync when measuring maximum throughput, or leave them fixed when measuring frame pacing. Warm up the client, chunks and skull textures for 30–60 seconds.
2. Start with **Off**, stand at a repeatable raid viewpoint, F8 ON to confirm similar candidate counts, then `/cleanentities profile`. Save the chat summary. Repeat 3–5 ten-second windows; do not compare an idle plaza to a raid.
3. Choose **Balanced**, then alternate F9 OFF / ON / OFF / ON windows (ABBA order across repeats helps). Keep F8 in the same state for each run. Record median FPS, median/p95/p99 frame intervals, ENTITY/NAMETAG/HEAD/FEATURE/PLANNING costs, candidate counts, render counts and raid stage. Counts and camera motion must be comparable.
4. If HEAD dominates child buckets, test only skullCache first. If tags dominate, test only textCache before any visible tag limits. If other features dominate, consider featureLod only if distant cosmetics disappearing is acceptable. If ENTITY is large but children are cheap, base models/shadows/driver submission or GPU work may dominate; this profiler cannot prove which without a CPU/GPU profiler.
5. Toggle **one** additional option per experiment. Keep only repeatable wins larger than run-to-run noise. A faster average with worse p99 or visible missing bosses is a failure. PLANNING overhead must not eat the savings; occlusion is not automatically a win.
6. Only after accepting the visual trade-offs try Aggressive or Raid Mode. Look specifically for holograms dropped by the cap, distant head hats, armor/held-item removal and boundary cuts. Protected entities intentionally exceed caps and may limit gains.
7. Finish by turning F8 OFF and not recording to measure ordinary gameplay overhead. If strict unchanged appearance is nonnegotiable, disable all lossy options regardless of FPS. No performance claim is established until tested on your raid, hardware and exact mod stack.
