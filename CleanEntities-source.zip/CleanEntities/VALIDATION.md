# Verification record

This is a **source project**, not an install-ready, game-tested mod JAR.

## Checks performed

- Java 17.0.12 compiler: all **20 Java source files** (19 main, 1 test) compiled successfully with `-source 17 -target 17 -proc:none`, against the real Minecraft 1.20.1 client classes remapped to Yarn `1.20.1+build.10`, Fabric API 0.92.2+1.20.1, Fabric Loader 0.14.25, Mixin/MixinExtras, Mod Menu 7.2.2 and Cloth Config 11.1.118 classes. No generated Minecraft stubs were used.
- Minecraft was remapped official -> intermediary -> named using TinyRemapper 0.10.3 and the pinned Fabric intermediary/Yarn mapping artifacts. Fabric API and optional mod API classes were remapped to named for this compile.
- All **8 @At(INVOKE) target selectors** were found in actual disassembled Minecraft owning methods, including exact JVM descriptors. This caught the generic FeatureRenderer Entity erasure and the skull model's block.entity package before delivery.
- Actual vanilla player-head model data contains `head/hat`, which the scoped hat implementation handles. Model state is restored in finally.
- `OcclusionMathTest` compiled and ran: **71,709 assertions passed**, including **1,434 randomized certified boxes**, whose sampled interior points independently intersected the occluder by a slab-ray intersection calculation. This checks the geometry routine, not the entire Minecraft rendering/worker integration.
- JSON syntax and the 8-class mixin registry were checked. Source archive packaging checks ensure all project paths, Java packages, metadata and docs are included.
- Final source includes no @Overwrite or @Redirect and no entity tick or packet manipulation hooks. This is a static source inspection, not a network trace or security certification.

## Important build/tooling distinction

The Java compile used annotation processing **disabled**. It is NOT a substitute for a full Gradle/Loom build: it does not generate/validate the production refmap, transform the Minecraft classes with Mixin at launch, remap an output mod JAR, validate Fabric dependency metadata at runtime or exercise optional class loading. Initial compile/API issues were fixed and the compile was rerun; the bundled machine-readable verification result records the successful pass.

The sandbox originally had no JDK or Gradle. A JDK was downloaded for verification; an internal compact validation runtime omitted ZIP filesystem/ct.sym support, so its compiler used extracted dependency classpaths and its own Java 17 platform with source/target 17. These internal tools and Minecraft/dependency binaries are deliberately **not distributed in this source archive**.

## Not performed / not claimed

- No full Gradle 8.6 / Loom build, annotation processor/refmap generation, remapped JAR packaging or Fabric client launch.
- No tested launch matrix with Sodium, Iris, ImmediatelyFast, Entity Culling, optional Cloth/Mod Menu combinations, custom resource packs or shader packs.
- No real Fakepixel connection, goblin raid benchmark, FPS gain, GPU timing, server-rule approval or proof that arbitrary server-defined bosses are recognized.
- No guarantee of identical visuals for distance/tag/hat/feature/shadow LOD, or zero pop-in with all renderers and packs. Hysteresis is not alpha fading.
- No tick throttling or limb-animation freezing: deliberately excluded because the requested strict render-only / unchanged-appearance requirements conflict with them.

Run `gradle build`, `gradle geometryTest`, and the full README testing checklist locally before relying on this project. The profiler and Off preset are the starting point, not an advertised optimized benchmark result.
