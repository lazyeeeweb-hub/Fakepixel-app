package dev.zacktills.config;

import dev.zacktills.ZacktillsClient;
import dev.zacktills.ui.HudEditorScreen;
import dev.zacktills.ui.BossbarFilterScreen;
import dev.zacktills.ui.ScoreboardEditorScreen;
import dev.zacktills.ui.TouchInputScreen;
import dev.zacktills.feature.Playtime;
import dev.zacktills.feature.TabParts;
import net.minecraft.client.gui.screen.Screen;
import dev.zacktills.ui.LoginSecretScreen;
import net.minecraft.client.MinecraftClient;
import java.util.*;
import static dev.zacktills.config.ConfigModel.*;

/** The UI and gameplay share these same Option objects; no copied settings. */
public final class FeatureSettings {
    public static final List<Category> CATEGORIES = new ArrayList<>();
    private static final Map<String, Option<?>> OPTIONS = new HashMap<>();
    private static final Set<Option<?>> HUD_POSITIONS = new HashSet<>();
    private static List<Option<?>> current;
    private static String category;
    public static ConfigStore STORE;
    static {
        group("interface", "Menus");
        range("ui_scale", "Settings menu scale", .5, 1.5, .05, .75);
        bool("realms", "Hide Realms", true);
        bool("extras", "Hide feedback, bug report, stats and advancements buttons", true);
        bool("sodium", "Hide Sodium donation prompt (not driver safety warnings)", true);
        bool("sodiumDriverWarning", "Hide Sodium driver warning (may hide compatibility problems)", false);
        bool("modmenu", "Remember Mod Menu scroll position", true);
        group("autoclick", "Auto click");
        bool("enabled", "Auto-click matching chat buttons (trusted servers only)", false);
        string("trigger", "Trigger text", "[OPEN MENU]");
        action("edit_trigger", "Enter trigger text (touch keyboard)", FeatureSettings::editTrigger);
        integer("delay", "Delay in ticks", 0, 40, 1, 4);
        integer("cooldown", "Cooldown seconds", 1, 60, 1, 2);
        bool("debug", "Debug: log why a matching button was skipped", false);
        group("tabparts", "Tab list");
        action("toggle", "Show tab list (toggle)", TabParts::toggleVanillaTab);
        action("manage", "Tab parts", TabParts::openManager);
        put(new Choice("style", "Tab overlay style", "Plain tab overlay background", List.of("F3", "Subtitles")));
        group("playtime", "Playtime");
        bool("show", "Show in pause menu", true);
        integer("days", "Days (draft)", 0, 999_999, 1, 0);
        integer("hours", "Hours (draft)", 0, 23, 1, 0);
        integer("minutes", "Minutes (draft)", 0, 59, 1, 0);
        action("edit_time", "Enter exact days / hours / minutes", FeatureSettings::editPlaytime);
        action("apply", "Apply (overwrite playtime)", Playtime::apply);
        action("reset", "Reset playtime to zero", Playtime::reset);
        group("bossbar", "Bossbars");
        bool("filter", "Enable bossbar filter", true);
        action("manage", "Bossbar filter", () -> open(BossbarFilterScreen::new));
        group("scoreboard", "Scoreboard");
        bool("enabled", "Clean sidebar (no score numbers)", true);
        range("radius", "Corner radius", 0, 12, 1, 5);
        range("opacity", "Background opacity", 0, 1, .05, .65);
        position("scoreboard", 1, .4);
        bool("visible", "Show scoreboard", true);
        action("editor", "Scoreboard editor", () -> open(ScoreboardEditorScreen::new));
        group("hud", "Hotbar & offhand");
        bool("enabled", "Custom movable hotbar and offhand", true);
        position("hotbar", .5, 1);
        position("offhand", .25, 1);
        action("editor", "HUD editor", () -> open(HudEditorScreen::new));
        bool("hotbar_visible", "Show custom hotbar", true);
        bool("offhand_visible", "Show custom offhand", true);
        bool("snap", "Snap HUD elements while editing", true);
        group("inventory", "Items & inventory");
        bool("flat", "Flat, camera-facing dropped items", true);
        bool("slot_lock", "Slot lock (L over a player inventory slot)", true);
        string("locked", "Locked inventory indices (0-40)", "");
        bool("swingthrough", "Attack through non-colliding foliage", true);
        group("tooltip", "Tooltips & crosshair");
        bool("scroll", "Scrollable tooltips; keep their top visible", true);
        bool("crosshair", "Centered crosshair (also third person)", true);
        integer("crosshair_thickness", "Crosshair thickness", 1, 9, 1, 1);
        integer("crosshair_length", "Crosshair arm length", 1, 20, 1, 4);
        group("camera", "Camera");
        bool("fade", "Third-person near-wall fade (vanilla renderer)", false);
        range("radius", "Fade distance", .5, 4, .1, 1.6);
        range("strength", "Maximum fade", .1, 1, .05, .85);
        group("login", "Autologin");
        bool("enabled", "Enable chat-triggered login (trusted server only)", false);
        string("server", "Exact server address, including port if used", "");
        string("prompt", "Server message contains (case insensitive)", "Please login");
        string("command", "Command template (no slash; {password} required)", "login {password}");
        action("secret", "Set password for this session (never saved)", () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new LoginSecretScreen(mc.currentScreen));
        });
        group("particle", "Particle ESP");
        bool("enabled", "Show particle ESP", false);
        bool("auto_break", "Auto-break targets in range (key R)", false);
        range("break_range", "Auto-break range (blocks)", 2, 6, .5, 5);
        integer("min_count", "Particles needed to mark a block", 1, 64, 1, 5);
        string("color", "ESP color (hex RGB)", "00FFFF");
        bool("tracer", "Draw a line to targets", false);
        bool("distance", "Show distance on targets", false);
        string("types", "Particle types to track (comma-separated)",
                "minecraft:witch,minecraft:portal,minecraft:enchant,minecraft:reverse_portal,minecraft:enchanted_hit,minecraft:dragon_breath,minecraft:instant_effect,minecraft:effect,minecraft:entity_effect,minecraft:ambient_entity_effect");
        bool("debug", "Debug: print every particle type seen", false);
        group("viewmodel", "Viewmodel");
        bool("enabled", "Enable per-hand transforms", true);
        for (String hand : List.of("main", "off")) {
            for (String axis : List.of("x", "y", "z")) range(hand + "_" + axis, hand + " position " + axis, -2, 2, .05, 0);
            range(hand + "_scale", hand + " scale", .1, 3, .05, 1);
            for (String axis : List.of("rx", "ry", "rz")) range(hand + "_" + axis, hand + " rotation " + axis, -180, 180, 5, 0);
            range(hand + "_speed", hand + " swing animation speed", .25, 4, .05, 1);
        }
    }
    private FeatureSettings() {}
    private static void group(String id, String label) {
        category = id; current = new ArrayList<>();
        Category c = new Category(id, label, current);
        CATEGORIES.add(c); current = c.options;
    }
    private static void put(Option<?> option) { current.add(option); OPTIONS.put(category + "." + option.id, option); }
    private static void bool(String id, String label, boolean value) { put(new Bool(id, label, label, value)); }
    private static void range(String id, String label, double min, double max, double step, double value) {
        put(new Range(id, label, label, min, max, step, value, false));
    }
    private static void integer(String id, String label, double min, double max, double step, double value) {
        put(new Range(id, label, label, min, max, step, value, true));
    }
    private static void string(String id, String label, String value) { put(new StringOption(id, label, label, value)); }
    private static void action(String id, String label, Runnable action) { put(new Action(id, label, label, action)); }
    private static void position(String id, double x, double y) {
        hudPosition(new Range(id + "_x", id + " horizontal anchor", "", 0, 1, .000001, x, false));
        hudPosition(new Range(id + "_y", id + " vertical anchor", "", 0, 1, .000001, y, false));
        hudPosition(new Range(id + "_scale", id + " scale", "", .25, 4, .05, 1, false));
    }
    private static void hudPosition(Range value) { put(value); HUD_POSITIONS.add(value); }
    public static boolean isHudPosition(Option<?> option) { return HUD_POSITIONS.contains(option); }
    private static String prefix(String id) { return id.equals("scoreboard") ? "scoreboard." : "hud."; }
    public static double pos(String id, String property) { return number(prefix(id) + id + "_" + property); }
    public static void pos(String id, String property, double value) { ((Range) OPTIONS.get(prefix(id) + id + "_" + property)).set(value); }
    private static void open(java.util.function.Function<Screen, Screen> create) {
        MinecraftClient mc = MinecraftClient.getInstance();
        save();
        mc.setScreen(create.apply(mc.currentScreen));
    }
    private static void editTrigger() {
        MinecraftClient mc = MinecraftClient.getInstance();
        save();
        mc.setScreen(new TouchInputScreen(mc.currentScreen, "Auto click: trigger text", text("autoclick.trigger"), false, value -> {
            text("autoclick.trigger", value);
            save();
        }));
    }
    private static final String[] TIME_FIELDS = {"days", "hours", "minutes"};
    private static final int[] TIME_MAX = {999_999, 23, 59};
    private static void editPlaytime() {
        MinecraftClient mc = MinecraftClient.getInstance();
        save();
        int[] draft = new int[3];
        for (int i = 0; i < draft.length; i++) draft[i] = (int) number("playtime." + TIME_FIELDS[i]);
        editTimeField(mc, mc.currentScreen, draft, 0);
    }
    private static void editTimeField(MinecraftClient mc, Screen parent, int[] draft, int step) {
        mc.setScreen(new TouchInputScreen(parent, "Playtime: " + TIME_FIELDS[step] + " (0-" + TIME_MAX[step] + ")",
                Integer.toString(draft[step]), true, value -> {
            draft[step] = Math.min(TIME_MAX[step], value.isEmpty() ? 0 : Integer.parseInt(value));
            if (step + 1 < draft.length) editTimeField(mc, parent, draft, step + 1);
            else {
                for (int i = 0; i < draft.length; i++) ((Range) OPTIONS.get("playtime." + TIME_FIELDS[i])).set(draft[i]);
                save();
            }
        }));
    }
    public static boolean on(String key) { return ((Bool) OPTIONS.get(key)).value; }
    public static boolean boolValue(String key, boolean fallback) {
        Option<?> option = OPTIONS.get(key);
        return option instanceof Bool value ? value.value : fallback;
    }
    public static void setBool(String key, boolean value) {
        Option<?> option = OPTIONS.get(key);
        if (option instanceof Bool bool) bool.value = value;
    }
    public static String choiceValue(String key) { return ((Choice) OPTIONS.get(key)).value; }
    public static double number(String key) { return ((Range) OPTIONS.get(key)).value; }
    public static String text(String key) { return ((StringOption) OPTIONS.get(key)).value; }
    public static void text(String key, String value) { ((StringOption) OPTIONS.get(key)).value = value; }
    public static void save() {
        if (STORE != null && !STORE.save()) ZacktillsClient.notifyError("Could not save settings; check the game log.");
    }
}
