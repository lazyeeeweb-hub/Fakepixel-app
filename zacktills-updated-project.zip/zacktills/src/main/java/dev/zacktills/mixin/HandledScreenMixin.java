package dev.zacktills.mixin;

import dev.zacktills.feature.HudFeatures;
import dev.zacktills.feature.ItemFeatures;
import dev.zacktills.feature.TooltipFeatures;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.item.TooltipData;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin extends Screen {
    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow @Final protected ScreenHandler handler;
    @Shadow protected Slot focusedSlot;
    @Shadow protected abstract List<Text> getTooltipFromItem(ItemStack stack);

    protected HandledScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void zacktills$locks(DrawContext c, int mx, int my, float delta, CallbackInfo ci) {
        for (var slot : handler.slots) if (ItemFeatures.locked(slot)) {
            c.getMatrices().push();
            c.getMatrices().translate(0, 0, 350);
            HudFeatures.outline(c, x + slot.x - 1, y + slot.y - 1, 18, 18, 0xFFFFC24A);
            c.getMatrices().pop();
        }
    }

    @Inject(method = "drawMouseoverTooltip(Lnet/minecraft/client/gui/DrawContext;II)V",
            at = @At("HEAD"), cancellable = true)
    private void zacktills$retainTooltip(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        if (!handler.getCursorStack().isEmpty()) {
            TooltipFeatures.hideSlot();
            return;
        }
        HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
        Slot slot = TooltipFeatures.retainedSlot(screen, focusedSlot, mouseX, mouseY);
        if (slot != null && slot != focusedSlot) {
            ItemStack stack = slot.getStack();
            TooltipFeatures.drawSlot(context, screen, slot, textRenderer, getTooltipFromItem(stack),
                    stack.getTooltipData(), mouseX, mouseY);
            ci.cancel();
        } else if (focusedSlot == null || !focusedSlot.hasStack()) {
            TooltipFeatures.hideSlot();
        }
    }

    @Redirect(method = "drawMouseoverTooltip(Lnet/minecraft/client/gui/DrawContext;II)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;Ljava/util/Optional;II)V"))
    private void zacktills$drawSlotTooltip(DrawContext context, TextRenderer font, List<Text> text,
                                         Optional<TooltipData> data, int mouseX, int mouseY) {
        TooltipFeatures.drawSlot(context, (HandledScreen<?>) (Object) this, focusedSlot, font, text, data, mouseX, mouseY);
    }
}
