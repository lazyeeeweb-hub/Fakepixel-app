package dev.zacktills.mixin;

import dev.zacktills.feature.TooltipFeatures;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin {
    @Inject(method = "drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;IILnet/minecraft/client/gui/tooltip/TooltipPositioner;)V",
            at = @At("HEAD"), cancellable = true)
    private void zacktills$tooltip(TextRenderer font, List<TooltipComponent> parts, int x, int y,
                                  TooltipPositioner positioner, CallbackInfo ci) {
        if (TooltipFeatures.draw((DrawContext) (Object) this, font, parts, x, y, positioner)) ci.cancel();
    }
}
