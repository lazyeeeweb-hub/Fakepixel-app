package dev.zacktills.mixin;

import dev.zacktills.feature.DungeoneerGlow;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityGlowMixin {
    @Inject(method = "isGlowing()Z", at = @At("RETURN"), cancellable = true)
    private void zacktills$glowing(CallbackInfoReturnable<Boolean> cir) {
        if (DungeoneerGlow.hasOutline((Entity) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColorValue()I", at = @At("RETURN"), cancellable = true)
    private void zacktills$glowColor(CallbackInfoReturnable<Integer> cir) {
        if (DungeoneerGlow.hasOutline((Entity) (Object) this)) cir.setReturnValue(DungeoneerGlow.outlineColor());
    }
}
