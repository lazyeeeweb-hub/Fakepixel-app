package dev.zacktills.mixin;

import dev.zacktills.feature.BossbarFilter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.ClientBossBar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {
    @Inject(method = "<init>(Lnet/minecraft/client/MinecraftClient;)V", at = @At("RETURN"))
    private void zacktills$initializeBossbarFilter(MinecraftClient client, CallbackInfo ci) {
        BossbarFilter.initialize();
    }

    @Redirect(method = "render(Lnet/minecraft/client/gui/DrawContext;)V",
            at = @At(value = "INVOKE", target = "Ljava/util/Map;values()Ljava/util/Collection;", remap = false))
    private Collection<ClientBossBar> zacktills$filterRenderedBossbars(Map<UUID, ClientBossBar> bars) {
        return BossbarFilter.forRender(bars);
    }
}
