package dev.zacktills.mixin;

import dev.zacktills.feature.HudFeatures;
import dev.zacktills.feature.ItemFeatures;
import dev.zacktills.feature.QuickDropFeature;
import dev.zacktills.feature.TooltipFeatures;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.item.TooltipData;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin extends Screen {
    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundWidth;
    @Shadow @Final protected ScreenHandler handler;
    @Shadow protected Slot focusedSlot;
    @Shadow protected abstract List<Text> getTooltipFromItem(ItemStack stack);
    @Shadow private boolean doubleClicking;
    @Shadow private long lastButtonClickTime;

    @Shadow
    private Slot getSlotAt(double mouseX, double mouseY) {
        throw new AssertionError();
    }

    @Unique private boolean zacktills$quickDropLeftDown;
    @Unique private long zacktills$quickDropHintUntil;
    @Unique private static final Text ZACKTILLS_QUICK_DROP_HINT = Text.literal("Quick drop stack");

    protected HandledScreenMixin(Text title) {
        super(title);
    }

    @Unique
    private QuickDropFeature.ButtonBounds zacktills$quickDropBounds() {
        // The creative inventory uses its own slot handler and creative packets.
        if ((Object) this instanceof CreativeInventoryScreen || !QuickDropFeature.available()
                || client == null || client.player == null || client.interactionManager == null
                || client.player.isSpectator() || client.player.currentScreenHandler != handler) return null;
        return QuickDropFeature.buttonBounds(x, y, backgroundWidth, width, height);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void zacktills$renderQuickDrop(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        QuickDropFeature.ButtonBounds bounds = zacktills$quickDropBounds();
        if (bounds == null) return;

        boolean hovered = bounds.contains(mouseX, mouseY);
        int bx = bounds.buttonX(), by = bounds.buttonY();
        int size = QuickDropFeature.BUTTON_SIZE;
        int face = QuickDropFeature.isOn() ? (hovered ? 0xFFD34456 : 0xFFB33244)
                : (hovered ? 0xFF6B6B74 : 0xFF55555D);
        context.fill(bx, by, bx + size, by + size, 0xFF202026);
        context.fill(bx + 1, by + 1, bx + size - 1, by + size - 1, face);
        context.drawCenteredTextWithShadow(textRenderer, "D", bx + size / 2,
                by + (size - textRenderer.fontHeight) / 2, 0xFFFFFF);

        // Keep the hint briefly after a tap, unless the pointer has moved onto a slot.
        if (hovered || (Util.getMeasuringTimeMs() < zacktills$quickDropHintUntil && getSlotAt(mouseX, mouseY) == null)) {
            context.drawTooltip(textRenderer, ZACKTILLS_QUICK_DROP_HINT,
                    hovered ? mouseX : bx + size / 2, hovered ? mouseY : by + size / 2);
        }
    }

    @Inject(method = "mouseClicked(DDI)Z", at = @At("HEAD"), cancellable = true)
    private void zacktills$quickDropClick(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return;
        zacktills$quickDropLeftDown = false;
        QuickDropFeature.ButtonBounds bounds = zacktills$quickDropBounds();
        if (bounds == null) return;

        // MouseMixin already gives the tooltip scrollbar first refusal at Mouse.onMouseButton HEAD.
        if (bounds.contains(mouseX, mouseY)) {
            QuickDropFeature.toggle();
            zacktills$quickDropHintUntil = Util.getMeasuringTimeMs() + 900L;
            zacktills$consumeQuickDropPress(cir);
            return;
        }
        if (!QuickDropFeature.isOn() || !handler.getCursorStack().isEmpty()) return;
        Slot slot = getSlotAt(mouseX, mouseY); // Live hit test, not the last rendered focused slot.
        if (slot == null || !slot.hasStack() || QuickDropFeature.isResultSlot(handler, slot)
                || !slot.canTakeItems(client.player)) return;

        zacktills$consumeQuickDropPress(cir);
        if (!ItemFeatures.locked(slot) && !ItemFeatures.blockClick(slot.id, 1, SlotActionType.THROW)) {
            client.interactionManager.clickSlot(handler.syncId, slot.id, 1, SlotActionType.THROW, client.player);
        }
    }

    @Unique
    private void zacktills$consumeQuickDropPress(CallbackInfoReturnable<Boolean> cir) {
        zacktills$quickDropLeftDown = true;
        // Do not let the consumed press pair with a vanilla press as a double-click.
        doubleClicking = false;
        lastButtonClickTime = 0L;
        cir.setReturnValue(true);
    }

    @Inject(method = "mouseDragged(DDIDD)Z", at = @At("HEAD"), cancellable = true)
    private void zacktills$quickDropDrag(double mouseX, double mouseY, int button, double dx, double dy,
                                        CallbackInfoReturnable<Boolean> cir) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && zacktills$quickDropLeftDown) cir.setReturnValue(true);
    }

    @Inject(method = "mouseReleased(DDI)Z", at = @At("HEAD"), cancellable = true)
    private void zacktills$quickDropRelease(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || !zacktills$quickDropLeftDown) return;
        zacktills$quickDropLeftDown = false;
        cir.setReturnValue(true);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void zacktills$locks(DrawContext c, int mx, int my, float delta, CallbackInfo ci) {
        for (var slot : handler.slots) if (ItemFeatures.locked(slot)) {
            c.getMatrices().push();
            c.getMatrices().translate(0, 0, 350);
            HudFeatures.outline(c, x + slot.x - 1, y + slot.y - 1, 18, 18, 0xFFFFC24A);
            c.getMatrices().pop();
        }
    }

    @Inject(method = "drawMouseoverTooltip(Lnet/minecraft/client/gui/DrawContext;II)V",
            at = @At("HEAD"), cancellable = true)
    private void zacktills$retainTooltip(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        if (!handler.getCursorStack().isEmpty()) {
            TooltipFeatures.hideSlot();
            return;
        }
        HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
        Slot slot = TooltipFeatures.retainedSlot(screen, focusedSlot, mouseX, mouseY);
        if (slot != null && slot != focusedSlot) {
            ItemStack stack = slot.getStack();
            TooltipFeatures.drawSlot(context, screen, slot, textRenderer, getTooltipFromItem(stack),
                    stack.getTooltipData(), mouseX, mouseY);
            ci.cancel();
        } else if (focusedSlot == null || !focusedSlot.hasStack()) {
            TooltipFeatures.hideSlot();
        }
    }

    @Redirect(method = "drawMouseoverTooltip(Lnet/minecraft/client/gui/DrawContext;II)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;Ljava/util/Optional;II)V"))
    private void zacktills$drawSlotTooltip(DrawContext context, TextRenderer font, List<Text> text,
                                         Optional<TooltipData> data, int mouseX, int mouseY) {
        TooltipFeatures.drawSlot(context, (HandledScreen<?>) (Object) this, focusedSlot, font, text, data, mouseX, mouseY);
    }
}
