package dev.zacktills.mixin;

import dev.zacktills.feature.TooltipFeatures;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void zacktills$scroll(long handle, double horizontal, double vertical, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        Window window = client.getWindow();
        Screen screen = client.currentScreen;
        if (handle != window.getHandle() || screen == null || client.getOverlay() != null) return;
        double amount = (client.options.getDiscreteMouseScroll().getValue() ? Math.signum(vertical) : vertical)
                * client.options.getMouseWheelSensitivity().getValue();
        double x = client.mouse.getX() * window.getScaledWidth() / window.getWidth();
        double y = client.mouse.getY() * window.getScaledHeight() / window.getHeight();
        if (TooltipFeatures.scroll(screen, x, y, amount)) ci.cancel();
    }

    @Inject(method = "onMouseButton(JIII)V", at = @At("HEAD"), cancellable = true)
    private void zacktills$thumb(long handle, int button, int action, int modifiers, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        Window window = client.getWindow();
        if (handle != window.getHandle() || button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return;
        Screen screen = client.getOverlay() == null ? client.currentScreen : null;
        double x = client.mouse.getX() * window.getScaledWidth() / window.getWidth();
        double y = client.mouse.getY() * window.getScaledHeight() / window.getHeight();
        if (action == GLFW.GLFW_PRESS && TooltipFeatures.press(screen, x, y)
                || action == GLFW.GLFW_RELEASE && TooltipFeatures.release(screen, y)) ci.cancel();
    }

    @Inject(method = "onCursorPos(JDD)V", at = @At("RETURN"))
    private void zacktills$dragThumb(long handle, double x, double y, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        Window window = client.getWindow();
        if (handle == window.getHandle() && client.getOverlay() == null) {
            TooltipFeatures.drag(client.currentScreen, y * window.getScaledHeight() / window.getHeight());
        }
    }
}
