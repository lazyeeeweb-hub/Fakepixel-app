package dev.zacktills.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.BossBarHudAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ClientBossBar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Client-thread rules keyed by the shared normalized title, not by boss bar UUID. */
public final class BossbarFilter {
    private static final Logger LOG = LoggerFactory.getLogger("zacktills");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public record Entry(String key, String rawTitle) {}
    public record Snapshot(List<Entry> visible, List<Entry> hidden) {}

    private BossbarFilter() {}

    /** Called by the HUD constructor mixin; loads and wires the store only once. */
    public static void initialize() { store(); }

    public static boolean enabled() { return FeatureSettings.on("bossbar.filter"); }

    /** Only the render iterator uses this collection. Vanilla still owns and updates the map. */
    public static Collection<ClientBossBar> forRender(Map<UUID, ClientBossBar> bars) {
        Store store = store();
        Collection<ClientBossBar> values = bars.values();
        if (store.hidden.isEmpty() || !enabled()) return values;

        List<ClientBossBar> visible = new ArrayList<>(values.size());
        for (ClientBossBar bar : values) {
            String key = TextKey.normalize(bar.getName().getString());
            if (!store.hidden.containsKey(key)) visible.add(bar);
        }
        return visible;
    }

    /** Shows one live candidate per unhidden key, in HUD order, even while the master is off. */
    public static Snapshot snapshot(MinecraftClient client) {
        Store store = store();
        Map<String, Entry> visible = new LinkedHashMap<>();
        for (ClientBossBar bar : liveBars(client).values()) {
            String raw = bar.getName().getString();
            String key = TextKey.normalize(raw);
            if (key != null && !store.hidden.containsKey(key)) visible.putIfAbsent(key, new Entry(key, raw));
        }
        List<Entry> hidden = new ArrayList<>(store.hidden.size());
        store.hidden.forEach((key, raw) -> hidden.add(new Entry(key, raw)));
        return new Snapshot(List.copyOf(visible.values()), List.copyOf(hidden));
    }

    public static void hide(String rawTitle) {
        String key = TextKey.normalize(rawTitle);
        if (key == null) return;
        Store store = store();
        if (rawTitle.equals(store.hidden.put(key, rawTitle))) return;
        store.markDirty();
        store.save();
    }

    public static void remove(String key) {
        Store store = store();
        if (store.hidden.remove(key) == null) return;
        store.seen.values().removeIf(entry -> entry.key().equals(key));
        store.markDirty();
        store.save();
    }

    public static boolean hasSaveError() { return store().saveError; }

    private static Map<UUID, ClientBossBar> liveBars(MinecraftClient client) {
        if (client == null || client.world == null || client.inGameHud == null) return Map.of();
        return ((BossBarHudAccessor) client.inGameHud.getBossBarHud()).zacktills$getBossBars();
    }

    private static Store store() { return StoreHolder.INSTANCE; }

    private static final class StoreHolder {
        private static final Store INSTANCE = new Store(FabricLoader.getInstance().getConfigDir()
                .resolve("zacktills").resolve("bossbar_filter.json"));

        static {
            ClientTickEvents.END_CLIENT_TICK.register(INSTANCE::tick);
            ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
                INSTANCE.observe(liveBars(client));
                if (INSTANCE.dirty) INSTANCE.save();
            });
        }
    }

    private static final class Store {
        private static final int SAVE_DELAY_TICKS = 40;
        private static final int RETRY_DELAY_TICKS = 200;
        private final Path path;
        private final Map<String, String> hidden = new LinkedHashMap<>();
        private final Map<UUID, Entry> seen = new HashMap<>();
        private boolean dirty, saveError;
        private int ticksUntilSave = SAVE_DELAY_TICKS;

        private Store(Path path) {
            this.path = path;
            load();
        }

        private void tick(MinecraftClient client) {
            if (!hidden.isEmpty()) observe(liveBars(client));
            if (dirty && --ticksUntilSave <= 0) save();
        }

        private void observe(Map<UUID, ClientBossBar> bars) {
            if (hidden.isEmpty() || bars.isEmpty()) {
                seen.clear();
                return;
            }
            seen.keySet().retainAll(bars.keySet());
            for (var item : bars.entrySet()) {
                UUID id = item.getKey();
                String raw = item.getValue().getName().getString();
                Entry previous = seen.get(id);
                if (previous != null && raw.equals(previous.rawTitle())) continue;
                String key = TextKey.normalize(raw);
                if (hidden.containsKey(key)) {
                    seen.put(id, new Entry(key, raw));
                    if (!raw.equals(hidden.put(key, raw))) markDirty();
                } else {
                    seen.remove(id);
                }
            }
        }

        private void load() {
            if (!Files.exists(path)) return;
            try (Reader in = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                JsonObject json = JsonParser.parseReader(in).getAsJsonObject();
                JsonObject entries = json.getAsJsonObject("hidden");
                if (entries == null) return;
                for (var item : entries.entrySet()) {
                    JsonElement value = item.getValue();
                    if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()) {
                        String raw = value.getAsString();
                        String normalized = TextKey.normalize(raw);
                        if (normalized != null) hidden.put(normalized, raw);
                    }
                }
            } catch (IOException | RuntimeException ex) {
                LOG.warn("Could not load Zacktills bossbar filters from {}", path, ex);
            }
        }

        private void markDirty() {
            if (!dirty) ticksUntilSave = SAVE_DELAY_TICKS;
            dirty = true;
        }

        private void save() {
            Path temp = null;
            try {
                Files.createDirectories(path.getParent());
                temp = Files.createTempFile(path.getParent(), "bossbar_filter-", ".tmp");
                JsonObject entries = new JsonObject();
                hidden.forEach(entries::addProperty);
                JsonObject json = new JsonObject();
                json.add("hidden", entries);
                try (Writer out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                    GSON.toJson(json, out);
                }
                try {
                    Files.move(temp, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
                }
                dirty = saveError = false;
                ticksUntilSave = SAVE_DELAY_TICKS;
            } catch (IOException | RuntimeException ex) {
                saveError = true;
                ticksUntilSave = RETRY_DELAY_TICKS;
                LOG.warn("Could not save Zacktills bossbar filters to {}; will retry", path, ex);
            } finally {
                if (temp != null) {
                    try {
                        Files.deleteIfExists(temp);
                    } catch (IOException | RuntimeException ex) {
                        LOG.debug("Could not clean up temporary bossbar filter file {}", temp, ex);
                    }
                }
            }
        }
    }
}
