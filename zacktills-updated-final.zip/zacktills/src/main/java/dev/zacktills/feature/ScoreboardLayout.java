package dev.zacktills.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** The sidebar and its editor project the same saved ordering over the live rows. */
public final class ScoreboardLayout {
    public enum Source { SCOREBOARD, TAB }
    public enum Mode { COPY, MOVE }
    public record Key(Source source, String key, int occurrence, TabParts.Ref tabRef) {
        public boolean isTab() { return source == Source.TAB; }
    }
    public record Row(Key id, Text text, Mode mode, boolean live) {}
    private record Entry(Source source, String key, int occurrence, TabParts.Ref tabRef, int order, Mode mode) {
        Key id() { return new Key(source, key, occurrence, tabRef); }
        Entry at(int next) { return new Entry(source, key, occurrence, tabRef, next, mode); }
    }
    private record Saved(List<Entry> entries, Set<String> hidden) {}

    private static final Logger LOG = LoggerFactory.getLogger("zacktills/scoreboard-layout");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zacktills/scoreboard_layout.json");
    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Set<String> HIDDEN = new LinkedHashSet<>();

    private ScoreboardLayout() {}

    static List<Row> apply(List<Text> natural, boolean includeMissingTabs) {
        Map<String, Integer> occurrences = new HashMap<>();
        Map<Key, Row> nativeRows = new LinkedHashMap<>();
        for (Text text : natural) {
            String key = TextKey.normalize(text.getString());
            int occurrence = occurrences.merge(key, 1, Integer::sum) - 1;
            if (!HIDDEN.contains(key)) {
                Key id = new Key(Source.SCOREBOARD, key, occurrence, null);
                nativeRows.put(id, new Row(id, text, null, true));
            }
        }
        List<Row> ordered = new ArrayList<>();
        Set<Key> tracked = new HashSet<>();
        for (Entry entry : ENTRIES) {
            Key id = entry.id();
            if (HIDDEN.contains(id.key())) continue;
            if (id.isTab()) {
                List<Text> lines = TabParts.liveLines(id.tabRef());
                if (!lines.isEmpty()) {
                    var joined = Text.empty();
                    for (int i = 0; i < lines.size(); i++) {
                        if (i != 0) joined.append(" | ");
                        joined.append(lines.get(i));
                    }
                    ordered.add(new Row(id, joined, entry.mode(), true));
                } else if (includeMissingTabs) {
                    String label = id.key().isBlank() ? "Tab entry" : id.key();
                    ordered.add(new Row(id, Text.literal(label + " (not in tab)"), entry.mode(), false));
                }
            } else {
                Row row = nativeRows.get(id);
                if (row != null) { ordered.add(row); tracked.add(id); }
            }
        }
        int naturalIndex = 0;
        for (Row row : nativeRows.values()) {
            if (!tracked.contains(row.id())) ordered.add(Math.min(naturalIndex, ordered.size()), row);
            naturalIndex++;
        }
        return List.copyOf(ordered);
    }

    public static boolean contains(TabParts.Ref ref) {
        return ref != null && ENTRIES.stream().anyMatch(e -> e.source() == Source.TAB && !HIDDEN.contains(e.key())
                && TabParts.sameTarget(e.tabRef(), ref));
    }

    public static boolean moves(TabParts.Ref ref) {
        return FeatureSettings.on("scoreboard.enabled") && FeatureSettings.on("scoreboard.visible")
                && ENTRIES.stream().anyMatch(e -> e.source() == Source.TAB && e.mode() == Mode.MOVE
                        && !HIDDEN.contains(e.key()) && TabParts.sameTarget(e.tabRef(), ref));
    }

    public static void addFromTab(TabParts.Ref ref) {
        if (ref == null || contains(ref)) return;
        boolean unhidden = HIDDEN.remove(ref.key());
        boolean exists = ENTRIES.stream().anyMatch(e -> e.source() == Source.TAB && TabParts.sameTarget(e.tabRef(), ref));
        if (!exists) ENTRIES.add(new Entry(Source.TAB, ref.key(), 0, ref, ENTRIES.size(), Mode.COPY));
        if (unhidden || !exists) save();
    }

    public static void toggleMode(Key key) {
        for (int i = 0; i < ENTRIES.size(); i++) {
            Entry e = ENTRIES.get(i);
            if (e.source() == Source.TAB && e.id().equals(key)) {
                ENTRIES.set(i, new Entry(e.source(), e.key(), e.occurrence(), e.tabRef(), e.order(),
                        e.mode() == Mode.MOVE ? Mode.COPY : Mode.MOVE));
                save();
                return;
            }
        }
    }

    public static void hide(Key key) { if (HIDDEN.add(key.key())) save(); }

    public static void reorder(List<Row> visible) {
        Map<Key, Entry> old = new LinkedHashMap<>();
        for (Entry entry : ENTRIES) old.put(entry.id(), entry);
        List<Entry> next = new ArrayList<>();
        for (Row row : visible) {
            Key id = row.id();
            Entry entry = old.remove(id);
            next.add(entry != null ? entry : new Entry(id.source(), id.key(), id.occurrence(), id.tabRef(), 0, row.mode()));
        }
        // A server can temporarily drop rows. Do not discard their saved positions.
        for (Entry absent : old.values()) next.add(Math.min(absent.order(), next.size()), absent);
        ENTRIES.clear();
        for (Entry entry : next) ENTRIES.add(entry.at(ENTRIES.size()));
        save();
    }

    public static void reset() {
        ENTRIES.clear();
        HIDDEN.clear();
        save();
    }

    public static void load() {
        if (!Files.isRegularFile(FILE)) return;
        try (var reader = Files.newBufferedReader(FILE)) {
            Saved saved = GSON.fromJson(reader, Saved.class);
            if (saved == null) return;
            ENTRIES.clear(); HIDDEN.clear();
            Set<Key> seen = new HashSet<>();
            if (saved.entries() != null) {
                for (Entry entry : saved.entries().stream().filter(java.util.Objects::nonNull)
                        .sorted(Comparator.comparingInt(Entry::order)).toList()) {
                    if (entry.source() == null || entry.key() == null) continue;
                    boolean tab = entry.source() == Source.TAB;
                    if (tab && (entry.tabRef() == null || entry.tabRef().kind() == null)) continue;
                    Entry valid = new Entry(entry.source(), tab ? entry.tabRef().key() : TextKey.normalize(entry.key()),
                            tab ? 0 : Math.max(0, entry.occurrence()), tab ? entry.tabRef() : null, ENTRIES.size(),
                            tab ? (entry.mode() == Mode.MOVE ? Mode.MOVE : Mode.COPY) : null);
                    if (seen.add(valid.id())) ENTRIES.add(valid);
                }
            }
            if (saved.hidden() != null) {
                for (String key : saved.hidden()) if (key != null) HIDDEN.add(TextKey.normalize(key));
            }
        } catch (IOException | RuntimeException e) {
            LOG.warn("Could not read {}", FILE, e);
        }
    }

    private static void save() {
        Path tmp = FILE.resolveSibling("scoreboard_layout.json.tmp");
        try {
            Files.createDirectories(FILE.getParent());
            try (var writer = Files.newBufferedWriter(tmp)) { GSON.toJson(new Saved(ENTRIES, HIDDEN), writer); }
            try {
                Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Could not save {}", FILE, e);
        }
    }
}
