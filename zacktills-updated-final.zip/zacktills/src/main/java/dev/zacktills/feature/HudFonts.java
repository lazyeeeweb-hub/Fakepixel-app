package dev.zacktills.feature;

import net.minecraft.text.Text;

/** Kept as a single switch point for HUD text. Currently uses Minecraft's default font (no custom font applied). */
public final class HudFonts {
    private HudFonts() {}

    public static Text apply(Text text) {
        return text;
    }

    public static Text literal(String value) {
        return Text.literal(value);
    }
}
