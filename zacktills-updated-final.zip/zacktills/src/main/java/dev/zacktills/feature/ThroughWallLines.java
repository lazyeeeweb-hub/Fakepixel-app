package dev.zacktills.feature;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

/** Shared batched, camera-relative line rendering for ESP overlays. */
final class ThroughWallLines {
    private ThroughWallLines() {}
    @FunctionalInterface interface Batch { void emit(BufferBuilder b, Matrix4f m, Vec3d camera); }
    static void draw(WorldRenderContext context, Batch batch) {
        Vec3d camera = context.camera().getPos(); MatrixStack matrices = context.matrixStack();
        matrices.push(); matrices.translate(-camera.x,-camera.y,-camera.z);
        ShaderProgram oldShader=RenderSystem.getShader(); float[] oldColor=RenderSystem.getShaderColor().clone();
        float oldWidth=RenderSystem.getShaderLineWidth();
        boolean oldDepth=GL11.glIsEnabled(GL11.GL_DEPTH_TEST), oldCull=GL11.glIsEnabled(GL11.GL_CULL_FACE);
        boolean oldBlend=GL11.glIsEnabled(GL11.GL_BLEND), oldMask=GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int src=GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB), dst=GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int srcA=GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA), dstA=GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        try {
            RenderSystem.disableDepthTest(); RenderSystem.depthMask(false); RenderSystem.disableCull();
            RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.lineWidth(2);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram); RenderSystem.setShaderColor(1,1,1,1);
            BufferBuilder b=new BufferBuilder(2048); b.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
            batch.emit(b,matrices.peek().getPositionMatrix(),camera); BufferRenderer.drawWithGlobalProgram(b.end());
        } finally {
            RenderSystem.depthMask(oldMask); if(oldDepth)RenderSystem.enableDepthTest();else RenderSystem.disableDepthTest();
            if(oldCull)RenderSystem.enableCull();else RenderSystem.disableCull();
            if(oldBlend)RenderSystem.enableBlend();else RenderSystem.disableBlend();
            RenderSystem.blendFuncSeparate(src,dst,srcA,dstA); RenderSystem.lineWidth(oldWidth);
            RenderSystem.setShaderColor(oldColor[0],oldColor[1],oldColor[2],oldColor[3]);
            if(oldShader!=null)RenderSystem.setShader(()->oldShader); matrices.pop();
        }
    }
    static void box(BufferBuilder b,Matrix4f m,Box q,int c){
        double a=q.minX,d=q.minY,g=q.minZ,x=q.maxX,y=q.maxY,z=q.maxZ;
        line(b,m,a,d,g,x,d,g,c);line(b,m,x,d,g,x,d,z,c);line(b,m,x,d,z,a,d,z,c);line(b,m,a,d,z,a,d,g,c);
        line(b,m,a,y,g,x,y,g,c);line(b,m,x,y,g,x,y,z,c);line(b,m,x,y,z,a,y,z,c);line(b,m,a,y,z,a,y,g,c);
        line(b,m,a,d,g,a,y,g,c);line(b,m,x,d,g,x,y,g,c);line(b,m,x,d,z,x,y,z,c);line(b,m,a,d,z,a,y,z,c);
    }
    static void line(BufferBuilder b,Matrix4f m,double x0,double y0,double z0,double x1,double y1,double z1,int c){
        b.vertex(m,(float)x0,(float)y0,(float)z0).color((c>>>16)&255,(c>>>8)&255,c&255,255).next();
        b.vertex(m,(float)x1,(float)y1,(float)z1).color((c>>>16)&255,(c>>>8)&255,c&255,255).next();
    }
}
