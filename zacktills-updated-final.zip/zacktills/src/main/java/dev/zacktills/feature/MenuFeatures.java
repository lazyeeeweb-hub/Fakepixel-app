package dev.zacktills.feature;

import dev.zacktills.ZacktillsClient;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.client.gui.widget.TexturedButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MenuFeatures {
    private static final Set<String> EXTRA = Set.of("menu.sendFeedback", "menu.reportBugs", "gui.advancements", "gui.stats");
    private static final int ROW_HEIGHT = 20;
    private static final int GAP = 4;
    private static final int FULL_WIDTH = 204;
    private static final int HALF_WIDTH = 98;
    private static final int TITLE_LOGO_BOTTOM = 81; // 1.20.1 LogoDrawer: 30 + 44 - 7 + 14

    private MenuFeatures() {}

    public static void initialize(MinecraftClient mc, Screen screen, int width, int height) {
        if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
            // Mod Menu also edits the title buttons in AFTER_INIT (which can run after us).
            // Run once on the first render of each init, after all those edits are complete.
            ScreenEvents.beforeRender(screen).register(new ScreenEvents.BeforeRender() {
                private boolean laidOut;

                @Override
                public void beforeRender(Screen s, net.minecraft.client.gui.DrawContext context, int x, int y, float delta) {
                    if (laidOut) return;
                    laidOut = true;
                    List<ClickableWidget> buttons = Screens.getButtons(s);
                    buttons.removeIf(button -> {
                        String key = key(button);
                        return FeatureSettings.on("interface.realms") && (key.equals("menu.online") || key.equals("menu.realms"))
                                || FeatureSettings.on("interface.extras") && EXTRA.contains(key);
                    });
                    compactMenuRows(s, buttons, width, height);
                    buttons.add(ButtonWidget.builder(Text.literal("Zacktills"), b -> mc.setScreen(ZacktillsClient.config(s)))
                            .dimensions(4, 4, 90, 20).build());
                }
            });
        }
        if (screen instanceof GameMenuScreen) {
            ScreenEvents.afterRender(screen).register((s, c, x, y, delta) -> Playtime.render(mc, s, c));
        }
        if (screen instanceof HandledScreen<?>) {
            ItemFeatures.clearHovered();
            ScreenEvents.afterRender(screen).register((s, c, x, y, delta) -> ItemFeatures.trackHovered(s));
        }
    }

    private static String key(ClickableWidget widget) {
        return widget.getMessage().getContent() instanceof TranslatableTextContent text ? text.getKey() : "";
    }

    private static boolean mods(ClickableWidget button, String key) {
        String label = button.getMessage().getString().toLowerCase(Locale.ROOT);
        return key.startsWith("modmenu.") || label.equals("mods") || label.equals("mod menu");
    }

    private static void compactMenuRows(Screen screen, List<ClickableWidget> buttons, int width, int height) {
        List<ClickableWidget> controls = new ArrayList<>();
        List<ClickableWidget> optionIcons = new ArrayList<>();
        int titleBottom = screen instanceof TitleScreen ? TITLE_LOGO_BOTTOM : 0;
        for (int i = 0; i < buttons.size(); i++) {
            ClickableWidget button = buttons.get(i);
            String key = key(button);
            if (button instanceof TextWidget && button.getMessage().equals(screen.getTitle())) {
                titleBottom = Math.max(titleBottom, button.getY() + button.getHeight());
            } else if (key.equals("narrator.button.language") || key.equals("narrator.button.accessibility")) {
                optionIcons.add(button);
            } else if (button instanceof ButtonWidget pressable && (key.startsWith("menu.") || EXTRA.contains(key) || mods(button, key))) {
                // 1.20.1 exposes setWidth but no setHeight. Vanilla and plain Mod Menu buttons
                // are already 20 high; normalize an icon-only Mods entry to a normal button.
                if (button.getHeight() != ROW_HEIGHT || button instanceof TexturedButtonWidget) {
                    ClickableWidget replacement = ButtonWidget.builder(button.getMessage(), b -> pressable.onPress())
                            .dimensions(button.getX(), button.getY(), button.getWidth(), ROW_HEIGHT).build();
                    replacement.active = button.active;
                    replacement.visible = button.visible;
                    replacement.setTooltip(button.getTooltip());
                    buttons.set(i, replacement);
                    button = replacement;
                }
                controls.add(button);
            }
        }
        if (controls.isEmpty()) return;
        controls.sort(Comparator.comparingInt(ClickableWidget::getY).thenComparingInt(ClickableWidget::getX));
        List<List<ClickableWidget>> rows = new ArrayList<>();
        int originalY = Integer.MIN_VALUE;
        for (ClickableWidget button : controls) {
            if (rows.isEmpty() || button.getY() - originalY > 2 || rows.get(rows.size() - 1).size() == 2) {
                rows.add(new ArrayList<>(2));
                originalY = button.getY();
            }
            rows.get(rows.size() - 1).add(button);
        }
        int stackHeight = rows.size() * (ROW_HEIGHT + GAP) - GAP;
        int y = Math.max(titleBottom + 12, (height - stackHeight) / 2);
        if (screen instanceof TitleScreen) y = Math.max(y, height / 4 + 48);
        for (List<ClickableWidget> row : rows) {
            int buttonWidth = row.size() == 1 ? FULL_WIDTH : HALF_WIDTH;
            int rowWidth = row.size() * buttonWidth + (row.size() - 1) * GAP;
            int x = (width - rowWidth) / 2;
            for (ClickableWidget button : row) {
                button.setWidth(buttonWidth);
                button.setX(x);
                button.setY(y);
                x += buttonWidth + GAP;
            }
            if (screen instanceof TitleScreen && row.stream().anyMatch(b -> key(b).equals("menu.options"))) {
                for (ClickableWidget icon : optionIcons) {
                    icon.setX(width / 2 + (key(icon).equals("narrator.button.language") ? -124 : 104));
                    icon.setY(y);
                }
            }
            y += ROW_HEIGHT + GAP;
        }
    }
}
