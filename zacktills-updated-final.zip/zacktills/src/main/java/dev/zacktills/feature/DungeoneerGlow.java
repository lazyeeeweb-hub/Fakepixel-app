package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

public final class DungeoneerGlow {
    private static final String GROUP = "dungeoneer.";
    private static final String BOX_STYLE = "Box through walls";
    private static final int DEFAULT_COLOR = 0xFF0000;
    private static final Pattern HEX = Pattern.compile("[0-9a-fA-F]{6}");
    private static ClientWorld world;
    private static boolean active;
    private static int ticksUntilDetection;
    private static Set<Integer> targets = Set.of();
    private static String lastExtraTypes;
    private static Set<Identifier> extraTypes = Set.of();
    private static String lastColor;
    private static int color = DEFAULT_COLOR;

    private DungeoneerGlow() {}

    public static void initialize() {
        WorldRenderEvents.LAST.register(DungeoneerGlow::renderBoxes);
    }

    public static void reset() {
        world = null;
        active = false;
        ticksUntilDetection = 0;
        targets = Set.of();
    }

    public static void tick(MinecraftClient client) {
        if (world != client.world) reset();
        ClientPlayNetworkHandler network = client.getNetworkHandler();
        if (!FeatureSettings.on(GROUP + "enabled") || client.world == null || client.player == null || network == null) {
            reset();
            return;
        }
        world = client.world;
        if (--ticksUntilDetection <= 0) {
            active = detectsDungeon(TabParts.orderedDisplayLines(client), FeatureSettings.text(GROUP + "area_label"),
                    FeatureSettings.text(GROUP + "area_contains"), FeatureSettings.text(GROUP + "area_ignore"));
            ticksUntilDetection = 20;
        }
        if (!active) {
            targets = Set.of();
            return;
        }

        String typeSetting = FeatureSettings.text(GROUP + "extra_types");
        if (!typeSetting.equals(lastExtraTypes)) {
            lastExtraTypes = typeSetting;
            extraTypes = parseTypes(typeSetting);
        }
        String colorSetting = FeatureSettings.text(GROUP + "color");
        if (!colorSetting.equals(lastColor)) {
            lastColor = colorSetting;
            color = parseColor(colorSetting);
        }
        String extraName = TextKey.normalize(FeatureSettings.text(GROUP + "extra_name"));
        double distance = FeatureSettings.number(GROUP + "distance");
        double distanceSquared = distance * distance;
        Vec3d camera = ArmorStandLimiter.cameraPosition(client);
        Box area = new Box(camera, camera).expand(distance);
        Set<Integer> next = new HashSet<>();
        for (Entity entity : world.getOtherEntities(client.player, area, candidate ->
                candidate.isAlive() && !(candidate instanceof ArmorStandEntity)
                        && candidate.squaredDistanceTo(camera) <= distanceSquared)) {
            if (entity instanceof PlayerEntity player) {
                // Players in tab are never matched, even by an explicit extra rule.
                if (isFakePlayer(client, network, player)) next.add(entity.getId());
                continue;
            }
            if ((entity instanceof LivingEntity && (entity instanceof HostileEntity || entity instanceof Monster))
                    || extraTypes.contains(Registries.ENTITY_TYPE.getId(entity.getType()))) {
                next.add(entity.getId());
            } else if (!extraName.isEmpty()) {
                Text name = entity.getCustomName();
                if (name != null && TextKey.normalize(name.getString()).contains(extraName)) next.add(entity.getId());
            }
        }
        targets = next;
    }

    static boolean detectsDungeon(List<Text> lines, String label, String required, String ignored) {
        String areaLabel = TextKey.normalize(label);
        String mustContain = required.strip().toLowerCase(Locale.ROOT);
        String mustNotContain = ignored.strip().toLowerCase(Locale.ROOT);
        if (areaLabel.isEmpty() || mustContain.isEmpty()) return false;
        for (Text line : lines) {
            String plain = Formatting.strip(line.getString());
            int colon = plain.indexOf(':');
            if (colon <= 0 || !TextKey.normalize(plain.substring(0, colon)).equals(areaLabel)) continue;
            String value = plain.substring(colon + 1).toLowerCase(Locale.ROOT);
            if (value.contains(mustContain) && (mustNotContain.isEmpty() || !value.contains(mustNotContain))) return true;
        }
        return false;
    }

    private static boolean isFakePlayer(MinecraftClient client, ClientPlayNetworkHandler network, PlayerEntity player) {
        return player != client.player && network != null && network.getPlayerListEntry(player.getUuid()) == null;
    }

    private static boolean ready(MinecraftClient client) {
        return world != null && world == client.world && active && FeatureSettings.on(GROUP + "enabled");
    }

    private static boolean stillEligible(MinecraftClient client, Entity entity) {
        return entity.getWorld() == world && entity.isAlive() && !(entity instanceof ArmorStandEntity)
                && (!(entity instanceof PlayerEntity player) || isFakePlayer(client, client.getNetworkHandler(), player));
    }

    public static boolean hasOutline(Entity entity) {
        if (world == null || entity.getWorld() != world || !targets.contains(entity.getId())) return false;
        MinecraftClient client = MinecraftClient.getInstance();
        return ready(client) && !boxStyle() && stillEligible(client, entity);
    }

    public static int outlineColor() { return color; }

    private static boolean boxStyle() { return BOX_STYLE.equals(FeatureSettings.choiceValue(GROUP + "style")); }

    public static void addTargetedMob() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!FeatureSettings.on(GROUP + "enabled")) {
            message(client, "Dungeoneer glow is off. Enable it first.");
            return;
        }
        if (!ready(client)) {
            message(client, "No dungeon detected. Check your tab area settings.");
            return;
        }
        Entity target = client.targetedEntity;
        if (target == null || target.getWorld() != world || !target.isAlive()) {
            message(client, "No entity under the crosshair.");
            return;
        }
        Identifier id = Registries.ENTITY_TYPE.getId(target.getType());
        String setting = FeatureSettings.text(GROUP + "extra_types");
        if (parseTypes(setting).contains(id)) {
            message(client, id + " is already in Extra entity types.");
            return;
        }
        Set<String> tokens = new LinkedHashSet<>();
        for (String entry : setting.split(",")) if (!entry.isBlank()) tokens.add(entry.strip());
        tokens.add(id.toString());
        FeatureSettings.text(GROUP + "extra_types", String.join(", ", tokens));
        FeatureSettings.save();
        message(client, "Added " + id + " to Extra entity types.");
    }

    private static void message(MinecraftClient client, String text) {
        client.inGameHud.getChatHud().addMessage(Text.literal("[Zacktills] " + text));
    }

    private static Set<Identifier> parseTypes(String value) {
        Set<Identifier> ids = new HashSet<>();
        for (String entry : value.split(",")) {
            if (entry.isBlank()) continue;
            Identifier id = Identifier.tryParse(entry.strip());
            if (id != null) ids.add(id);
        }
        return ids;
    }

    private static int parseColor(String value) {
        String hex = value.strip();
        if (hex.startsWith("#")) hex = hex.substring(1);
        return HEX.matcher(hex).matches() ? Integer.parseInt(hex, 16) : DEFAULT_COLOR;
    }

    private static void renderBoxes(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!ready(client) || context.world() != world || !boxStyle() || targets.isEmpty()) return;
        List<Box> boxes = new ArrayList<>();
        for (int id : targets) {
            Entity entity = world.getEntityById(id);
            if (entity != null && stillEligible(client, entity)) {
                Vec3d shift = entity.getLerpedPos(context.tickDelta()).subtract(entity.getPos());
                boxes.add(entity.getBoundingBox().offset(shift));
            }
        }
        if (!boxes.isEmpty()) ThroughWallLines.draw(context, (buffer, matrix, camera) -> {
            for (Box box : boxes) ThroughWallLines.box(buffer, matrix, box, color);
        });
    }
}
