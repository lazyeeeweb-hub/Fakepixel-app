package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.minecraft.inventory.CraftingResultInventory;
import net.minecraft.screen.BrewingStandScreenHandler;
import net.minecraft.screen.LoomScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.CraftingResultSlot;
import net.minecraft.screen.slot.FurnaceOutputSlot;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.TradeOutputSlot;

public final class QuickDropFeature {
    public static final int BUTTON_SIZE = 14;
    private static final int HIT_SIZE = 20;
    private static final int INSET = (HIT_SIZE - BUTTON_SIZE) / 2;
    private static boolean on;

    private QuickDropFeature() {}

    public static boolean available() {
        return FeatureSettings.boolValue("inventory.quick_drop_button", true);
    }

    public static boolean isOn() {
        return on;
    }

    public static void toggle() {
        on = !on;
    }

    /** Call on the client thread when disconnecting or changing worlds. */
    public static void reset() {
        on = false;
    }

    public static ButtonBounds buttonBounds(int x, int y, int backgroundWidth, int screenWidth, int screenHeight) {
        if (screenHeight < HIT_SIZE) return null;
        int left = x + backgroundWidth;
        if (left < 0 || left > screenWidth - HIT_SIZE) left = x - HIT_SIZE;
        if (left < 0 || left > screenWidth - HIT_SIZE) return null;
        return new ButtonBounds(left, Math.max(0, Math.min(y, screenHeight - HIT_SIZE)));
    }

    public record ButtonBounds(int left, int top) {
        public int buttonX() { return left + INSET; }
        public int buttonY() { return top + INSET; }

        public boolean contains(double x, double y) {
            return x >= left && x < left + HIT_SIZE && y >= top && y < top + HIT_SIZE;
        }
    }

    public static boolean isResultSlot(ScreenHandler handler, Slot slot) {
        // In 1.20.1, CraftingResultInventory also backs anvil/smithing, grindstone,
        // cartography and stonecutter results. The loom uses a SimpleInventory.
        return slot.inventory instanceof CraftingResultInventory
                || slot instanceof CraftingResultSlot
                || slot instanceof FurnaceOutputSlot
                || slot instanceof TradeOutputSlot
                || (handler instanceof LoomScreenHandler && slot.id == 3)
                // The three bottle slots are both brewing inputs and outputs.
                || (handler instanceof BrewingStandScreenHandler && slot.id >= 0 && slot.id < 3);
    }
}
