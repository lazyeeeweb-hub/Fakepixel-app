package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.HandledScreenAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.item.TooltipData;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

public final class TooltipFeatures {
    private static final int TOP = 8;
    private static final int SIDE_MARGIN = 6;
    private static final int MIN_HIT = 14;
    private static final long GENERIC_LIFETIME = TimeUnit.MILLISECONDS.toNanos(200);

    // The remembered slot identity/offset outlive the visible panel and any hover gap.
    private static StackKey slotKey;
    private static double slotOffset;
    private static Panel slotPanel;
    private static Panel genericPanel;
    private static Panel captured;
    private static SlotDraw slotDraw;

    private TooltipFeatures() {}

    private record StackKey(int slotId, int hash, ItemStack snapshot) {
        private static int hash(ItemStack stack) {
            return (31 * stack.getItem().hashCode() + stack.getCount()) * 31
                    + Objects.hashCode(stack.getNbt());
        }

        static StackKey of(Slot slot, ItemStack stack) {
            return new StackKey(slot.id, hash(stack), stack.copy());
        }

        boolean matches(Slot slot, ItemStack stack) {
            return slotId == slot.id && hash == hash(stack) && ItemStack.areEqual(snapshot, stack);
        }
    }

    private record SlotDraw(HandledScreen<?> screen, Slot slot, DrawContext context) {}

    /** Keep the exact vanilla text/data-to-component pipeline, with an explicit source slot. */
    public static void drawSlot(DrawContext context, HandledScreen<?> screen, Slot slot,
                                TextRenderer font, List<Text> text, Optional<TooltipData> data, int x, int y) {
        StackKey previousKey = slotKey;
        ItemStack stack = slot.getStack();
        if (FeatureSettings.on("tooltip.scroll") && (previousKey == null || !previousKey.matches(slot, stack))) {
            slotKey = StackKey.of(slot, stack);
            slotOffset = 0;
            hideSlot();
        }
        SlotDraw previousDraw = slotDraw;
        slotDraw = new SlotDraw(screen, slot, context);
        try {
            context.drawTooltip(font, text, data, x, y);
        } finally {
            slotDraw = previousDraw;
        }
    }

    public static void hideSlot() {
        slotPanel = null;
    }

    public static Slot retainedSlot(HandledScreen<?> screen, Slot focused, int x, int y) {
        Panel panel = slotPanel;
        if (!validSlot(panel, screen)) {
            hideSlot();
            return null;
        }
        if (panel == captured || panel.inScrollbar(x, y)
                || ((focused == null || !focused.hasStack()) && (panel.contains(x, y) || panel.inBridge(screen, x, y)))) {
            return panel.slot;
        }
        return null;
    }

    private static boolean validSlot(Panel panel, HandledScreen<?> screen) {
        return FeatureSettings.on("tooltip.scroll") && panel != null && panel.screen.get() == screen
                && screen instanceof HandledScreenAccess && screen.getScreenHandler().getCursorStack().isEmpty()
                && screen.getScreenHandler().slots.contains(panel.slot) && panel.slot.isEnabled()
                && panel.slot.hasStack() && slotKey.matches(panel.slot, panel.slot.getStack());
    }

    public static boolean draw(DrawContext context, TextRenderer font, List<TooltipComponent> parts,
                               int mouseX, int mouseY, TooltipPositioner positioner) {
        SlotDraw source = slotDraw != null && slotDraw.context == context ? slotDraw : null;
        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        int viewport = height - 2 * TOP;
        int contentHeight = parts.size() > 1 ? 2 : 0;
        int contentWidth = 0;
        for (TooltipComponent part : parts) {
            contentHeight += part.getHeight();
            contentWidth = Math.max(contentWidth, part.getWidth(font));
        }
        if (!FeatureSettings.on("tooltip.scroll") || parts.isEmpty() || contentHeight <= viewport
                || viewport < MIN_HIT || width < MIN_HIT) {
            if (source != null) hideSlot();
            return false;
        }
        Screen screen = source == null ? MinecraftClient.getInstance().currentScreen : source.screen;
        if (screen == null) return false;
        Panel panel = source == null ? genericPanel : slotPanel;
        long now = System.nanoTime();
        boolean reuse = panel != null && panel.screen.get() == screen
                && (source != null ? panel.slot == source.slot
                : panel == captured || (now - panel.lastDraw <= GENERIC_LIFETIME
                        && panel.contentHeight == contentHeight && panel.contentWidth == contentWidth));
        int panelWidth = clamp(contentWidth, 1, width - 2 * SIDE_MARGIN);
        int maxLeft = width - panelWidth - SIDE_MARGIN;
        if (!reuse) {
            int left = clamp(mouseX + 12, SIDE_MARGIN, maxLeft);
            panel = new Panel(screen, source == null ? null : source.slot, left);
        }
        // Keep the initial anchor so moving from the slot to the tooltip doesn't move the thumb.
        panel.left = clamp(panel.left, SIDE_MARGIN, maxLeft);
        panel.width = panelWidth;
        int hitRight = panel.left == maxLeft ? width : panel.left + panelWidth + 4;
        // Stay inside the popup where possible; keep all 14 pixels available at the screen edge.
        panel.scrollbarLeft = Math.min(width - MIN_HIT, Math.max(panel.left - 4, hitRight - MIN_HIT));
        panel.viewport = viewport;
        panel.contentHeight = contentHeight;
        panel.contentWidth = contentWidth;
        panel.lastDraw = now;
        if (source != null) slotPanel = panel;
        else genericPanel = panel;
        render(context, font, parts, panel);
        return true;
    }

    private static void render(DrawContext context, TextRenderer font, List<TooltipComponent> parts,
                               Panel panel) {
        int textX = panel.left;
        int right = textX + panel.width;
        int thumbTop = panel.thumbTop();
        int bottom = TOP + panel.viewport;
        int startY = TOP - (int) panel.offset();
        context.draw();
        context.getMatrices().push();
        try {
            context.getMatrices().translate(0, 0, 600);
            context.fill(textX - 4, TOP - 4, right + 4, bottom + 4, 0xF0100010);
            HudFeatures.outline(context, textX - 4, TOP - 4, panel.width + 8, panel.viewport + 8, 0xFF75659B);
            context.fill(right + 1, thumbTop, right + 3, thumbTop + panel.thumbHeight(), 0xFFBDA7FF);
            context.draw();
            context.enableScissor(textX, TOP, right, bottom);
            try {
                int lineY = startY;
                for (int i = 0; i < parts.size(); i++) {
                    TooltipComponent part = parts.get(i);
                    part.drawText(font, textX, lineY, context.getMatrices().peek().getPositionMatrix(), context.getVertexConsumers());
                    lineY += part.getHeight() + (i == 0 ? 2 : 0);
                }
                context.draw();
                lineY = startY;
                for (int i = 0; i < parts.size(); i++) {
                    TooltipComponent part = parts.get(i);
                    part.drawItems(font, textX, lineY, context);
                    lineY += part.getHeight() + (i == 0 ? 2 : 0);
                }
                context.draw();
            } finally {
                context.disableScissor();
            }
        } finally {
            context.getMatrices().pop();
        }
    }

    public static boolean scroll(Screen screen, double x, double y, double amount) {
        if (!Double.isFinite(amount) || amount == 0) return false;
        Panel panel = inputPanel(screen, x, y);
        if (panel == null) return false;
        panel.setOffset(panel.offset() - amount * 12);
        return true;
    }

    public static boolean press(Screen screen, double x, double y) {
        captured = null;
        if (screen == null || !FeatureSettings.on("tooltip.scroll")) return false;
        // Panel, slot and bridge hits matter for the wheel, but only a thumb can claim a press.
        Panel panel = slotPanel;
        if (!(screen instanceof HandledScreen<?> handled) || !validSlot(panel, handled) || !panel.hitsThumb(x, y)) {
            panel = activeGeneric(screen);
            if (panel == null || !panel.hitsThumb(x, y)) return false;
        }
        panel.grabY = Math.max(0, Math.min(panel.thumbHeight(), y - panel.thumbTop()));
        captured = panel;
        return true;
    }

    public static void drag(Screen screen, double y) {
        Panel panel = captured;
        if (panel == null || screen == null || panel.screen.get() != screen
                || !FeatureSettings.on("tooltip.scroll")) return;
        if (panel.slot != null ? !(screen instanceof HandledScreen<?> handled)
                || slotPanel != panel || !validSlot(panel, handled) : genericPanel != panel) return;
        panel.setOffset((y - panel.grabY - TOP) / panel.travel() * panel.maxOffset());
    }

    public static boolean release(Screen screen, double y) {
        if (captured == null) return false;
        drag(screen, y);
        captured = null;
        return true;
    }

    private static Panel inputPanel(Screen screen, double x, double y) {
        if (screen == null || !FeatureSettings.on("tooltip.scroll")) return null;
        Panel panel = slotPanel;
        if (screen instanceof HandledScreen<?> handled && validSlot(panel, handled)
                && (panel == captured || panel.contains(x, y) || panel.inScrollbar(x, y)
                        || panel.overSlot(handled, x, y) || panel.inBridge(handled, x, y))) return panel;
        return activeGeneric(screen);
    }

    private static Panel activeGeneric(Screen screen) {
        Panel panel = genericPanel;
        if (panel != null && panel.screen.get() == screen
                && (panel == captured || System.nanoTime() - panel.lastDraw <= GENERIC_LIFETIME)) return panel;
        return null;
    }

    private static int clamp(int n, int min, int max) {
        return Math.max(min, Math.min(max, n));
    }

    private static final class Panel {
        final WeakReference<Screen> screen;
        final Slot slot;
        int left, width, viewport, contentHeight, contentWidth, scrollbarLeft;
        long lastDraw;
        double genericOffset, grabY;

        Panel(Screen screen, Slot slot, int left) {
            this.screen = new WeakReference<>(screen);
            this.slot = slot;
            this.left = left;
        }

        int maxOffset() { return contentHeight - viewport; }
        double offset() { return Math.max(0, Math.min(maxOffset(), slot == null ? genericOffset : slotOffset)); }
        void setOffset(double offset) {
            double clamped = Math.max(0, Math.min(maxOffset(), offset));
            if (slot == null) genericOffset = clamped;
            else slotOffset = clamped;
        }

        int thumbHeight() { return Math.min(viewport - 1, Math.max(8, (int) ((long) viewport * viewport / contentHeight))); }
        int travel() { return viewport - thumbHeight(); }
        int thumbTop() { return TOP + (int) Math.round(travel() * offset() / maxOffset()); }

        boolean hitsThumb(double x, double y) {
            int hitHeight = Math.max(MIN_HIT, thumbHeight());
            int hitTop = clamp(thumbTop() - (hitHeight - thumbHeight()) / 2, TOP, TOP + viewport - hitHeight);
            return inScrollbar(x, y) && y >= hitTop && y < hitTop + hitHeight;
        }

        boolean inScrollbar(double x, double y) {
            return x >= scrollbarLeft && x < scrollbarLeft + MIN_HIT && y >= TOP && y < TOP + viewport;
        }

        boolean contains(double x, double y) {
            return x >= left - 4 && x < left + width + 4 && y >= TOP - 4 && y < TOP + viewport + 4;
        }

        boolean overSlot(HandledScreen<?> screen, double x, double y) {
            HandledScreenAccess access = (HandledScreenAccess) screen;
            int sx = access.zacktills$x() + slot.x;
            int sy = access.zacktills$y() + slot.y;
            return x >= sx - 1 && x < sx + 17 && y >= sy - 1 && y < sy + 17;
        }

        boolean inBridge(HandledScreen<?> screen, double x, double y) {
            HandledScreenAccess access = (HandledScreenAccess) screen;
            int sx = access.zacktills$x() + slot.x;
            int sy = access.zacktills$y() + slot.y;
            return y >= sy - 1 && y < sy + 17 && x >= Math.min(sx - 1, scrollbarLeft)
                    && x < Math.max(sx + 17, scrollbarLeft + MIN_HIT);
        }
    }
}
