package dev.zacktills.feature;

import java.util.Locale;
import java.util.regex.Pattern;

/** Stable keys for labels whose displayed counters can change. */
public final class TextKey {
    private static final Pattern FORMATTING = Pattern.compile("(?i)§(?:#[0-9a-f]{6}|[0-9a-fk-orx])");
    private static final Pattern ROMAN = Pattern.compile(
            "(?i)(?<![\\p{L}\\p{N}_])(?=[ivxlcdm])m{0,4}(?:cm|cd|d?c{0,3})"
                    + "(?:xc|xl|l?x{0,3})(?:ix|iv|v?i{0,3})(?![\\p{L}\\p{N}_])");
    private static final Pattern NUMBERS = Pattern.compile("(?:[+−-](?=\\p{Nd}))?(?:[,.](?=\\p{Nd}))?\\p{Nd}+(?:[,.]\\p{Nd}+)*");
    private static final Pattern SPACES = Pattern.compile("\\s+", Pattern.UNICODE_CHARACTER_CLASS);
    private static final Pattern EDGE_COLONS = Pattern.compile("^(?:[:：] *)+|(?: *[:：])+$");

    private TextKey() {}

    public static String normalize(String text) {
        if (text == null) return "";
        String plain = FORMATTING.matcher(text).replaceAll("");
        plain = ROMAN.matcher(plain).replaceAll(" ");
        plain = NUMBERS.matcher(plain).replaceAll("").replace("%", "").replace("％", "");
        plain = SPACES.matcher(plain).replaceAll(" ").strip();
        return EDGE_COLONS.matcher(plain).replaceAll("").strip().toLowerCase(Locale.ROOT);
    }
}
