package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Supplier;

/** Packet-expanded particle evidence, render overlay, and public root integration hooks. */
public final class ParticleEsp {
    private static final int MAX_SPAWNS_PER_PACKET = 256;
    private static final long DEBUG_INTERVAL_NS = 1_000_000_000L;
    private static final double WINDOW_SECONDS = 1.0;
    private static final int MAX_TARGETS = 3;
    private static volatile List<BlockPos> currentTargets = List.of();
    private static final ParticleTracker TRACKER = new ParticleTracker();
    private static final List<Spawn> PACKET_SPAWNS = new ArrayList<>();
    private static final Map<String, Long> DEBUG_COUNTS = new TreeMap<>();
    private static ParticleS2CPacket activePacket;
    private static boolean captureSelected;
    private static boolean initialized;
    private static boolean previousDebug;
    private static long nextDebugAt;
    private static int debugCursor;
    private static net.minecraft.client.world.ClientWorld trackedWorld;
    private static boolean wasAlive;

    private ParticleEsp() { }

    /** Root calls once from client initialization. */
    public static void initialize() {
        if (initialized) return;
        initialized = true;
        // Never carry an armed breaker across client startup / a saved configuration load.
        FeatureSettings.setBool("particle.auto_break", false);
        FeatureSettings.save();
        WorldRenderEvents.LAST.register(ParticleEsp::render);
    }

    /** Root calls once per END_CLIENT_TICK. */
    public static void tick(MinecraftClient client) {
        if (client == null) return;
        if (client.world != trackedWorld) {
            if (trackedWorld != null) resetSession(client);
            trackedWorld = client.world;
            wasAlive = client.player != null && !client.player.isDead();
        }
        PlayerEntity player = client.player;
        if (client.world == null || player == null) {
            ParticleBreaker.cancel(client);
            return;
        }
        if (player.isDead()) {
            if (wasAlive) resetSession(client);
            wasAlive = false;
            ParticleBreaker.cancel(client);
            return;
        }
        wasAlive = true;
        TRACKER.beginTick();
        updateDebug(client);
        boolean active = FeatureSettings.on("particle.enabled") || FeatureSettings.boolValue("particle.auto_break", false);
        List<BlockPos> targets = active
                ? TRACKER.findTargets(client.world, player, (int) FeatureSettings.number("particle.min_count"),
                    MAX_TARGETS, WINDOW_SECONDS, ParticleBreaker.freshAfterNanos())
                : List.of();
        currentTargets = targets;
        ParticleBreaker.tick(client, targets, TRACKER);
    }

    /** Reset transient evidence/debug state; root may call this on disconnect or session changes. */
    public static void reset() {
        resetSession(MinecraftClient.getInstance());
        trackedWorld = MinecraftClient.getInstance().world;
        PlayerEntity player = MinecraftClient.getInstance().player;
        wasAlive = player != null && !player.isDead();
    }

    /** Root binds this to R; the option itself is off by default and saved with other settings. */
    public static void toggleAutoBreak() {
        boolean enabled = !FeatureSettings.boolValue("particle.auto_break", false);
        FeatureSettings.setBool("particle.auto_break", enabled);
        FeatureSettings.save();
        MinecraftClient client = MinecraftClient.getInstance();
        if (!enabled) ParticleBreaker.cancel(client);
        if (client.player != null) {
            client.player.sendMessage(net.minecraft.text.Text.literal(
                    enabled ? "[Particle ESP] Auto-break armed." : "[Particle ESP] Auto-break disarmed."), false);
        }
    }

    /** Called by the mixin after forceMainThread and before vanilla expands the packet. */
    public static void beginPacketCapture(ParticleS2CPacket packet) {
        activePacket = packet;
        PACKET_SPAWNS.clear();
        Identifier id = particleId(packet.getParameters());
        captureSelected = isSelected(id) && (FeatureSettings.on("particle.enabled")
                || FeatureSettings.boolValue("particle.auto_break", false));
    }

    /** Mixin @ModifyArgs observer. The coordinates are passed through unchanged to vanilla. */
    public static void observeVanillaParticle(double x, double y, double z) {
        if (activePacket == null || !captureSelected || PACKET_SPAWNS.size() >= MAX_SPAWNS_PER_PACKET
                || !Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) return;
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (player == null || player.squaredDistanceTo(x, y, z) > ParticleTracker.MAX_RADIUS_SQUARED) return;
        PACKET_SPAWNS.add(new Spawn(x, y, z));
    }

    /** Mixin calls this at handler TAIL on the main thread. */
    public static void onParticle(ParticleS2CPacket packet) {
        if (FeatureSettings.on("particle.debug")) {
            String id = particleId(packet.getParameters()).toString();
            DEBUG_COUNTS.merge(id, (long) Math.max(1, packet.getCount()), Long::sum);
        }
        if (activePacket == packet) {
            if (captureSelected) {
                Identifier id = particleId(packet.getParameters());
                long now = System.nanoTime();
                for (Spawn spawn : PACKET_SPAWNS) TRACKER.add(id, spawn.x, spawn.y, spawn.z, now);
            }
            PACKET_SPAWNS.clear();
            activePacket = null;
            captureSelected = false;
        }
    }

    private static Identifier particleId(ParticleEffect effect) {
        Identifier id = Registries.PARTICLE_TYPE.getId(effect.getType());
        return id == null ? new Identifier("minecraft", "unknown") : id;
    }

    private static Set<Identifier> selectedTypes() {
        Set<Identifier> selected = new HashSet<>();
        String value = FeatureSettings.text("particle.types");
        for (String token : value.split(",")) {
            Identifier id = Identifier.tryParse(token.trim());
            if (id != null) selected.add(id);
        }
        return selected;
    }

    private static boolean isSelected(Identifier id) { return selectedTypes().contains(id); }

    private static void updateDebug(MinecraftClient client) {
        boolean enabled = FeatureSettings.on("particle.debug");
        if (!enabled) {
            previousDebug = false;
            return;
        }
        if (!previousDebug) {
            DEBUG_COUNTS.clear();
            debugCursor = 0;
            nextDebugAt = 0;
        }
        previousDebug = true;
        long now = System.nanoTime();
        if (client.player == null || now < nextDebugAt || DEBUG_COUNTS.isEmpty()) return;
        List<Map.Entry<String, Long>> entries = new ArrayList<>(DEBUG_COUNTS.entrySet());
        if (debugCursor >= entries.size()) debugCursor = 0;
        Map.Entry<String, Long> entry = entries.get(debugCursor++);
        client.player.sendMessage(net.minecraft.text.Text.literal(
                "[Particle ESP DEBUG] " + entry.getKey() + " = " + entry.getValue()), false);
        nextDebugAt = now + DEBUG_INTERVAL_NS;
    }

    private static void resetSession(MinecraftClient client) {
        TRACKER.reset();
        currentTargets = List.of();
        DEBUG_COUNTS.clear();
        PACKET_SPAWNS.clear();
        activePacket = null;
        captureSelected = false;
        debugCursor = 0;
        nextDebugAt = 0;
        previousDebug = false;
        // reset() is also used by root on JOIN/DISCONNECT; don't persist an armed state across servers.
        FeatureSettings.setBool("particle.auto_break", false);
        FeatureSettings.save();
        ParticleBreaker.reset(client);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!FeatureSettings.on("particle.enabled") || client.world == null || client.player == null) return;
        List<BlockPos> targets = currentTargets;
        if (targets.isEmpty()) return;

        int rgb = parseColor(FeatureSettings.text("particle.color"));
        Vec3d cameraPos = context.camera().getPos();
        ThroughWallLines.draw(context, (buffer, matrix, camera) -> {
            for (BlockPos pos : targets) {
                ThroughWallLines.box(buffer, matrix, new Box(pos).expand(.002), rgb);
                if (FeatureSettings.on("particle.tracer")) {
                    Vec3d center = Vec3d.ofCenter(pos);
                    ThroughWallLines.line(buffer, matrix, camera.x,camera.y,camera.z,
                            center.x,center.y,center.z,rgb);
                }
            }
        });
        if (FeatureSettings.on("particle.distance")) drawDistanceLabels(context, targets, rgb);
    }

    private static int parseColor(String value) {
        try {
            String hex = value == null ? "" : value.trim().replace("#", "");
            return hex.length() == 6 ? Integer.parseInt(hex, 16) : 0x00FFFF;
        } catch (RuntimeException ignored) { return 0x00FFFF; }
    }

    private static void drawDistanceLabels(WorldRenderContext context, List<BlockPos> targets, int rgb) {
        MinecraftClient client = MinecraftClient.getInstance();
        Camera camera = context.camera();
        Vec3d cameraPos = camera.getPos();
        BufferBuilder textBuffer = new BufferBuilder(256);
        VertexConsumerProvider.Immediate immediate = VertexConsumerProvider.immediate(textBuffer);
        for (BlockPos pos : targets) {
            Vec3d center = Vec3d.ofCenter(pos);
            double distance = cameraPos.distanceTo(center);
            String label = String.format(Locale.ROOT, "%.1fm", distance);
            MatrixStack matrices = new MatrixStack();
            matrices.translate(center.x-cameraPos.x, center.y-cameraPos.y, center.z-cameraPos.z);
            matrices.multiply(camera.getRotation());
            matrices.scale(-.025F,-.025F,.025F);
            matrices.translate(0, -10, 0);
            int color = 0xFF000000 | (rgb & 0xFFFFFF);
            client.textRenderer.draw(label, -client.textRenderer.getWidth(label)/2.0F, 0,
                    color, false, matrices.peek().getPositionMatrix(), immediate,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0, LightmapTextureManager.MAX_LIGHT_COORDINATE);
        }
        immediate.draw();
    }

    private record Spawn(double x, double y, double z) { }
}
