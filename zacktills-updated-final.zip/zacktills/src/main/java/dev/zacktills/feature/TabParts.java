package dev.zacktills.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.zacktills.config.ConfigModel.Range;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.PlayerListHudAccess;
import dev.zacktills.ui.HudEditorScreen;
import dev.zacktills.ui.TabPartsScreen;
import dev.zacktills.ui.TabPickerScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;
import net.minecraft.text.OrderedText;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.Map;

public final class TabParts {
    public enum Kind { LINE, SECTION }
    // The first occurrence is stored without an index. Later occurrences are zero-based.
    public record Ref(Kind kind, String key, Integer occurrence) {
        public Ref {
            key = TextKey.normalize(key);
            if (occurrence != null && occurrence <= 0) occurrence = null;
        }
        private int index() { return occurrence == null ? 0 : occurrence; }
    }
    public record Row(Text text, Ref line, Ref section) {}
    private record Match(Ref ref, String rawLabel, List<Text> lines) {}
    private record Label(Kind kind, String key) {}
    private record Snapshot(List<Row> rows, Map<Label, List<Match>> exact, List<Match> ordered) {
        private static final Snapshot EMPTY = new Snapshot(List.of(), Map.of(), List.of());

        Match find(Ref ref) {
            if (ref == null) return null;
            List<Match> matches = exact.get(new Label(ref.kind(), ref.key()));
            if (matches != null) return ref.index() < matches.size() ? matches.get(ref.index()) : null;
            if (ref.key().isEmpty()) return null;
            int index = ref.index();
            for (Match match : ordered) {
                if (match.ref().kind() == ref.kind() && match.ref().key().startsWith(ref.key()) && index-- == 0) return match;
            }
            return null;
        }
    }

    private static final Logger LOG = LoggerFactory.getLogger("zacktills/tab-parts");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zacktills/tab_parts.json");
    private static final Map<String, Part> PARTS = new LinkedHashMap<>();
    private static Snapshot snapshot = Snapshot.EMPTY;
    private static ClientPlayNetworkHandler connection;
    private static int ticksUntilRefresh;
    private static boolean persistentTab;

    private TabParts() {}

    public static boolean showVanillaTab() { return persistentTab; }
    public static void toggleVanillaTab() { persistentTab = !persistentTab; }
    public static List<Row> rows() { return snapshot.rows(); }
    public static List<Part> parts() { return List.copyOf(PARTS.values()); }
    public static boolean contains(Ref ref) {
        return ref != null && PARTS.values().stream().anyMatch(part -> sameTarget(part.ref(), ref));
    }

    public static boolean sameTarget(Ref first, Ref second) {
        if (first == null || second == null) return false;
        if (first.equals(second)) return true;
        Match a = snapshot.find(first), b = snapshot.find(second);
        return a != null && a == b;
    }

    public static List<Text> liveLines(Ref ref) {
        Match match = snapshot.find(ref);
        return match == null ? List.of() : match.lines();
    }

    public static void openManager() {
        var client = MinecraftClient.getInstance();
        FeatureSettings.save();
        client.setScreen(new TabPartsScreen(client.currentScreen));
    }

    public static void tick(MinecraftClient client) {
        var current = client.getNetworkHandler();
        if (client.world == null || current == null) {
            if (connection != null) disconnect();
            return;
        }
        if (current != connection || --ticksUntilRefresh <= 0) {
            if (connection != current) PARTS.values().forEach(Part::clearLive);
            connection = current;
            ticksUntilRefresh = 10;
            snapshot = buildSnapshot(orderedDisplayLines(client));
            PARTS.values().forEach(Part::live);
        }
    }

    // Use the same sorted/capped entries and styled display names as the vanilla HUD.
    static List<Text> orderedDisplayLines(MinecraftClient client) {
        if (client.world == null || client.getNetworkHandler() == null) return List.of();
        var hud = client.inGameHud.getPlayerListHud();
        var entries = ((PlayerListHudAccess) hud).zacktills$collectPlayerEntries();
        return entries.stream().map(hud::getPlayerName).toList();
    }

    public static void disconnect() {
        connection = null;
        snapshot = Snapshot.EMPTY;
        persistentTab = false;
        PARTS.values().forEach(Part::clearLive);
    }

    static Snapshot buildSnapshot(List<Text> entries) {
        var rows = new ArrayList<Row>();
        var ordered = new ArrayList<Match>();
        var counts = new HashMap<Label, Integer>();
        Match section = null;
        for (Text text : entries) {
            String plain = Formatting.strip(text.getString()).strip();
            if (plain.isEmpty()) {
                rows.add(new Row(text, null, null));
                section = null;
                continue;
            }
            int colon = plain.indexOf(':');
            String label = colon > 0 ? plain.substring(0, colon).strip() : plain;
            Ref line = ref(Kind.LINE, label, counts);
            ordered.add(new Match(line, label, List.of(text)));
            if (colon < 0 || startsBold(text)) {
                section = new Match(ref(Kind.SECTION, label, counts), label, new ArrayList<>());
                ordered.add(section);
            }
            if (section != null) section.lines().add(text);
            rows.add(new Row(text, line, section == null ? null : section.ref()));
        }
        List<Match> frozen = ordered.stream().map(m -> new Match(m.ref(), m.rawLabel(), List.copyOf(m.lines()))).toList();
        var exact = new HashMap<Label, List<Match>>();
        for (Match match : frozen) {
            Ref ref = match.ref();
            exact.computeIfAbsent(new Label(ref.kind(), ref.key()), unused -> new ArrayList<>()).add(match);
        }
        return new Snapshot(List.copyOf(rows), Map.copyOf(exact), frozen);
    }

    private static Ref ref(Kind kind, String label, Map<Label, Integer> counts) {
        String key = TextKey.normalize(label);
        int index = counts.merge(new Label(kind, key), 1, Integer::sum) - 1;
        return new Ref(kind, key, index);
    }

    private static boolean startsBold(Text text) {
        // OrderedText exposes effective style, including legacy §l codes in server-supplied text.
        boolean[] bold = {false};
        text.asOrderedText().accept((i, style, cp) -> {
            if (Character.isWhitespace(cp) || Character.isSpaceChar(cp)) return true;
            bold[0] = style.isBold();
            return false;
        });
        return bold[0];
    }

    public static void add(Ref ref) {
        Match match = snapshot.find(ref);
        if (match == null || contains(ref)) return;
        Part part = new Part();
        part.uuid = UUID.randomUUID().toString();
        part.kind = ref.kind(); part.key = ref.key(); part.occurrence = ref.occurrence();
        part.rawLabel = match.rawLabel();
        part.x = .15 + .07 * (PARTS.size() % 9);
        part.y = .2 + .08 * (PARTS.size() % 8);
        register(part);
        save();
    }

    public static void remove(Part part) {
        if (PARTS.remove(part.id(), part)) {
            HudElements.unregister(part.id());
            save();
        }
    }

    private static void register(Part part) {
        if (PARTS.putIfAbsent(part.id(), part) == null) HudElements.register(part);
    }

    public static void render(DrawContext context, PlayerListHud hud) {
        var client = MinecraftClient.getInstance();
        if (client.world == null || client.options.hudHidden || client.currentScreen instanceof HudEditorScreen
                || ((PlayerListHudAccess) hud).zacktills$isVisible()) return;
        for (Part part : PARTS.values()) {
            List<Text> lines = part.live();
            if (part.enabled && !ScoreboardLayout.moves(part.ref()) && !lines.isEmpty()) part.draw(context, lines, 1);
        }
    }

    public static void load() {
        if (!Files.isRegularFile(FILE)) return;
        try (var reader = Files.newBufferedReader(FILE)) {
            Part[] loaded = GSON.fromJson(reader, Part[].class);
            if (loaded == null) return;
            boolean migrated = false;
            for (Part part : loaded) {
                if (part == null || part.kind == null || part.key == null) continue;
                if (part.uuid == null || PARTS.containsKey(part.uuid) || !validUuid(part.uuid)) {
                    part.uuid = UUID.randomUUID().toString();
                    migrated = true;
                }
                String oldKey = part.key;
                if (part.rawLabel == null) {
                    part.rawLabel = oldKey;
                    // The old section keys used the complete header, including any value after a colon.
                    int colon = oldKey.indexOf(':');
                    if (part.kind == Kind.SECTION && colon > 0) oldKey = oldKey.substring(0, colon);
                    migrated = true;
                }
                Ref ref = new Ref(part.kind, oldKey, part.occurrence);
                if (!part.key.equals(ref.key()) || !java.util.Objects.equals(part.occurrence, ref.occurrence())) migrated = true;
                part.key = ref.key();
                part.occurrence = ref.occurrence();
                part.position(part.position());
                register(part);
            }
            if (migrated) save();
        } catch (IOException | RuntimeException e) {
            LOG.warn("Could not read {}", FILE, e);
        }
    }

    private static boolean validUuid(String id) {
        try { return UUID.fromString(id).toString().equals(id); }
        catch (IllegalArgumentException invalid) { return false; }
    }

    private static void save() {
        Path tmp = FILE.resolveSibling("tab_parts.json.tmp");
        try {
            Files.createDirectories(FILE.getParent());
            try (var writer = Files.newBufferedWriter(tmp)) { GSON.toJson(parts(), writer); }
            try {
                Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Could not save {}", FILE, e);
        }
    }

    public static final class Part implements HudElement {
        private String uuid;
        private Kind kind;
        private String key, rawLabel;
        private Integer occurrence;
        private double x = .5, y = .5, scale = 1;
        private boolean enabled = true;
        private transient Match lastMatch;
        private transient long lastSeen;

        private Part() {}

        private Ref ref() { return new Ref(kind, key, occurrence); }
        @Override public String id() { return uuid; }
        @Override public String label() {
            live();
            String label = lastMatch == null ? rawLabel : lastMatch.rawLabel();
            return label + (occurrence == null ? "" : " #" + ((long) occurrence + 1));
        }
        @Override public boolean enabled() { return enabled; }
        @Override public void enabled(boolean value) { enabled = value; save(); }
        @Override public int defaultWidth() { return 100; }
        @Override public int defaultHeight() { return kind == Kind.LINE ? 20 : 40; }
        @Override public Position position() { return new Position(x, y, scale); }
        @Override public void position(Position p) { x = p.x(); y = p.y(); scale = p.scale(); }
        @Override public void savePosition() { save(); }
        @Override public Size size() { return measure(display().stream().map(Part::tinted).toList(), padding()); }
        @Override public void render(DrawContext context, float alpha) { draw(context, display(), alpha); }

        private void clearLive() { lastMatch = null; }
        private List<Text> live() {
            long now = System.nanoTime();
            Match match = snapshot.find(ref());
            if (match != null) {
                lastMatch = match;
                lastSeen = now;
            }
            if (lastMatch == null || now - lastSeen >= TimeUnit.SECONDS.toNanos(3)) return List.of();
            return lastMatch.lines();
        }
        private List<Text> display() {
            List<Text> lines = live();
            if (!lines.isEmpty()) return lines;
            return kind == Kind.LINE ? List.of(Text.literal(label() + ": preview"))
                    : List.of(Text.literal(label()).formatted(Formatting.BOLD), Text.literal("Tab part preview"));
        }

        private static OrderedText tinted(Text line) {
            OrderedText original = HudFonts.apply(line).asOrderedText();
            return visitor -> original.accept((index, style, cp) -> visitor.accept(index, style.withColor((TextColor) null), cp));
        }

        private static int padding() {
            return (int) Math.round(FeatureSettings.number("tabparts.padding"));
        }

        private Size measure(List<OrderedText> lines, int padding) {
            var font = MinecraftClient.getInstance().textRenderer;
            int width = lines.stream().mapToInt(font::getWidth).max().orElse(0) + 2 * padding;
            return new Size(width, lines.size() * (font.fontHeight + 2 * padding));
        }

        private void draw(DrawContext context, List<Text> text, float alpha) {
            var font = MinecraftClient.getInstance().textRenderer;
            List<OrderedText> lines = text.stream().map(Part::tinted).toList();
            int padding = padding();
            int lineHeight = font.fontHeight + 2 * padding;
            int background = FeatureSettings.choiceValue("tabparts.style").equals("Subtitles") ? 0xCC000000 : 0x90505050;
            HudFeatures.begin(context, this, measure(lines, padding));
            for (int i = 0; i < lines.size(); i++) {
                OrderedText line = lines.get(i);
                int y = i * lineHeight;
                context.fill(0, y, font.getWidth(line) + 2 * padding, y + lineHeight, HudFeatures.fade(background, alpha));
                context.drawText(font, line, padding, y + padding, HudFeatures.textColor(0xE0E0E0, alpha), false);
            }
            context.getMatrices().pop();
        }
    }
}
