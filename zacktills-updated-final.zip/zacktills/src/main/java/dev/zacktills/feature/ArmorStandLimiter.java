package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/** A visibility budget for non-exempt stands, without changing any entity state. */
public final class ArmorStandLimiter {
    private static final String GROUP = "performance.";
    private static ClientWorld world;
    private static Set<Integer> retained = Set.of();
    private static int ticksUntilRefresh;
    private static int sampledLimit;
    private static double sampledRadius;
    private static boolean sampledNamed;

    private ArmorStandLimiter() {}

    public static void reset() {
        world = null;
        retained = Set.of();
        ticksUntilRefresh = 0;
    }

    public static void tick(MinecraftClient client) {
        if (!FeatureSettings.on(GROUP + "enabled") || client.world == null || client.player == null) {
            reset();
            return;
        }
        int limit = (int) FeatureSettings.number(GROUP + "max_stands");
        double radius = FeatureSettings.number(GROUP + "radius");
        boolean showNamed = FeatureSettings.on(GROUP + "show_named");
        if (world == client.world && limit == sampledLimit && radius == sampledRadius
                && showNamed == sampledNamed && --ticksUntilRefresh > 0) return;

        Vec3d camera = cameraPosition(client);
        Box area = new Box(camera, camera).expand(radius);
        double radiusSquared = radius * radius;
        var nearest = client.world.getEntitiesByClass(ArmorStandEntity.class, area,
                stand -> !exempt(client, stand, showNamed) && stand.squaredDistanceTo(camera) <= radiusSquared);
        nearest.sort(Comparator.comparingDouble((ArmorStandEntity stand) -> stand.squaredDistanceTo(camera))
                .thenComparingInt(Entity::getId));
        Set<Integer> kept = new HashSet<>();
        for (int i = 0; i < Math.min(limit, nearest.size()); i++) kept.add(nearest.get(i).getId());
        retained = kept;
        world = client.world;
        sampledLimit = limit;
        sampledRadius = radius;
        sampledNamed = showNamed;
        ticksUntilRefresh = 5;
    }

    public static boolean shouldCull(ArmorStandEntity stand, double cameraX, double cameraY, double cameraZ) {
        if (world == null || stand.getWorld() != world || !FeatureSettings.on(GROUP + "enabled")) return false;
        MinecraftClient client = MinecraftClient.getInstance();
        return world == client.world && client.player != null && !exempt(client, stand, sampledNamed)
                && stand.squaredDistanceTo(cameraX, cameraY, cameraZ) <= sampledRadius * sampledRadius
                && !retained.contains(stand.getId());
    }

    private static boolean exempt(MinecraftClient client, ArmorStandEntity stand, boolean showNamed) {
        return stand.hasPassengerDeep(client.player) || (showNamed && stand.hasCustomName());
    }

    static Vec3d cameraPosition(MinecraftClient client) {
        Camera camera = client.gameRenderer.getCamera();
        Entity focused = camera.getFocusedEntity();
        if (camera.isReady() && focused != null && focused.getWorld() == client.world) return camera.getPos();
        Entity cameraEntity = client.getCameraEntity();
        return cameraEntity != null && cameraEntity.getWorld() == client.world
                ? cameraEntity.getEyePos() : client.player.getEyePos();
    }
}
