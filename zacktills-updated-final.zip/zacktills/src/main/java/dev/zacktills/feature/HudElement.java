package dev.zacktills.feature;

import net.minecraft.client.gui.DrawContext;

public interface HudElement {
    record Size(int width, int height) {}
    record Position(double x, double y, double scale) {
        public Position {
            x = bounded(x, 0, 1, .5);
            y = bounded(y, 0, 1, .5);
            scale = bounded(scale, .25, 4, 1);
        }

        private static double bounded(double value, double min, double max, double fallback) {
            return Double.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
        }
    }
    record Bounds(double x, double y, double width, double height) {
        public boolean contains(double mx, double my) {
            return mx >= x && my >= y && mx < x + width && my < y + height;
        }
    }

    String id();
    default String label() { return id(); }
    int defaultWidth();
    int defaultHeight();
    default Size size() { return new Size(defaultWidth(), defaultHeight()); }
    Position position();
    void position(Position position);
    default boolean enabled() { return true; }
    default void enabled(boolean enabled) {}
    /** Restore the position in memory; the editor calls savePosition() after resetting it. */
    default void resetPosition() { position(new Position(.5, .5, 1)); }
    default void savePosition() {}
    void render(DrawContext context, float alpha);

    default Bounds bounds(Size size, int screenWidth, int screenHeight) {
        Position p = position();
        double w = size.width() * p.scale(), h = size.height() * p.scale();
        return new Bounds(Math.max(0, screenWidth - w) * p.x(), Math.max(0, screenHeight - h) * p.y(), w, h);
    }
}
