package dev.zacktills.ui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.client.gui.widget.ButtonWidget;

/** Place and manage existing parts in the HUD editor; this screen only opens the picker. */
public final class TabPartsScreen extends Screen {
    private final Screen parent;

    public TabPartsScreen(Screen parent) {
        super(Text.literal("Tab parts"));
        this.parent = parent;
    }

    @Override protected void init() {
        int w = Math.min(200, width - 16), x = (width - w) / 2;
        int y = Math.max(22, (height - 82) / 2);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add tab parts"), b -> client.setScreen(new TabPickerScreen(this)))
                .dimensions(x, y, w, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD editor"), b -> client.setScreen(new HudEditorScreen(this)))
                .dimensions(x, y + 29, w, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(x, y + 58, w, 24).build());
    }

    @Override public void render(net.minecraft.client.gui.DrawContext context, int mx, int my, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, Math.max(8, (height - 82) / 2 - 16), 0xFFFFFF);
        super.render(context, mx, my, delta);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
