package dev.zacktills.ui;

import dev.zacktills.feature.BossbarFilter;
import dev.zacktills.feature.BossbarFilter.Entry;
import dev.zacktills.feature.BossbarFilter.Snapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class BossbarFilterScreen extends Screen {
    private final Screen parent;
    private final ScrollList list = new ScrollList();
    private final Button back = new Button("Back", this::close);
    private Rect panel;
    private Widget capture;
    private Snapshot shown;
    private boolean shownEnabled;

    public BossbarFilterScreen(Screen parent) {
        super(Text.literal("Bossbar Filter"));
        this.parent = parent;
        back.primary = true;
        list.rowGap = 4;
        list.pad = 4;
    }

    @Override protected void init() {
        clearCapture();
        int w = Math.min(440, Math.max(0, width - 16));
        panel = new Rect((width - w) / 2, 8, w, height - 16);
        back.bounds(region(panel, Math.max(8, w - 64), 37, 56, 24));
        list.bounds(region(panel, 6, 66, w - 12, panel.h() - 72));
        shown = null;
        syncRows();
    }

    private void syncRows() {
        if (capture != null) return; // Keep the pressed row stable until tap or drag ends.
        Snapshot snapshot = BossbarFilter.snapshot(client);
        boolean enabled = BossbarFilter.enabled();
        if (enabled == shownEnabled && snapshot.equals(shown)) return;
        shown = snapshot;
        shownEnabled = enabled;
        List<Widget> rows = new ArrayList<>();
        rows.add(new Label(enabled ? "Visible bossbars" : "Live bossbars without a rule", TITLE));
        if (snapshot.visible().isEmpty()) rows.add(new Label("No live titles to hide", MUTED));
        else snapshot.visible().forEach(entry -> rows.add(new TitleRow(entry, false)));
        rows.add(new Label("Hidden titles", TITLE));
        if (snapshot.hidden().isEmpty()) rows.add(new Label("No hidden titles", MUTED));
        else snapshot.hidden().forEach(entry -> rows.add(new TitleRow(entry, true)));
        list.setItems(rows);
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        syncRows();
        drawBackdrop(context, width, height);
        drawPanel(context, panel, title.getString());
        String hint = BossbarFilter.hasSaveError() ? "Save failed; will retry"
                : shownEnabled ? "Tap to hide | Drag to scroll" : "Filter off; rules aren't applied";
        text(context, hint, panel.x() + 10, panel.y() + 45, back.bounds.x() - panel.x() - 15, MUTED);
        back.render(context, mouseX, mouseY);
        list.render(context, mouseX, mouseY);
    }

    @Override public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return false;
        clearCapture();
        // Use the last drawn layout, so a live update cannot move the target under the tap.
        capture = back.down(x, y) ? back : list.down(x, y) ? list : null;
        return capture != null;
    }

    @Override public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (button != 0 || capture == null) return false;
        capture.drag(x, y);
        return true;
    }

    @Override public boolean mouseReleased(double x, double y, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(x, y);
        syncRows();
        return true;
    }

    @Override public boolean mouseScrolled(double x, double y, double amount) {
        return capture == null && list.wheel(x, y, amount);
    }

    private void clearCapture() {
        if (capture != null) capture.cancel();
        capture = null;
    }

    @Override public void removed() { clearCapture(); super.removed(); }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }

    private static final class Label extends Widget {
        private final String label;
        private final int color;

        private Label(String label, int color) {
            this.label = label;
            this.color = color;
            enabled = false;
        }

        @Override public int height() { return 16; }
        @Override public void render(DrawContext context, int mouseX, int mouseY) {
            text(context, label, bounds.x() + 4, bounds.y() + 4, bounds.w() - 8, color);
        }
    }

    private static final class TitleRow extends Widget {
        private final String label;
        private final boolean hidden;
        private final Button action;
        private Rect badge;

        private TitleRow(Entry entry, boolean hidden) {
            String raw = entry.rawTitle();
            label = raw.isBlank() ? "(blank title)" : raw.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
            this.hidden = hidden;
            action = hidden ? new Button("Remove", () -> BossbarFilter.remove(entry.key()))
                    : new Button("Hide", () -> BossbarFilter.hide(entry.rawTitle()));
        }

        @Override public int height() { return 32; }
        @Override public void bounds(Rect r) {
            super.bounds(r);
            int w = Math.min(58, Math.max(0, r.w() - 8));
            badge = region(r, r.w() - w - 4, 3, w, r.h() - 6);
            action.bounds(hidden ? badge : r);
        }

        @Override public void render(DrawContext context, int mouseX, int mouseY) {
            drawRow(context, bounds, hidden ? State.NORMAL : action.state(mouseX, mouseY));
            text(context, label, bounds.x() + 6, bounds.y() + 12, badge.x() - bounds.x() - 10, TEXT);
            if (hidden) action.render(context, mouseX, mouseY);
            else centered(context, action.label, badge, MUTED);
        }

        @Override public boolean down(double x, double y) { return action.down(x, y); }
        @Override public void up(double x, double y) { action.up(x, y); }
        @Override public void cancel() { action.cancel(); }
    }
}
