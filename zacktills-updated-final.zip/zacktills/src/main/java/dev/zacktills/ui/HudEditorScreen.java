package dev.zacktills.ui;

import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.HudElement;
import dev.zacktills.feature.HudElement.Bounds;
import dev.zacktills.feature.HudElement.Position;
import dev.zacktills.feature.HudElements;
import dev.zacktills.feature.TabParts;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;

/** Touch editor for the full HUD layout. All positions are stored in live HUD coordinates. */
public final class HudEditorScreen extends Screen {
    private static final String SNAP = "hud.snap";
    private static final int MARGIN = 5, GAP = 4, ROW = 24, HANDLE = 18;
    private static final int WIDE_DOCK = 420;
    private static final double TAP_SLOP = 3, SNAP_DISTANCE = 4;
    private static final double MIN_SCALE = .5, MAX_SCALE = 3;
    private static final int GUIDE = 0xFF65E5EF;

    private final Screen parent;
    private HudElement selected;
    private Gesture gesture;
    private Control pressed;
    private Snap guideX, guideY;
    private Rect dock;
    private View view;

    private enum Action { SELECT, ENABLE, RESET, DELETE, SCOREBOARD, SNAP, BACK }
    private record Item(Action action, String label, int preferredWidth) {}
    private record Control(Item item, Rect rect) {}
    private record Snap(double origin, double guide, double distance) {}
    private record View(int x, int y, double factor) {
        double projectX(double value) { return x + value * factor; }
        double projectY(double value) { return y + value * factor; }
    }

    private static final class Gesture {
        final HudElement target, nextOnTap;
        final boolean resize;
        final double x, y;
        final Position initial;
        final Bounds bounds;
        boolean moved;

        Gesture(HudElement target, HudElement nextOnTap, boolean resize, double x, double y, Bounds bounds) {
            this.target = target;
            this.nextOnTap = nextOnTap;
            this.resize = resize;
            this.x = x;
            this.y = y;
            this.initial = target.position();
            this.bounds = bounds;
        }
    }

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override protected void init() {
        finishGesture();
        pressed = null;
        checkSelection();
        int dockWidth = Math.min(490, Math.max(1, width - 2 * MARGIN));
        int dockHeight = 2 * MARGIN + (dockWidth >= WIDE_DOCK ? ROW : 2 * ROW + GAP);
        dock = new Rect((width - dockWidth) / 2, Math.max(0, height - dockHeight - MARGIN), dockWidth, dockHeight);

        // Fit the actual screen into a separate canvas, with room for a handle even at (1, 1).
        // The dock must never intercept touches on a HUD target or on the selected resize handle.
        int availableW = Math.max(1, width - 2 * MARGIN - HANDLE);
        int availableH = Math.max(1, dock.y() - 2 * MARGIN - HANDLE);
        double factor = Math.min(availableW / (double) Math.max(1, width), availableH / (double) Math.max(1, height));
        view = new View(MARGIN + (int) ((availableW - width * factor) / 2),
                MARGIN + (int) ((availableH - height * factor) / 2), factor);
    }

    private static List<HudElement> targets() {
        // The contextual crosshair stays at the aim point; scoreboard-injected lines are not targets.
        return HudElements.all().stream().filter(element -> !element.id().equals("crosshair")).toList();
    }

    private void checkSelection() {
        if (selected != null && HudElements.get(selected.id()) != selected) {
            selected = null;
            gesture = null;
            guideX = guideY = null;
            pressed = null;
        }
    }

    private Bounds bounds(HudElement element) {
        return element.bounds(element.size(), width, height);
    }

    private Rect canvas() {
        return new Rect(view.x(), view.y(), (int) Math.ceil(width * view.factor()), (int) Math.ceil(height * view.factor()));
    }

    private Rect outline(Bounds b) {
        int x = (int) Math.floor(view.projectX(b.x()));
        int y = (int) Math.floor(view.projectY(b.y()));
        int right = (int) Math.ceil(view.projectX(Math.min(width, b.x() + b.width())));
        int bottom = (int) Math.ceil(view.projectY(Math.min(height, b.y() + b.height())));
        return new Rect(x, y, right - x, bottom - y);
    }

    private Rect handle(Rect target) {
        int x = clamp(target.x() + target.w() - 2, 0, width - HANDLE);
        int y = clamp(target.y() + target.h() - 2, 0, dock.y() - HANDLE);
        return new Rect(x, y, HANDLE, HANDLE);
    }

    private List<Control> controls() {
        Item name = new Item(Action.SELECT, (selected == null ? "Select HUD" : selected.label()) + " ›", 96);
        Item snap = new Item(Action.SNAP, FeatureSettings.on(SNAP) ? "Snap: On" : "Snap: Off", 59);
        Item back = new Item(Action.BACK, "Back", 37);
        List<Item> actions = new ArrayList<>(3);
        if (selected != null) {
            actions.add(new Item(Action.ENABLE, selected.enabled() ? "Enabled: On" : "Enabled: Off", 79));
            actions.add(new Item(Action.RESET, "Reset", 42));
            if (selected instanceof TabParts.Part) actions.add(new Item(Action.DELETE, "Delete", 51));
            if (selected.id().equals("scoreboard")) actions.add(new Item(Action.SCOREBOARD, "Scoreboard editor", 105));
        }
        List<Control> controls = new ArrayList<>(7);
        if (dock.w() >= WIDE_DOCK) {
            actions.add(0, name);
            actions.add(snap);
            actions.add(back);
            addRow(controls, actions, 0, true);
        } else {
            addRow(controls, List.of(name, snap, back), 0, true);
            addRow(controls, actions, 1, false);
        }
        return controls;
    }

    private void addRow(List<Control> controls, List<Item> items, int row, boolean stretchName) {
        if (items.isEmpty()) return;
        int preferred = items.stream().mapToInt(Item::preferredWidth).sum();
        int available = Math.max(0, dock.w() - 2 * MARGIN - (items.size() - 1) * GAP);
        int extra = Math.max(0, available - preferred);
        int x = dock.x() + MARGIN + (stretchName ? 0 : extra / 2);
        int y = dock.y() + MARGIN + row * (ROW + GAP);
        int accumulated = 0;
        for (Item item : items) {
            int w = item.preferredWidth();
            if (available < preferred) {
                w = (accumulated + w) * available / preferred - accumulated * available / preferred;
                accumulated += item.preferredWidth();
            } else if (stretchName && item.action() == Action.SELECT) {
                w += extra;
            }
            controls.add(new Control(item, new Rect(x, y, w, ROW)));
            x += w + GAP;
        }
    }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        checkSelection();
        drawBackdrop(c, width, height);
        Rect canvas = canvas();
        fill(c, canvas, INSET);
        for (int x = canvas.x() + 16; x < canvas.x() + canvas.w(); x += 16) {
            fill(c, new Rect(x, canvas.y(), 1, canvas.h()), BORDER);
        }
        for (int y = canvas.y() + 16; y < canvas.y() + canvas.h(); y += 16) {
            fill(c, new Rect(canvas.x(), y, canvas.w(), 1), BORDER);
        }

        c.enableScissor(canvas.x(), canvas.y(), canvas.x() + canvas.w(), canvas.y() + canvas.h());
        c.getMatrices().push();
        try {
            c.getMatrices().translate(view.x(), view.y(), 0);
            c.getMatrices().scale((float) view.factor(), (float) view.factor(), 1);
            for (HudElement target : targets()) if (target != selected) target.render(c, .5f);
            if (selected != null) selected.render(c, 1f);
        } finally {
            c.getMatrices().pop();
            c.disableScissor();
        }

        c.getMatrices().push();
        try {
            // Draw above item previews as well as text; stay in unscaled GUI units.
            c.getMatrices().translate(0, 0, 400);
            if (guideX != null) {
                int x = clamp((int) Math.round(view.projectX(guideX.guide())), canvas.x(), canvas.x() + canvas.w() - 1);
                fill(c, new Rect(x, canvas.y(), 1, canvas.h()), GUIDE);
            }
            if (guideY != null) {
                int y = clamp((int) Math.round(view.projectY(guideY.guide())), canvas.y(), canvas.y() + canvas.h() - 1);
                fill(c, new Rect(canvas.x(), y, canvas.w(), 1), GUIDE);
            }
            if (selected != null) {
                Rect target = outline(bounds(selected));
                c.drawBorder(target.x(), target.y(), target.w(), target.h(), TITLE);
                Rect handle = handle(target);
                fill(c, handle, TITLE);
                fill(c, inset(handle, 2), PANEL);
                for (int i = 0; i < 7; i++) {
                    fill(c, new Rect(handle.x() + 5 + i, handle.y() + 11 - i, 2, 2), ACCENT_HOVER);
                }
            }
            framed(c, dock, 6, PANEL, BORDER);
            if (selected == null && dock.w() < WIDE_DOCK) {
                centered(c, "Tap a HUD element to select it", new Rect(dock.x(), dock.y() + MARGIN + ROW + GAP, dock.w(), ROW), MUTED);
            }
            for (Control control : controls()) {
                boolean hover = control.rect().contains(mouseX, mouseY);
                State state = hover ? (control.equals(pressed) ? State.PRESSED : State.HOVER) : State.NORMAL;
                if (control.item().action() == Action.BACK) drawPrimary(c, control.rect(), control.item().label(), state);
                else drawButton(c, control.rect(), control.item().label(), state, false);
            }
        } finally {
            c.getMatrices().pop();
        }
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        checkSelection();
        finishGesture();
        pressed = null;
        for (Control control : controls()) {
            if (control.rect().contains(mx, my)) {
                pressed = control;
                return true;
            }
        }
        if (selected != null) {
            Bounds selectedBounds = bounds(selected);
            if (handle(outline(selectedBounds)).contains(mx, my)) {
                gesture = new Gesture(selected, null, true, mx, my, selectedBounds);
                return true;
            }
        }
        double x = (mx - view.x()) / view.factor(), y = (my - view.y()) / view.factor();
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        List<HudElement> hits = targets().stream().filter(target -> bounds(target).contains(x, y)).toList();
        if (hits.isEmpty()) return false;
        int index = selected == null ? -1 : hits.indexOf(selected);
        HudElement next = index >= 0 && hits.size() > 1 ? hits.get(Math.floorMod(index - 1, hits.size())) : null;
        selected = index >= 0 ? hits.get(index) : hits.get(hits.size() - 1);
        gesture = new Gesture(selected, next, false, mx, my, bounds(selected));
        return true;
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0) return false;
        checkSelection();
        if (gesture != null) {
            updateGesture(mx, my);
            return true;
        }
        return pressed != null;
    }

    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0) return false;
        checkSelection();
        if (pressed != null) {
            Control control = pressed;
            pressed = null;
            if (control.rect().contains(mx, my)) activate(control.item().action());
            return true;
        }
        Gesture current = gesture;
        if (current == null) return false;
        updateGesture(mx, my);
        if (!current.moved) {
            if (current.resize) {
                double scale = current.initial.scale();
                resize(current, scale < 1 ? 1 : scale < 1.5 ? 1.5 : scale < 2 ? 2 : 1);
            } else if (current.nextOnTap != null && HudElements.get(current.nextOnTap.id()) == current.nextOnTap) {
                selected = current.nextOnTap;
            }
        }
        finishGesture();
        return true;
    }

    private void updateGesture(double mx, double my) {
        Gesture current = gesture;
        double dx = mx - current.x, dy = my - current.y;
        if (!current.moved && Math.hypot(dx, dy) < TAP_SLOP) return;
        current.moved = true;
        if (current.resize) {
            // Bound the travel required per increment so an edge handle can still grow by dragging
            // down or right, even when the touch crosses from the canvas into the dock.
            double content = (current.bounds.width() + current.bounds.height()) * view.factor() / current.initial.scale();
            double travelPerScale = between(content, 32, 64);
            double scale = Math.round((current.initial.scale() + (dx + dy) / travelPerScale) * 4) / 4.0;
            resize(current, between(scale, MIN_SCALE, MAX_SCALE));
        } else {
            move(current, dx / view.factor(), dy / view.factor());
        }
    }

    private void resize(Gesture current, double scale) {
        HudElement.Size size = current.target.size();
        place(current, current.bounds.x(), current.bounds.y(), scale, size.width() * scale, size.height() * scale);
    }

    private void move(Gesture current, double dx, double dy) {
        Bounds live = bounds(current.target);
        double x = between(current.bounds.x() + dx, 0, Math.max(0, width - live.width()));
        double y = between(current.bounds.y() + dy, 0, Math.max(0, height - live.height()));
        guideX = guideY = null;
        if (FeatureSettings.on(SNAP)) {
            guideX = snap(null, x, live.width(), 0, width, width);
            guideY = snap(null, y, live.height(), 0, height, height);
            for (HudElement target : targets()) {
                if (target == current.target) continue;
                Bounds other = bounds(target);
                guideX = snap(guideX, x, live.width(), other.x(), other.width(), width);
                guideY = snap(guideY, y, live.height(), other.y(), other.height(), height);
            }
        }
        place(current, guideX == null ? x : guideX.origin(), guideY == null ? y : guideY.origin(),
                current.initial.scale(), live.width(), live.height());
    }

    private Snap snap(Snap best, double origin, double size, double otherOrigin, double otherSize, int extent) {
        double maxOrigin = extent - size;
        if (maxOrigin <= 0) return best;
        for (int a = 0; a < 3; a++) {
            double anchorOffset = size * a / 2;
            for (int b = 0; b < 3; b++) {
                double guide = otherOrigin + otherSize * b / 2;
                double candidate = guide - anchorOffset;
                if (guide < 0 || guide > extent || candidate < -1e-7 || candidate > maxOrigin + 1e-7) continue;
                double distance = Math.abs(candidate - origin) * view.factor();
                if (distance <= SNAP_DISTANCE && (best == null || distance < best.distance())) {
                    best = new Snap(between(candidate, 0, maxOrigin), guide, distance);
                }
            }
        }
        return best;
    }

    private void place(Gesture current, double x, double y, double scale, double w, double h) {
        // Retain a saved anchor on an axis where the widget currently fills or exceeds the screen.
        double anchorX = w < width ? x / (width - w) : current.initial.x();
        double anchorY = h < height ? y / (height - h) : current.initial.y();
        Position next = new Position(anchorX, anchorY, scale);
        if (!next.equals(current.target.position())) current.target.position(next);
    }

    private static double between(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private void finishGesture() {
        Gesture previous = gesture;
        gesture = null;
        guideX = guideY = null;
        if (previous != null && HudElements.get(previous.target.id()) == previous.target
                && !previous.initial.equals(previous.target.position())) previous.target.savePosition();
    }

    private void activate(Action action) {
        switch (action) {
            case SELECT -> {
                List<HudElement> choices = targets();
                if (!choices.isEmpty()) {
                    int index = selected == null ? -1 : choices.indexOf(selected);
                    selected = choices.get((index + 1) % choices.size());
                }
            }
            case ENABLE -> {
                if (selected != null) {
                    selected.enabled(!selected.enabled());
                    selected.savePosition();
                }
            }
            case RESET -> {
                if (selected != null) {
                    selected.resetPosition();
                    selected.savePosition();
                }
            }
            case DELETE -> {
                if (selected instanceof TabParts.Part part) {
                    TabParts.remove(part);
                    selected = null;
                }
            }
            case SCOREBOARD -> {
                if (client != null && selected != null && selected.id().equals("scoreboard")) {
                    client.setScreen(new ScoreboardEditorScreen(this));
                }
            }
            case SNAP -> {
                FeatureSettings.setBool(SNAP, !FeatureSettings.on(SNAP));
                FeatureSettings.save();
            }
            case BACK -> close();
        }
    }

    @Override public void removed() {
        finishGesture();
        pressed = null;
        super.removed();
    }

    @Override public void close() {
        finishGesture();
        if (client != null) client.setScreen(parent);
    }

    @Override public boolean shouldPause() { return false; }
}
