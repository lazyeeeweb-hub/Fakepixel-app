package dev.zacktills.ui;

import dev.zacktills.feature.HudFeatures;
import dev.zacktills.feature.ScoreboardLayout;
import dev.zacktills.feature.ScoreboardLayout.Row;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;

/** Drag the left grip to reorder; drag anywhere else on a row to scroll. */
public final class ScoreboardEditorScreen extends Screen {
    private static final int ROW_HEIGHT = 29, GRIP_WIDTH = 28, HIDE_WIDTH = 27, MODE_WIDTH = 49;

    private final Screen parent;
    private Rect panel, viewport;
    private List<Row> rows = List.of();
    private List<Row> working;
    private ScoreboardLayout.Key dragged, tapKey;
    private Action action;
    private int originalIndex;
    private double scroll, downX, downY, startScroll, pointerY, grabY;
    private boolean pressed, moved;

    private enum Action { HIDE, MODE }

    public ScoreboardEditorScreen(Screen parent) {
        super(Text.literal("Scoreboard editor"));
        this.parent = parent;
    }

    @Override protected void init() {
        clearGesture();
        int w = Math.min(440, Math.max(1, width - 16)), x = (width - w) / 2;
        panel = new Rect(x, 8, w, Math.max(0, height - 16));
        int inner = Math.max(1, w - 16), resetWidth = Math.min(146, 2 * (inner - 8) / 3);
        int backWidth = Math.min(48, inner / 4), addWidth = inner - resetWidth - backWidth - 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("Add from tab"), b -> client.setScreen(
                new TabPickerScreen(this, "Add to scoreboard", ScoreboardLayout::addFromTab, ScoreboardLayout::contains)))
                .dimensions(x + 8, 39, addWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset scoreboard layout"), b -> {
            ScoreboardLayout.reset(); scroll = 0; refresh();
        }).dimensions(x + 12 + addWidth, 39, resetWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(x + 16 + addWidth + resetWidth, 39, backWidth, 24).build());
        viewport = region(panel, 8, 62, inner, panel.h() - 83);
        refresh();
    }

    private void refresh() {
        rows = HudFeatures.scoreboardLayout();
        scroll = clampScroll(scroll);
    }

    private List<Row> shown() { return working == null ? rows : working; }
    private double clampScroll(double y) { return Math.max(0, Math.min(Math.max(0, shown().size() * ROW_HEIGHT - viewport.h()), y)); }
    private int rowY(int index) { return viewport.y() + index * ROW_HEIGHT - (int) Math.round(scroll); }
    private int rowAt(double y) { return (int) Math.floor((y - viewport.y() + Math.round(scroll)) / ROW_HEIGHT); }
    private Rect rowRect(int index) { return new Rect(viewport.x(), rowY(index), viewport.w(), ROW_HEIGHT - 3); }
    private static Rect hideRect(Rect row) { return region(row, row.w() - HIDE_WIDTH, 0, HIDE_WIDTH, row.h()); }
    private static Rect modeRect(Rect row) { return region(row, row.w() - HIDE_WIDTH - MODE_WIDTH - 3, 0, MODE_WIDTH, row.h()); }
    private static Rect gripRect(Rect row) { return region(row, 0, 0, GRIP_WIDTH, row.h()); }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        if (!pressed) refresh();
        drawBackdrop(c, width, height);
        drawPanel(c, panel, title.getString());
        drawList(c, viewport);
        if (viewport.h() > 0) {
            clip(c, viewport);
            List<Row> current = shown();
            for (int i = 0; i < current.size(); i++) {
                Row row = current.get(i);
                Rect bounds = rowRect(i);
                if (bounds.y() + bounds.h() <= viewport.y() || bounds.y() >= viewport.y() + viewport.h()) continue;
                boolean active = row.id().equals(dragged);
                drawRow(c, bounds, active ? State.HOVER : State.NORMAL);
                drawButton(c, gripRect(bounds), "=", active ? State.PRESSED : State.NORMAL, active);
                drawButton(c, hideRect(bounds), "X", State.NORMAL, false);
                if (row.id().isTab()) drawButton(c, modeRect(bounds), row.mode() == ScoreboardLayout.Mode.MOVE ? "Move" : "Copy", State.NORMAL, false);
                String label = Formatting.strip(row.text().getString());
                int available = bounds.w() - GRIP_WIDTH - HIDE_WIDTH - (row.id().isTab() ? MODE_WIDTH + 3 : 0) - 10;
                text(c, label, bounds.x() + GRIP_WIDTH + 5, bounds.y() + (bounds.h() - 9) / 2, available, row.live() ? TEXT : MUTED);
            }
            if (current.isEmpty()) centered(c, "No visible scoreboard lines", viewport, MUTED);
            unclip(c);
        }
        centered(c, "Drag = to reorder | Swipe list to scroll | X hides", region(panel, 8, panel.h() - 17, panel.w() - 16, 14), MUTED);
        super.render(c, mx, my, delta);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0 || !viewport.contains(mx, my)) return super.mouseClicked(mx, my, button);
        clearGesture();
        pressed = true; downX = mx; pointerY = downY = my; startScroll = scroll;
        int index = rowAt(my);
        if (index >= 0 && index < rows.size()) {
            Rect rect = rowRect(index);
            Row row = rows.get(index);
            if (gripRect(rect).contains(mx, my)) {
                dragged = row.id(); originalIndex = index; grabY = my - rect.y(); working = new ArrayList<>(rows);
            } else if (hideRect(rect).contains(mx, my)) {
                action = Action.HIDE; tapKey = row.id();
            } else if (row.id().isTab() && modeRect(rect).contains(mx, my)) {
                action = Action.MODE; tapKey = row.id();
            }
        }
        return true;
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0 || !pressed) return super.mouseDragged(mx, my, button, dx, dy);
        moved |= Math.hypot(mx - downX, my - downY) >= 3;
        pointerY = my;
        if (moved) {
            if (dragged != null) placeDragged();
            else scroll = clampScroll(startScroll + downY - my);
        }
        return true;
    }

    private int draggedIndex() {
        for (int i = 0; i < working.size(); i++) if (working.get(i).id().equals(dragged)) return i;
        return -1;
    }

    private void placeDragged() {
        int to = Math.max(0, Math.min(working.size() - 1, rowAt(pointerY - grabY + ROW_HEIGHT / 2.0)));
        int from = draggedIndex();
        if (from >= 0 && from != to) working.add(to, working.remove(from));
    }

    @Override public void tick() {
        super.tick();
        if (dragged == null || !moved) return;
        int edge = Math.min(20, viewport.h() / 4);
        if (pointerY < viewport.y() + edge) scroll = clampScroll(scroll - 8);
        else if (pointerY >= viewport.y() + viewport.h() - edge) scroll = clampScroll(scroll + 8);
        placeDragged();
    }

    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || !pressed) return super.mouseReleased(mx, my, button);
        if (dragged != null && moved) {
            pointerY = my;
            placeDragged();
            if (draggedIndex() != originalIndex) ScoreboardLayout.reorder(working);
        } else if (!moved && tapKey != null && viewport.contains(mx, my)) {
            int index = rowAt(my);
            if (index >= 0 && index < rows.size() && rows.get(index).id().equals(tapKey)) {
                Rect rect = rowRect(index);
                if (action == Action.HIDE && hideRect(rect).contains(mx, my)) ScoreboardLayout.hide(tapKey);
                if (action == Action.MODE && modeRect(rect).contains(mx, my)) ScoreboardLayout.toggleMode(tapKey);
            }
        }
        clearGesture(); refresh();
        return true;
    }

    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        if (!pressed && viewport.contains(mx, my)) { scroll = clampScroll(scroll - amount * ROW_HEIGHT); return true; }
        return super.mouseScrolled(mx, my, amount);
    }

    private void clearGesture() { pressed = moved = false; dragged = tapKey = null; working = null; action = null; }
    @Override public void removed() { clearGesture(); super.removed(); }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
