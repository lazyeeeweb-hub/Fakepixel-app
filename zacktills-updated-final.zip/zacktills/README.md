# Zacktills Client (Minecraft 1.20.1 / Fabric)

This is an experimental client-side source update to the provided config-menu prototype. It contains settings and rendering hooks for configurable HUD elements, clean scoreboard, slot locks, flat dropped-item icons, tooltip scrolling, custom crosshair/viewmodel, swing-through, opt-in chat-triggered login, third-person wall fade.

## Build
Open the project with a Java 17 Gradle environment and run `gradle build`. The resulting mod JAR is expected under `build/libs/`. The source targets Fabric Loom 1.6.12, Yarn 1.20.1+build.10, Fabric API 0.92.2+1.20.1 and Java 17. Verify the in-game controls and visuals in a test profile before use.

## Notes / limitations
- Sodium donation-prompt hiding is controlled by the existing menu setting. A separate opt-in setting, “Hide Sodium driver warning (may hide compatibility problems),” suppresses Sodium 0.5.x early and context-time driver-warning checks. It is off by default; enabling it can conceal real driver compatibility problems. Hooks are optional when Sodium is absent.
- Wall fade is experimental, uses a vanilla core-shader dither effect, and is disabled when Sodium or Iris is detected.
- Autologin is off by default and requires an exact server address. The password is kept in memory only until disconnect; only enable it for a trusted server. Chat prompts on unsigned/custom servers may be spoofed.
- Slot lock is a client-side guard for local inventory interactions, not protection against server/plugin changes. Multi-slot inventory operations are conservatively blocked when any local slot is locked.
- Mod Menu 7.2.2 already restores the mod-list scroll position when returning to the same ModsScreen instance; recent mods are not reordered. Other Mod Menu versions or screens that create a fresh ModsScreen are unverified.

Controls: Right Shift opens configuration; L toggles lock for the hovered player-inventory slot. All settings are configurable in the Zacktills menu.

## ZUI-style hub
- Right Shift still opens settings. Pick a named tab on the left. Search, filters, tooltips, keyboard navigation, and unrelated setting IDs are retained.
- Drag the title bar to move the hub or the dotted lower-right grip to resize it. `−` collapses the hub; `+` expands it. `X` or Escape closes it and saves settings. Window placement and collapse state are not written to the config.
- Under **Tooltips & crosshair**, **Crosshair thickness** (1–9) and **Crosshair arm length** (1–20) work independently, in scaled GUI pixels. Arm length is measured outward from the center square. The preview uses the same geometry as the HUD. The 1/4 defaults reproduce the old 9×9 crosshair. Turning off the custom crosshair leaves the vanilla renderer in control.

## Touch controls and HUD additions
- Tap **Zacktills** on the pause or title screen to open the hub. The persistent-tab keybind is unbound by default; under **Tab list**, tap **Show tab list (toggle)** instead. It changes only the vanilla tab-key check and resets on disconnect; vanilla still controls singleplayer eligibility and HUD visibility.
- **Tab parts** opens the picker and HUD editor. Pick a live line or whole section with taps; normalized labels ignore changing numbers and duplicate occurrences remain distinct. Each saved part has a UUID so its position survives changing labels. When a part briefly disappears during a tab refresh, its previous text stays visible for up to three seconds. Tap **HUD editor** to select and move any HUD element, resize from its corner handle, toggle visibility, reset its position, or delete a tab part. Toggle **Snap** in the editor bar to align elements and screen edges/centers. Tab overlays use square F3 grey by default; **Tab overlay style** also offers square black Subtitles style. Missing tab parts are hidden after the three-second grace period. Tab parts also hide when vanilla's tab list is open or F1 hides the HUD.
- **Scoreboard editor** shows the sidebar's live lines. Drag a row grip to reorder, tap **X** to hide it, or use **Add from tab** to inject a tab line/section as **Copy** or **Move** (Move also hides its separate overlay). **Reset scoreboard layout** clears the ordering and hidden-key list. New native lines keep natural order; numbers in line names are ignored for matching.
- **Bossbar filter** lists live bars to hide and saved hidden names to remove. Filtering only excludes bars from rendering, not from the server/client bossbar map.
- Pause/title menu rows now re-center in both axes and normalize to full-width singles or equal half-width pairs when optional buttons are hidden.
- **Auto click** starts off. Enable it only on trusted servers. It uses vanilla's `RUN_COMMAND` rules and ignores overlay/action-bar messages and other click actions. The default trigger is `[OPEN MENU]` (case-insensitive), with a four-tick delay and two-second cooldown. **Enter trigger text (touch keyboard)** works without a launcher keyboard. Debug messages are written to the game log.
- **Playtime** counts real time with a world loaded, including while paused. The pause menu shows it by default. Use **Enter exact days / hours / minutes** to set the draft with a tap keypad, then **Apply (overwrite playtime)**. **Reset playtime to zero** clears the total; changing draft fields alone leaves the counter untouched.
- Tab parts, scoreboard layout, hidden bossbars, and playtime are saved atomically as JSON in `config/zacktills/tab_parts.json`, `config/zacktills/scoreboard_layout.json`, `config/zacktills/bossbar_filter.json`, and `config/zacktills/playtime.json`. The tab-parts loader migrates old raw keys to normalized labels and assigns UUIDs without discarding saved positions. Playtime saves every minute while playing, on disconnect, and on normal client shutdown. Legacy unknown settings are ignored.



- In-game HUD text (scoreboard, tab-part boxes, and item stack counts) uses the bundled Google Fonts Inter typeface with a TrueType font provider; the settings/menu UI keeps the vanilla font. Inter is distributed under the SIL Open Font License; its license is included beside the font resource.

## Tooltip panel and tab boxes
- Long tooltips keep their slot/stack scroll positions and show a retained classic dark panel with a purple outline, fixed 8 GUI pixels from the top. The scrollbar has only a thin 2px thumb; an invisible wide touch target lets you drag it. There is no track or gutter.
- **Tab list → Tab overlay box size** controls 0–8 px of padding on all four sides of each plain F3 row (default 1). Rows abut, and the HUD editor bounds, snapping, and resize handle use the same padded measurements.

## Quick drop
- The enabled **Quick drop toggle button** appears beside standard container GUIs. Tap its **D** button to toggle (gray off, red on); its hit area is larger than its 14×14 graphic. When on, a left tap on an occupied slot with an empty cursor drops the entire stack. Right/other clicks and output slots remain vanilla; locked slots are skipped. The toggle starts off and resets on disconnect/world changes. The creative inventory uses a different screen path and is not supported by this button.

## Performance: Armor stand limiter
- **Armor stand limiter** is off by default. In camera radius 8–128 blocks (default 64), **Max armor stands rendered** (1–1000, default 48) limits only the nearest ordinary stands. Stands outside the radius are unaffected. Your vehicle is exempt; enable **Always show named stands** to exempt named stands too. This is client render culling only; it does not alter ticks, entity data, or packets.

## Dungeoneer glow
- Disabled by default. Every 20 ticks, visible tab text is checked for the normalized **Tab area label** (`Area`) and case-insensitive **Area must contain** (`Dungeon`), except when **Ignore if area contains** (`Hub`) matches. Leave Ignore empty to disable it.
- Living hostile monsters, fake players absent from the multiplayer tab list, and optional extras are highlighted only within **Max distance (blocks)** (default 48). Tab-listed players, the local player, dead entities and armor stands are excluded. **Extra entity types** accepts comma-separated entity IDs; **Extra name contains** checks normalized custom names. Aim at an entity and tap **Add targeted mob** to add its type ID, with a chat confirmation.
- Tap each **Edit … (touch keyboard)** action to change the string/color settings with the built-in on-screen keyboard. **Glow color (hex RGB)** defaults to `FF0000`; **Highlight style** offers vanilla glow outline (default) or **Box through walls**. Both use client-side rendering without changing teams, scoreboard, entity data, or packets.
