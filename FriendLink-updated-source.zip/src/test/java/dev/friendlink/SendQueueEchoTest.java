package dev.friendlink;

import dev.friendlink.Models.*;
import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SendQueueEchoTest {
    private Field field(String name) throws Exception { Field f = SendQueue.class.getDeclaredField(name); f.setAccessible(true); return f; }
    @SuppressWarnings("unchecked")
    @Test void outgoingEchoAcknowledgesWithoutAddingMessageAndOnlyOnce() throws Exception {
        FriendLink mod = new FriendLink(); SendQueue queue = new SendQueue(mod);
        Message message = new Message("Me", "hello", false);
        SendQueue.Job job = new SendQueue.Job("Steve", "hello", "f:steve", message);
        assertTrue(queue.offer(List.of(job)));
        ((ArrayDeque<SendQueue.Job>) field("waiting").get(queue)).remove(); field("active").set(queue, job);
        assertTrue(queue.echo("sTeVe", "hello")); assertEquals(1, message.delivery.get("Steve").completed);
        assertTrue(queue.echo("Steve", "hello")); assertEquals(1, message.delivery.get("Steve").completed);
        assertEquals("Steve: \u2713 sent", message.status()); assertFalse(queue.echo("Other", "hello"));
    }
    @SuppressWarnings("unchecked")
    @Test void lateEchoUpgradesUnconfirmedOnce() throws Exception {
        FriendLink mod = new FriendLink(); SendQueue queue = new SendQueue(mod);
        Message message = new Message("Me", "hello", false);
        SendQueue.Job job = new SendQueue.Job("Steve", "hello", "f:steve", message);
        queue.offer(List.of(job));
        ((ArrayDeque<SendQueue.Job>) field("waiting").get(queue)).remove(); field("active").set(queue, job);
        var finish = SendQueue.class.getDeclaredMethod("finish", boolean.class, boolean.class, String.class);
        finish.setAccessible(true); finish.invoke(queue, false, true, "");
        assertEquals(1, message.delivery.get("Steve").unconfirmed);
        assertTrue(queue.echo("Steve", "hello")); assertEquals(0, message.delivery.get("Steve").unconfirmed);
        assertTrue(queue.echo("Steve", "hello")); assertEquals(0, message.delivery.get("Steve").unconfirmed);
        queue.clearEchoes(); assertFalse(queue.echo("Steve", "hello"));
    }
}
