package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WhisperRulesTest {
    private void matches(List<String> regexes, String text, String name, String body) {
        int count = 0;
        for (String regex : regexes) {
            var match = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
            if (match.matches()) {
                assertEquals(name, match.group("name")); assertEquals(body, match.group("message")); count++;
            }
        }
        assertEquals(1, count, text);
    }
    @Test void allRequestedPluginFormatsAndVanillaFallback() {
        Config c = new Config();
        matches(c.incomingRegex, "[Steve -> me] hello", "Steve", "hello");
        matches(c.incomingRegex, "From Steve: hello", "Steve", "hello");
        matches(c.outgoingRegex, "[me -> Steve] hello", "Steve", "hello");
        matches(c.outgoingRegex, "To Steve: hello", "Steve", "hello");
        matches(c.incomingRegex, "Steve whispers to you: hello", "Steve", "hello");
        matches(c.outgoingRegex, "You whisper to Steve: hello", "Steve", "hello");
        matches(c.incomingRegex, "fRoM sTeVe: hello", "sTeVe", "hello");
    }
    @Test void nameOrUuidIdentityAndStrangers() {
        State s = new State(); Friend f = new Friend(); f.name = "Steve";
        UUID uuid = UUID.randomUUID(); f.uuid = uuid.toString(); s.friends.put("steve", f);
        assertSame(f, FriendIdentity.find(s, "sTeVe", null));
        assertSame(f, FriendIdentity.find(s, "Renamed", uuid));
        assertSame(f, FriendIdentity.find(s, "Steve", UUID.randomUUID()));
        assertNull(FriendIdentity.find(s, "Stranger", UUID.randomUUID()));
    }
    @Test void groupTagParsesOnlyBodyAndPreservesPayload() {
        String id = "00000000-0000-0000-0000-000000000001";
        var matcher = Protocol.groupPattern(new Config().groupTag).matcher("[FL:" + id + "] hello");
        assertTrue(matcher.matches()); assertEquals(id, matcher.group("id")); assertEquals("hello", matcher.group("message"));
        assertFalse(Protocol.groupPattern(new Config().groupTag).matcher("Steve whispers: [FL:" + id + "] hello").matches());
    }
    @Test void sentStatusUsesASingleTick() {
        Message m = new Message("Me", "hello", false); Delivery d = new Delivery(); d.total = d.completed = 1;
        m.delivery.put("Steve", d); assertEquals("Steve: \u2713 sent", m.status());
    }
}
