package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.friendlink.Models.Friend;
import dev.friendlink.mixin.PlayerGlowPoseAccessor;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/** Standalone, unlit geometry. Never changes any entity's vanilla rendering state. */
public final class FriendGlow {
    private static final int LIMIT = 512;
    private final FriendLink mod;
    private final Entry[] entries = new Entry[LIMIT];
    private int count, ticks;
    private long version = Long.MIN_VALUE;
    // All buffers, layers, wrappers and colour components are retained, not created in render().
    private final BufferBuilder buffer = new BufferBuilder(1 << 20);
    private final FlatConsumer flat = new FlatConsumer();
    private final MatrixStack matrices = new MatrixStack();
    private final Layer[] layers = new Layer[6];

    private static final class Entry {
        AbstractClientPlayerEntity player;
        int red, green, blue, alpha;
        GlowStyle style;
        boolean throughWalls, pulse;
        float thickness, occlusion = 1;
        double distanceSquared;
    }

    public FriendGlow(FriendLink mod) {
        this.mod = mod;
        for (int i = 0; i < LIMIT; i++) entries[i] = new Entry();
        for (int style = 0; style < 3; style++) {
            layers[style * 2] = new Layer(style, false);
            layers[style * 2 + 1] = new Layer(style, true);
        }
        /**
         * LAST is after entities AND translucent terrain/Fabulous compositing.
         * Drawing immediately here prevents later world geometry from covering an
         * x-ray glow. We traverse only the client's loaded player list, independently
         * of vanilla entity distance/frustum/occlusion culling. Camera-relative vertices
         * use the context view matrix, not a second camera transform.
         */
        WorldRenderEvents.LAST.register(this::render);
    }

    public void clear() {
        for (int i = 0; i < count; i++) entries[i].player = null;
        count = 0; version = Long.MIN_VALUE;
    }

    /** Client tick only: name matching, settings resolution and block raycasts may allocate here. */
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { clear(); return; }
        if (++ticks % 5 != 0 && version == mod.version) return;
        clear();
        Config c = mod.config;
        var players = mc.world.getPlayers();
        for (int i = 0; i < players.size() && count < LIMIT; i++) {
            AbstractClientPlayerEntity player = players.get(i);
            if (player == mc.player || !player.isAlive() || player.isSpectator() || player.isInvisible()) continue;
            Friend friend = mod.friend(player.getGameProfile().getName());
            if (friend == null || !friend.glow) continue;
            friend.normalizeGlow();
            Entry e = entries[count++];
            e.player = player;
            int rgb = friend.color;
            e.red = (rgb >> 16) & 255; e.green = (rgb >> 8) & 255; e.blue = rgb & 255;
            e.alpha = Math.round((friend.glowOpacity < 0 ? c.glowOpacity : friend.glowOpacity) * 2.55f);
            e.style = GlowStyle.resolve(friend.glowStyle, c.defaultGlowStyle);
            e.throughWalls = friend.glowThroughWalls.resolve(c.glowThroughWalls);
            e.pulse = friend.glowPulse.resolve(c.glowMarkerPulse);
            e.thickness = (float) (friend.glowThickness == 0 ? c.glowThickness : friend.glowThickness);
            int distance = friend.glowMaxDistance == 0 ? c.glowMaxDistance : friend.glowMaxDistance;
            e.distanceSquared = (double) distance * distance;
            e.occlusion = 1;
            if (e.throughWalls && c.glowFadeBehindBlocks && mod.config.glowEnabled) {
                Vec3d camera = mc.gameRenderer.getCamera().getPos();
                Vec3d body = player.getPos().add(0, player.getHeight() * .5, 0);
                if (camera.squaredDistanceTo(body) <= e.distanceSquared
                    && mc.world.raycast(new RaycastContext(camera, body, RaycastContext.ShapeType.COLLIDER,
                        RaycastContext.FluidHandling.NONE, mc.player)).getType() == HitResult.Type.BLOCK)
                    e.occlusion = c.glowOccludedOpacity / 100f;
            }
        }
        version = mod.version;
    }

    private void render(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!mod.config.glowEnabled || mc.world == null || mc.player == null || count == 0) return;
        Vec3d camera = context.camera().getPos();
        float delta = context.tickDelta();
        for (int i = 0; i < count; i++) {
            Entry e = entries[i];
            AbstractClientPlayerEntity p = e.player;
            // Repeat the volatile checks: an unload, invisibility or spectator change may occur between cache ticks.
            if (p == null || p == mc.player || p.isRemoved() || p.getWorld() != mc.world
                || mc.world.getEntityById(p.getId()) != p || !p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            double x = MathHelper.lerp(delta, p.prevX, p.getX()) - camera.x;
            double y = MathHelper.lerp(delta, p.prevY, p.getY()) - camera.y;
            double z = MathHelper.lerp(delta, p.prevZ, p.getZ()) - camera.z;
            if (x * x + y * y + z * z > e.distanceSquared || e.alpha == 0) continue;
            // Reset the same base matrices, without allocating a friend-specific MatrixStack.
            matrices.peek().getPositionMatrix().set(context.matrixStack().peek().getPositionMatrix());
            matrices.peek().getNormalMatrix().set(context.matrixStack().peek().getNormalMatrix());
            matrices.translate(x, y, z);
            int style = e.style.ordinal() - 1;
            Layer layer = layers[style * 2 + (e.throughWalls ? 1 : 0)];
            buffer.begin(VertexFormat.DrawMode.QUADS, style == 1 ? VertexFormats.POSITION_TEXTURE_COLOR : VertexFormats.POSITION_COLOR);
            flat.set(buffer, e.red, e.green, e.blue, Math.round(e.alpha * e.occlusion));
            if (e.style == GlowStyle.SILHOUETTE) silhouette(mc, p, e, delta);
            else {
                double distance = Math.sqrt(x * x + y * y + z * z);
                float scale = (float) DistanceScaling.multiplier(distance, mod.config.glowScaleWithDistance,
                    mod.config.glowScaleFactor, mod.config.glowMaxScale);
                billboard(context, p, e, delta, scale);
            }
            // Immediate draw: our own buffer, never the entity/outline VertexConsumerProvider.
            layer.draw(buffer, RenderSystem.getVertexSorting());
        }
    }

    private void silhouette(MinecraftClient mc, AbstractClientPlayerEntity p, Entry e, float delta) {
        if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerEntityRenderer renderer)) return;
        PlayerGlowPoseAccessor pose = (PlayerGlowPoseAccessor) renderer;
        PlayerEntityModel<AbstractClientPlayerEntity> model = renderer.getModel();
        pose.friendlink$setModelPose(p);
        model.handSwingProgress = p.getHandSwingProgress(delta);
        model.riding = p.hasVehicle(); model.child = p.isBaby();
        float bodyYaw = MathHelper.lerpAngleDegrees(delta, p.prevBodyYaw, p.bodyYaw);
        float headYaw = MathHelper.lerpAngleDegrees(delta, p.prevHeadYaw, p.headYaw);
        float relativeYaw = headYaw - bodyYaw;
        if (p.getVehicle() instanceof LivingEntity mount) {
            bodyYaw = MathHelper.lerpAngleDegrees(delta, mount.prevBodyYaw, mount.bodyYaw);
            relativeYaw = MathHelper.wrapDegrees(headYaw - bodyYaw);
            float clamp = MathHelper.clamp(relativeYaw, -85, 85);
            bodyYaw = headYaw - clamp;
            if (clamp * clamp > 2500) bodyYaw += clamp * .2f;
            relativeYaw = headYaw - bodyYaw;
        }
        float pitch = MathHelper.lerp(delta, p.prevPitch, p.getPitch());
        if (LivingEntityRenderer.shouldFlipUpsideDown(p)) { pitch = -pitch; relativeYaw = -relativeYaw; }
        if (p.isInSneakingPose()) matrices.translate(0, -.125, 0);
        if (p.isInPose(EntityPose.SLEEPING)) {
            Direction direction = p.getSleepingDirection();
            if (direction != null) {
                float eye = p.getEyeHeight(EntityPose.STANDING) - .1f;
                matrices.translate(-direction.getOffsetX() * eye, 0, -direction.getOffsetZ() * eye);
            }
        }
        // Expand around the body centre rather than lifting the model off its feet.
        float centre = p.getHeight() * .5f;
        matrices.translate(0, centre, 0);
        matrices.scale(e.thickness, e.thickness, e.thickness);
        matrices.translate(0, -centre, 0);
        float age = p.age + delta;
        pose.friendlink$setupTransforms(p, matrices, age, bodyYaw, delta);
        matrices.scale(-1, -1, 1);
        pose.friendlink$scale(p, matrices, delta);
        matrices.translate(0, -1.501, 0);
        float speed = 0, limb = 0;
        if (!p.hasVehicle() && p.isAlive()) {
            speed = Math.min(1, p.limbAnimator.getSpeed(delta));
            limb = p.limbAnimator.getPos(delta);
            if (p.isBaby()) limb *= 3;
        }
        model.animateModel(p, limb, speed, delta);
        model.setAngles(p, limb, speed, age, relativeYaw, pitch);
        // FlatConsumer drops texture, normal, overlay and light attributes. Player skin,
        // armour, held items, hurt tint, light level and vanilla glow cannot affect this colour.
        model.render(matrices, flat, 0, 0, 1, 1, 1, 1);
    }

    private void billboard(WorldRenderContext context, AbstractClientPlayerEntity p, Entry e, float delta, float scale) {
        int alpha = Math.round(e.alpha * e.occlusion);
        if (e.style == GlowStyle.HALO) {
            matrices.translate(0, p.getHeight() * .5, 0);
            matrices.multiply(context.camera().getRotation());
            // The textured billboard lies slightly behind the centre of the player's body.
            Matrix4f m = matrices.peek().getPositionMatrix();
            textureVertex(m, -.9f, -1.2f, -.35f, 0, 1, e, alpha);
            textureVertex(m, .9f, -1.2f, -.35f, 1, 1, e, alpha);
            textureVertex(m, .9f, 1.2f, -.35f, 1, 0, e, alpha);
            textureVertex(m, -.9f, 1.2f, -.35f, 0, 0, e, alpha);
        } else {
            float wave = e.pulse ? MathHelper.sin((p.age + delta) * .12f) : 0;
            matrices.translate(0, p.getHeight() + .45 + wave * .07, 0);
            matrices.multiply(context.camera().getRotation());
            Matrix4f m = matrices.peek().getPositionMatrix();
            float size = (.19f + wave * .025f) * scale;
            diamond(m, size * 1.5f, e, alpha / 4);
            // A contrasting border grows proportionally, rather than becoming hair-thin.
            diamond(m, size * 1.12f, 0, 0, 0, alpha);
            diamond(m, size, e, alpha);
        }
    }
    private void diamond(Matrix4f m, float radius, Entry e, int alpha) {
        diamond(m, radius, e.red, e.green, e.blue, alpha);
    }
    private void diamond(Matrix4f m, float radius, int red, int green, int blue, int alpha) {
        position(buffer, m, 0, radius, 0).color(red, green, blue, alpha).next();
        position(buffer, m, radius * .7f, 0, 0).color(red, green, blue, alpha).next();
        position(buffer, m, 0, -radius, 0).color(red, green, blue, alpha).next();
        position(buffer, m, -radius * .7f, 0, 0).color(red, green, blue, alpha).next();
    }
    private void textureVertex(Matrix4f m, float x, float y, float z, float u, float v, Entry e, int alpha) {
        position(buffer, m, x, y, z).texture(u, v).color(e.red, e.green, e.blue, alpha).next();
    }
    /** Scalar transform, avoiding the default consumer's temporary vector objects. */
    private static VertexConsumer position(VertexConsumer target, Matrix4f m, float x, float y, float z) {
        return target.vertex(m.m00() * x + m.m10() * y + m.m20() * z + m.m30(),
            m.m01() * x + m.m11() * y + m.m21() * z + m.m31(),
            m.m02() * x + m.m12() * y + m.m22() * z + m.m32());
    }

    /** Six cached layers, with state bound when DRAWN, not when vertices are queued. */
    private static final class Layer extends RenderLayer {
        private static final Identifier HALO = new Identifier("friendlink", "textures/glow/halo.png");
        // RenderLayer inherits RenderPhase.ShaderProgram, which shadows an import.
        // RenderSystem.setShader requires the GL program, NOT that render-phase wrapper.
        private static final Supplier<net.minecraft.client.gl.ShaderProgram> FLAT_SHADER = GameRenderer::getPositionColorProgram;
        private static final Supplier<net.minecraft.client.gl.ShaderProgram> HALO_SHADER = GameRenderer::getPositionTexColorProgram;
        Layer(int style, boolean through) {
            super("friendlink_glow_" + style + (through ? "_xray" : "_depth"),
                style == 1 ? VertexFormats.POSITION_TEXTURE_COLOR : VertexFormats.POSITION_COLOR,
                // Blending is configured explicitly below. No quad sorting is needed for
                // additive auras or a single marker, so avoid its temporary sort arrays.
                VertexFormat.DrawMode.QUADS, 1 << 20, false, false,
                () -> begin(style, through), Layer::end);
        }
        private static void begin(int style, boolean through) {
            RenderSystem.setShader(style == 1 ? HALO_SHADER : FLAT_SHADER);
            if (style == 1) RenderSystem.setShaderTexture(0, HALO);
            RenderSystem.setShaderColor(1, 1, 1, 1);
            RenderSystem.enableBlend();
            if (style == 2) RenderSystem.defaultBlendFunc();
            else RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ZERO);
            RenderSystem.disableCull();
            RenderSystem.depthMask(false);
            if (through) RenderSystem.disableDepthTest();
            else { RenderSystem.enableDepthTest(); RenderSystem.depthFunc(GL11.GL_LEQUAL); }
        }
        private static void end() {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest(); RenderSystem.depthFunc(GL11.GL_LEQUAL);
            RenderSystem.enableCull(); RenderSystem.defaultBlendFunc(); RenderSystem.disableBlend();
            RenderSystem.setShaderColor(1, 1, 1, 1);
        }
    }

    /** One reusable adapter: Minecraft model vertices -> untextured POSITION_COLOR. */
    private static final class FlatConsumer implements VertexConsumer {
        private VertexConsumer target;
        private int r, g, b, a;
        void set(VertexConsumer target, int r, int g, int b, int a) {
            this.target = target; this.r = r; this.g = g; this.b = b; this.a = a;
        }
        @Override public VertexConsumer vertex(double x, double y, double z) { target.vertex(x, y, z); return this; }
        @Override public VertexConsumer vertex(Matrix4f m, float x, float y, float z) {
            position(target, m, x, y, z); return this;
        }
        @Override public VertexConsumer color(int r, int g, int b, int a) { target.color(this.r, this.g, this.b, this.a); return this; }
        @Override public VertexConsumer texture(float u, float v) { return this; }
        @Override public VertexConsumer overlay(int u, int v) { return this; }
        @Override public VertexConsumer light(int u, int v) { return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { return this; }
        @Override public void next() { target.next(); }
        @Override public void fixedColor(int r, int g, int b, int a) { }
        @Override public void unfixColor() { }
    }
}
