package dev.friendlink.ui;

import dev.friendlink.Faces;
import dev.friendlink.FriendLink;
import dev.friendlink.ConversationSelection;
import dev.friendlink.GlowStyle;
import dev.friendlink.Models.*;
import dev.friendlink.Protocol;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Rendering uses prepared rows/OrderedText. Rewrapping and texture/name lookup happen in tick/init. */
public final class ChatScreen extends Screen {
    private final FriendLink mod = FriendLink.INSTANCE;
    private final List<Row> rows = new ArrayList<>();
    private final List<Line> lines = new ArrayList<>();
    private String selected, heading = "Select a friend or group", error = "", draft = "";
    private TextFieldWidget input;
    private ButtonWidget send, manage, glowButton, colorButton;
    private GlowStyleDropdown glowStyle;
    private Friend glowTarget;
    private static final Text GLOW_ON = Text.literal("✦ Glow: ON"), GLOW_OFF = Text.literal("✦ Glow: OFF");
    private int side, mainX, top = 76, bottom, sidebarScroll, messageScroll;
    private static final int SIDEBAR_TOP = 44;
    private long cachedVersion = -1;
    private static final class Row {
        String key, name, badge;
        Friend friend;
        Group group;
        Identifier[] faces;
    }
    private record Line(OrderedText text, Identifier face, int color) {}
    public ChatScreen(String selected) {
        super(Text.literal("FriendLink"));
        this.selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
    }
    public String conversation() { return selected; }
    @Override protected void init() {
        if (input != null) draft = input.getText();
        selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
        messageScroll = 0;
        side = Math.min(170, Math.max(132, width / 3)); mainX = side + 8; bottom = height - 58;
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> client.setScreen(new PromptScreen(this,
            "Add friend (Java username)", "", mod::addFriend))).dimensions(6, 23, 24, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Group +"), b -> client.setScreen(new GroupScreen(this, null)))
            .dimensions(34, 23, 54, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cfg"), b -> mod.openConfig(this)).dimensions(92, 23, 32, 18).build());
        int actionWidth = Math.min(60, Math.max(24, (width - mainX - 10) / 2));
        addDrawableChild(ButtonWidget.builder(Text.literal("View"), b -> client.setScreen(new ViewSettingsScreen(this)))
            .dimensions(width - 10 - actionWidth * 2, 22, actionWidth, 18).build());
        manage = addDrawableChild(ButtonWidget.builder(Text.literal("Manage"), b -> manage())
            .dimensions(width - 6 - actionWidth, 22, actionWidth, 18).build());
        input = new TextFieldWidget(textRenderer, mainX, height - 25, Math.max(32, width - mainX - 54), 20, Text.literal("Private message"));
        input.setMaxLength(4096); input.setText(draft); addDrawableChild(input); setInitialFocus(input);
        send = addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> send()).dimensions(width - 46, height - 25, 40, 20).build());
        int available = width - mainX - 6;
        int colorWidth = Math.max(24, Math.min(58, available / 5));
        int toggleWidth = Math.min(98, (available - colorWidth - 8) / 2);
        int styleWidth = available - colorWidth - toggleWidth - 8;
        glowButton = addDrawableChild(ButtonWidget.builder(GLOW_ON, b -> {
            if (glowTarget != null) { glowTarget.glow = !glowTarget.glow; mod.touch(); }
            else { mod.config.glowEnabled = !mod.config.glowEnabled; mod.saveConfig(); }
            refresh();
        }).dimensions(mainX, 48, toggleWidth, 20).build());
        glowStyle = addDrawableChild(new GlowStyleDropdown(mainX + toggleWidth + 4, 48, styleWidth, style -> {
            if (glowTarget != null) { glowTarget.glowStyle = style; mod.touch(); }
            else { mod.config.defaultGlowStyle = style; mod.saveConfig(); }
        }));
        colorButton = addDrawableChild(ButtonWidget.builder(Text.literal("RGB"), b -> {
            if (glowTarget != null) client.setScreen(new ColorScreen(this, glowTarget));
            else client.setScreen(new ColorScreen(this, "Default glow color", mod.config.defaultGlowColor,
                color -> { mod.config.defaultGlowColor = color; mod.saveConfig(); }));
        }).dimensions(mainX + toggleWidth + styleWidth + 8, 48, colorWidth, 20).build());
        colorButton.setTooltip(Tooltip.of(Text.literal("Choose the glow colour with RGB sliders or a hex value.")));
        refresh();
    }
    @Override public void tick() {
        input.tick(); mod.read(selected);
        if (cachedVersion != mod.version) refresh();
    }
    private void refresh() {
        rows.clear();
        for (Friend f : mod.state.friends.values()) {
            Row r = new Row(); r.key = "f:" + Protocol.key(f.name); r.friend = f;
            r.name = textRenderer.trimToWidth(f.name, side - 55); r.badge = f.unread == 0 ? "" : Integer.toString(Math.min(99, f.unread));
            r.faces = new Identifier[] { mod.skins.face(f.name) }; rows.add(r);
        }
        for (Group g : mod.state.groups.values()) {
            if (g.left) continue;
            Row r = new Row(); r.key = "g:" + g.id; r.group = g;
            r.name = textRenderer.trimToWidth((g.pending ? "? " : "") + g.name, side - 45);
            r.badge = g.unread == 0 ? "" : Integer.toString(Math.min(99, g.unread));
            r.faces = new Identifier[Math.min(4, g.members.size())];
            for (int i = 0; i < r.faces.length; i++) r.faces[i] = mod.skins.face(g.members.get(i));
            rows.add(r);
        }
        Row active = null;
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).key.equals(selected)) { active = rows.get(i); break; }
        if (active == null) {
            selected = ConversationSelection.choose(mod.state, null, mod.config.reopenLastConversation);
            for (Row row : rows) if (row.key.equals(selected)) { active = row; break; }
            messageScroll = 0;
        }
        mod.rememberConversation(selected);
        heading = textRenderer.trimToWidth(active == null ? "Select a friend or group" : active.friend != null
            ? active.friend.name : active.group.name + (active.group.pending ? " (pending)" : active.group.muted ? " (muted)" : ""), width - mainX - 6);
        glowTarget = active == null ? null : active.friend;
        boolean enabled = glowTarget == null ? mod.config.glowEnabled : glowTarget.glow;
        glowButton.setMessage(enabled ? GLOW_ON : GLOW_OFF);
        glowButton.setTooltip(Tooltip.of(Text.literal(glowTarget == null
            ? "Master glow toggle. No friend selected: style and colour edit global defaults. Key G also toggles all glow."
            : "Toggle glow for " + glowTarget.name + ". " + (mod.config.glowEnabled
                ? "Master glow is ON." : "Master glow is OFF; press G in-game or use Cfg to enable all glow."))));
        glowStyle.selection(glowTarget == null ? mod.config.defaultGlowStyle : glowTarget.glowStyle, glowTarget != null);
        colorButton.setTooltip(Tooltip.of(Text.literal("Pick " + (glowTarget == null ? "default" : glowTarget.name + "'s")
            + " glow colour (RGB / hex).")));
        manage.active = active != null;
        send.active = active != null && (active.group == null || !active.group.pending);
        input.setEditable(send.active);
        lines.clear();
        List<Message> messages = mod.messages(selected);
        for (int i = 0; i < messages.size(); i++) {
            Message m = messages.get(i);
            if (!m.system) mod.skins.request(m.sender);
            Identifier face = m.system ? null : mod.skins.face(m.sender);
            List<OrderedText> wrapped = textRenderer.wrapLines(Text.literal((m.system ? "• " : m.sender + ": ") + m.text), Math.max(20, width - mainX - 28));
            for (int j = 0; j < wrapped.size(); j++) lines.add(new Line(wrapped.get(j), j == 0 ? face : null, m.system ? 0xFFB7B7C8 : 0xFFE8E8F2));
            String status = m.status();
            if (!status.isEmpty()) {
                List<OrderedText> statuses = textRenderer.wrapLines(Text.literal(status), Math.max(20, width - mainX - 28));
                for (int j = 0; j < statuses.size(); j++) lines.add(new Line(statuses.get(j), null, 0xFF8995BC));
            }
        }
        sidebarScroll = Math.min(sidebarScroll, Math.max(0, rows.size() * 32 - (height - SIDEBAR_TOP - 20)));
        messageScroll = Math.min(messageScroll, Math.max(0, lines.size() - visibleLines()));
        mod.read(selected); cachedVersion = mod.version;
    }
    private int visibleLines() { return Math.max(1, (bottom - top) / 14); }
    private void send() {
        String result = mod.send(selected, input.getText());
        if (result == null) { input.setText(""); draft = ""; error = ""; messageScroll = 0; }
        else error = textRenderer.trimToWidth(result, Math.max(20, width - mainX - 8));
    }
    private void manage() {
        if (selected == null) return;
        if (selected.startsWith("f:")) {
            Friend f = mod.state.friends.get(selected.substring(2)); if (f != null) client.setScreen(new ColorScreen(this, f));
        } else {
            Group g = mod.state.groups.get(selected.substring(2)); if (g != null) client.setScreen(new GroupScreen(this, g));
        }
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (glowStyle.isFocused() && glowStyle.keyPressed(key, scan, modifiers)) return true;
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && send.active) { send(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP) { messageScroll = Math.min(Math.max(0, lines.size() - visibleLines()), messageScroll + visibleLines()); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_DOWN) { messageScroll = Math.max(0, messageScroll - visibleLines()); return true; }
        return super.keyPressed(key, scan, modifiers);
    }
    @Override public boolean mouseScrolled(double x, double y, double amount) {
        if (x < side) sidebarScroll = Math.max(0, Math.min(Math.max(0, rows.size() * 32 - (height - SIDEBAR_TOP - 20)), sidebarScroll - (int) (amount * 32)));
        else messageScroll = Math.max(0, Math.min(Math.max(0, lines.size() - visibleLines()), messageScroll + (int) (amount * 3)));
        return true;
    }
    @Override public boolean mouseClicked(double x, double y, int button) {
        if (glowStyle.menuClick(x, y, button)) return true;
        if (x < side && y >= SIDEBAR_TOP && y < height - 20) {
            int index = ((int) y - SIDEBAR_TOP + sidebarScroll) / 32;
            if (index >= 0 && index < rows.size()) {
                Row r = rows.get(index);
                if (button == 1 && r.friend != null) {
                    client.setScreen(new ConfirmScreen(ok -> {
                        if (ok) mod.removeFriend(r.friend.name);
                        client.setScreen(new ChatScreen(ok ? null : selected));
                    }, Text.literal("Remove " + r.friend.name + "?"), Text.literal("This also deletes this private history. Group memberships are unchanged.")));
                } else if (button == 0 && r.friend != null && x >= side - 18) client.setScreen(new ColorScreen(this, r.friend));
                else if (button == 0) client.setScreen(new ChatScreen(r.key));
                return true;
            }
        }
        return super.mouseClicked(x, y, button);
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0xD91C1F29); c.fill(0, 0, side, height, 0xEC151820);
        c.drawText(textRenderer, title, 7, 8, 0xFFFFFFFF, true);
        c.drawText(textRenderer, heading, mainX, 8, 0xFFE4E7FF, true);
        c.enableScissor(0, SIDEBAR_TOP, side, Math.max(SIDEBAR_TOP + 1, height - 20));
        for (int i = 0; i < rows.size(); i++) {
            int y = SIDEBAR_TOP + i * 32 - sidebarScroll;
            if (y + 32 < SIDEBAR_TOP || y >= height - 20) continue;
            Row r = rows.get(i);
            if (r.key.equals(selected)) c.fill(2, y, side - 2, y + 31, 0xFF353B51);
            if (r.faces.length == 1) Faces.draw(c, r.faces[0], 6, y + 4, 24);
            else for (int n = 0; n < r.faces.length; n++) Faces.draw(c, r.faces[n], 6 + (n % 2) * 12, y + 4 + (n / 2) * 12, 12);
            c.drawText(textRenderer, r.name, 34, y + 5, 0xFFE6E6F0, false);
            if (!r.badge.isEmpty()) c.drawText(textRenderer, r.badge, 34, y + 18, 0xFFFF9EAC, false);
            if (r.friend != null) {
                c.fill(side - 17, y + 9, side - 5, y + 22, 0xFF000000 | r.friend.color);
            }
        }
        c.disableScissor();
        if (bottom > top) {
            c.enableScissor(mainX, top, width - 4, bottom);
            int start = Math.max(0, lines.size() - visibleLines() - messageScroll), end = Math.min(lines.size(), start + visibleLines());
            for (int i = start; i < end; i++) {
                Line line = lines.get(i); int y = top + (i - start) * 14;
                if (line.face() != null) Faces.draw(c, line.face(), mainX, y - 2, 13);
                c.drawText(textRenderer, line.text(), mainX + 18, y, line.color(), false);
            }
            c.disableScissor();
        }
        c.drawText(textRenderer, error, mainX, height - 44, 0xFFFF9999, false);
        c.drawText(textRenderer, "Select friend to edit glow", 6, height - 16, 0xFF8990AA, false);
        super.render(c, mouseX, mouseY, delta);
        // The dropdown is an overlay and must remain above messages and neighbouring widgets.
        glowStyle.renderMenu(c, mouseX, mouseY);
    }
    @Override public boolean shouldPause() { return false; }
}
