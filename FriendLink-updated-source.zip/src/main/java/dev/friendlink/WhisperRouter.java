package dev.friendlink;

import dev.friendlink.Models.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** ALLOW_GAME and ALLOW_CHAT run before HUD insertion. Returning true here means suppress. */
public final class WhisperRouter {
    private final FriendLink mod;
    private final List<Pattern> incoming = new ArrayList<>(), outgoing = new ArrayList<>(), errors = new ArrayList<>();
    private final Map<String, Assembly> assemblies = new HashMap<>();
    private Pattern groupPattern;
    private ClientPlayNetworkHandler connection;
    private MessageType incomingType, outgoingType, incomingTeamType, outgoingTeamType;
    private static final class Assembly {
        final String[] chunks;
        final long expires = System.currentTimeMillis() + 60000;
        Assembly(int count) { chunks = new String[count]; }
    }
    public WhisperRouter(FriendLink mod) { this.mod = mod; reload(); }
    public void reload() {
        compile(incoming, mod.config.incomingRegex, true);
        compile(outgoing, mod.config.outgoingRegex, true);
        compile(errors, mod.config.notFoundRegex, false);
        groupPattern = Protocol.groupPattern(mod.config.groupTag);
    }
    private void compile(List<Pattern> output, List<String> source, boolean whisper) {
        output.clear();
        for (String s : source) {
            if (output.size() == 32) break;
            if (s == null || s.length() > 1024 || !Config.validRegex(s, whisper)) {
                FriendLink.LOG.warn("Ignored invalid FriendLink regex: {}", s); continue;
            }
            output.add(Pattern.compile(s, Pattern.CASE_INSENSITIVE));
        }
    }
    public void tick(long now) { assemblies.values().removeIf(a -> a.expires < now); }
    public void clear() {
        assemblies.clear();
        connection = null;
        incomingType = outgoingType = incomingTeamType = outgoingTeamType = null;
    }
    /** Resolve registry instances once for each connection, never once per message. */
    public void connected(MinecraftClient client) {
        if (client.player == null) return;
        ClientPlayNetworkHandler handler = client.player.networkHandler;
        if (connection == handler) return;
        clear();
        var types = handler.getRegistryManager().get(RegistryKeys.MESSAGE_TYPE);
        incomingType = types.get(MessageType.MSG_COMMAND_INCOMING);
        outgoingType = types.get(MessageType.MSG_COMMAND_OUTGOING);
        incomingTeamType = types.get(MessageType.TEAM_MSG_COMMAND_INCOMING);
        outgoingTeamType = types.get(MessageType.TEAM_MSG_COMMAND_OUTGOING);
        connection = handler;
    }
    /** Typed whispers belong exclusively to the Mixin; team chat never enters regex parsing. */
    public boolean bypassTextFallback(MessageType.Parameters params) {
        connected(MinecraftClient.getInstance());
        return params != null && (params.type() == incomingType || params.type() == outgoingType
            || params.type() == incomingTeamType || params.type() == outgoingTeamType);
    }
    public boolean receiveTyped(MessageType.Parameters params, SignedMessage message, GameProfile sender) {
        connected(MinecraftClient.getInstance());
        boolean outgoing = params.type() == outgoingType;
        if (!outgoing && params.type() != incomingType) return false;
        String name = outgoing ? (params.targetName() == null ? null : params.targetName().getString())
            : sender == null ? null : sender.getName();
        Friend friend = mod.friend(name, outgoing || sender == null ? null : sender.getId());
        if (friend == null) return false;
        if (!outgoing && sender != null && sender.getId() != null
            && !sender.getId().toString().equalsIgnoreCase(friend.uuid)) {
            friend.uuid = sender.getId().toString(); mod.touch();
        }
        // getContent() already applies the signed message's filter mask. The decoration
        // contains sender/target labels and is deliberately not used as the message body.
        String body = message.getContent().getString();
        if (body != null) route(friend, name, body, outgoing);
        return true;
    }
    /** Profileless chat has raw content but skips processChatMessageInternal entirely. */
    public boolean receiveProfileless(MessageType.Parameters params, Text content) {
        connected(MinecraftClient.getInstance());
        boolean outgoing = params.type() == outgoingType;
        if (!outgoing && params.type() != incomingType) return false;
        Text participant = outgoing ? params.targetName() : params.name();
        if (participant == null) return false;
        String name = participant.getString();
        Friend friend = mod.friend(name, null);
        if (friend == null) return false;
        route(friend, name, content.getString(), outgoing);
        return true;
    }
    private void route(Friend friend, String wireName, String body, boolean outgoing) {
        if (outgoing && (mod.queue.echo(wireName, body)
            || (!friend.name.equalsIgnoreCase(wireName) && mod.queue.echo(friend.name, body)))) return;
        if (body.startsWith("[FLI:")) {
            if (!outgoing) control(friend.name, body);
            return;
        }
        Matcher group = groupPattern.matcher(body);
        if (group.matches()) {
            if (!outgoing) groupMessage(friend.name, group.group("id"), group.group("message"));
            else {
                Group g = mod.state.groups.get(group.group("id"));
                if (g != null && !g.left && !g.pending && FriendLink.contains(g.members, friend.name))
                    mod.append("g:" + g.id, new Message(mod.self(), group.group("message"), false), false);
            }
            return;
        }
        mod.append("f:" + Protocol.key(friend.name), new Message(outgoing ? mod.self() : friend.name, body, false), !outgoing);
    }
    public boolean receive(String raw) {
        if (raw.length() > 8192) return false;
        // Formatting is absent from Text.getString() on vanilla, but plugin servers can embed § codes.
        String text = raw.indexOf('\u00a7') < 0 ? raw : raw.replaceAll("\\u00a7[0-9a-fk-orA-FK-OR]", "");
        for (Pattern p : outgoing) {
            Matcher m = p.matcher(text);
            if (!m.matches()) continue;
            String name = m.group("name"), body = m.group("message");
            if (!Protocol.validName(name)) return false;
            Friend f = mod.friend(name);
            if (f == null) return false;
            route(f, name, body, true);
            return true;
        }
        for (Pattern p : incoming) {
            Matcher m = p.matcher(text);
            if (!m.matches()) continue;
            String name = m.group("name"), body = m.group("message");
            if (!Protocol.validName(name)) return false;
            Friend f = mod.friend(name);
            if (f == null) return false; // Even protocol-looking whispers from strangers stay untouched.
            route(f, name, body, false);
            return true;
        }
        for (Pattern p : errors) if (p.matcher(text).matches()) return mod.queue.notFound();
        return false;
    }
    private void groupMessage(String sender, String id, String text) {
        Group g = mod.state.groups.get(id);
        if (g == null) {
            if (mod.state.groups.size() >= 128) return;
            g = new Group(); g.id = id; g.owner = sender; g.revision = -1;
            g.members.add(sender);
            if (!sender.equalsIgnoreCase(mod.self())) g.members.add(mod.self());
            mod.state.groups.put(id, g);
            mod.inviteNotice(g, sender);
        }
        if (g.left || !FriendLink.contains(g.members, sender) || !FriendLink.contains(g.members, mod.self())) return;
        // Pending groups retain a bounded preview, but cannot transmit until explicitly accepted.
        mod.append("g:" + id, new Message(sender, text, false), true);
    }
    private void control(String sender, String body) {
        Matcher m = Protocol.CONTROL.matcher(body);
        if (!m.matches() || !Protocol.validId(m.group("id"))) return;
        int count = Integer.parseInt(m.group("count")), part = Integer.parseInt(m.group("part"));
        if (count < 1 || count > 16 || part < 1 || part > count) return;
        String key = Protocol.key(sender) + ":" + m.group("id") + ":" + m.group("token");
        Assembly a = assemblies.get(key);
        if (a == null) {
            if (assemblies.size() >= 32) return;
            a = new Assembly(count); assemblies.put(key, a);
        }
        if (a.chunks.length != count) { assemblies.remove(key); return; }
        a.chunks[part - 1] = m.group("data");
        for (String chunk : a.chunks) if (chunk == null) return;
        assemblies.remove(key);
        try {
            Protocol.Invite i = Protocol.decodeInvite(String.join("", a.chunks));
            if (!Protocol.validInvite(i, mod.config.maxGroupSize) || !i.id.equals(m.group("id"))) return;
            mod.receiveInvite(sender, i);
        } catch (RuntimeException e) { FriendLink.LOG.debug("Rejected malformed FriendLink invitation", e); }
    }
}
