package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.List;

/** Pure selection policy shared by ordinary opens, explicit notification opens and tests. */
public final class ConversationSelection {
    private ConversationSelection() {}
    public static boolean exists(State state, String key) {
        if (key == null) return false;
        if (key.startsWith("f:")) return state.friends.containsKey(key.substring(2));
        if (!key.startsWith("g:")) return false;
        Group g = state.groups.get(key.substring(2));
        return g != null && !g.left;
    }
    public static String choose(State state, String requested, boolean reopen) {
        if (exists(state, requested)) return requested;
        if (reopen && exists(state, state.lastConversation)) return state.lastConversation;
        for (Friend f : state.friends.values()) if (f.unread > 0) return "f:" + Protocol.key(f.name);
        for (Group g : state.groups.values()) if (!g.left && g.unread > 0) return "g:" + g.id;
        String best = null;
        long latest = Long.MIN_VALUE;
        for (Friend f : state.friends.values()) {
            long time = activity(f.messages);
            if (best == null || time > latest) { best = "f:" + Protocol.key(f.name); latest = time; }
        }
        for (Group g : state.groups.values()) if (!g.left) {
            long time = activity(g.messages);
            if (best == null || time > latest) { best = "g:" + g.id; latest = time; }
        }
        return best;
    }
    private static long activity(List<Message> messages) {
        long latest = 0;
        for (Message message : messages) latest = Math.max(latest, message.time);
        return latest;
    }
}
