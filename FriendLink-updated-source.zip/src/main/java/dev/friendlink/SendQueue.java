package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;

/** One in-flight command correlates otherwise nameless vanilla 'player not found' errors. */
public final class SendQueue {
    public record Job(String target, String body, String conversation, Message message) {}
    private static final class Recent {
        final Job job;
        final long until = System.currentTimeMillis() + 30000;
        boolean unconfirmed;
        Recent(Job job, boolean unconfirmed) { this.job = job; this.unconfirmed = unconfirmed; }
    }
    private final FriendLink mod;
    private final ArrayDeque<Job> waiting = new ArrayDeque<>();
    private final ArrayDeque<Recent> recent = new ArrayDeque<>();
    private Job active;
    private long deadline, nextSend;
    private static final int CAPACITY = 512;
    public SendQueue(FriendLink mod) { this.mod = mod; }
    public boolean offer(List<Job> jobs) {
        if (waiting.size() + (active == null ? 0 : 1) + jobs.size() > CAPACITY) return false;
        for (Job j : jobs) {
            if (!Protocol.validName(j.target()) || j.body().length() > Protocol.bodyLimit(j.target())) return false;
        }
        for (Job j : jobs) {
            if (j.message() != null) j.message().delivery.computeIfAbsent(j.target(), n -> new Delivery()).total++;
            waiting.add(j);
        }
        mod.touch(); return true;
    }
    public void tick(long now) {
        while (!recent.isEmpty() && recent.peek().until < now) recent.remove();
        if (active != null && now >= deadline) finish(false, true, "");
        if (active != null || waiting.isEmpty() || now < nextSend) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null || mc.player == null) { cancel("player not found: not connected"); return; }
        active = waiting.remove();
        deadline = now + mod.config.echoTimeoutMs;
        nextSend = now + mod.config.sendDelayMs;
        try { mc.getNetworkHandler().sendChatCommand("msg " + active.target() + " " + active.body()); }
        catch (RuntimeException e) {
            FriendLink.LOG.warn("Could not send FriendLink command", e);
            finish(true, false, "player not found: command could not be sent");
        }
    }
    public boolean echo(String name, String body) {
        if (active != null && active.target().equalsIgnoreCase(name) && active.body().equals(body)) {
            finish(false, false, ""); return true;
        }
        // Late echoes must not duplicate a message after our timeout.
        for (Recent r : recent) if (r.job.target().equalsIgnoreCase(name) && r.job.body().equals(body)) {
            if (r.unconfirmed && r.job.message() != null) {
                Delivery d = r.job.message().delivery.get(r.job.target());
                if (d != null && d.unconfirmed > 0) d.unconfirmed--;
                r.unconfirmed = false;
                mod.touch();
            }
            return true;
        }
        return false;
    }
    public void clearEchoes() { recent.clear(); }
    public boolean notFound() {
        if (active == null) return false;
        finish(true, false, "player not found"); return true;
    }
    private void finish(boolean failed, boolean unknown, String reason) {
        Job j = active; active = null;
        if (j == null) return;
        recent.add(new Recent(j, unknown && !failed));
        while (recent.size() > 512) recent.remove();
        complete(j, failed, unknown, reason);
    }
    private void complete(Job j, boolean failed, boolean unknown, String reason) {
        if (j.message() != null) {
            Delivery d = j.message().delivery.get(j.target());
            if (d != null) { d.completed++; if (failed) d.failed++; if (unknown) d.unconfirmed++; }
        }
        if (failed) mod.system(j.conversation(), reason + ": " + j.target());
        mod.touch();
    }
    public void cancel(String reason) {
        if (active != null) finish(true, false, reason);
        while (!waiting.isEmpty()) complete(waiting.remove(), true, false, reason);
        nextSend = 0;
    }
    public void cancelConversation(String key) {
        // Already transmitted commands cannot be recalled; keep the active echo correlation.
        List<Job> removed = new ArrayList<>();
        waiting.removeIf(j -> { if (j.conversation().equals(key)) { removed.add(j); return true; } return false; });
        for (Job j : removed) complete(j, true, false, "Canceled");
    }
}
