# Zacktills configuration prototype

Target: Minecraft 1.20.1, Fabric, Yarn mappings, Java 17.
Mod name/id: zacktills. Screen title: Zacktils configuration menu.

## Build and run

Install JDK 17 and Gradle 8.6. From this directory:

    gradle build
    gradle runClient

The distributable is build/libs/zacktills-0.1.0.jar, not the sources JAR.
Install Fabric Loader and Fabric API for Minecraft 1.20.1 alongside it.
No Gradle wrapper binaries are included; the commands use installed Gradle.
The dependency versions are pinned compatible-era versions, not a claim that
these are the newest versions in 2026. The initial build requires internet.

Enter a world, then press Right Shift. Rebind it under Options > Controls >
Key Binds > Zacktills. The registered key opens the screen from gameplay,
not the title screen. Escape or the red X saves/closes the config screen.
The action row opens a separate draggable/resizable POSITION PREVIEW;
Escape/Back returns to the config screen. It does not copy NBT.

## Test interactions

- General contains action, bool, integral and fractional sliders, dropdown,
  string field, nested folder, disabled row and an empty color-picker box.
- There are enough categories and options to test both scrollbars.
- Wheel over a list to scroll it. Drag blank/row-label space or a scrollbar
  to pan. A short click activates a button only on release. A vertical drag
  cancels a pending button click. Sliders and text-selection drags capture
  their own gesture; use row-label space to pan past them.
- Touch works where the launcher maps a single finger to mouse down/drag/up.
  No native multi-touch, kinetic fling or launcher-specific input API is used.
- Dropdowns render above the list scissor, scroll independently, close on an
  outside click, and support Up/Down, Enter and Escape while open.
- Tab/Shift+Tab cycles controls and reveals offscreen controls. Enter/Space
  activates buttons, toggles and folders. Slider Left/Right changes value.
- Text fields implement caret/selection, drag selection, Home/End, arrows,
  Backspace/Delete, Ctrl/Cmd+A/C/X/V and a 128-character maximum. They do not
  provide a mobile soft-keyboard or IME adapter; a launcher must supply input.
- The top-right search field filters the selected category recursively.
  Matching nested children appear even if their parent was collapsed.
- Values save to the Fabric config directory as zacktills.json when leaving
  the config screen, including when opening the position preview. Invalid
  individual values are ignored. No account passwords are stored.

## Layout and drawing

The panel aims for 80% of scaled GUI width/height, clamped to 296..900 by
180..560 GUI units, with a four-unit screen safety margin. If the window is
smaller than those minima, fitting the screen takes precedence. The sidebar
is approximately 25%, minimum 72 units when space allows. All screen
positions derive from panel/list rectangles; constants are GUI-unit metrics,
not absolute screen coordinates. Option rows are 24 units; category rows 20.
Minecraft already supplies scaled GUI coordinates; do not multiply by the
window scale factor. Layout is recalculated by init() after a resize.

Every fill, one-GUI-unit border, text draw and scissor call is in DrawUtil.
No vanilla textured widgets or Screen.renderBackground calls are used.
Replace DrawUtil methods later to skin the same behavior with textures.
A one-GUI-unit border becomes multiple physical pixels at GUI scales >1.

Palette sampled from the supplied 244x192 reference:
- Main panel/rows: #313638
- Inset/sidebar: #272A2B
- Title: #4D65B4
- Selection: #4A5052
- Border: #9B9B9B
- Text: white; secondary text: muted gray

The screenshot's tiny text cannot be recovered verbatim; supplied labels
and useful dummy descriptions replace it. The color-picker box is blank by
design. The title spelling Zacktils follows the requested exact title even
though the project/mod id is zacktills. Default key was unspecified, so it is
Right Shift. Folder expansion, search and the preview's position/size are
session UI state, not saved configuration values. There is no Mod Menu
integration in this prototype and no server entrypoint.

## Feature scope: do not mistake dummy settings for working gameplay

Implemented: custom configuration menu; dummy option data; local JSON
persistence; preview-only position editor with dragging and +/- resizing.
The preview is not connected to any HUD or item/NBT feature.

Not implemented in this layout prototype:
1. Title/pause-menu button removal: needs separate screen customization and
   an explicit allowlist; this project does not remove any vanilla buttons.
2. Sodium warning changes: no warnings are hidden and Sodium is not patched.
   The phrase "no sodium warning" needs identification of the exact warning.
3. Copy-NBT button: preview editor only; copying NBT and binding the editor to
   that button still need implementation. Servers may restrict available NBT.
4. Clean scoreboard: no rendering replacement, rounded corners, red-number
   hiding, resizing or actual scoreboard placement yet.
5. 2D floating item rendering: not implemented.
6. Chat-detected autologin: not implemented; needs server-specific matching
   and a secure, opt-in credentials design, not plaintext demo config fields.
7. Giant file-backed whiteboard with text, arrows, pen and movement tools:
   separate editor/document model required; not implemented.
8. Mod Menu recent-mod sorting/scroll retention: no integration yet.
9. Hotbar/offhand inventory HUD positioning and scaling: not implemented.
10. Slot locking/drop prevention: not implemented; must cover keyboard drop,
    inventory throw clicks and other client actions, not merely a visual lock.
11. Swing-through targeting: not implemented.
12. Third-person obstructing-block fade: not implemented; requires a rendering
    integration and careful handling of depth/transparency and other mods.
13. Tooltip scrolling/forcing top visible: not implemented.
14. Centered crosshair behavior: not implemented.
15. Main/offhand viewmodel position, scale, rotation and animation speed:
    not implemented.

## Validation status and local acceptance checklist

This source has not been compiled against Minecraft or run in a launcher in
the generation environment: Java and Gradle are unavailable there. Structural
checks are not a substitute for gradle build or a gameplay test.

Locally test GUI scale 1, 2, 3 and Auto; resize while scrolled; test narrow
phone aspect ratios; tap versus drag, list/thumb edges, disabled controls,
search, nested folders, dropdown clipping, keyboard focus and persistence.
Phone-launcher touch/soft-keyboard behavior needs testing on that launcher.
