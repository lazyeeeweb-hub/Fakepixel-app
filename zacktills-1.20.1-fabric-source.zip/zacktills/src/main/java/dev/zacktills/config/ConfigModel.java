package dev.zacktills.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ConfigModel {
    private ConfigModel() {}

    public enum Kind { BOOL, RANGE, ENUM, STRING, ACTION, FOLDER, PLACEHOLDER }

    public static final class Category {
        public final String id;
        public final String label;
        public final List<Option<?>> options;
        public Category(String id, String label, List<Option<?>> options) {
            this.id = id;
            this.label = label;
            this.options = new ArrayList<>(options);
        }
    }

    public abstract static class Option<T> {
        public final Kind kind;
        public final String id;
        public final String label;
        public final String description;
        public T value;
        public boolean enabled = true;
        protected Option(Kind kind, String id, String label, String description, T value) {
            this.kind = kind;
            this.id = id;
            this.label = label;
            this.description = description;
            this.value = value;
        }
    }

    public static final class Bool extends Option<Boolean> {
        public Bool(String id, String label, String description, boolean value) {
            super(Kind.BOOL, id, label, description, value);
        }
    }

    public static final class Range extends Option<Double> {
        public final double min, max, step;
        public final boolean integral;
        public Range(String id, String label, String description,
                     double min, double max, double step, double value, boolean integral) {
            super(Kind.RANGE, id, label, description, value);
            if (max <= min || step <= 0) throw new IllegalArgumentException("Invalid range");
            this.min = min;
            this.max = max;
            this.step = step;
            this.integral = integral;
            set(value);
        }
        public void set(double number) {
            if (!Double.isFinite(number)) return;
            double snapped = min + Math.round((number - min) / step) * step;
            value = Math.max(min, Math.min(max, integral ? Math.rint(snapped) : snapped));
        }
        public String display() {
            return integral ? Long.toString(Math.round(value))
                    : String.format(Locale.ROOT, "%.2f", value);
        }
    }

    public static final class Choice extends Option<String> {
        public final List<String> choices;
        public Choice(String id, String label, String description, List<String> choices) {
            super(Kind.ENUM, id, label, description, choices.get(0));
            this.choices = List.copyOf(choices);
        }
    }

    public static final class StringOption extends Option<String> {
        public StringOption(String id, String label, String description, String value) {
            super(Kind.STRING, id, label, description, value);
        }
    }

    public static final class Action extends Option<Runnable> {
        public Action(String id, String label, String description, Runnable action) {
            super(Kind.ACTION, id, label, description, action);
        }
    }

    public static final class Folder extends Option<Void> {
        public final List<Option<?>> children;
        public boolean expanded;
        public Folder(String id, String label, String description, List<Option<?>> children) {
            super(Kind.FOLDER, id, label, description, null);
            this.children = new ArrayList<>(children);
        }
    }

    public static final class Placeholder extends Option<Void> {
        public Placeholder(String id) {
            super(Kind.PLACEHOLDER, id, "", "", null);
        }
    }

    public static List<Category> demo(Runnable openEditor) {
        List<Category> result = new ArrayList<>();
        List<Option<?>> general = new ArrayList<>();
        general.add(new Action("editor", "Open button editor", "Position preview only", openEditor));
        general.add(new Bool("enabled", "Button Text Here", "Red off / green on", false));
        general.add(new Range("size", "Button Text Here", "Integer range", 0, 100, 1, 45, true));
        general.add(new Choice("choice", "Button Text Here", "Select an option",
                List.of("Option1", "Option2", "Option3", "A longer option", "Option5", "Option6")));
        general.add(new Folder("folder", "Closed folder with options", "Expandable group", List.of(
                new Bool("child", "Indented toggle", "Nested option", true),
                new Folder("nested", "Nested folder", "Another level", List.of(
                        new StringOption("note", "Nested text", "Editable demo", "Hello"))),
                new Range("opacity", "Fractional slider", "Steps of 0.05", 0, 1, 0.05, 0.65, false))));
        general.add(new Placeholder("future_color"));
        general.add(new StringOption("message", "Text field", "Editable string", "Zacktills"));
        general.add(new Range("speed", "Float range", "Steps of 0.1", 0.1, 3, 0.1, 1, false));
        Bool disabled = new Bool("disabled", "Disabled example", "Cannot be changed", false);
        disabled.enabled = false;
        general.add(disabled);
        for (int i = 1; i <= 6; i++) {
            general.add(new Bool("extra_" + i, "Extra test row " + i, "Scroll-list test", i % 2 == 0));
        }
        result.add(new Category("general", "General", general));
        String[] names = {"Interface", "HUD preview", "Items", "Inventory", "Camera",
                "Tooltips", "Viewmodel", "Whiteboard", "Integrations", "Accessibility", "Debug"};
        for (int i = 0; i < names.length; i++) {
            result.add(new Category("demo_" + i, names[i], List.of(
                    new Bool("test", "Demo toggle", "UI only; no gameplay hook", false),
                    new Range("scale", "Demo scale", "UI only", 0.5, 2, 0.05, 1, false),
                    new StringOption("note", "Demo note", "Local test data", names[i]))));
        }
        return result;
    }
}
