package dev.zacktills.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

public final class ConfigStore {
    private static final Logger LOG = LoggerFactory.getLogger("zacktills");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final List<ConfigModel.Category> categories;
    private final Path path = FabricLoader.getInstance().getConfigDir().resolve("zacktills.json");

    public ConfigStore(List<ConfigModel.Category> categories) { this.categories = categories; }

    public void load() {
        if (!Files.exists(path)) return;
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) throw new IllegalArgumentException("Expected object");
            for (ConfigModel.Category category : categories) {
                readOptions(parsed.getAsJsonObject(), category.id + ".", category.options);
            }
        } catch (Exception ex) {
            LOG.warn("Could not load Zacktills config; retaining defaults", ex);
        }
    }

    private void readOptions(JsonObject json, String prefix, List<ConfigModel.Option<?>> options) {
        for (ConfigModel.Option<?> option : options) {
            String key = prefix + option.id;
            if (option instanceof ConfigModel.Folder folder) {
                readOptions(json, key + ".", folder.children);
                continue;
            }
            if (!json.has(key)) continue;
            try {
                JsonElement element = json.get(key);
                if (!element.isJsonPrimitive()) continue;
                var primitive = element.getAsJsonPrimitive();
                switch (option.kind) {
                    case BOOL -> {
                        if (primitive.isBoolean()) ((ConfigModel.Bool) option).value = primitive.getAsBoolean();
                    }
                    case RANGE -> {
                        if (primitive.isNumber()) ((ConfigModel.Range) option).set(primitive.getAsDouble());
                    }
                    case ENUM -> {
                        ConfigModel.Choice choice = (ConfigModel.Choice) option;
                        if (primitive.isString() && choice.choices.contains(primitive.getAsString())) {
                            choice.value = primitive.getAsString();
                        }
                    }
                    case STRING -> {
                        if (primitive.isString()) {
                            String value = primitive.getAsString();
                            ((ConfigModel.StringOption) option).value = value.substring(0, Math.min(128, value.length()));
                        }
                    }
                    default -> { }
                }
            } catch (RuntimeException ex) {
                LOG.warn("Ignoring invalid Zacktills value for {}", key, ex);
            }
        }
    }

    public boolean save() {
        JsonObject json = new JsonObject();
        for (ConfigModel.Category category : categories) {
            writeOptions(json, category.id + ".", category.options);
        }
        Path temporary = path.resolveSibling(path.getFileName() + ".tmp");
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                GSON.toJson(json, writer);
            }
            try {
                Files.move(temporary, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (Exception ex) {
            LOG.error("Could not save Zacktills config to {}", path, ex);
            return false;
        }
    }

    private void writeOptions(JsonObject json, String prefix, List<ConfigModel.Option<?>> options) {
        for (ConfigModel.Option<?> option : options) {
            String key = prefix + option.id;
            switch (option.kind) {
                case FOLDER -> writeOptions(json, key + ".", ((ConfigModel.Folder) option).children);
                case BOOL -> json.addProperty(key, ((ConfigModel.Bool) option).value);
                case RANGE -> json.addProperty(key, ((ConfigModel.Range) option).value);
                case ENUM -> json.addProperty(key, ((ConfigModel.Choice) option).value);
                case STRING -> json.addProperty(key, ((ConfigModel.StringOption) option).value);
                default -> { }
            }
        }
    }
}
