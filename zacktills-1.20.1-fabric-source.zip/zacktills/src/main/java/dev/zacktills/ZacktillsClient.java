package dev.zacktills;

import dev.zacktills.config.ConfigModel;
import dev.zacktills.config.ConfigStore;
import dev.zacktills.ui.ConfigScreen;
import dev.zacktills.ui.PositionEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class ZacktillsClient implements ClientModInitializer {
    public static final String MOD_ID = "zacktills";
    private List<ConfigModel.Category> categories;
    private ConfigStore store;

    @Override
    public void onInitializeClient() {
        categories = ConfigModel.demo(() -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new PositionEditorScreen(mc.currentScreen));
        });
        store = new ConfigStore(categories);
        store.load();
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zacktills.open_config", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.zacktills"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (open.wasPressed()) {
                if (mc.currentScreen == null) {
                    mc.setScreen(new ConfigScreen(null, categories, store));
                }
            }
        });
    }
}
