package dev.zacktills.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class DrawUtil {
    private DrawUtil() {}
    public static final int PANEL = 0xFF313638, INSET = 0xFF272A2B;
    public static final int TITLE = 0xFF4D65B4, SELECTED = 0xFF4A5052;
    public static final int BORDER = 0xFF9B9B9B, TEXT = 0xFFFFFFFF, MUTED = 0xFFB9BDBF;
    public enum State { NORMAL, HOVER, PRESSED, DISABLED }
    public record Rect(int x, int y, int w, int h) {
        public boolean contains(double mx, double my) {
            return mx >= x && my >= y && mx < x + w && my < y + h;
        }
    }
    public static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    public static TextRenderer font() { return MinecraftClient.getInstance().textRenderer; }
    public static int textWidth(String text) { return font().getWidth(text); }
    public static String trim(String text, int width) {
        if (width <= 0) return "";
        if (textWidth(text) <= width) return text;
        if (width < textWidth("...")) return "";
        return font().trimToWidth(text, width - textWidth("...")) + "...";
    }
    public static void fill(DrawContext c, Rect r, int color) {
        if (r.w > 0 && r.h > 0) c.fill(r.x, r.y, r.x + r.w, r.y + r.h, color);
    }
    public static void box(DrawContext c, Rect r, int fill, int border) {
        fill(c, r, border);
        fill(c, new Rect(r.x + 1, r.y + 1, r.w - 2, r.h - 2), fill);
    }
    public static int surface(State state) {
        return switch (state) {
            case NORMAL -> 0xFF303232;
            case HOVER -> 0xFF484D50;
            case PRESSED -> 0xFF1B1C1D;
            case DISABLED -> 0xFF292E30;
        };
    }
    public static int ink(State state) { return state == State.DISABLED ? 0xFF74797C : TEXT; }
    public static void text(DrawContext c, String value, int x, int y, int width, int color) {
        c.drawText(font(), trim(value, width), x, y, color, false);
    }
    public static void centered(DrawContext c, String value, Rect r, int color) {
        String fit = trim(value, Math.max(0, r.w - 4));
        text(c, fit, r.x + (r.w - textWidth(fit)) / 2, r.y + (r.h - 8) / 2,
                Math.max(0, r.w - 4), color);
    }
    public static void clip(DrawContext c, Rect r) {
        c.enableScissor(r.x, r.y, r.x + Math.max(0, r.w), r.y + Math.max(0, r.h));
    }
    public static void unclip(DrawContext c) { c.disableScissor(); }
    public static void drawBackdrop(DrawContext c, int width, int height) {
        fill(c, new Rect(0, 0, width, height), 0xB0000000);
    }
    public static void drawPanel(DrawContext c, Rect r, String title) {
        box(c, r, PANEL, BORDER);
        fill(c, new Rect(r.x + 1, r.y + 1, r.w - 2, 16), TITLE);
        text(c, title, r.x + 5, r.y + 5, Math.max(0, r.w - 28), TEXT);
    }
    public static void drawList(DrawContext c, Rect r) { box(c, r, INSET, 0xFF484D50); }
    public static void drawRow(DrawContext c, Rect r, State state) {
        box(c, r, state == State.HOVER ? 0xFF383E40 : PANEL,
                state == State.PRESSED ? TITLE : 0xFF3D4345);
    }
    public static void drawButton(DrawContext c, Rect r, String value, State state, boolean selected) {
        int background = selected && state != State.DISABLED
                ? state == State.PRESSED ? 0xFF343C40 : state == State.HOVER ? 0xFF5A6266 : SELECTED
                : surface(state);
        box(c, r, background, state == State.DISABLED ? 0xFF505457 : BORDER);
        centered(c, value, r, ink(state));
    }
    public static void drawClose(DrawContext c, Rect r, State state) {
        box(c, r, state == State.PRESSED ? 0xFF822E34 : state == State.HOVER ? 0xFFE45159 : 0xFFB93D46, BORDER);
        centered(c, "X", r, TEXT);
    }
    public static void drawToggle(DrawContext c, Rect r, boolean on, State state) {
        box(c, r, surface(state), BORDER);
        int indicator = state == State.DISABLED ? 0xFF62676A : on ? 0xFF5EC36B : 0xFFE05360;
        fill(c, new Rect(r.x + 2, r.y + 2, Math.min(9, Math.max(0, r.w - 4)), r.h - 4), indicator);
        text(c, on ? "On" : "Off", r.x + 14, r.y + (r.h - 8) / 2, r.w - 16, ink(state));
    }
    public static void drawSlider(DrawContext c, Rect r, double fraction, String value, State state) {
        int trackW = Math.max(2, r.w - 38);
        Rect track = new Rect(r.x, r.y + r.h / 2 - 2, trackW, 4);
        box(c, track, INSET, 0xFF6B7377);
        int handleX = r.x + (int) Math.round(Math.max(0, Math.min(1, fraction)) * Math.max(0, trackW - 4));
        fill(c, new Rect(r.x + 1, track.y + 1, Math.max(0, handleX - r.x), 2), TITLE);
        box(c, new Rect(handleX, r.y + 1, 4, r.h - 2),
                state == State.DISABLED ? 0xFF666A6D : state == State.PRESSED ? 0xFFBFC2FF
                        : state == State.HOVER ? 0xFF91A5E5 : 0xFF6C84CF, BORDER);
        text(c, value, r.x + trackW + 3, r.y + (r.h - 8) / 2, 35, ink(state));
    }
    public static void drawDropdown(DrawContext c, Rect r, String value, State state) {
        box(c, r, surface(state), BORDER);
        text(c, value, r.x + 3, r.y + (r.h - 8) / 2, r.w - 16, ink(state));
        text(c, "v", r.x + r.w - 11, r.y + (r.h - 8) / 2, 8, ink(state));
    }
    public static void drawFolder(DrawContext c, Rect r, String label, boolean expanded, State state) {
        box(c, r, surface(state), 0xFF4A5052);
        text(c, expanded ? "v" : ">", r.x + 3, r.y + (r.h - 8) / 2, 8, ink(state));
        text(c, label, r.x + 13, r.y + (r.h - 8) / 2, r.w - 16, ink(state));
    }
    public static void drawTextField(DrawContext c, Rect r, String value, int caret,
                                     int anchor, int start, boolean focused, State state) {
        box(c, r, surface(state), focused ? 0xFFBFC2FF : BORDER);
        Rect inside = new Rect(r.x + 2, r.y + 1, Math.max(0, r.w - 4), Math.max(0, r.h - 2));
        clip(c, inside);
        String visible = value.substring(start);
        int base = r.x + 3, ty = r.y + (r.h - 8) / 2;
        int a = Math.max(start, Math.min(caret, anchor)), b = Math.max(start, Math.max(caret, anchor));
        if (focused && a != b) {
            int sx = base + textWidth(value.substring(start, a));
            fill(c, new Rect(sx, ty - 1, textWidth(value.substring(a, b)), 10), TITLE);
        }
        text(c, visible, base, ty, Math.max(textWidth(visible), inside.w), ink(state));
        if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = base + textWidth(value.substring(start, Math.max(start, caret)));
            fill(c, new Rect(cx, ty, 1, 8), TEXT);
        }
        unclip(c);
    }
    public static void drawScrollbar(DrawContext c, Rect track, Rect thumb, State state) {
        fill(c, track, 0xFF1B1C1D);
        box(c, thumb, state == State.DISABLED ? 0xFF505457 : state == State.PRESSED ? 0xFFBFC2FF
                        : state == State.HOVER ? 0xFF6C84CF : TITLE,
                state == State.DISABLED ? 0xFF505457 : 0xFF484D50);
    }
    public static void drawPlaceholder(DrawContext c, Rect r) { box(c, r, INSET, 0xFF62676A); }
}
