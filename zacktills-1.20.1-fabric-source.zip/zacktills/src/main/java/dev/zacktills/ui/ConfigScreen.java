package dev.zacktills.ui;

import dev.zacktills.config.ConfigModel;
import dev.zacktills.config.ConfigStore;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class ConfigScreen extends Screen {
    private final Screen parent;
    private final List<ConfigModel.Category> categories;
    private final ConfigStore store;
    private final CategoryList categoryList = new CategoryList();
    private final ScrollList optionList = new ScrollList();
    private final TextField search;
    private final Button closeButton;
    private Rect panel, heading;
    private Widget focus, capture;
    private Dropdown openDropdown;
    private ScrollList popup;
    private int selected, popupIndex;
    private boolean dirty = true;

    public ConfigScreen(Screen parent, List<ConfigModel.Category> categories, ConfigStore store) {
        super(Text.literal("Zacktils configuration menu"));
        if (categories.isEmpty()) throw new IllegalArgumentException("At least one category required");
        this.parent = parent;
        this.categories = categories;
        this.store = store;
        search = new TextField("", value -> { optionList.scroll = 0; dirty = true; });
        closeButton = new Button("X", this::close) {
            @Override public void render(DrawContext c, int mx, int my) { drawClose(c, bounds, state(mx, my)); }
        };
    }

    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        closePopup();
        int w = Math.min(Math.max(296, (int) Math.round(width * 0.8)), Math.min(900, Math.max(1, width - 8)));
        int h = Math.min(Math.max(180, (int) Math.round(height * 0.8)), Math.min(560, Math.max(1, height - 8)));
        panel = new Rect((width - w) / 2, (height - h) / 2, w, h);
        closeButton.bounds(new Rect(panel.x() + panel.w() - 15, panel.y() + 3, 11, 11));
        int bodyX = panel.x() + 4, bodyY = panel.y() + 21;
        int bodyW = Math.max(1, panel.w() - 8), bodyH = Math.max(1, panel.h() - 25);
        int sideW = Math.min(Math.max(1, bodyW * 2 / 5), Math.max(72, bodyW / 4));
        int rightX = bodyX + sideW + 4, rightW = Math.max(1, bodyW - sideW - 4);
        categoryList.bounds(new Rect(bodyX, bodyY + 16, sideW, Math.max(1, bodyH - 16)));
        heading = new Rect(rightX, bodyY, rightW, 16);
        int searchW = Math.min(rightW, Math.min(120, Math.max(42, rightW * 36 / 100)));
        search.bounds(new Rect(rightX + rightW - searchW, bodyY, searchW, 13));
        optionList.bounds(new Rect(rightX, bodyY + 16, rightW, Math.max(1, bodyH - 16)));
        dirty = true;
        rebuild();
    }

    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    private void rebuild() {
        if (!dirty) return;
        dirty = false;
        closePopup();
        categoryList.categories(categories, selected, index -> {
            if (selected != index) {
                selected = index;
                optionList.scroll = 0;
                dirty = true;
            }
        });
        List<Widget> rows = new ArrayList<>();
        String query = search.value.toLowerCase(Locale.ROOT).trim();
        append(rows, categories.get(selected).options, query, 0, true);
        optionList.setItems(rows);
        if (focus != search && focus != closeButton) setFocus(null);
    }
    private boolean matches(ConfigModel.Option<?> option, String query) {
        if (query.isEmpty() || (option.label + " " + option.description).toLowerCase(Locale.ROOT).contains(query)) return true;
        if (option instanceof ConfigModel.Folder folder) {
            for (ConfigModel.Option<?> child : folder.children) if (matches(child, query)) return true;
        }
        return false;
    }
    private void append(List<Widget> rows, List<ConfigModel.Option<?>> options, String query, int depth, boolean parentEnabled) {
        for (ConfigModel.Option<?> option : options) {
            if (!matches(option, query)) continue;
            OptionRow row = new OptionRow(option, depth, this::openPopup, () -> dirty = true);
            row.enabled = parentEnabled && option.enabled;
            if (row.control != null) row.control.enabled = row.enabled;
            rows.add(row);
            if (option instanceof ConfigModel.Folder folder && (folder.expanded || !query.isEmpty())) {
                append(rows, folder.children, query, depth + 1, row.enabled);
            }
        }
    }
    private void openPopup(Dropdown dropdown) {
        closePopup();
        openDropdown = dropdown;
        popup = new ScrollList();
        List<Widget> choices = new ArrayList<>();
        for (String choice : dropdown.option.choices) {
            Button button = new Button(choice, () -> { dropdown.option.value = choice; closePopup(); }) {
                @Override public int height() { return 20; }
            };
            button.selected = choice.equals(dropdown.option.value);
            choices.add(button);
        }
        popup.setItems(choices);
        Rect anchor = dropdown.bounds;
        int w = Math.min(Math.max(80, anchor.w()), Math.max(1, panel.w() - 8));
        int h = Math.min(choices.size() * 20 + 2, Math.max(22, panel.h() / 2));
        h = Math.min(h, Math.max(1, panel.h() - 8));
        int x = clamp(anchor.x(), panel.x() + 4, panel.x() + panel.w() - w - 4);
        int y = anchor.y() + anchor.h() + 1;
        if (y + h > panel.y() + panel.h() - 4) y = anchor.y() - h - 1;
        y = clamp(y, panel.y() + 4, panel.y() + panel.h() - h - 4);
        popup.bounds(new Rect(x, y, w, h));
        popupIndex = Math.max(0, dropdown.option.choices.indexOf(dropdown.option.value));
        setFocus(popup.items.get(popupIndex));
        popup.reveal(focus);
    }
    private void closePopup() {
        if (popup != null) {
            popup.cancel();
            if (focus != null && popup.items.contains(focus)) setFocus(openDropdown);
        }
        popup = null;
        openDropdown = null;
    }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        rebuild();
        drawBackdrop(c, width, height);
        drawPanel(c, panel, getTitle().getString());
        closeButton.render(c, mx, my);
        text(c, "Categories", categoryList.bounds.x() + 3, categoryList.bounds.y() - 13,
                categoryList.bounds.w() - 6, TEXT);
        text(c, categories.get(selected).label, heading.x() + 2, heading.y() + 2,
                Math.max(0, heading.w() - search.bounds.w() - 8), TEXT);
        search.render(c, mx, my);
        categoryList.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        optionList.render(c, popup == null ? mx : -10000, popup == null ? my : -10000);
        if (optionList.items.isEmpty()) {
            text(c, "No matching options", optionList.bounds.x() + 4, optionList.bounds.y() + 5,
                    optionList.bounds.w() - 12, MUTED);
        }
        if (popup != null) popup.render(c, mx, my);
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        rebuild();
        if (capture != null) capture.cancel();
        capture = null;
        if (popup != null) {
            if (popup.bounds.contains(mx, my)) {
                setFocus(popup.focusAt(mx, my));
                int pointerIndex = popup.items.indexOf(focus);
                if (pointerIndex >= 0) popupIndex = pointerIndex;
                if (popup.down(mx, my)) capture = popup;
            } else closePopup();
            return true;
        }
        Widget target = closeButton.bounds.contains(mx, my) ? closeButton
                : search.bounds.contains(mx, my) ? search
                : categoryList.bounds.contains(mx, my) ? categoryList
                : optionList.bounds.contains(mx, my) ? optionList : null;
        setFocus(target == null ? null : target.focusAt(mx, my));
        if (target != null && target.down(mx, my)) { capture = target; return true; }
        return panel.contains(mx, my);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && capture != null) { capture.drag(mx, my); return true; }
        return false;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(mx, my);
        rebuild();
        return true;
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        if (popup != null) return popup.wheel(mx, my, amount) || panel.contains(mx, my);
        return categoryList.wheel(mx, my, amount) || optionList.wheel(mx, my, amount);
    }
    @Override public boolean charTyped(char chr, int modifiers) {
        if (focus != null && focus.character(chr)) { rebuild(); return true; }
        return false;
    }
    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        rebuild();
        if (popup != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { closePopup(); return true; }
            if (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
                popupIndex = Math.floorMod(popupIndex + (key == GLFW.GLFW_KEY_UP ? -1 : 1), popup.items.size());
                setFocus(popup.items.get(popupIndex));
                popup.reveal(focus);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) {
                Widget target = popup.items.get(popupIndex);
                target.key(GLFW.GLFW_KEY_ENTER, modifiers);
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = new ArrayList<>();
            controls.add(search);
            controls.addAll(categoryList.focusables());
            controls.addAll(optionList.focusables());
            controls.add(closeButton);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            int next = current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size());
            setFocus(controls.get(next));
            categoryList.reveal(focus);
            optionList.reveal(focus);
            return true;
        }
        if (focus != null && focus.key(key, modifiers)) { rebuild(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN) {
            optionList.page(key == GLFW.GLFW_KEY_PAGE_UP ? -1 : 1);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }
    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        if (capture != null) capture.cancel();
        closePopup();
        if (!store.save() && client != null && client.player != null) {
            client.player.sendMessage(Text.literal("Zacktills: config save failed; see the log."), false);
        }
        super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
