package dev.friendlink.ui;

import dev.friendlink.ConversationSelection;
import dev.friendlink.Faces;
import dev.friendlink.FriendLink;
import dev.friendlink.GlowStyle;
import dev.friendlink.Models.*;
import dev.friendlink.Protocol;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Client-only social window. Layout, wrapping, dates, skin lookups and labels are cached in tick/init.
 * render() only draws prepared data and interpolates primitive scroll values: no new render-loop objects.
 */
public final class ChatScreen extends Screen {
    private static final int ROW = 46, FRIEND_ROW = 54, BLUE = 0xFF539FF5, DIM = 0xFF8793A5;
    private static final OrderedText SOCIAL = text("Social"), CHAT = text("Chat"), FRIENDS = text("Friends"),
        EMPTY = text("No conversations"), SEARCH_EMPTY = text("No matches"), SELECT = text("Select a friend or group"),
        GLOW = text("Glow"), CROSS = text("x"), GROUP = text("#"),
        LOADING = text("Loading conversation..."), OFFLINE = text("Offline"), ONLINE = text("Online"),
        QUEUED_HINT = text("Queued"), SENT_HINT = text("Sent / pending"), DELIVERED_HINT = text("Delivered"),
        READ_HINT = text("Read"), FAILED_HINT = text("Left-click: retry | Right-click: details"),
        GROUP_HINT = text("Click for per-member delivery details");
    private static final Comparator<Row> RECENT = Comparator.comparingLong((Row r) -> r.activity).reversed()
        .thenComparing(r -> r.name, String.CASE_INSENSITIVE_ORDER).thenComparing(r -> r.key);
    private static final Comparator<Row> NAMES = Comparator.comparing((Row r) -> r.name, String.CASE_INSENSITIVE_ORDER);
    private final FriendLink mod = FriendLink.INSTANCE;
    private final Screen parent;
    private final ZoneId zone = ZoneId.systemDefault();
    private final List<Row> rows = new ArrayList<>();
    private final List<Bubble> bubbles = new ArrayList<>();
    private final List<SocialButton> buttons = new ArrayList<>();
    private final Set<String> summaryRequests = new HashSet<>();
    private String selected, draft = "", filter = "";
    private OrderedText heading = SELECT, error = text("");
    private boolean transientScreen, ready, friendsTab, searching, snapMessages = true;
    private long selectionGeneration, cachedVersion = -1, nextRefresh, lastFrame;
    private int left, right, panelTop, panelBottom, split, listTop, listBottom, messageTop, messageBottom, contentHeight;
    private double sidebarScroll, sidebarTarget, messageScroll, messageTarget;
    private TextFieldWidget input, search;
    private SocialButton send, glowButton, manage, glowAll, unglowAll, cfg, view, back;
    private GlowStyleDropdown styleMenu;
    private Friend styleTarget;
    private Row activeRow;

    private static final class Row {
        String key, name;
        Friend friend;
        Group group;
        Identifier[] faces;
        long activity;
        OrderedText title, preview, time, badge, style;
        int timeWidth, badgeWidth;
        boolean online;
    }
    private static final class Bubble {
        Message message;
        List<OrderedText> lines;
        OrderedText stamp, date, hint;
        boolean outbound, system;
        int y, height, width, textWidth, stage, dateWidth, hintWidth;
    }
    private static OrderedText text(String value) { return Text.literal(value).asOrderedText(); }
    public ChatScreen(String selected) { this(selected, null); }
    public ChatScreen(String selected, Screen parent) {
        super(Text.literal("FriendLink")); this.parent = parent;
        this.selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
    }
    public String conversation() { return selected; }

    // Screen init/reinit retains the caller, draft, selection, filters and logical presence session.
    @Override protected void init() {
        if (input != null) draft = input.getText();
        selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
        int w = Math.max(1, Math.min(width - 8, Math.round(width * .85F)));
        int h = Math.max(1, Math.min(height - 8, Math.round(height * .75F)));
        left = (width - w) / 2; right = left + w; panelTop = (height - h) / 2; panelBottom = panelTop + h;
        int side = Math.min(Math.max(122, w * 38 / 100), Math.max(90, w - 128));
        split = left + side; listTop = panelTop + 56; listBottom = panelBottom - 28;
        messageTop = panelTop + 38; messageBottom = panelBottom - 37;
        buttons.clear();
        button(split - 66, panelTop + 8, 18, "+", () -> openSubscreen(new PromptScreen(this,
            "Add friend (Java username)", "", mod::addFriend))).accent(true);
        button(split - 44, panelTop + 8, 18, "#", () -> openSubscreen(new GroupScreen(this, null)));
        button(split - 22, panelTop + 8, 18, "?", () -> {
            searching = !searching; search.setVisible(searching);
            search.setFocused(searching); setFocused(searching ? search : input);
            if (!searching) { filter = ""; search.setText(""); }
            sidebarTarget = sidebarScroll = 0; refresh();
        });
        int sendWidth = Math.min(34, Math.max(20, (right - split) / 5));
        input = new TextFieldWidget(textRenderer, split + 10, panelBottom - 25,
            Math.max(16, right - split - sendWidth - 26), 18, Text.literal("Message"));
        input.setMaxLength(4096); input.setDrawsBackground(false); input.setText(draft); addDrawableChild(input);
        send = button(right - sendWidth - 8, panelBottom - 28, sendWidth, ">", this::send).accent(true);
        glowButton = button(right - 75, panelTop + 9, 43, "Glow", this::toggleGlow).accent(true);
        manage = button(right - 26, panelTop + 9, 18, "≡", () -> {
            if (selected != null) openSubscreen(new ConversationOptionsScreen(this, selected));
        });
        glowAll = button(left + 6, panelBottom - 24, Math.max(24, (side - 16) / 2), "Glow all", () -> { mod.setAllGlow(true); refresh(); });
        unglowAll = button(left + 10 + (side - 16) / 2, panelBottom - 24, Math.max(24, (side - 16) / 2), "Unglow all", () -> { mod.setAllGlow(false); refresh(); });
        int footerWidth = Math.max(20, (side - 24) / 3);
        cfg = button(left + 6, panelBottom - 24, footerWidth, "Cfg", () -> { transientScreen = true; mod.openConfig(this); });
        view = button(left + 12 + footerWidth, panelBottom - 24, footerWidth, "View", () -> openSubscreen(new ViewSettingsScreen(this)));
        back = button(left + 18 + footerWidth * 2, panelBottom - 24, footerWidth, "Back", this::close);
        search = new TextFieldWidget(textRenderer, left + 7, panelTop + 34, Math.max(20, side - 14), 18, Text.literal("Search conversations"));
        search.setMaxLength(64); search.setPlaceholder(Text.literal("Search...")); search.setText(filter);
        search.setChangedListener(value -> { filter = value.toLowerCase(Locale.ROOT); sidebarScroll = sidebarTarget = 0; refresh(); });
        search.setVisible(searching); addDrawableChild(search);
        styleMenu = addDrawableChild(new GlowStyleDropdown(left + 5, listTop, Math.max(50, side - 10), value -> {
            if (styleTarget != null) { styleTarget.glowStyle = value; mod.touch(); }
            styleMenu.visible = false; refresh();
        }));
        styleMenu.visible = false;
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(true);
        select(selected);
    }
    private SocialButton button(int x, int y, int w, String label, Runnable action) {
        SocialButton button = addDrawableChild(new SocialButton(x, y, w, 18, label, action));
        buttons.add(button); return button;
    }
    @Override public void tick() {
        input.tick(); if (searching) search.tick();
        if (ready) mod.read(selected);
        long now = System.currentTimeMillis();
        if (cachedVersion != mod.version || now >= nextRefresh) {
            String choice = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
            if (!Objects.equals(choice, selected)) select(choice); else refresh();
            nextRefresh = now + 1000;
        }
    }
    private void select(String key) {
        selected = key; ready = key == null; snapMessages = true; messageScroll = messageTarget = 0;
        error = text(""); long generation = ++selectionGeneration; refresh();
        if (key == null) return;
        mod.ensureConversation(key, () -> {
            if (generation != selectionGeneration || !key.equals(selected)) return;
            ready = true; snapMessages = true;
            if (client.currentScreen == this) { mod.read(key); refresh(); setFocused(input); input.setFocused(true); }
        }).exceptionally(failure -> {
            client.execute(() -> { if (generation == selectionGeneration) error = text("Could not load chat log; reopen to retry."); });
            return null;
        });
    }
    private void openSubscreen(Screen screen) { transientScreen = true; client.setScreen(screen); }
    @Override public void removed() {
        draft = input == null ? draft : input.getText();
        if (!transientScreen && mod.presence != null) mod.presence.screenOpen(false);
        super.removed();
    }
    @Override public void close() {
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(false);
        client.setScreen(parent);
    }
    private void toggleGlow() {
        if (activeRow != null && activeRow.friend != null) activeRow.friend.glow = !activeRow.friend.glow;
        else if (activeRow != null && activeRow.group != null) {
            boolean enable = !groupGlow(activeRow.group);
            for (int i = 0; i < activeRow.group.members.size(); i++) {
                Friend f = mod.friend(activeRow.group.members.get(i)); if (f != null) f.glow = enable;
            }
        } else { mod.config.glowEnabled = !mod.config.glowEnabled; mod.saveConfig(); }
        mod.touch(); refresh();
    }
    private boolean groupGlow(Group group) {
        boolean any = false;
        for (int i = 0; i < group.members.size(); i++) {
            Friend friend = mod.friend(group.members.get(i));
            if (friend != null) { any = true; if (!friend.glow) return false; }
        }
        return any;
    }
    private void refresh() {
        if (input == null) return;
        rows.clear(); activeRow = null;
        long now = System.currentTimeMillis();
        for (Friend f : mod.state.friends.values()) {
            Row row = row("f:" + Protocol.key(f.name), f.name, f.lastActivity, f.lastPreview, f.messages, f.unread, now);
            row.friend = f; row.faces = new Identifier[] { mod.skins.face(f.name) };
            row.online = client.getNetworkHandler() != null && client.getNetworkHandler().getPlayerListEntry(f.name) != null;
            row.style = text(textRenderer.trimToWidth((f.glowStyle == null ? GlowStyle.DEFAULT : f.glowStyle).name().toLowerCase(Locale.ROOT), Math.max(20, split - left - 87)));
            if (!f.logLoaded) summary(row, f);
            addRow(row);
        }
        for (Group g : mod.state.groups.values()) {
            if (g.left) continue;
            Row row = row("g:" + g.id, g.name, g.lastActivity, g.lastPreview, g.messages, g.unread, now);
            row.group = g; row.faces = new Identifier[Math.min(4, g.members.size())];
            for (int i = 0; i < row.faces.length; i++) row.faces[i] = mod.skins.face(g.members.get(i));
            if (!g.logLoaded) summary(row, g);
            addRow(row);
        }
        rows.sort(friendsTab ? NAMES : RECENT);
        mod.rememberConversation(selected);
        heading = text(textRenderer.trimToWidth(activeRow == null ? "Select a friend or group" : activeRow.name,
            Math.max(8, right - split - 122)));
        boolean enabled = activeRow == null ? mod.config.glowEnabled : activeRow.friend != null
            ? activeRow.friend.glow : groupGlow(activeRow.group);
        glowButton.label(enabled ? "Glow ✓" : "Glow"); glowButton.accent(enabled);
        manage.active = activeRow != null;
        send.active = ready && activeRow != null && (activeRow.group == null || !activeRow.group.pending);
        input.setEditable(send.active);
        input.setPlaceholder(Text.literal(activeRow == null ? "Select a conversation" : "Message " + activeRow.name));
        glowAll.visible = unglowAll.visible = friendsTab;
        cfg.visible = view.visible = back.visible = !friendsTab;
        sidebarTarget = SocialFormat.clampScroll(sidebarTarget, rows.size() * rowHeight(), listBottom - listTop);
        sidebarScroll = SocialFormat.clampScroll(sidebarScroll, rows.size() * rowHeight(), listBottom - listTop);
        layoutMessages(now);
        cachedVersion = mod.version;
    }
    private Row row(String key, String name, long activity, String preview, List<Message> messages, int unread, long now) {
        Row row = new Row(); row.key = key; row.name = name; row.activity = activity;
        if (messages != null && !messages.isEmpty()) {
            Message last = messages.get(messages.size() - 1); row.activity = Math.max(activity, last.time);
            preview = SocialFormat.preview(last.sender, last.text, last.system);
        }
        String time = SocialFormat.activity(row.activity, now, zone); row.time = text(time); row.timeWidth = textRenderer.getWidth(row.time) * 3 / 4;
        row.title = text(textRenderer.trimToWidth(name, Math.max(12, split - left - 46 - (friendsTab ? 0 : row.timeWidth))));
        row.preview = text(textRenderer.trimToWidth(preview == null || preview.isEmpty() ? "No messages yet" : preview,
            Math.max(8, split - left - 58)));
        row.badge = unread <= 0 ? null : text(unread > 99 ? "99+" : Integer.toString(unread));
        row.badgeWidth = row.badge == null ? 0 : Math.max(12, textRenderer.getWidth(row.badge) + 6);
        return row;
    }
    private void addRow(Row row) {
        if (row.key.equals(selected)) activeRow = row;
        if ((!friendsTab || row.friend != null) && row.name.toLowerCase(Locale.ROOT).contains(filter)) rows.add(row);
    }
    /** Backfill legacy metadata on the ordered IO worker without publishing/marking a whole log read. */
    private void summary(Row row, Object owner) {
        String preview = owner instanceof Friend f ? f.lastPreview : ((Group) owner).lastPreview;
        if (preview != null && !preview.isEmpty() || !summaryRequests.add(row.key)) return;
        long expected = row.activity;
        mod.storage.loadLogAsync(row.key, 1).whenComplete((messages, failure) -> client.execute(() -> {
            if (failure != null) { FriendLink.LOG.warn("Could not read sidebar summary for {}", row.key, failure); return; }
            if (messages.isEmpty()) return;
            Object current = row.key.startsWith("f:") ? mod.state.friends.get(row.key.substring(2)) : mod.state.groups.get(row.key.substring(2));
            if (owner != current) return;
            if (owner instanceof Friend f && f.logLoaded && f.messages.isEmpty()) return;
            if (owner instanceof Group g && g.logLoaded && g.messages.isEmpty()) return;
            Message last = messages.get(messages.size() - 1);
            String value = SocialFormat.preview(last.sender, last.text, last.system);
            if (owner instanceof Friend f && f.lastActivity == expected) { f.lastPreview = value; f.lastActivity = Math.max(f.lastActivity, last.time); mod.touch(); }
            else if (owner instanceof Group g && g.lastActivity == expected) { g.lastPreview = value; g.lastActivity = Math.max(g.lastActivity, last.time); mod.touch(); }
        }));
    }
    private void layoutMessages(long now) {
        int previous = contentHeight; contentHeight = 0; bubbles.clear();
        List<Message> messages = ready ? mod.messages(selected) : Collections.emptyList();
        long previousDay = Long.MIN_VALUE;
        int maxWidth = Math.max(24, (right - split - 22) * 78 / 100);
        for (int i = 0; i < messages.size(); i++) {
            Message message = messages.get(i); Bubble b = new Bubble(); b.message = message;
            long day = java.time.Instant.ofEpochMilli(message.time).atZone(zone).toLocalDate().toEpochDay();
            if (day != previousDay) {
                b.date = text(SocialFormat.date(message.time, now, zone)); b.dateWidth = textRenderer.getWidth(b.date);
                contentHeight += 23; previousDay = day;
            }
            b.outbound = !message.system && message.sender.equalsIgnoreCase(mod.self()); b.system = message.system;
            b.stage = b.outbound ? Math.max(0, Math.min(4, message.stage())) : -1;
            b.stamp = text((activeRow != null && activeRow.group != null && !b.outbound && !b.system ? message.sender + " · " : "")
                + SocialFormat.clock(message.time, zone));
            b.lines = textRenderer.wrapLines(Text.literal(message.text), Math.max(8, maxWidth - 14));
            b.textWidth = 0; for (int j = 0; j < b.lines.size(); j++) b.textWidth = Math.max(b.textWidth, textRenderer.getWidth(b.lines.get(j)));
            b.width = Math.max(b.outbound ? 35 : 20, b.textWidth + 14);
            b.height = b.lines.size() * 11 + (b.outbound ? 19 : 12); b.y = contentHeight;
            b.hint = b.stage == 4 ? FAILED_HINT : selected != null && selected.startsWith("g:") ? GROUP_HINT
                : b.stage == 0 ? QUEUED_HINT : b.stage == 1 ? SENT_HINT : b.stage == 2 ? DELIVERED_HINT : READ_HINT;
            b.hintWidth = textRenderer.getWidth(b.hint);
            bubbles.add(b); contentHeight += b.height + 21;
        }
        if (snapMessages) { messageScroll = messageTarget = 0; snapMessages = false; }
        else if (messageTarget > 2 && contentHeight > previous) { messageTarget += contentHeight - previous; messageScroll += contentHeight - previous; }
        messageTarget = SocialFormat.clampScroll(messageTarget, contentHeight, messageBottom - messageTop);
        messageScroll = SocialFormat.clampScroll(messageScroll, contentHeight, messageBottom - messageTop);
    }
    private int rowHeight() { return friendsTab ? FRIEND_ROW : ROW; }
    private void send() {
        if (!send.active) return;
        String result = mod.send(selected, input.getText());
        if (result == null) { input.setText(""); draft = ""; error = text(""); snapMessages = true; refresh(); }
        else error = text(textRenderer.trimToWidth(result, Math.max(12, right - split - 12)));
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (styleMenu.visible && styleMenu.isFocused() && styleMenu.keyPressed(key, scan, modifiers)) return true;
        if (key == GLFW.GLFW_KEY_ESCAPE && styleMenu.visible) { styleMenu.dismiss(); styleMenu.visible = false; return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && input.isFocused() && send.active) { send(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN) {
            messageTarget = SocialFormat.clampScroll(messageTarget + (key == GLFW.GLFW_KEY_PAGE_UP ? 1 : -1)
                * Math.max(1, messageBottom - messageTop - 16), contentHeight, messageBottom - messageTop); return true;
        }
        return super.keyPressed(key, scan, modifiers);
    }
    @Override public boolean mouseScrolled(double x, double y, double amount) {
        if (inside(x, y, left, listTop, split, listBottom)) {
            sidebarTarget = SocialFormat.clampScroll(sidebarTarget - amount * rowHeight(), rows.size() * rowHeight(), listBottom - listTop); return true;
        }
        if (inside(x, y, split, messageTop, right, messageBottom)) {
            messageTarget = SocialFormat.clampScroll(messageTarget + amount * 32, contentHeight, messageBottom - messageTop); return true;
        }
        return super.mouseScrolled(x, y, amount);
    }
    private static boolean inside(double x, double y, int l, int t, int r, int b) { return x >= l && x < r && y >= t && y < b; }
    @Override public boolean mouseClicked(double x, double y, int button) {
        if (styleMenu.visible) {
            if (styleMenu.menuClick(x, y, button)) return true;
            styleMenu.visible = false;
        }
        if (!searching && button == 0 && inside(x, y, left, panelTop + 33, split, panelTop + 54)) {
            friendsTab = x >= left + (split - left) / 2; sidebarScroll = sidebarTarget = 0; refresh(); return true;
        }
        if (inside(x, y, left, listTop, split, listBottom)) {
            int index = ((int) y - listTop + (int) sidebarScroll) / rowHeight();
            if (index >= 0 && index < rows.size()) {
                Row row = rows.get(index); int rowY = listTop + index * rowHeight() - (int) sidebarScroll;
                if (button == 1) { openSubscreen(new ConversationOptionsScreen(this, row.key)); return true; }
                if (button == 0 && friendsTab && y >= rowY + 29) {
                    if (x < left + 39) { row.friend.glow = !row.friend.glow; mod.touch(); refresh(); }
                    else if (x < left + 58) openSubscreen(new ColorScreen(this, row.friend));
                    else if (x >= split - 23) openSubscreen(removalScreen(this, row.key));
                    else {
                        styleTarget = row.friend; styleMenu.setX(left + 58);
                        styleMenu.setY(Math.max(panelTop, Math.min(rowY + 28, panelBottom - 101)));
                        styleMenu.setWidth(Math.max(48, split - left - 64));
                        styleMenu.selection(row.friend.glowStyle, true); styleMenu.visible = true;
                        styleMenu.open(); setFocused(styleMenu); styleMenu.setFocused(true);
                    }
                } else if (button == 0) { select(row.key); setFocused(input); input.setFocused(true); }
                return true;
            }
        }
        if (inside(x, y, split, messageTop, right, messageBottom) && (button == 0 || button == 1)) {
            int offset = messageOffset();
            for (int i = 0; i < bubbles.size(); i++) {
                Bubble b = bubbles.get(i); if (!b.outbound) continue;
                int bx = bubbleX(b), by = messageTop + b.y + offset + 12;
                if (inside(x, y, bx + b.width - 21, by + b.height - 13, bx + b.width - 3, by + b.height)) {
                    if (selected.startsWith("g:") || button == 1) openSubscreen(new DeliveryScreen(this, selected, b.message, b.message.status()));
                    else if (b.stage == 4) { mod.retryMessage(selected, b.message); refresh(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(x, y, button);
    }
    private int messageOffset() { return -Math.max(0, contentHeight - (messageBottom - messageTop)) + (int) messageScroll; }
    private int bubbleX(Bubble b) { return b.system ? split + (right - split - b.width) / 2 : b.outbound ? right - b.width - 10 : split + 10; }
    private void small(DrawContext c, OrderedText value, int x, int y, int color) {
        c.getMatrices().scale(.75F, .75F, 1F);
        c.drawText(textRenderer, value, Math.round(x / .75F), Math.round(y / .75F), color, false);
        c.getMatrices().scale(4F / 3F, 4F / 3F, 1F);
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime(); double seconds = lastFrame == 0 ? 1 : Math.min(.1, (now - lastFrame) / 1_000_000_000D); lastFrame = now;
        double blend = 1 - Math.exp(-18 * seconds);
        sidebarScroll += (sidebarTarget - sidebarScroll) * blend; messageScroll += (messageTarget - messageScroll) * blend;
        c.fill(0, 0, width, height, 0xA6000000);
        c.fill(left - 2, panelTop - 2, right + 2, panelBottom + 2, 0xFF0C1017);
        c.fill(left, panelTop, split, panelBottom, 0xFF171D27); c.fill(split, panelTop, right, panelBottom, 0xFF111720);
        c.fill(split, panelTop, split + 1, panelBottom, 0xFF29313F);
        c.drawText(textRenderer, SOCIAL, left + 9, panelTop + 13, 0xFFF4F6FC, false);
        c.fill(split + 1, panelTop + 35, right, panelTop + 36, 0xFF28303D);
        if (!searching) {
            c.drawText(textRenderer, CHAT, left + 13, panelTop + 39, friendsTab ? DIM : BLUE, false);
            c.drawText(textRenderer, FRIENDS, left + (split - left) / 2 + 5, panelTop + 39, friendsTab ? BLUE : DIM, false);
            int tabX = friendsTab ? left + (split - left) / 2 : left;
            c.fill(tabX + 5, panelTop + 53, tabX + (split - left) / 2 - 5, panelTop + 55, BLUE);
        }
        if (activeRow != null) drawFace(c, activeRow, split + 9, panelTop + 8, 20);
        c.drawText(textRenderer, heading, split + (activeRow == null ? 9 : 36), panelTop + 14, 0xFFF1F4FA, false);
        renderRows(c, mouseX, mouseY); renderMessages(c, mouseX, mouseY);
        c.fill(split + 7, panelBottom - 29, right - 6, panelBottom - 6, 0xFF222B38);
        for (int i = 0; i < buttons.size(); i++) { SocialButton b = buttons.get(i); if (b.visible) b.render(c, mouseX, mouseY, delta); }
        input.render(c, mouseX, mouseY, delta); if (searching) search.render(c, mouseX, mouseY, delta);
        c.drawText(textRenderer, error, split + 8, panelBottom - 36, 0xFFFF697B, false);
        if (styleMenu.visible) { styleMenu.render(c, mouseX, mouseY, delta); styleMenu.renderMenu(c, mouseX, mouseY); }
    }
    private void renderRows(DrawContext c, int mouseX, int mouseY) {
        if (listBottom <= listTop) return;
        c.enableScissor(left, listTop, split, listBottom);
        if (rows.isEmpty()) c.drawText(textRenderer, filter.isEmpty() ? EMPTY : SEARCH_EMPTY, left + 8, listTop + 10, DIM, false);
        for (int i = 0; i < rows.size(); i++) {
            int y = listTop + i * rowHeight() - (int) sidebarScroll; if (y + rowHeight() <= listTop || y >= listBottom) continue;
            Row row = rows.get(i); boolean chosen = row.key.equals(selected);
            if (chosen || inside(mouseX, mouseY, left, y, split, y + rowHeight()))
                c.fill(left + 3, y, split - 3, y + rowHeight() - 2, chosen ? 0xFF293950 : 0xFF222C3A);
            if (chosen) c.fill(left + 3, y, left + 5, y + rowHeight() - 2, BLUE);
            drawFace(c, row, left + 9, y + 5, 24);
            c.drawText(textRenderer, row.title, left + 39, y + 6, 0xFFEDF1F7, false);
            if (friendsTab) {
                c.fill(left + 28, y + 23, left + 34, y + 29, row.online ? 0xFF58D99C : 0xFF697586);
                small(c, row.online ? ONLINE : OFFLINE, left + 39, y + 18, row.online ? 0xFF58D99C : DIM);
                c.fill(left + 8, y + 32, left + 36, y + 49, row.friend.glow ? 0xFF2879D5 : 0xFF313C4B);
                small(c, GLOW, left + 12, y + 37, 0xFFF0F4FA);
                c.fill(left + 42, y + 34, left + 54, y + 47, 0xFF000000 | row.friend.color);
                c.fill(left + 59, y + 32, split - 25, y + 49, 0xFF313C4B);
                small(c, row.style, left + 62, y + 37, 0xFFE7EDF7);
                c.drawText(textRenderer, CROSS, split - 18, y + 36, 0xFFFF7184, false);
            } else {
                small(c, row.time, split - row.timeWidth - 9, y + 7, DIM);
                c.drawText(textRenderer, row.preview, left + 39, y + 22, DIM, false);
            }
            if (row.badge != null && mod.config.unreadFriendBadges) {
                int by = friendsTab ? y + 15 : y + 23, bx = split - row.badgeWidth - 8;
                c.fill(bx, by, split - 8, by + 13, 0xFFD5475E);
                c.drawText(textRenderer, row.badge, bx + 3, by + 3, 0xFFFFFFFF, false);
            }
        }
        c.disableScissor(); scrollbar(c, split - 2, listTop, listBottom, rows.size() * rowHeight(), sidebarScroll);
    }
    private void drawFace(DrawContext c, Row row, int x, int y, int size) {
        if (row.faces.length == 1) Faces.draw(c, row.faces[0], x, y, size);
        else if (row.faces.length == 0) { c.fill(x, y, x + size, y + size, 0xFF344760); c.drawText(textRenderer, GROUP, x + 8, y + 7, 0xFFDBE9FF, false); }
        else for (int i = 0; i < row.faces.length; i++) Faces.draw(c, row.faces[i], x + i % 2 * (size / 2), y + i / 2 * (size / 2), size / 2);
    }
    private void renderMessages(DrawContext c, int mouseX, int mouseY) {
        if (messageBottom <= messageTop) return;
        c.enableScissor(split + 1, messageTop, right, messageBottom);
        if (!ready) c.drawText(textRenderer, LOADING, split + 10, messageTop + 12, DIM, false);
        int offset = messageOffset(); Bubble hovered = null;
        for (int i = 0; i < bubbles.size(); i++) {
            Bubble b = bubbles.get(i); int y = messageTop + b.y + offset;
            if (y + b.height + 21 < messageTop || y - 23 >= messageBottom) continue;
            if (b.date != null) {
                int center = (split + right) / 2, dy = y - 14;
                c.fill(split + 13, dy + 4, center - b.dateWidth / 2 - 9, dy + 5, 0xFF2C3645);
                c.fill(center + b.dateWidth / 2 + 9, dy + 4, right - 13, dy + 5, 0xFF2C3645);
                c.drawText(textRenderer, b.date, center - b.dateWidth / 2, dy, DIM, false);
            }
            int x = bubbleX(b); small(c, b.stamp, x + 2, y + 3, DIM); y += 12;
            c.fill(x, y, x + b.width, y + b.height, b.system ? 0xFF1C2532 : b.outbound ? 0xFF235CA4 : 0xFF29323F);
            for (int j = 0; j < b.lines.size(); j++) c.drawText(textRenderer, b.lines.get(j), x + 7, y + 6 + j * 11, b.system ? DIM : 0xFFF2F5FC, false);
            if (b.outbound) {
                int rx = x + b.width - 19, ry = y + b.height - 12; receipt(c, rx, ry, b.stage);
                if (inside(mouseX, mouseY, rx - 2, ry - 1, rx + 17, ry + 12)) hovered = b;
            }
        }
        c.disableScissor();
        int maxScroll = Math.max(0, contentHeight - (messageBottom - messageTop));
        scrollbar(c, right - 2, messageTop, messageBottom, contentHeight, maxScroll - messageScroll);
        if (hovered != null && inside(mouseX, mouseY, split, messageTop, right, messageBottom)) {
            int w = hovered.hintWidth + 10, x = Math.max(3, Math.min(mouseX + 8, width - w - 3)), y = Math.max(2, mouseY - 16);
            c.fill(x, y, x + w, y + 14, 0xFF070D18); c.drawText(textRenderer, hovered.hint, x + 5, y + 3, 0xFFE5EDFB, false);
        }
    }
    private void scrollbar(DrawContext c, int x, int top, int bottom, int content, double scroll) {
        int viewport = bottom - top; if (viewport <= 0 || content <= viewport) return;
        int thumb = Math.max(8, viewport * viewport / content);
        int y = top + (int) ((viewport - thumb) * scroll / (content - viewport));
        c.fill(x, y, x + 2, y + thumb, 0xFF4B5A70);
    }
    private void receipt(DrawContext c, int x, int y, int stage) {
        int color = stage == 4 ? 0xFFFF6678 : stage == 3 ? 0xFF000000 | (mod.config.readReceiptColor & 0xFFFFFF) : 0xFFB4C8E2;
        if (stage == 0) {
            c.fill(x + 2, y, x + 8, y + 1, color); c.fill(x + 2, y + 8, x + 8, y + 9, color);
            c.fill(x + 1, y + 1, x + 2, y + 8, color); c.fill(x + 8, y + 1, x + 9, y + 8, color);
            c.fill(x + 4, y + 2, x + 5, y + 5, color); c.fill(x + 4, y + 4, x + 7, y + 5, color);
        } else if (stage == 4) {
            c.fill(x + 4, y, x + 6, y + 6, color); c.fill(x + 4, y + 8, x + 6, y + 10, color);
        } else { tickMark(c, x, y, color); if (stage >= 2) tickMark(c, x + 5, y, color); }
    }
    private static void tickMark(DrawContext c, int x, int y, int color) {
        c.fill(x, y + 4, x + 2, y + 6, color); c.fill(x + 2, y + 6, x + 4, y + 8, color);
        c.fill(x + 4, y + 4, x + 6, y + 6, color); c.fill(x + 6, y + 2, x + 8, y + 4, color);
    }
    /** Also called by Cloth Config; preserving a log remains a separate explicit choice. */
    public static Screen removalScreen(Screen parent, String key) { return new RemovalScreen(parent, key); }
    private static final class RemovalScreen extends Screen {
        private final Screen parent;
        private final String key;
        private List<OrderedText> explanation = Collections.emptyList();
        RemovalScreen(Screen parent, String key) {
            super(Text.literal(key.startsWith("g:") ? "Delete group?" : "Remove friend?")); this.parent = parent; this.key = key;
        }
        @Override protected void init() {
            explanation = textRenderer.wrapLines(Text.literal("Keep log preserves the local conversation. Delete log permanently removes it. Group memberships of a removed friend are unchanged."), Math.max(40, Math.min(340, width - 24)));
            int w = Math.min(330, width - 16), x = (width - w) / 2, y = Math.max(80, height / 2 + 24);
            addDrawableChild(ButtonWidget.builder(Text.literal("Keep log"), b -> remove(false)).dimensions(x, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete log"), b -> remove(true)).dimensions(x + w / 2 + 2, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x, y + 24, w, 20).build());
        }
        private void remove(boolean deleteLog) {
            FriendLink mod = FriendLink.INSTANCE;
            if (key.startsWith("f:")) mod.removeFriend(key.substring(2), deleteLog); else mod.deleteGroup(key.substring(2), deleteLog);
            close();
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
            int x = Math.max(12, (width - 340) / 2);
            for (int i = 0; i < explanation.size(); i++) c.drawText(textRenderer, explanation.get(i), x, 44 + i * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    private static final class DeliveryScreen extends Screen {
        private final Screen parent;
        private final String key, detail;
        private final Message message;
        private List<OrderedText> wrapped = Collections.emptyList();
        private int scroll;
        DeliveryScreen(Screen parent, String key, Message message, String detail) {
            super(Text.literal("Delivery details")); this.parent = parent; this.key = key; this.message = message; this.detail = detail;
        }
        @Override protected void init() {
            wrapped = textRenderer.wrapLines(Text.literal(detail), Math.max(40, width - 32));
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close()).dimensions(width / 2 - 100, height - 30, 96, 20).build());
            ButtonWidget retry = addDrawableChild(ButtonWidget.builder(Text.literal("Retry failed"), b -> {
                FriendLink.INSTANCE.retryMessage(key, message); close();
            }).dimensions(width / 2 + 4, height - 30, 96, 20).build());
            retry.active = message.stage() == 4; scroll = Math.min(scroll, Math.max(0, wrapped.size() - visible()));
        }
        private int visible() { return Math.max(1, (height - 80) / 12); }
        @Override public boolean mouseScrolled(double x, double y, double amount) {
            scroll = Math.max(0, Math.min(Math.max(0, wrapped.size() - visible()), scroll - (int) (amount * 3))); return true;
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
            for (int i = scroll, end = Math.min(wrapped.size(), scroll + visible()); i < end; i++)
                c.drawText(textRenderer, wrapped.get(i), 16, 38 + (i - scroll) * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    @Override public boolean shouldPause() { return false; }
}
