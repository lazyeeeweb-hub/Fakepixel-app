package dev.friendlink.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Flat social-menu button. Text is prepared on changes, never in renderButton (Yarn 1.20.1). */
public final class SocialButton extends ClickableWidget {
    private final Runnable action;
    private OrderedText label;
    private int labelWidth;
    private boolean accent;
    private final boolean searchIcon;

    public SocialButton(int x, int y, int width, int height, String label, Runnable action) {
        super(x, y, width, height, Text.literal(label));
        this.action = action;
        searchIcon = label.equals("?");
        label(label);
    }
    public SocialButton accent(boolean value) { accent = value; return this; }
    public void label(String value) {
        Text text = Text.literal(value);
        setMessage(text);
        label = Text.literal(MinecraftClient.getInstance().textRenderer.trimToWidth(value, Math.max(1, width - 4))).asOrderedText();
        labelWidth = MinecraftClient.getInstance().textRenderer.getWidth(label);
    }
    @Override public void onClick(double x, double y) { action.run(); }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (active && visible && isFocused() && (key == GLFW.GLFW_KEY_ENTER
            || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE)) {
            playDownSound(MinecraftClient.getInstance().getSoundManager());
            action.run(); return true;
        }
        return false;
    }
    @Override public void renderButton(DrawContext c, int mouseX, int mouseY, float delta) {
        boolean hover = isHovered() || isFocused();
        int color = !active ? 0xFF252B34 : accent ? (hover ? 0xFF408FE7 : 0xFF2879D5)
            : hover ? 0xFF3B4554 : 0xFF29313D;
        c.fill(getX(), getY(), getX() + width, getY() + height, color);
        if (searchIcon) {
            int x = getX() + 4, y = getY() + 4, ink = 0xFFE5EDFA;
            c.fill(x + 1, y, x + 7, y + 1, ink); c.fill(x + 1, y + 6, x + 7, y + 7, ink);
            c.fill(x, y + 1, x + 1, y + 6, ink); c.fill(x + 7, y + 1, x + 8, y + 6, ink);
            c.fill(x + 7, y + 7, x + 9, y + 9, ink); c.fill(x + 9, y + 9, x + 11, y + 11, ink);
        } else c.drawText(MinecraftClient.getInstance().textRenderer, label,
            getX() + Math.max(2, (width - labelWidth) / 2), getY() + (height - 8) / 2,
            active ? 0xFFF0F3FA : 0xFF727C8E, false);
    }
    @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
