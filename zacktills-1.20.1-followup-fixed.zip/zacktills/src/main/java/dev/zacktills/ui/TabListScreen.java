package dev.zacktills.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** A press becomes a tap only when the list has not begun panning. */
abstract class TabListScreen extends Screen {
    private final Screen parent;
    protected final ScrollList list = new ScrollList();
    protected final Button control;
    private final Button back = new Button("Back", this::close);
    private Rect panel;
    private Widget capture;
    protected boolean dirty = true;
    protected String empty = "No entries";

    TabListScreen(Screen parent, String title, String controlLabel) {
        super(Text.literal(title));
        this.parent = parent;
        control = new Button(controlLabel, this::controlPressed);
        back.primary = true;
    }

    protected abstract void controlPressed();
    protected abstract void syncRows();
    protected String hint() { return "Drag to scroll | Tap to select"; }

    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        int w = Math.max(1, Math.min(440, width - 16));
        panel = new Rect((width - w) / 2, 8, w, Math.max(0, height - 16));
        back.bounds(region(panel, w - 64, 32, 56, 25));
        control.bounds(region(panel, 8, 32, w - 78, 25));
        list.bounds(region(panel, 8, 63, w - 16, panel.h() - 85));
        dirty = true;
    }

    @Override public void render(DrawContext context, int mx, int my, float delta) {
        if (capture == null) syncRows();
        drawBackdrop(context, width, height);
        drawPanel(context, panel, title.getString());
        clip(context, panel);
        back.render(context, mx, my);
        control.render(context, mx, my);
        list.render(context, mx, my);
        if (list.items.isEmpty() && list.bounds.h() >= 28) centered(context, empty, list.bounds, MUTED);
        if (panel.h() >= 90) centered(context, hint(), region(panel, 8, panel.h() - 20, panel.w() - 16, 17), MUTED);
        unclip(context);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (capture != null) capture.cancel();
        capture = back.down(mx, my) ? back : control.down(mx, my) ? control : list.down(mx, my) ? list : null;
        return capture != null;
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0 || capture == null) return false;
        capture.drag(mx, my);
        return true;
    }

    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(mx, my);
        return true;
    }

    @Override public boolean mouseScrolled(double mx, double my, double amount) { return list.wheel(mx, my, amount); }
    @Override public void removed() {
        if (capture != null) capture.cancel();
        capture = null;
        super.removed();
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
