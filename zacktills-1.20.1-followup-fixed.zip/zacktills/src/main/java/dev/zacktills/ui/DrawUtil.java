package dev.zacktills.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

/** Flat, filled UI primitives. This class deliberately uses only Yarn 1.20.1 APIs. */
public final class DrawUtil {
    private DrawUtil() {}
    // RGB tokens from the ZUI hub reference, mapped to Minecraft's ARGB colors.
    public static final int PANEL = 0xFF16161C, RAIL = 0xFF1C1C24, INSET = 0xFF24242E;
    public static final int BORDER = 0xFF3A3A48, TEXT = 0xFFECECF2, MUTED = 0xFF9696A8;
    public static final int TITLE = 0xFF5882FF, ACCENT_HOVER = 0xFF789AFF, SELECTED = INSET;
    public static final int HOVER = 0xFF30303D, DISABLED_TEXT = 0xFF747486, WHITE = 0xFFFFFFFF, TOGGLE_OFF = BORDER;
    /** Layout scale of the screen currently being drawn; scissor rectangles must follow it. */
    public static float scale = 1f;
    public enum State { NORMAL, HOVER, PRESSED, DISABLED }
    public record Rect(int x, int y, int w, int h) {
        public Rect { w = Math.max(0, w); h = Math.max(0, h); }
        public boolean contains(double mx, double my) {
            return w > 0 && h > 0 && mx >= x && my >= y && mx < x + w && my < y + h;
        }
    }
    public static int clamp(int value, int min, int max) { return Math.max(min, Math.min(Math.max(min, max), value)); }
    /** A bounded child rectangle; zero-sized regions remain inert on tiny windows. */
    public static Rect region(Rect parent, int x, int y, int w, int h) {
        x = clamp(x, 0, parent.w); y = clamp(y, 0, parent.h);
        return new Rect(parent.x + x, parent.y + y, Math.min(Math.max(0, w), parent.w - x),
                Math.min(Math.max(0, h), parent.h - y));
    }
    public static Rect inset(Rect r, int padding) {
        int px = Math.min(Math.max(0, padding), r.w / 2), py = Math.min(Math.max(0, padding), r.h / 2);
        return region(r, px, py, r.w - px * 2, r.h - py * 2);
    }
    public static Rect panelBounds(int width, int height, int minW, int minH, int maxW, int maxH) {
        int w = Math.min(Math.max(minW, (int) Math.round(width * .8)), Math.min(maxW, Math.max(0, width - (width >= 8 ? 8 : 0))));
        int h = Math.min(Math.max(minH, (int) Math.round(height * .8)), Math.min(maxH, Math.max(0, height - (height >= 8 ? 8 : 0))));
        return new Rect((width - w) / 2, (height - h) / 2, w, h);
    }
    public static TextRenderer font() { return MinecraftClient.getInstance().textRenderer; }
    public static int textWidth(String text) { return font().getWidth(text); }
    public static String trim(String text, int width) {
        if (width <= 0) return "";
        if (textWidth(text) <= width) return text;
        if (width < textWidth("...")) return "";
        return font().trimToWidth(text, width - textWidth("...")) + "...";
    }
    public static void fill(DrawContext c, Rect r, int color) {
        if (r.w > 0 && r.h > 0) c.fill(r.x, r.y, r.x + r.w, r.y + r.h, color);
    }
    /** Scanline-filled corners: no textures, gradients, bevels, or outline passes. */
    public static void rounded(DrawContext c, Rect r, int radius, int color) {
        if (r.w == 0 || r.h == 0) return;
        int rad = Math.max(0, Math.min(radius, Math.min(r.w, r.h) / 2));
        if (rad == 0) { fill(c, r, color); return; }
        fill(c, new Rect(r.x, r.y + rad, r.w, r.h - rad * 2), color);
        for (int y = 0; y < rad; y++) {
            double dy = rad - y - .5;
            int cut = (int) Math.ceil(rad - Math.sqrt(rad * rad - dy * dy) - .5);
            fill(c, new Rect(r.x + cut, r.y + y, r.w - cut * 2, 1), color);
            fill(c, new Rect(r.x + cut, r.y + r.h - 1 - y, r.w - cut * 2, 1), color);
        }
    }
    public static void framed(DrawContext c, Rect r, int radius, int color, int border) {
        rounded(c, r, radius, border);
        rounded(c, inset(r, 1), Math.max(0, radius - 1), color);
    }
    public static void box(DrawContext c, Rect r, int fill, int border) { framed(c, r, 6, fill, border); }
    /** Shared ZUI chrome for the hub and companion screens. */
    public static void hubFrame(DrawContext c, Rect r, int topHeight) {
        framed(c, r, 10, PANEL, BORDER);
        Rect inside = inset(r, 1);
        Rect top = region(inside, 0, 0, inside.w(), topHeight - 1);
        rounded(c, top, 9, RAIL);
        if (top.h() < inside.h() && top.h() >= 9) {
            fill(c, region(top, 0, top.h() - 9, top.w(), 9), RAIL);
            fill(c, region(inside, 0, top.h(), inside.w(), 1), BORDER);
        }
    }
    public static int surface(State state) {
        return switch (state) { case HOVER -> HOVER; case PRESSED -> BORDER; default -> INSET; };
    }
    public static int ink(State state) { return state == State.DISABLED ? DISABLED_TEXT : TEXT; }
    public static void text(DrawContext c, String value, int x, int y, int width, int color) {
        if (width > 0) c.drawText(font(), trim(value, width), x, y, color, false);
    }
    public static void centered(DrawContext c, String value, Rect r, int color) {
        if (r.h < 9) return;
        String fit = trim(value, Math.max(0, r.w - 8));
        text(c, fit, r.x + (r.w - textWidth(fit)) / 2, r.y + (r.h - 8) / 2, r.w - 8, color);
    }
    public static void clip(DrawContext c, Rect r) {
        // enableScissor ignores the matrix stack in 1.20.1, so scale the rectangle by hand.
        c.enableScissor((int) Math.floor(r.x * scale), (int) Math.floor(r.y * scale),
                (int) Math.ceil((r.x + r.w) * scale), (int) Math.ceil((r.y + r.h) * scale));
    }
    public static void unclip(DrawContext c) { c.disableScissor(); }
    public static void drawBackdrop(DrawContext c, int width, int height) { fill(c, new Rect(0, 0, width, height), 0xB0000000); }
    public static void drawPanel(DrawContext c, Rect r, String title) {
        hubFrame(c, r, 34);
        clip(c, r);
        if (r.h >= 24) text(c, title, r.x + 12, r.y + 13, r.w - 24, TEXT);
        unclip(c);
    }
    public static void drawList(DrawContext c, Rect r) { rounded(c, r, 5, PANEL); }
    public static void drawRow(DrawContext c, Rect r, State state) { rounded(c, r, 5, state == State.HOVER ? HOVER : INSET); }
    public static void drawButton(DrawContext c, Rect r, String value, State state, boolean selected) {
        rounded(c, r, 5, selected && state != State.DISABLED ? SELECTED : surface(state));
        centered(c, value, r, selected && state != State.DISABLED ? ACCENT_HOVER : ink(state));
    }
    public static void drawPrimary(DrawContext c, Rect r, String value, State state) {
        rounded(c, r, 5, state == State.DISABLED ? INSET : state == State.HOVER ? ACCENT_HOVER : TITLE);
        centered(c, value, r, state == State.DISABLED ? DISABLED_TEXT : WHITE);
    }
    public static void drawClose(DrawContext c, Rect r, State state) { drawButton(c, r, "x", state, false); }
    public static void drawToggle(DrawContext c, Rect r, boolean on, State state) { drawToggle(c, r, on ? 1 : 0, state); }
    public static void drawToggle(DrawContext c, Rect r, double progress, State state) {
        int w = Math.min(38, r.w), h = Math.min(20, Math.min(r.h, w));
        Rect pill = new Rect(r.x + (r.w - w) / 2, r.y + (r.h - h) / 2, w, h);
        rounded(c, pill, h / 2, state == State.DISABLED ? BORDER : blend(TOGGLE_OFF, TITLE, progress));
        int size = Math.max(0, h - 6);
        int x = pill.x + 3 + (int) Math.round(Math.max(0, w - size - 6) * Math.max(0, Math.min(1, progress)));
        rounded(c, new Rect(x, pill.y + 3, size, size), size / 2, state == State.DISABLED ? MUTED : WHITE);
    }
    private static int blend(int a, int b, double amount) {
        double t = Math.max(0, Math.min(1, amount));
        int r = (int) Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int blue = (int) Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | r << 16 | g << 8 | blue;
    }
    public static int sliderTrackWidth(int width) { return Math.max(0, width - (width >= 58 ? 34 : 0)); }
    public static void drawSlider(DrawContext c, Rect r, double fraction, String value, State state) {
        int tw = sliderTrackWidth(r.w), diameter = Math.min(12, Math.min(r.h, tw));
        int travel = Math.max(0, tw - diameter);
        int kx = r.x + (int) Math.round(Math.max(0, Math.min(1, fraction)) * travel);
        Rect track = new Rect(r.x + diameter / 2, r.y + r.h / 2 - 3, travel, Math.min(6, r.h));
        rounded(c, track, 2, TOGGLE_OFF);
        rounded(c, new Rect(track.x, track.y, kx - r.x, track.h), 2, state == State.DISABLED ? MUTED : TITLE);
        rounded(c, new Rect(kx, r.y + (r.h - diameter) / 2, diameter, diameter), diameter / 2,
                state == State.DISABLED ? MUTED : state == State.HOVER ? ACCENT_HOVER : WHITE);
        if (tw < r.w) text(c, value, r.x + tw + 4, r.y + (r.h - 8) / 2, r.w - tw - 4, state == State.DISABLED ? DISABLED_TEXT : MUTED);
    }
    private static void inputSurface(DrawContext c, Rect r, State state, boolean focused) {
        framed(c, r, 6, PANEL, focused && state != State.DISABLED ? TITLE : BORDER);
    }
    public static void drawDropdown(DrawContext c, Rect r, String value, State state) { drawDropdown(c, r, value, state, false); }
    public static void drawDropdown(DrawContext c, Rect r, String value, State state, boolean focused) {
        inputSurface(c, r, state, focused);
        clip(c, r);
        if (r.h >= 9) {
            text(c, value, r.x + 8, r.y + (r.h - 8) / 2, r.w - 28, ink(state));
            text(c, "v", r.x + r.w - 14, r.y + (r.h - 8) / 2, Math.min(8, r.w), MUTED);
        }
        unclip(c);
    }
    public static void drawFolder(DrawContext c, Rect r, String label, boolean expanded, State state) {
        rounded(c, r, 5, surface(state));
        clip(c, r);
        if (r.h >= 9) {
            text(c, expanded ? "v" : ">", r.x + 8, r.y + (r.h - 8) / 2, 8, ink(state));
            text(c, label, r.x + 24, r.y + (r.h - 8) / 2, r.w - 32, ink(state));
        }
        unclip(c);
    }
    public static void drawTextField(DrawContext c, Rect r, String value, int caret, int anchor, int start, boolean focused, State state) {
        inputSurface(c, r, state, focused);
        if (r.h < 9 || r.w < 4) return;
        start = clamp(start, 0, value.length()); caret = clamp(caret, 0, value.length()); anchor = clamp(anchor, 0, value.length());
        Rect inside = inset(r, 2);
        clip(c, inside);
        int base = r.x + 8, ty = r.y + (r.h - 8) / 2;
        int a = Math.max(start, Math.min(caret, anchor)), b = Math.max(start, Math.max(caret, anchor));
        if (focused && a != b) {
            int sx = base + textWidth(value.substring(start, a));
            fill(c, new Rect(sx, ty - 1, textWidth(value.substring(a, b)), 10), SELECTED);
        }
        // Trim without ellipsis so the horizontally scrolling caret remains exact.
        c.drawText(font(), font().trimToWidth(value.substring(start), Math.max(0, r.w - 12)), base, ty, ink(state), false);
        if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = base + textWidth(value.substring(start, Math.max(start, caret)));
            fill(c, new Rect(cx, ty, 1, 8), TEXT);
        }
        unclip(c);
    }
    public static void drawScrollbar(DrawContext c, Rect track, Rect thumb, State state) {
        if (state == State.DISABLED) return;
        rounded(c, track, 2, INSET);
        rounded(c, thumb, 2, state == State.PRESSED || state == State.HOVER ? ACCENT_HOVER : TITLE);
    }
    public static void drawPlaceholder(DrawContext c, Rect r) { framed(c, r, 8, RAIL, BORDER); }
    public static void drawGrid(DrawContext c, Rect r) {
        rounded(c, r, 5, INSET);
        clip(c, r);
        for (int x = r.x + 16; x < r.x + r.w; x += 16) fill(c, new Rect(x, r.y, 1, r.h), BORDER);
        for (int y = r.y + 16; y < r.y + r.h; y += 16) fill(c, new Rect(r.x, y, r.w, 1), BORDER);
        unclip(c);
    }
    /** Bounded, wrapped hover help, including full labels clipped in compact rows. */
    public static void drawHint(DrawContext c, Rect area, String value, int mx, int my) {
        if (area.w < 32 || area.h < 24 || value.isBlank()) return;
        int width = Math.min(300, area.w), inner = width - 16;
        List<String> lines = new ArrayList<>();
        String rest = value;
        int limit = Math.max(1, (area.h - 16) / 12);
        while (!rest.isEmpty() && lines.size() < limit) {
            String fit = font().trimToWidth(rest, inner);
            if (fit.isEmpty()) break;
            if (fit.length() < rest.length() && fit.lastIndexOf(' ') > 0) fit = fit.substring(0, fit.lastIndexOf(' '));
            lines.add(fit); rest = rest.substring(fit.length()).stripLeading();
        }
        if (!rest.isEmpty() && !lines.isEmpty()) lines.set(lines.size() - 1, trim(lines.get(lines.size() - 1) + "...", inner));
        int h = Math.min(area.h, lines.size() * 12 + 12);
        Rect hint = new Rect(clamp(mx + 12, area.x, area.x + area.w - width),
                clamp(my + 16, area.y, area.y + area.h - h), width, h);
        rounded(c, hint, 5, HOVER); clip(c, hint);
        for (int i = 0; i < lines.size(); i++) text(c, lines.get(i), hint.x + 8, hint.y + 8 + i * 12, inner, TEXT);
        unclip(c);
    }

    public static void drawChip(DrawContext c, Rect r, String value, State state, boolean selected) {
        int bg = selected && state != State.DISABLED ? SELECTED : state == State.HOVER ? HOVER : INSET;
        rounded(c, r, r.h / 2, bg);
        centered(c, value, r, selected ? ACCENT_HOVER : ink(state));
    }
    private static final int TAB_LEFT = 10, TAB_RIGHT = 7;
    public static int tabInsets() { return TAB_LEFT + TAB_RIGHT; }
    public static void drawTab(DrawContext c, Rect r, String label, State state, boolean selected) {
        if (r.w() <= 0 || r.h() <= 0) return;
        clip(c, r);
        try {
            if (selected || state == State.HOVER || state == State.PRESSED) {
                rounded(c, r, 6, selected ? INSET : HOVER);
            }
            if (selected && r.h() > 10 && r.w() > 4) rounded(c, region(r, 2, 5, 2, r.h() - 10), 1, TITLE);
            Rect labelBox = region(r, TAB_LEFT, 0, r.w() - tabInsets(), r.h());
            if (labelBox.w() > 0) {
                clip(c, labelBox);
                try {
                    text(c, label, labelBox.x(), labelBox.y() + (labelBox.h() - font().fontHeight) / 2,
                            labelBox.w(), selected || state == State.HOVER ? TEXT : MUTED);
                } finally {
                    unclip(c);
                }
            }
        } finally {
            unclip(c);
        }
    }
    public static void drawMagnifier(DrawContext c, int x, int y, int color, int background) {
        rounded(c, new Rect(x, y, 8, 8), 4, color);
        rounded(c, new Rect(x + 1, y + 1, 6, 6), 3, background);
        fill(c, new Rect(x + 7, y + 7, 2, 2), color);
        fill(c, new Rect(x + 9, y + 9, 1, 1), color);
    }
    public static void bigText(DrawContext c, String value, int x, int y, float size, int color) {
        c.getMatrices().push();
        c.getMatrices().translate(x, y, 0);
        c.getMatrices().scale(size, size, 1f);
        c.drawText(font(), value, 0, 0, color, false);
        c.getMatrices().pop();
    }
}
