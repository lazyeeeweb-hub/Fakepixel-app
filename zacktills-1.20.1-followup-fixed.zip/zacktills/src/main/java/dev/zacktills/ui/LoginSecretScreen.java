package dev.zacktills.ui;

import dev.zacktills.feature.AutoLogin;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** Session-only secret; never sent to ConfigStore or copied to the clipboard. */
public final class LoginSecretScreen extends Screen {
    private final Screen parent;
    private final TextField password = new TextField("", value -> {});
    private final Button use, back;
    private Rect panel, help;
    private Widget focus, capture;

    public LoginSecretScreen(Screen parent) {
        super(Text.literal("Session login password"));
        this.parent = parent;
        password.masked = true;
        password.maxLength = 256;
        password.placeholder = "Password";
        use = new Button("Use until disconnect", () -> {
            AutoLogin.password(password.value);
            password.clear();
            close();
        });
        use.primary = true;
        back = new Button("Cancel", this::close);
    }
    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        panel = panelBounds(width, height, 280, 176, 360, 208);
        password.bounds(region(panel, 16, 48, panel.w() - 32, 24));
        use.bounds(region(panel, 16, 80, panel.w() - 32, 24));
        back.bounds(region(panel, 16, 112, panel.w() - 32, 24));
        help = region(panel, 16, 144, panel.w() - 32, panel.h() - 152);
        setFocus(password);
    }
    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        // Yarn 1.20.1's single-argument background hook; no 1.20.2 overloads.
        renderBackground(c);
        drawPanel(c, panel, title.getString());
        clip(c, panel);
        password.render(c, mx, my); use.render(c, mx, my); back.render(c, mx, my);
        clip(c, help);
        text(c, "Not saved to disk. Trusted servers only.", help.x(), help.y(), help.w(), MUTED);
        unclip(c); unclip(c);
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (capture != null) capture.cancel();
        capture = null;
        for (Widget widget : List.of(password, use, back)) {
            if (widget.down(mx, my)) { capture = widget; setFocus(widget); return true; }
        }
        setFocus(null);
        return panel.contains(mx, my);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0 || capture == null) return false;
        capture.drag(mx, my); return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture; capture = null; target.up(mx, my); return true;
    }
    @Override public boolean charTyped(char chr, int modifiers) { return focus != null && focus.character(chr); }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = List.of(password, use, back);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            setFocus(controls.get(current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size())));
            return true;
        }
        if (focus == password && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            use.key(GLFW.GLFW_KEY_ENTER, modifiers); return true;
        }
        return focus != null && focus.key(key, modifiers) || super.keyPressed(key, scan, modifiers);
    }
    @Override public void close() { password.clear(); if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        password.clear(); if (capture != null) capture.cancel(); capture = null;
        super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
