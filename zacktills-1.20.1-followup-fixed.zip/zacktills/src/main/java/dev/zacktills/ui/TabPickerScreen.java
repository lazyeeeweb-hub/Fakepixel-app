package dev.zacktills.ui;

import dev.zacktills.feature.TabParts;
import dev.zacktills.feature.TabParts.Ref;
import dev.zacktills.feature.TabParts.Row;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class TabPickerScreen extends TabListScreen {
    private boolean wholeSection;
    private List<Row> shown = List.of();

    public TabPickerScreen(Screen parent) {
        super(parent, "Pick tab parts", "Mode: This line only");
        empty = "No tab entries. Join a world first.";
    }

    @Override protected void controlPressed() {
        wholeSection = !wholeSection;
        control.label = wholeSection ? "Mode: Whole section" : "Mode: This line only";
        dirty = true;
    }

    @Override protected void syncRows() {
        List<Row> current = TabParts.rows();
        if (!dirty && current.equals(shown)) return;
        shown = current;
        dirty = false;
        var buttons = new ArrayList<Widget>();
        for (Row row : shown) buttons.add(new Entry(row, wholeSection ? row.section() : row.line()));
        list.setItems(buttons);
    }

    @Override protected String hint() {
        return wholeSection ? "Tap a header or a line in its section" : "Tap a line to add or remove it";
    }

    private final class Entry extends Button {
        private final Row row;
        private final Ref ref;

        private Entry(Row row, Ref ref) {
            super("", () -> { TabParts.toggle(ref); dirty = true; });
            this.row = row; this.ref = ref;
            enabled = ref != null;
        }
        @Override public int height() { return 26; }
        @Override public void render(DrawContext c, int mx, int my) {
            boolean checked = TabParts.contains(ref);
            drawButton(c, bounds, "", state(mx, my), checked);
            Rect inner = inset(bounds, 5);
            if (inner.w() == 0 || inner.h() == 0) return;
            clip(c, inner);
            int y = bounds.y() + (bounds.h() - font().fontHeight) / 2;
            if (enabled) c.drawText(font(), checked ? "[x]" : "[ ]", inner.x(), y, checked ? ACCENT_HOVER : MUTED, false);
            c.drawTextWithShadow(font(), row.text(), inner.x() + 24, y, enabled ? 0xFFFFFFFF : 0xFF9A9FAC);
            unclip(c);
        }
    }
}
