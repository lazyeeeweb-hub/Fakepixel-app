package dev.zacktills.ui;

import dev.zacktills.feature.TabParts;
import dev.zacktills.feature.TabParts.Part;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

public final class TabPartsScreen extends TabListScreen {
    public TabPartsScreen(Screen parent) {
        super(parent, "Manage tab parts", "Pick tab parts");
        empty = "No saved parts. Tap Pick tab parts.";
    }

    @Override protected void controlPressed() {
        if (client != null) client.setScreen(new TabPickerScreen(this));
    }

    @Override protected void syncRows() {
        if (!dirty) return;
        dirty = false;
        var rows = new ArrayList<Widget>();
        for (Part part : TabParts.parts()) rows.add(new PartRow(part));
        list.setItems(rows);
    }

    @Override protected String hint() { return "Drag to scroll | Edit opens the shared editor; tap another tab part to select it"; }

    private final class PartRow extends Widget {
        private final Part part;
        private final Button enabledButton, edit, remove;
        private final List<Button> controls;
        private Button active;

        PartRow(Part part) {
            this.part = part;
            enabledButton = new Button(part.enabled() ? "On" : "Off", () -> {
                part.toggleEnabled();
                enabledButtonLabel();
            });
            enabledButton.selected = part.enabled();
            edit = new Button("Edit", () -> {
                if (client != null) client.setScreen(new HudEditorScreen(TabPartsScreen.this, part.id()));
            });
            remove = new Button("Remove", () -> { TabParts.remove(part); dirty = true; });
            controls = List.of(enabledButton, edit, remove);
        }

        private void enabledButtonLabel() {
            enabledButton.label = part.enabled() ? "On" : "Off";
            enabledButton.selected = part.enabled();
        }

        @Override public int height() { return 49; }
        @Override public void bounds(Rect r) {
            super.bounds(r);
            int available = Math.max(0, r.w() - 14);
            int third = available / 3;
            for (int i = 0; i < controls.size(); i++) {
                controls.get(i).bounds(region(r, 4 + (third + 3) * i, 20, third, 25));
            }
        }
        @Override public void render(DrawContext c, int mx, int my) {
            rounded(c, bounds, 5, INSET);
            text(c, part.label() + (part.kind() == TabParts.Kind.SECTION ? " [section]" : " [line]"),
                    bounds.x() + 6, bounds.y() + 6, bounds.w() - 12, TEXT);
            for (Button b : controls) b.render(c, mx, my);
        }
        @Override public boolean down(double mx, double my) {
            active = null;
            for (Button b : controls) if (b.down(mx, my)) { active = b; return true; }
            return false;
        }
        @Override public void up(double mx, double my) {
            Button b = active; active = null;
            if (b != null) b.up(mx, my);
        }
        @Override public void cancel() {
            if (active != null) active.cancel();
            active = null;
        }
    }
}
