package dev.zacktills.feature;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

import static dev.zacktills.feature.HudElement.*;

public final class HudFeatures {
    private static final Identifier WIDGETS = new Identifier("minecraft", "textures/gui/widgets.png");
    private static final List<Text> SCORE_PREVIEW = java.util.stream.IntStream.rangeClosed(1, 8)
            .mapToObj(i -> (Text) Text.literal("Player / information " + i)).toList();

    private static boolean fadingItem; // accessed only on the render thread

    private HudFeatures() {}

    public static boolean isFadingItem() { return fadingItem; }

    public static void initialize() {
        HudElements.register(new BuiltIn("hotbar", "Hotbar", 182, 22) {
            @Override public void render(DrawContext c, float alpha) { drawHotbar(c, this, alpha); }
        });
        HudElements.register(new BuiltIn("offhand", "Offhand", 22, 22) {
            @Override public void render(DrawContext c, float alpha) { drawOffhand(c, this, alpha); }
        });
        HudElements.register(new BuiltIn("scoreboard", "Scoreboard", 150, 110) {
            @Override public Size size() { return scoreboardLayout(currentSidebar()).size(); }
            @Override public void render(DrawContext c, float alpha) {
                drawScoreboard(c, this, scoreboardLayout(currentSidebar()), alpha);
            }
        });
        // The crosshair remains fixed at the aim point; it is a contextual overlay, not a drag target.
        HudElements.register(new HudElement() {
            public String id() { return "crosshair"; }
            public int defaultWidth() { return 9; }
            public int defaultHeight() { return 9; }
            public Position position() { return new Position(.5, .5, 1); }
            public void position(Position ignored) {}
            public void render(DrawContext c, float alpha) { crosshair(c, alpha); }
        });
    }

    private abstract static class BuiltIn implements HudElement {
        private final String id, label;
        private final int width, height;
        private BuiltIn(String id, String label, int width, int height) {
            this.id = id; this.label = label; this.width = width; this.height = height;
        }
        public String id() { return id; }
        public String label() { return label; }
        public int defaultWidth() { return width; }
        public int defaultHeight() { return height; }
        public Position position() {
            return new Position(FeatureSettings.pos(id, "x"), FeatureSettings.pos(id, "y"), FeatureSettings.pos(id, "scale"));
        }
        public void position(Position p) {
            FeatureSettings.pos(id, "x", p.x());
            FeatureSettings.pos(id, "y", p.y());
            FeatureSettings.pos(id, "scale", p.scale());
        }
        @Override public void savePosition() { FeatureSettings.save(); }
    }

    public static void begin(DrawContext c, HudElement element, Size size) {
        var window = MinecraftClient.getInstance().getWindow();
        Bounds bounds = element.bounds(size, window.getScaledWidth(), window.getScaledHeight());
        float scale = (float) element.position().scale();
        c.getMatrices().push();
        c.getMatrices().translate(bounds.x(), bounds.y(), 0);
        c.getMatrices().scale(scale, scale, 1);
    }

    public static int fade(int argb, float alpha) {
        return (Math.round((argb >>> 24) * Math.max(0, Math.min(1, alpha))) << 24) | (argb & 0xFFFFFF);
    }

    public static int textColor(int rgb, float alpha) {
        // TextRenderer treats alpha 0..3 as implicit fully opaque RGB.
        return (Math.max(4, Math.round(255 * alpha)) << 24) | (rgb & 0xFFFFFF);
    }

    private static void tinted(DrawContext c, float alpha, Runnable draw) {
        if (alpha == 1) { draw.run(); return; }
        c.draw();
        float[] color = RenderSystem.getShaderColor().clone();
        boolean blend = org.lwjgl.opengl.GL11.glIsEnabled(org.lwjgl.opengl.GL11.GL_BLEND);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(color[0], color[1], color[2], color[3] * alpha);
        try {
            draw.run();
            c.draw();
        } finally {
            RenderSystem.setShaderColor(color[0], color[1], color[2], color[3]);
            if (blend) RenderSystem.enableBlend();
            else RenderSystem.disableBlend();
        }
    }

    public static void hotbar(DrawContext c) {
        HudElements.get("hotbar").render(c, 1);
        HudElements.get("offhand").render(c, 1);
    }

    private static void drawHotbar(DrawContext c, HudElement element, float alpha) {
        var player = MinecraftClient.getInstance().player;
        int selected = player == null ? 0 : player.getInventory().selectedSlot;
        begin(c, element, element.size());
        tinted(c, alpha, () -> {
            c.drawTexture(WIDGETS, 0, 0, 0, 0, 182, 22);
            c.drawTexture(WIDGETS, selected * 20 - 1, -1, 0, 22, 24, 22);
        });
        for (int i = 0; i < 9; i++) {
            if (player != null) drawStack(c, player.getInventory().getStack(i), 3 + i * 20, 3, alpha);
            if (ItemFeatures.locked(i)) outline(c, 2 + i * 20, 2, 18, 18, fade(0xFFFFC24A, alpha));
        }
        c.getMatrices().pop();
    }

    private static void drawOffhand(DrawContext c, HudElement element, float alpha) {
        var player = MinecraftClient.getInstance().player;
        begin(c, element, element.size());
        rounded(c, 0, 0, 22, 22, 3, fade(0xBB202020, alpha));
        if (player != null) drawStack(c, player.getOffHandStack(), 3, 3, alpha);
        if (ItemFeatures.locked(40)) outline(c, 2, 2, 18, 18, fade(0xFFFFC24A, alpha));
        c.getMatrices().pop();
    }

    private static void drawStack(DrawContext c, ItemStack stack, int x, int y, float alpha) {
        if (stack.isEmpty()) return;
        var mc = MinecraftClient.getInstance();
        if (alpha == 1) c.drawItem(stack, x, y);
        else tinted(c, alpha, () -> {
            fadingItem = true;
            try {
                c.drawItem(stack, x, y);
                c.draw();
            } finally {
                fadingItem = false;
            }
        });
        if (alpha == 1) {
            c.drawItemInSlot(mc.textRenderer, stack, x, y);
            return;
        }
        // Vanilla draws these decorations on separate text/fill layers; fade their ARGB explicitly.
        c.getMatrices().push();
        c.getMatrices().translate(0, 0, 200);
        if (stack.getCount() != 1) {
            String count = Integer.toString(stack.getCount());
            c.drawTextWithShadow(mc.textRenderer, count, x + 17 - mc.textRenderer.getWidth(count), y + 9,
                    textColor(0xFFFFFF, alpha));
        }
        if (stack.isItemBarVisible()) {
            c.fill(x + 2, y + 13, x + 15, y + 15, fade(0xFF000000, alpha));
            c.fill(x + 2, y + 13, x + 2 + stack.getItemBarStep(), y + 14,
                    fade(0xFF000000 | stack.getItemBarColor(), alpha));
        }
        float cooldown = mc.player == null ? 0 : mc.player.getItemCooldownManager().getCooldownProgress(stack.getItem(), mc.getTickDelta());
        if (cooldown > 0) {
            c.fill(x, y + (int) Math.floor(16 * (1 - cooldown)), x + 16, y + 16, fade(0x7FFFFFFF, alpha));
        }
        c.getMatrices().pop();
    }

    public static void crosshair(DrawContext c, float alpha) {
        var mc = MinecraftClient.getInstance();
        CrosshairShape.draw(c, mc.getWindow().getScaledWidth() / 2, mc.getWindow().getScaledHeight() / 2,
                (int) FeatureSettings.number("tooltip.crosshair_thickness"),
                (int) FeatureSettings.number("tooltip.crosshair_length"), fade(0xFFFFFFFF, alpha));
    }

    private record ScoreLayout(Text title, List<Text> lines, Size size, boolean preview) {}

    private static ScoreboardObjective currentSidebar() {
        var mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return null;
        Scoreboard board = mc.world.getScoreboard();
        Team team = board.getPlayerTeam(mc.player.getEntityName());
        if (team != null && team.getColor().getColorIndex() >= 0) {
            ScoreboardObjective teamSidebar = board.getObjectiveForSlot(3 + team.getColor().getColorIndex());
            if (teamSidebar != null) return teamSidebar;
        }
        return board.getObjectiveForSlot(1);
    }

    private static ScoreLayout scoreboardLayout(ScoreboardObjective objective) {
        if (objective == null) return new ScoreLayout(Text.literal("Scoreboard preview"), SCORE_PREVIEW, new Size(150, 110), true);
        var mc = MinecraftClient.getInstance(); Scoreboard board = objective.getScoreboard();
        List<ScoreboardPlayerScore> scores = new ArrayList<>(board.getAllPlayerScores(objective));
        scores.removeIf(s -> s.getPlayerName() == null || s.getPlayerName().startsWith("#"));
        scores.sort(ScoreboardPlayerScore.COMPARATOR);
        if (scores.size() > 15) scores = scores.subList(scores.size() - 15, scores.size());
        List<Text> lines = new ArrayList<>(); int w = mc.textRenderer.getWidth(objective.getDisplayName());
        for (int i = scores.size() - 1; i >= 0; i--) {
            String name = scores.get(i).getPlayerName();
            Text line = Team.decorateName(board.getPlayerTeam(name), Text.literal(name));
            lines.add(line);
            w = Math.max(w, mc.textRenderer.getWidth(line));
        }
        return new ScoreLayout(objective.getDisplayName(), lines, new Size(w + 12, 16 + lines.size() * 10), false);
    }

    public static void scoreboard(DrawContext c, ScoreboardObjective objective) {
        drawScoreboard(c, HudElements.get("scoreboard"), scoreboardLayout(objective), 1);
    }

    private static void drawScoreboard(DrawContext c, HudElement element, ScoreLayout layout, float alpha) {
        var font = MinecraftClient.getInstance().textRenderer;
        Size size = layout.size();
        begin(c, element, size);
        drawBox(c, size, alpha);
        c.drawCenteredTextWithShadow(font, layout.title(), size.width() / 2, 4, textColor(0xFFFFFF, alpha));
        for (int i = 0; i < layout.lines().size(); i++) {
            c.drawTextWithShadow(font, layout.lines().get(i), 6, (layout.preview() ? 22 : 16) + i * 10,
                    textColor(layout.preview() ? 0xBAC0CB : 0xFFFFFF, alpha));
        }
        c.getMatrices().pop();
    }

    public static void drawBox(DrawContext c, Size size, float alpha) {
        int opacity = (int) (255 * FeatureSettings.number("scoreboard.opacity"));
        rounded(c, 0, 0, size.width(), size.height(), (int) FeatureSettings.number("scoreboard.radius"),
                fade((opacity << 24) | 0x171C24, alpha));
    }
    public static void outline(DrawContext c,int x,int y,int w,int h,int color) {
        c.fill(x,y,x+w,y+1,color); c.fill(x,y+h-1,x+w,y+h,color);
        c.fill(x,y,x+1,y+h,color); c.fill(x+w-1,y,x+w,y+h,color);
    }
    public static void rounded(DrawContext c,int x,int y,int w,int h,int radius,int color) {
        int r=Math.max(0,Math.min(radius,Math.min(w,h)/2));
        for(int row=0;row<h;row++) {
            int inset=0;
            if(row<r) inset=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-Math.pow(r-row-.5,2))));
            else if(row>=h-r) inset=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-Math.pow(row-(h-r)+.5,2))));
            c.fill(x+inset,y+row,x+w-inset,y+row+1,color);
        }
    }
}
