package dev.zacktills.feature;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Client-thread registry shared by the HUD and position editor. */
public final class HudElements {
    private static final Map<String, HudElement> ELEMENTS = new LinkedHashMap<>();

    private HudElements() {}

    public static void register(HudElement element) { ELEMENTS.put(element.id(), element); }
    public static void unregister(String id) { ELEMENTS.remove(id); }
    public static HudElement get(String id) { return ELEMENTS.get(id); }
    public static List<HudElement> all() { return List.copyOf(ELEMENTS.values()); }
}
