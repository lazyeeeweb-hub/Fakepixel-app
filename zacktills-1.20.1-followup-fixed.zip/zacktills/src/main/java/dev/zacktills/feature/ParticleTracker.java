package dev.zacktills.feature;

import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Bounded spatial buckets of observed spawn positions, timestamped with monotonic time. */
final class ParticleTracker {
    static final double MAX_RADIUS_SQUARED = 64.0 * 64.0;
    private static final int MAX_TOTAL = 4096;
    private static final int MAX_PER_BUCKET = 128;
    private static final int MAX_PER_TICK = 1024;
    private static final int MAX_CANDIDATES = 32768;

    private final ArrayDeque<Point> ordered = new ArrayDeque<>();
    private final Map<BlockPos, ArrayDeque<Point>> buckets = new HashMap<>();
    private final Map<BlockPos, Long> blacklistUntil = new HashMap<>();
    private int addedThisTick;

    void beginTick() { addedThisTick = 0; }

    void add(Identifier type, double x, double y, double z, long timeNanos) {
        if (addedThisTick >= MAX_PER_TICK || ordered.size() >= MAX_TOTAL) return;
        BlockPos bucket = BlockPos.ofFloored(x, y, z);
        ArrayDeque<Point> inBucket = buckets.computeIfAbsent(bucket, ignored -> new ArrayDeque<>());
        if (inBucket.size() >= MAX_PER_BUCKET) return;
        Point point = new Point(type, x, y, z, timeNanos, bucket);
        ordered.addLast(point);
        inBucket.addLast(point);
        addedThisTick++;
    }

    /**
     * Every fresh particle votes for the nearest solid block (distance to the block's cube).
     * Particles sit on the exposed faces of the real block, so the real block collects the most
     * votes; neighbours get a few stray ones. Then only the strongest block of each cluster is kept.
     */
    List<BlockPos> findTargets(ClientWorld world, PlayerEntity player,
                               int minimum, int maximum, double windowSeconds, long freshAfterNanos) {
        long now = System.nanoTime();
        long window = (long) (Math.max(0.1, Math.min(5.0, windowSeconds)) * 1_000_000_000L);
        expire(now, window);
        expireBlacklists(now);
        if (ordered.isEmpty() || player == null) return List.of();
        int required = Math.max(1, Math.min(128, minimum));
        int maxTargets = Math.max(1, Math.min(10, maximum));
        Map<BlockPos, Integer> votes = new HashMap<>();
        for (Point point : ordered) {
            if (point.timeNanos <= freshAfterNanos) continue;
            BlockPos nearest = nearestSolid(world, point, now);
            if (nearest != null) votes.merge(nearest, 1, Integer::sum);
        }
        Vec3d playerPos = player.getPos();
        List<Map.Entry<BlockPos, Integer>> ranked = new ArrayList<>();
        for (Map.Entry<BlockPos, Integer> entry : votes.entrySet()) {
            if (entry.getValue() >= required
                    && playerPos.squaredDistanceTo(Vec3d.ofCenter(entry.getKey())) <= MAX_RADIUS_SQUARED) {
                ranked.add(entry);
            }
        }
        ranked.sort(Comparator.<Map.Entry<BlockPos, Integer>>comparingInt(e -> -e.getValue())
                .thenComparingDouble(e -> playerPos.squaredDistanceTo(Vec3d.ofCenter(e.getKey()))));
        List<BlockPos> result = new ArrayList<>();
        for (Map.Entry<BlockPos, Integer> entry : ranked) {
            BlockPos pos = entry.getKey();
            boolean tooClose = false;
            for (BlockPos kept : result) {
                if (kept.getSquaredDistance(pos) <= 4.0) { tooClose = true; break; }
            }
            if (tooClose) continue;
            result.add(pos);
            if (result.size() >= maxTargets) break;
        }
        result.sort(Comparator.comparingDouble(pos -> playerPos.squaredDistanceTo(Vec3d.ofCenter(pos))));
        return List.copyOf(result);
    }

    private BlockPos nearestSolid(ClientWorld world, Point point, long now) {
        int bx = (int) Math.floor(point.x), by = (int) Math.floor(point.y), bz = (int) Math.floor(point.z);
        BlockPos best = null;
        double bestDistance = 0.75 * 0.75;
        BlockPos.Mutable cursor = new BlockPos.Mutable();
        for (int x = bx - 1; x <= bx + 1; x++) for (int y = by - 1; y <= by + 1; y++) for (int z = bz - 1; z <= bz + 1; z++) {
            cursor.set(x, y, z);
            if (!world.isChunkLoaded(cursor)) continue;
            BlockState state = world.getBlockState(cursor);
            if (state.isAir() || state.getCollisionShape(world, cursor).isEmpty()) continue;
            if (isBlacklisted(cursor, now)) continue;
            double dx = Math.max(Math.max(x - point.x, 0), point.x - (x + 1));
            double dy = Math.max(Math.max(y - point.y, 0), point.y - (y + 1));
            double dz = Math.max(Math.max(z - point.z, 0), point.z - (z + 1));
            double distance = dx * dx + dy * dy + dz * dz;
            if (distance < bestDistance) {
                bestDistance = distance;
                best = cursor.toImmutable();
            }
        }
        return best;
    }

    void removeWithin(BlockPos center, double radius) {
        double cx = center.getX() + 0.5, cy = center.getY() + 0.5, cz = center.getZ() + 0.5;
        double radiusSquared = radius * radius;
        Iterator<Point> iterator = ordered.iterator();
        while (iterator.hasNext()) {
            Point point = iterator.next();
            double dx = point.x - cx, dy = point.y - cy, dz = point.z - cz;
            if (dx * dx + dy * dy + dz * dz > radiusSquared) continue;
            iterator.remove();
            ArrayDeque<Point> bucket = buckets.get(point.bucket);
            if (bucket != null) {
                bucket.remove(point);
                if (bucket.isEmpty()) buckets.remove(point.bucket);
            }
        }
    }

    void blacklist(BlockPos pos, long durationNanos) {
        if (pos == null || durationNanos <= 0L) return;
        long until = System.nanoTime() + durationNanos;
        blacklistUntil.merge(pos.toImmutable(), until, Math::max);
    }

    boolean isBlacklisted(BlockPos pos) { return isBlacklisted(pos, System.nanoTime()); }

    private boolean isBlacklisted(BlockPos pos, long now) {
        Long until = blacklistUntil.get(pos);
        return until != null && now < until;
    }

    void expireBlacklists(long now) {
        blacklistUntil.entrySet().removeIf(entry -> now >= entry.getValue());
    }

    int blacklistCount() {
        expireBlacklists(System.nanoTime());
        return blacklistUntil.size();
    }

    private void expire(long now, long windowNanos) {
        while (!ordered.isEmpty() && now - ordered.peekFirst().timeNanos > windowNanos) {
            Point expired = ordered.removeFirst();
            ArrayDeque<Point> bucket = buckets.get(expired.bucket);
            if (bucket != null) {
                bucket.removeFirstOccurrence(expired);
                if (bucket.isEmpty()) buckets.remove(expired.bucket);
            }
        }
    }

    void reset() {
        ordered.clear();
        buckets.clear();
        blacklistUntil.clear();
        addedThisTick = 0;
    }

    private record Point(Identifier type, double x, double y, double z, long timeNanos, BlockPos bucket) { }
}
