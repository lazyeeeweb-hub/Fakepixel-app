package dev.zacktills.feature;

import net.minecraft.client.gui.DrawContext;

/** A centered solid plus; length counts the pixels of each arm outside the center. */
public final class CrosshairShape {
    private CrosshairShape() {}

    public static void draw(DrawContext context, int x, int y, int thickness, int armLength, int color) {
        // At even thickness, the extra pixel falls on the positive side of the center.
        int left = x - (thickness - 1) / 2;
        int top = y - (thickness - 1) / 2;
        int right = left + thickness;
        int bottom = top + thickness;
        context.fill(left - armLength, top, right + armLength, bottom, color);
        context.fill(left, top - armLength, right, top, color);
        context.fill(left, bottom, right, bottom + armLength, color);
    }
}
