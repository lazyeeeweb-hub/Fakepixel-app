package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Optional;

public final class AutoChatClick {
    private static final Logger LOG = LoggerFactory.getLogger("zacktills/auto-chat-click");
    private static Pending pending;
    private static int ticksLeft;
    private static long lastAttempt;
    private static boolean attempted;

    private record Pending(ClientPlayNetworkHandler connection, String command) {}
    private record Span(ClickEvent click, StringBuilder text) {}

    private AutoChatClick() {}

    public static void receive(MinecraftClient client, Text message) {
        client.execute(() -> accept(client, message));
    }

    private static void accept(MinecraftClient client, Text message) {
        if (!FeatureSettings.on("autoclick.enabled") || client.player == null || client.world == null) return;
        String trigger = fold(FeatureSettings.text("autoclick.trigger").strip());
        if (trigger.isEmpty() || !fold(message.getString()).contains(trigger)) return;

        String command = matchingCommand(message, trigger);
        if (command == null) {
            debug("Trigger found, but the matching text has no RUN_COMMAND click event.");
            return;
        }
        if (pending != null || coolingDown()) return;
        pending = new Pending(client.getNetworkHandler(), command);
        ticksLeft = (int) FeatureSettings.number("autoclick.delay");
        if (ticksLeft == 0) run(client);
    }

    static String matchingCommand(Text message, String foldedTrigger) {
        var spans = new ArrayList<Span>();
        // The styled visitor walks the root and all siblings, with vanilla style inheritance.
        // Coalesce adjacent pieces of the same clickable text (e.g. mixed bold and regular text).
        message.visit((style, text) -> {
            if (!text.isEmpty()) {
                ClickEvent click = style.getClickEvent();
                if (click != null && click.getAction() != ClickEvent.Action.RUN_COMMAND) click = null;
                Span prev = spans.isEmpty() ? null : spans.get(spans.size() - 1);
                if (prev != null && java.util.Objects.equals(prev.click(), click)) prev.text().append(text);
                else spans.add(new Span(click, new StringBuilder(text)));
            }
            return Optional.empty();
        }, Style.EMPTY);
        for (Span span : spans) {
            if (span.click() != null && fold(span.text().toString()).contains(foldedTrigger)) {
                return span.click().getValue();
            }
        }
        return null;
    }

    private static String fold(String value) {
        return Formatting.strip(value).toLowerCase(Locale.ROOT);
    }

    private static boolean coolingDown() {
        long nanos = (long) FeatureSettings.number("autoclick.cooldown") * 1_000_000_000L;
        return attempted && System.nanoTime() - lastAttempt < nanos;
    }

    public static void tick(MinecraftClient client) {
        if (pending == null) return;
        if (!FeatureSettings.on("autoclick.enabled") || client.world == null
                || pending.connection() != client.getNetworkHandler()) {
            pending = null;
        } else if (--ticksLeft <= 0) {
            run(client);
        }
    }

    private static void run(MinecraftClient client) {
        Pending click = pending;
        pending = null;
        if (client.player == null || click.connection() == null
                || click.connection() != client.getNetworkHandler() || coolingDown()) return;
        lastAttempt = System.nanoTime();
        attempted = true;
        // Screen.handleTextClick in 1.20.1 sanitizes, requires '/', and rejects signed arguments.
        String value = SharedConstants.stripInvalidChars(click.command());
        if (!value.startsWith("/")) {
            debug("Matching RUN_COMMAND had no '/' prefix; skipped.");
        } else if (!click.connection().sendCommand(value.substring(1))) {
            debug("Vanilla rejected the click command because it requires a signed argument.");
        }
    }

    public static void reset() {
        pending = null;
        attempted = false;
    }

    private static void debug(String reason) {
        if (FeatureSettings.on("autoclick.debug")) LOG.info(reason);
    }
}
