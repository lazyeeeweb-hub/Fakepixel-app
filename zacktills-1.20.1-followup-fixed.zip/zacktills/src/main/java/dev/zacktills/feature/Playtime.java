package dev.zacktills.feature;

import com.google.gson.Gson;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

public final class Playtime {
    private static final Logger LOG = LoggerFactory.getLogger("zacktills/playtime");
    private static final Gson GSON = new Gson();
    private static final long SAVE_INTERVAL = 60_000_000_000L;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zacktills/playtime.json");
    private static double seconds;
    private static long lastSample, lastSave;
    private static boolean wasLoaded;

    private record Saved(double seconds) {}

    private Playtime() {}

    public static void load() {
        lastSave = System.nanoTime();
        if (!Files.isRegularFile(FILE)) return;
        try (var reader = Files.newBufferedReader(FILE)) {
            Saved value = GSON.fromJson(reader, Saved.class);
            if (value != null && Double.isFinite(value.seconds()) && value.seconds() >= 0) seconds = value.seconds();
        } catch (IOException | RuntimeException e) {
            LOG.warn("Could not read {}", FILE, e);
        }
    }

    private static void sample(long now, boolean loaded) {
        if (wasLoaded) seconds += Math.max(0, now - lastSample) / 1_000_000_000.0;
        lastSample = now;
        wasLoaded = loaded;
    }

    public static void tick(MinecraftClient client) {
        long now = System.nanoTime();
        sample(now, client.world != null);
        if (wasLoaded && now - lastSave >= SAVE_INTERVAL) save(now);
    }

    // Stop charging at the event, even when the preceding client tick has already ended.
    public static void finishSession() {
        long now = System.nanoTime();
        sample(now, false);
        save(now);
    }

    public static void apply() {
        long days = (long) FeatureSettings.number("playtime.days");
        long hours = (long) FeatureSettings.number("playtime.hours");
        long minutes = (long) FeatureSettings.number("playtime.minutes");
        replace(days * 86400L + hours * 3600L + minutes * 60L);
    }

    public static void reset() { replace(0); }

    private static void replace(long total) {
        long now = System.nanoTime();
        seconds = total;
        lastSample = now; // Do not add elapsed time from before the edit to the new total.
        wasLoaded = MinecraftClient.getInstance().world != null;
        save(now);
    }

    private static void save(long now) {
        lastSave = now;
        Path tmp = FILE.resolveSibling("playtime.json.tmp");
        try {
            Files.createDirectories(FILE.getParent());
            try (var writer = Files.newBufferedWriter(tmp)) { GSON.toJson(new Saved(seconds), writer); }
            try {
                Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Could not save {}", FILE, e);
        }
    }

    static String format(long seconds) {
        long days = seconds / 86400;
        long years = days / 365;
        days %= 365;
        long months = days / 30;
        return "Playtime: " + (years != 0 ? years + "Y, " : "") + (months != 0 ? months + "Mo, " : "")
                + days % 30 + "D, " + seconds / 3600 % 24 + "H, " + seconds / 60 % 60 + "M";
    }

    public static void render(MinecraftClient client, Screen screen, DrawContext context) {
        // Keep the display and autosave current even when the singleplayer world is paused.
        if (client.world != null) tick(client);
        if (!FeatureSettings.on("playtime.show")) return;
        String text = format((long) seconds);
        int w = client.textRenderer.getWidth(text) + 1, h = client.textRenderer.fontHeight + 1;
        if (w + 8 > screen.width) return;
        List<ClickableWidget> buttons = Screens.getButtons(screen);
        // Prefer the bottom center, then the side gutters. Never draw over a visible button.
        int[] columns = {(screen.width - w) / 2, 4, screen.width - w - 4};
        for (int x : columns) {
            for (int y = screen.height - h - 4; y >= 54; y--) {
                if (free(buttons, x, y, w, h)) {
                    context.drawTextWithShadow(client.textRenderer, text, x, y, 0xFFFFFFFF);
                    return;
                }
            }
        }
        // On a short viewport the strip between the top-left mod button and the vanilla
        // full pause screen title (y=40) may be the only free space.
        int y = 26;
        if (y + h <= 38 && y + h <= screen.height) {
            for (int x : columns) if (free(buttons, x, y, w, h)) {
                context.drawTextWithShadow(client.textRenderer, text, x, y, 0xFFFFFFFF);
                return;
            }
        }
    }

    private static boolean free(List<ClickableWidget> buttons, int x, int y, int w, int h) {
        for (ClickableWidget b : buttons) {
            if (b.visible && x < b.getX() + b.getWidth() + 2 && x + w + 2 > b.getX()
                    && y < b.getY() + b.getHeight() + 2 && y + h + 2 > b.getY()) return false;
        }
        return true;
    }
}
