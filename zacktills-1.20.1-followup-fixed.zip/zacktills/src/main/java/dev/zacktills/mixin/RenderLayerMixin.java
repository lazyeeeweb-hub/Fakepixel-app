package dev.zacktills.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.zacktills.feature.HudFeatures;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.RenderLayer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(RenderLayer.class)
public abstract class RenderLayerMixin {
    @Redirect(method = "draw", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/BufferRenderer;drawWithGlobalProgram(Lnet/minecraft/client/render/BufferBuilder$BuiltBuffer;)V"))
    private void zacktills$blendEditorItem(BufferBuilder.BuiltBuffer buffer) {
        if (!HudFeatures.isFadingItem()) {
            BufferRenderer.drawWithGlobalProgram(buffer);
            return;
        }
        // An opaque/cutout item layer can disable blending after the GUI sets its tint.
        // Apply the alpha at the actual draw, without affecting normal item/world rendering.
        boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
        int srcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB), dstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int srcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA), dstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        try {
            BufferRenderer.drawWithGlobalProgram(buffer);
        } finally {
            RenderSystem.blendFuncSeparate(srcRgb, dstRgb, srcAlpha, dstAlpha);
            if (!blend) RenderSystem.disableBlend();
        }
    }
}
