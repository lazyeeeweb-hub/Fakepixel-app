package dev.zacktills.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ClientPlayerInteractionManager.class)
public interface ClientPlayerInteractionManagerAccessor {
    @Accessor("currentBreakingPos")
    BlockPos zacktills$getCurrentBreakingPos();

    @Accessor("currentBreakingProgress")
    float zacktills$getCurrentBreakingProgress();

    @Accessor("breakingBlock")
    boolean zacktills$isBreakingBlock();

    @Accessor("blockBreakingCooldown")
    int zacktills$getBlockBreakingCooldown();

    @Accessor("blockBreakingCooldown")
    void zacktills$setBlockBreakingCooldown(int cooldown);

    @Accessor("selectedStack")
    ItemStack zacktills$getCurrentBreakingItem();

    @Invoker("isCurrentlyBreaking")
    boolean zacktills$invokeIsCurrentlyBreaking(BlockPos pos);
}
