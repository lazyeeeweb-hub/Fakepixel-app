package dev.zacktills.mixin;

import dev.zacktills.feature.ParticleBreaker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
abstract class ClientPlayerInteractionManagerMixin {
    /**
     * Vanilla calls cancelBlockBreaking() every tick while the attack key is up. That aborts our
     * break on the server (so the block pops back) while the client keeps predicting it. Same idea
     * as Meteor's onStopDestroyBlock: ignore that cancel while the aura is mining.
     */
    @Inject(method = "cancelBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void zacktills$keepAuraBreaking(CallbackInfo ci) {
        if (ParticleBreaker.blocksVanillaCancel()) ci.cancel();
    }

    @Inject(method = "isCurrentlyBreaking(Lnet/minecraft/util/math/BlockPos;)Z",
            at = @At("HEAD"), cancellable = true)
    private void zacktills$compareItemTypeOnly(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (!ParticleBreaker.isActive()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            cir.setReturnValue(false);
            return;
        }
        ClientPlayerInteractionManagerAccessor access = (ClientPlayerInteractionManagerAccessor) this;
        BlockPos activePos = access.zacktills$getCurrentBreakingPos();
        ItemStack activeStack = access.zacktills$getCurrentBreakingItem();
        ItemStack heldStack = client.player.getMainHandStack();
        cir.setReturnValue(activePos != null && activePos.equals(pos)
                && activeStack != null && heldStack != null
                && activeStack.getItem() == heldStack.getItem());
    }
}
