package dev.zacktills.mixin;

import dev.zacktills.feature.ParticleEsp;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
abstract class ParticleNetworkMixin {
    @Inject(method = "onParticle(Lnet/minecraft/network/packet/s2c/play/ParticleS2CPacket;)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/util/thread/ThreadExecutor;)V",
                    shift = At.Shift.AFTER))
    private void particleEsp$beginCapture(ParticleS2CPacket packet, CallbackInfo ci) {
        ParticleEsp.beginPacketCapture(packet);
    }

    @ModifyArgs(method = "onParticle(Lnet/minecraft/network/packet/s2c/play/ParticleS2CPacket;)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/world/ClientWorld;addParticle(Lnet/minecraft/particle/ParticleEffect;ZDDDDDD)V"))
    private void particleEsp$observeVanillaSpawn(Args args) {
        ParticleEsp.observeVanillaParticle((Double) args.get(2), (Double) args.get(3), (Double) args.get(4));
    }

    @Inject(method = "onParticle(Lnet/minecraft/network/packet/s2c/play/ParticleS2CPacket;)V", at = @At("TAIL"))
    private void particleEsp$finishCapture(ParticleS2CPacket packet, CallbackInfo ci) {
        ParticleEsp.onParticle(packet);
    }
}
