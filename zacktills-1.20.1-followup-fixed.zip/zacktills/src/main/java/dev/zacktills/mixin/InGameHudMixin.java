package dev.zacktills.mixin;

import dev.zacktills.config.FeatureSettings;
import dev.zacktills.feature.HudFeatures;
import dev.zacktills.feature.TabParts;
import dev.zacktills.ui.HudEditorScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void zacktills$hotbar(float tickDelta, DrawContext c, CallbackInfo ci) {
        var mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof HudEditorScreen) { ci.cancel(); return; }
        if (FeatureSettings.on("hud.enabled") && mc.player != null && !mc.player.isSpectator()) {
            HudFeatures.hotbar(c);
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void zacktills$scoreboard(DrawContext c, ScoreboardObjective objective, CallbackInfo ci) {
        if (MinecraftClient.getInstance().currentScreen instanceof HudEditorScreen) { ci.cancel(); return; }
        if (FeatureSettings.on("scoreboard.enabled")) {
            HudFeatures.scoreboard(c, objective);
            ci.cancel();
        }
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void zacktills$crosshair(DrawContext c, CallbackInfo ci) {
        var mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof HudEditorScreen) { ci.cancel(); return; }
        if (!FeatureSettings.on("tooltip.crosshair") || mc.player == null || mc.player.isSpectator()) return;
        HudFeatures.crosshair(c, 1);
        ci.cancel();
    }

    @Redirect(method = "render", slice = @Slice(from = @At(value = "FIELD",
            target = "Lnet/minecraft/client/option/GameOptions;playerListKey:Lnet/minecraft/client/option/KeyBinding;")),
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;isPressed()Z", ordinal = 0))
    private boolean zacktills$tabKey(KeyBinding binding) {
        var mc = MinecraftClient.getInstance();
        return binding.isPressed() || (binding == mc.options.playerListKey && TabParts.showVanillaTab());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void zacktills$tabParts(DrawContext context, float tickDelta, CallbackInfo ci) {
        var mc = MinecraftClient.getInstance();
        TabParts.render(context, mc.inGameHud.getPlayerListHud());
    }
}
