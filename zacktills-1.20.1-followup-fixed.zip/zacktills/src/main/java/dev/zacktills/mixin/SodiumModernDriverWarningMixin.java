package dev.zacktills.mixin;

import dev.zacktills.config.FeatureSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Optional hook for the relocated driver check in newer Sodium 0.5.x releases. */
@Pseudo
@Mixin(targets = "net.caffeinemc.mods.sodium.client.compatibility.checks.GraphicsDriverChecks", remap = false)
public abstract class SodiumModernDriverWarningMixin {
    @Inject(method = "postContextInit(Lnet/caffeinemc/mods/sodium/client/platform/NativeWindowHandle;Lnet/caffeinemc/mods/sodium/client/compatibility/environment/GlContextInfo;)V", at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private static void zacktills$hideDriverWarning(CallbackInfo ci) {
        if (FeatureSettings.on("interface.sodiumDriverWarning")) ci.cancel();
    }
}
