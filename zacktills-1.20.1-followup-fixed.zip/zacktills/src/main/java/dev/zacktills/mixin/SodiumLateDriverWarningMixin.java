package dev.zacktills.mixin;

import dev.zacktills.config.FeatureSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Optional Sodium 0.5.x hook for context-time driver compatibility warnings. */
@Pseudo
@Mixin(targets = "me.jellysquid.mods.sodium.client.compatibility.checks.LateDriverScanner", remap = false)
public abstract class SodiumLateDriverWarningMixin {
    @Inject(method = "onContextInitialized()V", at = @At("HEAD"), cancellable = true, require = 0, remap = false)
    private static void zacktills$hideDriverWarning(CallbackInfo ci) {
        if (FeatureSettings.on("interface.sodiumDriverWarning")) ci.cancel();
    }
}
