package dev.zacktills.ui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A self-contained, file-backed whiteboard screen for Minecraft 1.20.1 (Yarn).
 * Board files are stored in config/zacktills/boards as bounded JSON documents.
 */
public final class WhiteboardScreen extends Screen {
    private static final int CANVAS_TOP = 78;
    private static final int MAX_FILE_BYTES = 1_048_576;
    private static final int MAX_OBJECTS = 500;
    private static final int MAX_POINTS_PER_OBJECT = 2_000;
    private static final int MAX_TOTAL_POINTS = 20_000;
    private static final int MAX_TEXT_CHARS = 2_048;
    private static final int MAX_HISTORY = 50;
    private static final int BACKGROUND_COLOR = 0xFF111821;
    private static final int GRID_COLOR = 0xFF26323F;
    private static final int GRID_MAJOR_COLOR = 0xFF344252;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private final Screen parent;
    private final ArrayList<BoardObject> objects = new ArrayList<>();
    private final ArrayDeque<List<BoardObject>> undoStack = new ArrayDeque<>();
    private final ArrayDeque<List<BoardObject>> redoStack = new ArrayDeque<>();

    private TextFieldWidget filenameField;
    private TextFieldWidget textEntryField;
    private ButtonWidget[] toolButtons = new ButtonWidget[4];
    private Tool activeTool = Tool.PEN;
    private DragMode dragMode = DragMode.NONE;
    private String statusText = "Ready";
    private String lastError = "";
    private String currentFilename = "whiteboard";
    private boolean dirty;
    private boolean spaceDown;
    private boolean moveHistoryCaptured;
    private int selectedIndex = -1;
    private int dragObjectIndex = -1;
    private double zoom = 1.0;
    private double cameraX;
    private double cameraY;
    private double moveStartWorldX;
    private double moveStartWorldY;
    private BoardObject moveStartObject;
    private int drawObjectIndex = -1;

    public WhiteboardScreen(Screen parent) {
        super(Text.literal("Whiteboard"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.clearChildren();
        int gap = 3;
        int buttonWidth = 42;
        int rowY = 6;
        int rightButtonsWidth = buttonWidth * 3 + gap * 3;
        int filenameWidth = Math.max(40, this.width - 16 - rightButtonsWidth);

        this.filenameField = this.addDrawableChild(new TextFieldWidget(
                this.textRenderer, 8, rowY, filenameWidth, 20, Text.literal("Board filename")));
        this.filenameField.setMaxLength(96);
        this.filenameField.setPlaceholder(Text.literal("Board filename"));
        this.filenameField.setText(this.currentFilename);

        int x = 8 + filenameWidth + gap;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save"), button -> this.saveBoard())
                .dimensions(x, rowY, buttonWidth, 20).build());
        x += buttonWidth + gap;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Load"), button -> this.loadBoard())
                .dimensions(x, rowY, buttonWidth, 20).build());
        x += buttonWidth + gap;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("New"), button -> this.newBoard())
                .dimensions(x, rowY, buttonWidth, 20).build());

        int toolY = 30;
        int available = Math.max(6 * 28, this.width - 16 - 5 * gap);
        int toolWidth = Math.min(58, available / 6);
        int toolX = 8;
        this.toolButtons = new ButtonWidget[4];
        this.toolButtons[0] = this.addDrawableChild(ButtonWidget.builder(Text.literal("Text"), button -> this.setTool(Tool.TEXT))
                .dimensions(toolX, toolY, toolWidth, 20).build());
        toolX += toolWidth + gap;
        this.toolButtons[1] = this.addDrawableChild(ButtonWidget.builder(Text.literal("Arrow"), button -> this.setTool(Tool.ARROW))
                .dimensions(toolX, toolY, toolWidth, 20).build());
        toolX += toolWidth + gap;
        this.toolButtons[2] = this.addDrawableChild(ButtonWidget.builder(Text.literal("Pen"), button -> this.setTool(Tool.PEN))
                .dimensions(toolX, toolY, toolWidth, 20).build());
        toolX += toolWidth + gap;
        this.toolButtons[3] = this.addDrawableChild(ButtonWidget.builder(Text.literal("Move"), button -> this.setTool(Tool.MOVE))
                .dimensions(toolX, toolY, toolWidth, 20).build());
        toolX += toolWidth + gap;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Undo"), button -> this.undo())
                .dimensions(toolX, toolY, toolWidth, 20).build());
        toolX += toolWidth + gap;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Redo"), button -> this.redo())
                .dimensions(toolX, toolY, toolWidth, 20).build());

        this.textEntryField = this.addDrawableChild(new TextFieldWidget(
                this.textRenderer, 8, 54, Math.max(40, this.width - 16), 20, Text.literal("Text to place")));
        this.textEntryField.setMaxLength(MAX_TEXT_CHARS);
        this.textEntryField.setPlaceholder(Text.literal("Type text, then choose Text and click the canvas"));
        this.updateToolButtonLabels();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xFF202832);
        context.fill(0, CANVAS_TOP, this.width, this.height, BACKGROUND_COLOR);
        this.renderGrid(context);

        if (this.height > CANVAS_TOP) {
            context.enableScissor(0, CANVAS_TOP, this.width, this.height);
            int[] drawBudget = new int[]{8_000};
            for (int i = 0; i < this.objects.size() && drawBudget[0] > 0; i++) {
                this.renderObject(context, this.objects.get(i), drawBudget);
            }
            if (this.selectedIndex >= 0 && this.selectedIndex < this.objects.size() && drawBudget[0] > 0) {
                this.renderSelection(context, this.objects.get(this.selectedIndex), drawBudget);
            }
            context.disableScissor();
        }

        String status = this.lastError.isEmpty() ? this.statusText : this.lastError;
        String suffix = "  |  " + Math.round(this.zoom * 100.0) + "%" + (this.dirty ? "  |  unsaved" : "");
        context.enableScissor(0, CANVAS_TOP, this.width, this.height);
        context.drawText(this.textRenderer, status + suffix, 8, Math.max(CANVAS_TOP + 2, this.height - 13),
                this.lastError.isEmpty() ? 0xFFE0E6ED : 0xFFFF8585, true);
        context.disableScissor();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Screen.render invokes renderBackground first, then renders child widgets on top.
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (!this.isInsideCanvas(mouseX, mouseY)) {
            return false;
        }

        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT || (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && this.spaceDown)) {
            this.dragMode = DragMode.PAN;
            return true;
        }
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return false;
        }

        double worldX = this.worldX(mouseX);
        double worldY = this.worldY(mouseY);
        if (!Double.isFinite(worldX) || !Double.isFinite(worldY)) {
            this.setError("Cannot edit at a non-finite canvas position.");
            return true;
        }

        switch (this.activeTool) {
            case TEXT -> this.placeText(worldX, worldY);
            case PEN -> this.beginDrawing("PEN", worldX, worldY);
            case ARROW -> this.beginDrawing("ARROW", worldX, worldY);
            case MOVE -> this.beginMove(mouseX, mouseY, worldX, worldY);
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.dragMode == DragMode.PAN) {
            this.cameraX -= deltaX / this.zoom;
            this.cameraY -= deltaY / this.zoom;
            return true;
        }
        if (this.dragMode == DragMode.DRAW_PEN || this.dragMode == DragMode.DRAW_ARROW) {
            if (this.drawObjectIndex < 0 || this.drawObjectIndex >= this.objects.size()) {
                return true;
            }
            BoardObject object = this.objects.get(this.drawObjectIndex);
            double x = this.worldX(mouseX);
            double y = this.worldY(mouseY);
            if (!Double.isFinite(x) || !Double.isFinite(y)) {
                return true;
            }
            if (this.dragMode == DragMode.DRAW_ARROW) {
                object.points.set(1, new Point(x, y));
            } else if (object.points.size() < MAX_POINTS_PER_OBJECT) {
                Point last = object.points.get(object.points.size() - 1);
                if (Math.hypot(x - last.x, y - last.y) >= 1.5 / this.zoom) {
                    int totalPoints = this.totalPointCount();
                    if (totalPoints < MAX_TOTAL_POINTS) {
                        object.points.add(new Point(x, y));
                        this.dirty = true;
                    } else {
                        this.setError("Drawing stopped: board point limit reached.");
                    }
                }
            } else {
                this.setError("Drawing stopped: per-stroke point limit reached.");
            }
            return true;
        }
        if (this.dragMode == DragMode.MOVE_OBJECT && this.dragObjectIndex >= 0
                && this.dragObjectIndex < this.objects.size() && this.moveStartObject != null) {
            double x = this.worldX(mouseX);
            double y = this.worldY(mouseY);
            if (!Double.isFinite(x) || !Double.isFinite(y)) {
                return true;
            }
            double dx = x - this.moveStartWorldX;
            double dy = y - this.moveStartWorldY;
            if (Math.hypot(dx, dy) < 1.0e-9) {
                return true;
            }
            if (!this.moveHistoryCaptured) {
                this.pushUndoSnapshot();
                this.moveHistoryCaptured = true;
            }
            BoardObject moved = this.moveStartObject.copy();
            for (int i = 0; i < moved.points.size(); i++) {
                Point original = this.moveStartObject.points.get(i);
                moved.points.set(i, new Point(original.x + dx, original.y + dy));
            }
            this.objects.set(this.dragObjectIndex, moved);
            this.dirty = true;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseReleased(mouseX, mouseY, button);
        boolean hadDrag = this.dragMode != DragMode.NONE;
        this.dragMode = DragMode.NONE;
        this.drawObjectIndex = -1;
        this.dragObjectIndex = -1;
        this.moveStartObject = null;
        this.moveHistoryCaptured = false;
        return handled || hadDrag;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!this.isInsideCanvas(mouseX, mouseY)) {
            return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        if (verticalAmount == 0.0) {
            return true;
        }
        double anchorX = this.worldX(mouseX);
        double anchorY = this.worldY(mouseY);
        double newZoom = Math.max(0.20, Math.min(5.0, this.zoom * Math.pow(1.10, verticalAmount)));
        this.zoom = newZoom;
        this.cameraX = anchorX - (mouseX - this.width / 2.0) / this.zoom;
        this.cameraY = anchorY - (mouseY - this.canvasCenterY()) / this.zoom;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_SPACE) {
            this.spaceDown = true;
        }
        boolean textFieldFocused = this.isTextFieldFocused();
        boolean controlDown = (modifiers & GLFW.GLFW_MOD_CONTROL) != 0
                || keyCode == GLFW.GLFW_KEY_LEFT_CONTROL || keyCode == GLFW.GLFW_KEY_RIGHT_CONTROL;
        boolean shiftDown = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
        if (!textFieldFocused && controlDown && keyCode == GLFW.GLFW_KEY_Z) {
            if (shiftDown) this.redo(); else this.undo();
            return true;
        }
        if (!textFieldFocused && controlDown && keyCode == GLFW.GLFW_KEY_Y) {
            this.redo();
            return true;
        }
        if (!textFieldFocused && (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE)) {
            this.deleteSelection();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_SPACE) {
            this.spaceDown = false;
        }
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        if (this.dirty && !this.saveBoard()) {
            // Keep the screen and document open so the user can see and address the save error.
            return;
        }
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private void renderGrid(DrawContext context) {
        if (this.height <= CANVAS_TOP || this.width <= 0 || this.zoom <= 0.0) {
            return;
        }
        double worldStep = 32.0;
        while (worldStep * this.zoom < 16.0) worldStep *= 2.0;
        while (worldStep * this.zoom > 128.0) worldStep /= 2.0;

        double leftWorld = this.cameraX - (this.width / 2.0) / this.zoom;
        double rightWorld = this.cameraX + (this.width / 2.0) / this.zoom;
        double topWorld = this.cameraY - (this.canvasCenterY() - CANVAS_TOP) / this.zoom;
        double bottomWorld = this.cameraY + (this.height - this.canvasCenterY()) / this.zoom;
        if (!Double.isFinite(leftWorld) || !Double.isFinite(rightWorld)
                || !Double.isFinite(topWorld) || !Double.isFinite(bottomWorld)
                || Math.max(Math.max(Math.abs(leftWorld), Math.abs(rightWorld)),
                Math.max(Math.abs(topWorld), Math.abs(bottomWorld))) > 1.0e15) {
            return;
        }

        double firstX = Math.ceil(leftWorld / worldStep) * worldStep;
        for (int i = 0; i < 600; i++) {
            double world = firstX + i * worldStep;
            double sxValue = this.screenX(world);
            if (sxValue > this.width) break;
            if (sxValue < 0 || !Double.isFinite(sxValue)) continue;
            int sx = (int) Math.round(sxValue);
            double gridIndex = Math.rint(world / worldStep);
            int color = Math.abs(world) < worldStep * 0.0001 ? 0xFF536273
                    : (Math.floorMod((long) gridIndex, 4L) == 0L ? GRID_MAJOR_COLOR : GRID_COLOR);
            context.fill(sx, CANVAS_TOP, sx + 1, this.height, color);
        }

        double firstY = Math.ceil(topWorld / worldStep) * worldStep;
        for (int i = 0; i < 600; i++) {
            double world = firstY + i * worldStep;
            double syValue = this.screenY(world);
            if (syValue > this.height) break;
            if (syValue < CANVAS_TOP || !Double.isFinite(syValue)) continue;
            int sy = (int) Math.round(syValue);
            double gridIndex = Math.rint(world / worldStep);
            int color = Math.abs(world) < worldStep * 0.0001 ? 0xFF536273
                    : (Math.floorMod((long) gridIndex, 4L) == 0L ? GRID_MAJOR_COLOR : GRID_COLOR);
            context.fill(0, sy, this.width, sy + 1, color);
        }
    }

    private void renderObject(DrawContext context, BoardObject object, int[] budget) {
        if (object.points.isEmpty() || budget[0] <= 0) return;
        if ("TEXT".equals(object.type)) {
            Point p = object.points.get(0);
            double sx = this.screenX(p.x);
            double sy = this.screenY(p.y);
            if (!this.isDrawableCoordinate(sx, sy)) return;
            String[] lines = object.text.split("\\R", -1);
            int lineY = (int) Math.round(sy);
            for (int i = 0; i < lines.length && i < 64 && budget[0] > 0; i++) {
                context.drawText(this.textRenderer, lines[i], (int) Math.round(sx), lineY + i * 10,
                        object.color, true);
                budget[0]--;
            }
            return;
        }
        if ("PEN".equals(object.type)) {
            if (object.points.size() == 1) {
                double x = this.screenX(object.points.get(0).x);
                double y = this.screenY(object.points.get(0).y);
                this.drawDot(context, x, y, object.color, budget);
            } else {
                for (int i = 1; i < object.points.size() && budget[0] > 0; i++) {
                    Point a = object.points.get(i - 1);
                    Point b = object.points.get(i);
                    this.drawSegment(context, this.screenX(a.x), this.screenY(a.y),
                            this.screenX(b.x), this.screenY(b.y), object.color, budget);
                }
            }
        } else if ("ARROW".equals(object.type) && object.points.size() >= 2) {
            Point a = object.points.get(0);
            Point b = object.points.get(1);
            double x1 = this.screenX(a.x), y1 = this.screenY(a.y);
            double x2 = this.screenX(b.x), y2 = this.screenY(b.y);
            this.drawSegment(context, x1, y1, x2, y2, object.color, budget);
            double dx = x2 - x1, dy = y2 - y1;
            double length = Math.hypot(dx, dy);
            if (length > 1.0 && Double.isFinite(length) && budget[0] > 0) {
                double ux = dx / length, uy = dy / length;
                double baseX = x2 - ux * 10.0, baseY = y2 - uy * 10.0;
                double wing = 5.0;
                this.drawSegment(context, x2, y2, baseX - uy * wing, baseY + ux * wing, object.color, budget);
                this.drawSegment(context, x2, y2, baseX + uy * wing, baseY - ux * wing, object.color, budget);
            }
        }
    }

    private void renderSelection(DrawContext context, BoardObject object, int[] budget) {
        if (object.points.isEmpty() || budget[0] <= 0) return;
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
        for (Point point : object.points) {
            double x = this.screenX(point.x), y = this.screenY(point.y);
            if (!this.isDrawableCoordinate(x, y)) continue;
            minX = Math.min(minX, x); minY = Math.min(minY, y);
            maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
        }
        if ("TEXT".equals(object.type)) {
            Point point = object.points.get(0);
            double x = this.screenX(point.x), y = this.screenY(point.y);
            if (this.isDrawableCoordinate(x, y)) {
                minX = Math.min(minX, x); minY = Math.min(minY, y);
                maxX = Math.max(maxX, x + Math.min(this.textRenderer.getWidth(object.text), this.width));
                maxY = Math.max(maxY, y + 10.0 * Math.max(1, object.text.split("\\R", -1).length));
            }
        }
        if (!Double.isFinite(minX) || !Double.isFinite(minY) || !Double.isFinite(maxX) || !Double.isFinite(maxY)) return;
        int left = clampScreen(minX - 4), top = clampScreen(minY - 4);
        int right = clampScreen(maxX + 4), bottom = clampScreen(maxY + 4);
        int color = 0xFF55D6E8;
        context.fill(left, top, right, top + 1, color);
        context.fill(left, bottom - 1, right, bottom, color);
        context.fill(left, top, left + 1, bottom, color);
        context.fill(right - 1, top, right, bottom, color);
        budget[0] = Math.max(0, budget[0] - 4);
    }

    private void drawDot(DrawContext context, double x, double y, int color, int[] budget) {
        if (budget[0] <= 0 || !this.isDrawableCoordinate(x, y)) return;
        int ix = (int) Math.round(x), iy = (int) Math.round(y);
        context.fill(ix - 1, iy - 1, ix + 2, iy + 2, color);
        budget[0]--;
    }

    private void drawSegment(DrawContext context, double x1, double y1, double x2, double y2, int color, int[] budget) {
        if (budget[0] <= 0 || !this.isDrawableCoordinate(x1, y1) || !this.isDrawableCoordinate(x2, y2)) return;
        double distance = Math.hypot(x2 - x1, y2 - y1);
        if (!Double.isFinite(distance)) return;
        int steps = Math.max(1, Math.min(256, (int) Math.min(256.0, Math.ceil(distance))));
        steps = Math.min(steps, Math.max(1, budget[0]));
        for (int i = 0; i <= steps && budget[0] > 0; i++) {
            double t = (double) i / steps;
            int x = (int) Math.round(x1 + (x2 - x1) * t);
            int y = (int) Math.round(y1 + (y2 - y1) * t);
            context.fill(x - 1, y - 1, x + 2, y + 2, color);
            budget[0]--;
        }
    }

    private void placeText(double worldX, double worldY) {
        String text = this.textEntryField == null ? "" : this.textEntryField.getText();
        if (text == null || text.isBlank()) {
            this.statusText = "Enter text in the field above, then click the canvas.";
            return;
        }
        if (text.length() > MAX_TEXT_CHARS) {
            this.setError("Text exceeds the " + MAX_TEXT_CHARS + " character limit.");
            return;
        }
        if (this.objects.size() >= MAX_OBJECTS || this.totalPointCount() >= MAX_TOTAL_POINTS) {
            this.setError("Cannot add text: board object/point limit reached.");
            return;
        }
        this.pushUndoSnapshot();
        BoardObject object = new BoardObject("TEXT", 0xFFFFE08A, text);
        object.points.add(new Point(worldX, worldY));
        this.objects.add(object);
        this.selectedIndex = this.objects.size() - 1;
        this.dirty = true;
        this.statusText = "Text added";
    }

    private void beginDrawing(String type, double worldX, double worldY) {
        if (this.objects.size() >= MAX_OBJECTS || this.totalPointCount() + ("ARROW".equals(type) ? 2 : 1) > MAX_TOTAL_POINTS) {
            this.setError("Cannot draw: board object/point limit reached.");
            return;
        }
        this.pushUndoSnapshot();
        int color = "ARROW".equals(type) ? 0xFFFFA45B : 0xFFF2F5F8;
        BoardObject object = new BoardObject(type, color, "");
        object.points.add(new Point(worldX, worldY));
        if ("ARROW".equals(type)) object.points.add(new Point(worldX, worldY));
        this.objects.add(object);
        this.drawObjectIndex = this.objects.size() - 1;
        this.selectedIndex = this.drawObjectIndex;
        this.dragMode = "ARROW".equals(type) ? DragMode.DRAW_ARROW : DragMode.DRAW_PEN;
        this.dirty = true;
    }

    private void beginMove(double mouseX, double mouseY, double worldX, double worldY) {
        int hit = this.hitTest(mouseX, mouseY);
        this.selectedIndex = hit;
        if (hit < 0) {
            this.dragMode = DragMode.NONE;
            this.statusText = "No object selected";
            return;
        }
        this.dragObjectIndex = hit;
        this.moveStartWorldX = worldX;
        this.moveStartWorldY = worldY;
        this.moveStartObject = this.objects.get(hit).copy();
        this.moveHistoryCaptured = false;
        this.dragMode = DragMode.MOVE_OBJECT;
    }

    private int hitTest(double mouseX, double mouseY) {
        for (int i = this.objects.size() - 1; i >= 0; i--) {
            BoardObject object = this.objects.get(i);
            if (this.hitObject(object, mouseX, mouseY)) return i;
        }
        return -1;
    }

    private boolean hitObject(BoardObject object, double x, double y) {
        if (object.points.isEmpty()) return false;
        if ("TEXT".equals(object.type)) {
            Point p = object.points.get(0);
            double sx = this.screenX(p.x), sy = this.screenY(p.y);
            if (!Double.isFinite(sx) || !Double.isFinite(sy)) return false;
            String[] lines = object.text.split("\\R", -1);
            for (int i = 0; i < lines.length && i < 64; i++) {
                double lineY = sy + i * 10.0;
                if (x >= sx - 4 && x <= sx + Math.max(8, this.textRenderer.getWidth(lines[i])) + 4
                        && y >= lineY - 4 && y <= lineY + 12) return true;
            }
            return false;
        }
        if ("PEN".equals(object.type)) {
            if (object.points.size() == 1) {
                Point p = object.points.get(0);
                return Math.hypot(x - this.screenX(p.x), y - this.screenY(p.y)) <= 8.0;
            }
            for (int i = 1; i < object.points.size(); i++) {
                Point a = object.points.get(i - 1), b = object.points.get(i);
                if (distanceToSegment(x, y, this.screenX(a.x), this.screenY(a.y),
                        this.screenX(b.x), this.screenY(b.y)) <= 8.0) return true;
            }
            return false;
        }
        if ("ARROW".equals(object.type) && object.points.size() >= 2) {
            Point a = object.points.get(0), b = object.points.get(1);
            return distanceToSegment(x, y, this.screenX(a.x), this.screenY(a.y),
                    this.screenX(b.x), this.screenY(b.y)) <= 9.0;
        }
        return false;
    }

    private void deleteSelection() {
        if (this.selectedIndex < 0 || this.selectedIndex >= this.objects.size()) return;
        this.pushUndoSnapshot();
        this.objects.remove(this.selectedIndex);
        this.selectedIndex = -1;
        this.dirty = true;
        this.statusText = "Selection deleted";
    }

    private void undo() {
        if (this.undoStack.isEmpty()) {
            this.statusText = "Nothing to undo";
            return;
        }
        this.redoStack.push(copyBoard(this.objects));
        replaceBoard(this.objects, this.undoStack.pop());
        this.selectedIndex = -1;
        this.dirty = true;
        this.statusText = "Undo";
    }

    private void redo() {
        if (this.redoStack.isEmpty()) {
            this.statusText = "Nothing to redo";
            return;
        }
        this.undoStack.push(copyBoard(this.objects));
        trimHistory(this.undoStack);
        replaceBoard(this.objects, this.redoStack.pop());
        this.selectedIndex = -1;
        this.dirty = true;
        this.statusText = "Redo";
    }

    private void pushUndoSnapshot() {
        this.undoStack.push(copyBoard(this.objects));
        trimHistory(this.undoStack);
        this.redoStack.clear();
    }

    private static void trimHistory(ArrayDeque<List<BoardObject>> stack) {
        while (stack.size() > MAX_HISTORY) stack.removeLast();
    }

    private void newBoard() {
        this.pushUndoSnapshot();
        this.objects.clear();
        this.selectedIndex = -1;
        this.dirty = true;
        this.statusText = "New board — save or close to autosave";
    }

    private boolean saveBoard() {
        String sanitized = sanitizeFilename(this.filenameField == null ? this.currentFilename : this.filenameField.getText());
        if (sanitized == null) {
            this.setError("Save failed: enter a usable filename (letters, numbers, spaces, _ or -). ");
            return false;
        }
        this.currentFilename = sanitized;
        if (this.filenameField != null) this.filenameField.setText(sanitized);
        String validationError = this.validateBoard(this.objects);
        if (validationError != null) {
            this.setError("Save failed: " + validationError);
            return false;
        }

        Path temp = null;
        try {
            Path directory = boardDirectory();
            Files.createDirectories(directory);
            Path target = safeBoardPath(directory, sanitized);
            JsonObject root = new JsonObject();
            root.addProperty("version", 1);
            JsonArray array = new JsonArray();
            for (BoardObject object : this.objects) array.add(this.objectToJson(object));
            root.add("objects", array);
            byte[] bytes = GSON.toJson(root).getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_FILE_BYTES) {
                this.setError("Save failed: JSON would exceed the " + MAX_FILE_BYTES + " byte file limit.");
                return false;
            }
            temp = Files.createTempFile(directory, sanitized + "-", ".tmp");
            Files.write(temp, bytes, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            try {
                Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
            this.dirty = false;
            this.lastError = "";
            this.statusText = "Saved " + sanitized + ".json";
            return true;
        } catch (Exception exception) {
            if (temp != null) {
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException cleanupException) {
                    exception.addSuppressed(cleanupException);
                }
            }
            this.setError("Save failed: " + messageOf(exception));
            return false;
        }
    }

    private boolean loadBoard() {
        String sanitized = sanitizeFilename(this.filenameField == null ? this.currentFilename : this.filenameField.getText());
        if (sanitized == null) {
            this.setError("Load failed: enter a usable filename (letters, numbers, spaces, _ or -).");
            return false;
        }
        this.currentFilename = sanitized;
        if (this.filenameField != null) this.filenameField.setText(sanitized);
        try {
            Path directory = boardDirectory();
            Path file = safeBoardPath(directory, sanitized);
            long size = Files.size(file);
            if (size > MAX_FILE_BYTES) {
                this.setError("Load failed: file exceeds the " + MAX_FILE_BYTES + " byte size limit.");
                return false;
            }
            byte[] bytes = Files.readAllBytes(file);
            if (bytes.length > MAX_FILE_BYTES) {
                this.setError("Load failed: file exceeds the " + MAX_FILE_BYTES + " byte size limit.");
                return false;
            }
            String json;
            try {
                json = StandardCharsets.UTF_8.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(bytes)).toString();
            } catch (CharacterCodingException exception) {
                this.setError("Load failed: file is not valid UTF-8.");
                return false;
            }
            JsonElement parsed = JsonParser.parseString(json);
            if (!parsed.isJsonObject()) throw new IllegalArgumentException("root must be a JSON object");
            JsonObject root = parsed.getAsJsonObject();
            JsonElement versionElement = root.get("version");
            if (!isNumeric(versionElement) || versionElement.getAsInt() != 1) {
                throw new IllegalArgumentException("unsupported or missing board version");
            }
            JsonElement objectsElement = root.get("objects");
            if (objectsElement == null || !objectsElement.isJsonArray()) {
                throw new IllegalArgumentException("objects must be an array");
            }
            JsonArray array = objectsElement.getAsJsonArray();
            if (array.size() > MAX_OBJECTS) throw new IllegalArgumentException("object count exceeds limit");
            ArrayList<BoardObject> loaded = new ArrayList<>(array.size());
            int totalPoints = 0;
            for (JsonElement element : array) {
                if (!element.isJsonObject()) throw new IllegalArgumentException("each object must be a JSON object");
                JsonObject objectJson = element.getAsJsonObject();
                JsonElement typeElement = objectJson.get("type");
                if (typeElement == null || !typeElement.isJsonPrimitive() || !typeElement.getAsJsonPrimitive().isString()) {
                    throw new IllegalArgumentException("object type must be a string");
                }
                String type = typeElement.getAsString();
                if (!"TEXT".equals(type) && !"ARROW".equals(type) && !"PEN".equals(type)) {
                    throw new IllegalArgumentException("unknown object type: " + type);
                }
                JsonElement colorElement = objectJson.get("color");
                if (!isNumeric(colorElement)) throw new IllegalArgumentException("object color must be an integer");
                int color = colorElement.getAsInt();
                JsonElement pointsElement = objectJson.get("points");
                if (pointsElement == null || !pointsElement.isJsonArray()) {
                    throw new IllegalArgumentException("object points must be an array");
                }
                JsonArray pointsArray = pointsElement.getAsJsonArray();
                if (pointsArray.size() > MAX_POINTS_PER_OBJECT) {
                    throw new IllegalArgumentException("per-object point count exceeds limit");
                }
                if ("TEXT".equals(type) && pointsArray.size() != 1) {
                    throw new IllegalArgumentException("text objects must have exactly one point");
                }
                if ("ARROW".equals(type) && pointsArray.size() != 2) {
                    throw new IllegalArgumentException("arrows must have exactly two points");
                }
                if ("PEN".equals(type) && pointsArray.isEmpty()) {
                    throw new IllegalArgumentException("pen strokes must have at least one point");
                }
                BoardObject object = new BoardObject(type, color, "");
                for (JsonElement pointElement : pointsArray) {
                    if (!pointElement.isJsonObject()) throw new IllegalArgumentException("point must be a JSON object");
                    JsonObject pointJson = pointElement.getAsJsonObject();
                    JsonElement xElement = pointJson.get("x"), yElement = pointJson.get("y");
                    if (!isNumeric(xElement) || !isNumeric(yElement)) {
                        throw new IllegalArgumentException("point coordinates must be numbers");
                    }
                    double x = xElement.getAsDouble(), y = yElement.getAsDouble();
                    if (!Double.isFinite(x) || !Double.isFinite(y)) {
                        throw new IllegalArgumentException("point coordinates must be finite");
                    }
                    object.points.add(new Point(x, y));
                }
                totalPoints += object.points.size();
                if (totalPoints > MAX_TOTAL_POINTS) throw new IllegalArgumentException("total point count exceeds limit");
                if ("TEXT".equals(type)) {
                    JsonElement textElement = objectJson.get("text");
                    if (textElement == null || !textElement.isJsonPrimitive() || !textElement.getAsJsonPrimitive().isString()) {
                        throw new IllegalArgumentException("text object content must be a string");
                    }
                    object.text = textElement.getAsString();
                    if (object.text.length() > MAX_TEXT_CHARS) throw new IllegalArgumentException("text exceeds character limit");
                }
                loaded.add(object);
            }

            replaceBoard(this.objects, loaded);
            this.undoStack.clear();
            this.redoStack.clear();
            this.selectedIndex = -1;
            this.dirty = false;
            this.lastError = "";
            this.statusText = "Loaded " + sanitized + ".json";
            return true;
        } catch (Exception exception) {
            this.setError("Load failed: " + messageOf(exception));
            return false;
        }
    }

    private JsonObject objectToJson(BoardObject object) {
        JsonObject json = new JsonObject();
        json.addProperty("type", object.type);
        json.addProperty("color", object.color);
        JsonArray points = new JsonArray();
        for (Point point : object.points) {
            JsonObject pointJson = new JsonObject();
            pointJson.addProperty("x", point.x);
            pointJson.addProperty("y", point.y);
            points.add(pointJson);
        }
        json.add("points", points);
        if ("TEXT".equals(object.type)) json.addProperty("text", object.text);
        return json;
    }

    private String validateBoard(List<BoardObject> board) {
        if (board.size() > MAX_OBJECTS) return "object count exceeds limit";
        int totalPoints = 0;
        for (BoardObject object : board) {
            if (!"TEXT".equals(object.type) && !"ARROW".equals(object.type) && !"PEN".equals(object.type)) {
                return "unknown object type";
            }
            if (object.points.size() > MAX_POINTS_PER_OBJECT) return "per-object point count exceeds limit";
            if (("TEXT".equals(object.type) && object.points.size() != 1)
                    || ("ARROW".equals(object.type) && object.points.size() != 2)
                    || ("PEN".equals(object.type) && object.points.isEmpty())) return "invalid point count";
            totalPoints += object.points.size();
            if (totalPoints > MAX_TOTAL_POINTS) return "total point count exceeds limit";
            for (Point point : object.points) {
                if (!Double.isFinite(point.x) || !Double.isFinite(point.y)) return "coordinates must be finite";
            }
            if ("TEXT".equals(object.type) && (object.text == null || object.text.length() > MAX_TEXT_CHARS)) {
                return "text exceeds character limit or is missing";
            }
        }
        return null;
    }

    private static boolean isNumeric(JsonElement element) {
        return element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber();
    }

    private static String sanitizeFilename(String value) {
        if (value == null) return null;
        String sanitized = value.trim().replaceAll("[^A-Za-z0-9 _-]", "_");
        sanitized = sanitized.replaceAll("\\s+", " ").trim();
        while (sanitized.endsWith(".")) sanitized = sanitized.substring(0, sanitized.length() - 1);
        if (sanitized.length() > 64) sanitized = sanitized.substring(0, 64).trim();
        if (sanitized.isBlank() || ".".equals(sanitized) || "..".equals(sanitized)) return null;
        return sanitized;
    }

    private static Path boardDirectory() {
        return FabricLoader.getInstance().getConfigDir().resolve("zacktills").resolve("boards").normalize();
    }

    private static Path safeBoardPath(Path directory, String filename) {
        Path normalizedDirectory = directory.toAbsolutePath().normalize();
        Path target = normalizedDirectory.resolve(filename + ".json").normalize();
        if (!target.startsWith(normalizedDirectory) || target.equals(normalizedDirectory)) {
            throw new IllegalArgumentException("unsafe board filename");
        }
        return target;
    }

    private static String messageOf(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.isBlank()) message = exception.getClass().getSimpleName();
        message = message.replace('\n', ' ').replace('\r', ' ');
        return message.length() > 180 ? message.substring(0, 180) + "…" : message;
    }

    private void setTool(Tool tool) {
        this.activeTool = tool;
        this.statusText = "Tool: " + tool.label;
        this.updateToolButtonLabels();
    }

    private void updateToolButtonLabels() {
        if (this.toolButtons == null || this.toolButtons.length != 4) return;
        Tool[] tools = new Tool[]{Tool.TEXT, Tool.ARROW, Tool.PEN, Tool.MOVE};
        for (int i = 0; i < this.toolButtons.length; i++) {
            if (this.toolButtons[i] != null) {
                String label = tools[i].label + (this.activeTool == tools[i] ? "*" : "");
                this.toolButtons[i].setMessage(Text.literal(label));
            }
        }
    }

    private void setError(String message) {
        this.lastError = message;
        this.statusText = message;
    }

    private boolean isTextFieldFocused() {
        return (this.filenameField != null && this.filenameField.isFocused())
                || (this.textEntryField != null && this.textEntryField.isFocused());
    }

    private boolean isInsideCanvas(double x, double y) {
        return x >= 0 && x < this.width && y >= CANVAS_TOP && y < this.height;
    }

    private double canvasCenterY() {
        return (CANVAS_TOP + this.height) / 2.0;
    }

    private double worldX(double screenX) {
        return this.cameraX + (screenX - this.width / 2.0) / this.zoom;
    }

    private double worldY(double screenY) {
        return this.cameraY + (screenY - this.canvasCenterY()) / this.zoom;
    }

    private double screenX(double worldX) {
        return this.width / 2.0 + (worldX - this.cameraX) * this.zoom;
    }

    private double screenY(double worldY) {
        return this.canvasCenterY() + (worldY - this.cameraY) * this.zoom;
    }

    private static boolean isDrawableCoordinate(double x, double y) {
        return Double.isFinite(x) && Double.isFinite(y) && Math.abs(x) < 1.0e7 && Math.abs(y) < 1.0e7;
    }

    private static int clampScreen(double value) {
        if (!Double.isFinite(value)) return 0;
        return (int) Math.max(-1_000_000, Math.min(1_000_000, Math.round(value)));
    }

    private static double distanceToSegment(double px, double py, double x1, double y1, double x2, double y2) {
        if (!Double.isFinite(x1) || !Double.isFinite(y1) || !Double.isFinite(x2) || !Double.isFinite(y2)) {
            return Double.POSITIVE_INFINITY;
        }
        double dx = x2 - x1, dy = y2 - y1;
        double lengthSquared = dx * dx + dy * dy;
        if (lengthSquared <= 1.0e-12) return Math.hypot(px - x1, py - y1);
        double t = ((px - x1) * dx + (py - y1) * dy) / lengthSquared;
        t = Math.max(0.0, Math.min(1.0, t));
        return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
    }

    private int totalPointCount() {
        int count = 0;
        for (BoardObject object : this.objects) count += object.points.size();
        return count;
    }

    private static ArrayList<BoardObject> copyBoard(List<BoardObject> source) {
        ArrayList<BoardObject> copy = new ArrayList<>(source.size());
        for (BoardObject object : source) copy.add(object.copy());
        return copy;
    }

    private static void replaceBoard(ArrayList<BoardObject> destination, List<BoardObject> source) {
        destination.clear();
        for (BoardObject object : source) destination.add(object.copy());
    }

    private enum Tool {
        TEXT("Text"), ARROW("Arrow"), PEN("Pen"), MOVE("Move");
        private final String label;
        Tool(String label) { this.label = label; }
    }

    private enum DragMode { NONE, PAN, DRAW_PEN, DRAW_ARROW, MOVE_OBJECT }

    private static final class Point {
        private final double x;
        private final double y;
        private Point(double x, double y) { this.x = x; this.y = y; }
    }

    private static final class BoardObject {
        private final String type;
        private final int color;
        private final ArrayList<Point> points = new ArrayList<>();
        private String text;

        private BoardObject(String type, int color, String text) {
            this.type = type;
            this.color = color;
            this.text = text;
        }

        private BoardObject copy() {
            BoardObject copy = new BoardObject(this.type, this.color, this.text);
            copy.points.addAll(this.points);
            return copy;
        }
    }
}
