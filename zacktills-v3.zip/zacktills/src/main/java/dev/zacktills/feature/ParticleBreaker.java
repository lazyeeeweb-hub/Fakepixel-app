package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.ClientPlayerInteractionManagerAccessor;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Break aura: no rotation, no looking. Picks the nearest particle target in range and mines it
 * the same way a held attack key would (start once, then keep updating every tick).
 */
public final class ParticleBreaker {
    private static final long BROKEN_BLACKLIST_NANOS = 3_000_000_000L;
    private static final long STUCK_BLACKLIST_NANOS = 5_000_000_000L;
    private static final int STUCK_TICKS = 160;
    private static final int PAUSE_AFTER_BREAK_TICKS = 3;

    private static BlockPos target;
    private static BlockState originalState;
    private static Direction face = Direction.UP;
    private static int ticksOnTarget;
    private static int pause;
    private static long freshAfterNanos;

    private ParticleBreaker() { }

    static long freshAfterNanos() { return freshAfterNanos; }

    /** True only while this module is mining something; the mixin uses it so normal mining is never touched. */
    public static boolean isActive() { return target != null; }

    static void tick(MinecraftClient client, List<BlockPos> targets, ParticleTracker tracker) {
        ClientPlayerEntity player = client == null ? null : client.player;
        ClientPlayerInteractionManager manager = client == null ? null : client.interactionManager;
        boolean enabled = FeatureSettings.boolValue("particle.auto_break", false)
                && client != null && client.world != null && player != null && manager != null
                && client.currentScreen == null && !player.isDead() && !player.isSpectator();
        if (!enabled) {
            cancel(client);
            return;
        }
        if (pause > 0) { pause--; return; }

        long now = System.nanoTime();
        double range = Math.max(1.0, Math.min(6.0, FeatureSettings.number("particle.break_range")));
        Vec3d eye = player.getEyePos();

        if (target != null) {
            BlockState current = client.world.getBlockState(target);
            if (current.isAir() || !current.equals(originalState)) {
                finish(client, tracker, now);
                return;
            }
            if (distanceToBlock(eye, target) > range + 0.5 || ++ticksOnTarget > STUCK_TICKS) {
                if (ticksOnTarget > STUCK_TICKS) {
                    tracker.blacklist(target, STUCK_BLACKLIST_NANOS);
                    debug(client, "stuck, skipping", target);
                }
                cancel(client);
                return;
            }
        } else {
            BlockPos best = null;
            double bestDistance = Double.MAX_VALUE;
            for (BlockPos candidate : targets) {
                if (tracker.isBlacklisted(candidate)) continue;
                BlockState state = client.world.getBlockState(candidate);
                if (state.isAir() || state.getHardness(client.world, candidate) < 0) continue;
                double distance = distanceToBlock(eye, candidate);
                if (distance <= range && distance < bestDistance) {
                    bestDistance = distance;
                    best = candidate;
                }
            }
            if (best == null) return;
            target = best.toImmutable();
            originalState = client.world.getBlockState(target);
            ticksOnTarget = 0;
            Vec3d center = Vec3d.ofCenter(target);
            face = Direction.getFacing(eye.x - center.x, eye.y - center.y, eye.z - center.z);
            debug(client, "breaking", target);
        }

        ClientPlayerInteractionManagerAccessor access = (ClientPlayerInteractionManagerAccessor) manager;
        if (access.zacktills$invokeIsCurrentlyBreaking(target)) manager.updateBlockBreakingProgress(target, face);
        else manager.attackBlock(target, face);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static void finish(MinecraftClient client, ParticleTracker tracker, long now) {
        BlockPos broken = target;
        target = null;
        originalState = null;
        tracker.blacklist(broken, BROKEN_BLACKLIST_NANOS);
        tracker.removeWithin(broken, 3.0);
        freshAfterNanos = now;
        pause = PAUSE_AFTER_BREAK_TICKS;
        debug(client, "broken", broken);
    }

    private static double distanceToBlock(Vec3d eye, BlockPos pos) {
        double dx = Math.max(Math.max(pos.getX() - eye.x, 0), eye.x - (pos.getX() + 1));
        double dy = Math.max(Math.max(pos.getY() - eye.y, 0), eye.y - (pos.getY() + 1));
        double dz = Math.max(Math.max(pos.getZ() - eye.z, 0), eye.z - (pos.getZ() + 1));
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Stops our own mining only. Never touches the break state unless this module started it. */
    static void cancel(MinecraftClient client) {
        if (target != null && client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        target = null;
        originalState = null;
        ticksOnTarget = 0;
    }

    static void reset(MinecraftClient client) {
        cancel(client);
        pause = 0;
        freshAfterNanos = 0L;
    }

    private static void debug(MinecraftClient client, String event, BlockPos pos) {
        if (client == null || client.player == null || !FeatureSettings.boolValue("particle.debug", false)) return;
        client.player.sendMessage(Text.literal("[Particle ESP] " + event + " " + pos.getX() + ","
                + pos.getY() + "," + pos.getZ()), false);
    }
}
