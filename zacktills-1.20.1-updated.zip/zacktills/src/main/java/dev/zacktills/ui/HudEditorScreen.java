package dev.zacktills.ui;

import dev.zacktills.feature.HudElement;
import dev.zacktills.feature.HudElements;
import dev.zacktills.feature.HudElement.Position;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** Normalized coordinates remain shared with the real HUD renderers. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private final String id;
    private final HudElement element;
    private final Button minus, plus, reset, back;
    private Rect toolbar;
    private Widget focus, capture;
    private boolean dragging;
    private double offsetX, offsetY;

    public HudEditorScreen(Screen parent, String id) {
        this(parent, HudElements.get(id));
    }
    private HudEditorScreen(Screen parent, HudElement element) {
        super(Text.literal("Position: " + (element == null ? "Unavailable" : element.label())));
        this.parent = parent;
        this.element = element;
        this.id = element == null ? "" : element.id();
        minus = new Button("-", () -> resize(-.05));
        plus = new Button("+", () -> resize(.05));
        reset = new Button("Reset", () -> {
            if (element != null) {
                element.position(new Position(.5, .5, 1));
                element.savePosition();
            }
        });
        back = new Button("Save / Back", this::close); back.primary = true;
    }
    @Override protected void init() {
        dragging = false;
        if (capture != null) capture.cancel();
        capture = null;
        layoutToolbar();
    }
    private void layoutToolbar() {
        Rect screen = inset(new Rect(0, 0, width, height), 8);
        int w = Math.min(360, screen.w()), h = Math.min(64, screen.h());
        toolbar = region(screen, 0, 0, w, h);
        if (element != null) {
            HudElement.Bounds target = element.bounds(element.size(), width, height);
            for (int y : new int[]{0, screen.h() - h}) {
                for (int x : new int[]{0, screen.w() - w}) {
                    Rect candidate = region(screen, x, y, w, h);
                    if (overlap(target, candidate) < overlap(target, toolbar)) toolbar = candidate;
                }
            }
        }
        Rect row = region(toolbar, 8, 32, toolbar.w() - 16, 24);
        int gap = Math.min(8, row.w() / 6), available = Math.max(0, row.w() - gap * 3);
        int a = available * 24 / 196, b = available * 24 / 196, d = available * 56 / 196;
        minus.bounds(region(row, 0, 0, a, 24));
        plus.bounds(region(row, a + gap, 0, b, 24));
        reset.bounds(region(row, a + b + gap * 2, 0, d, 24));
        back.bounds(region(row, a + b + d + gap * 3, 0, available - a - b - d, 24));
    }
    private static double overlap(HudElement.Bounds target, Rect toolbar) {
        double w = Math.min(target.x() + target.width(), toolbar.x() + toolbar.w()) - Math.max(target.x(), toolbar.x());
        double h = Math.min(target.y() + target.height(), toolbar.y() + toolbar.h()) - Math.max(target.y(), toolbar.y());
        return Math.max(0, w) * Math.max(0, h);
    }
    private void resize(double delta) {
        if (element == null || delta == 0) return;
        Position p = element.position();
        element.position(new Position(p.x(), p.y(), p.scale() + delta));
        element.savePosition();
    }
    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        if (capture == null) layoutToolbar();
        Rect screen = new Rect(0, 0, width, height);
        drawBackdrop(c, width, height);
        drawGrid(c, screen);
        clip(c, screen);
        for (HudElement other : HudElements.all()) {
            if (!id.equals(other.id())) other.render(c, .5f);
        }
        if (element != null) element.render(c, 1);
        unclip(c);
        drawPanel(c, toolbar, title.getString());
        clip(c, toolbar);
        for (Widget widget : List.of(minus, plus, reset, back)) widget.render(c, mx, my);
        unclip(c);
        if (height > 104 && toolbar.y() + toolbar.h() <= height - 28) {
            Rect hint = new Rect(8, Math.max(0, height - 24), Math.max(0, width - 16), 16);
            drawPlaceholder(c, hint);
            centered(c, "Drag to move | Tap - / + to resize", hint, MUTED);
        }
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        dragging = false;
        if (capture != null) capture.cancel();
        capture = null;
        for (Widget widget : List.of(minus, plus, reset, back)) {
            if (widget.down(mx, my)) { capture = widget; setFocus(widget); return true; }
        }
        setFocus(null);
        if (toolbar.contains(mx, my)) return true;
        if (element == null) return false;
        HudElement.Bounds r = element.bounds(element.size(), width, height);
        if (r.contains(mx, my)) {
            dragging = true; offsetX = mx - r.x(); offsetY = my - r.y(); return true;
        }
        return false;
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0) return false;
        if (capture != null) { capture.drag(mx, my); return true; }
        if (!dragging) return false;
        Position p = element.position();
        HudElement.Bounds r = element.bounds(element.size(), width, height);
        element.position(new Position((mx - offsetX) / Math.max(1, width - r.width()),
                (my - offsetY) / Math.max(1, height - r.height()), p.scale()));
        return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0) return false;
        if (capture != null) {
            Widget target = capture; capture = null; target.up(mx, my); return true;
        }
        boolean wasDragging = dragging;
        dragging = false;
        if (wasDragging) element.savePosition();
        return wasDragging;
    }
    @Override public boolean mouseScrolled(double mx, double my, double amount) { resize(Math.signum(amount) * .05); return true; }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = List.of(minus, plus, reset, back);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1, current = controls.indexOf(focus);
            setFocus(controls.get(current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size())));
            return true;
        }
        if (key == GLFW.GLFW_KEY_EQUAL || key == GLFW.GLFW_KEY_KP_ADD) { resize(.05); return true; }
        if (key == GLFW.GLFW_KEY_MINUS || key == GLFW.GLFW_KEY_KP_SUBTRACT) { resize(-.05); return true; }
        if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
            if (element == null) return false;
            double step = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? .1 : .01;
            Position p = element.position();
            double dx = key == GLFW.GLFW_KEY_LEFT ? -step : key == GLFW.GLFW_KEY_RIGHT ? step : 0;
            double dy = key == GLFW.GLFW_KEY_UP ? -step : key == GLFW.GLFW_KEY_DOWN ? step : 0;
            element.position(new Position(p.x() + dx, p.y() + dy, p.scale()));
            element.savePosition();
            return true;
        }
        return focus != null && focus.key(key, modifiers) || super.keyPressed(key, scan, modifiers);
    }
    @Override public void close() { if (dragging && element != null) element.savePosition(); if (client != null) client.setScreen(parent); }
    @Override public void removed() {
        if (dragging && element != null) element.savePosition();
        dragging = false; if (capture != null) capture.cancel(); capture = null; super.removed();
    }
    @Override public boolean shouldPause() { return false; }
}
