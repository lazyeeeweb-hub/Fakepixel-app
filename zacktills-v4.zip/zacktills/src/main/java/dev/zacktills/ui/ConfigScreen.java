package dev.zacktills.ui;

import dev.zacktills.config.ConfigModel;
import dev.zacktills.config.ConfigStore;
import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.zacktills.ui.DrawUtil.*;
import static dev.zacktills.ui.Widgets.*;

/** Modrinth-app style settings screen: icon rail, big header, search, filter chips, rows with controls on the right. */
public final class ConfigScreen extends Screen {
    private static final int RAIL_W = 44;
    private static final String[] CHIP_LABELS = {"All", "Enabled", "Disabled"};

    private final Screen parent;
    private final List<ConfigModel.Category> categories;
    private final ConfigStore store;
    private final CategoryList categoryList = new CategoryList();
    private final ScrollList optionList = new ScrollList();
    private final TextField search;
    private final Button doneButton;
    private final Chip[] chips = new Chip[3];
    private Rect panel, rail, header, searchBox;
    private Widget focus, capture;
    private Dropdown openDropdown;
    private ScrollList popup;
    private int selected, popupIndex, filter;
    private boolean dirty = true;
    private float scale = 1f;

    public ConfigScreen(Screen parent, List<ConfigModel.Category> categories, ConfigStore store) {
        super(Text.literal("Zacktills settings"));
        if (categories.isEmpty()) throw new IllegalArgumentException("At least one category required");
        this.parent = parent;
        this.categories = categories;
        this.store = store;
        optionList.framed = false;
        optionList.pad = 2;
        optionList.bar = 4;
        optionList.barGap = 6;
        optionList.rowGap = 0;
        search = new TextField("", value -> { optionList.scroll = 0; dirty = true; });
        doneButton = new Button("Done", this::close);
        doneButton.primary = true;
        for (int i = 0; i < chips.length; i++) {
            final int mode = i;
            chips[i] = new Chip(CHIP_LABELS[i], () -> {
                if (filter != mode) { filter = mode; optionList.scroll = 0; dirty = true; }
            });
        }
    }

    private static float configuredScale() {
        try {
            return (float) Math.max(.5, Math.min(1.5, FeatureSettings.number("interface.ui_scale")));
        } catch (RuntimeException ignored) {
            return 1f;
        }
    }

    @Override protected void init() {
        if (capture != null) capture.cancel();
        capture = null;
        closePopup();
        scale = configuredScale();
        int vw = Math.round(width / scale), vh = Math.round(height / scale);
        int pw = Math.min(760, Math.max(Math.min(300, vw), vw - 24));
        int ph = Math.min(440, Math.max(Math.min(180, vh), vh - 24));
        panel = new Rect((vw - pw) / 2, (vh - ph) / 2, pw, ph);
        rail = region(panel, 6, 6, RAIL_W, panel.h() - 12);
        int contentX = 6 + RAIL_W + 10;
        Rect content = region(panel, contentX, 10, panel.w() - contentX - 12, panel.h() - 20);
        header = region(content, 0, 0, content.w(), 34);
        int doneW = Math.min(56, header.w());
        doneButton.bounds(region(header, header.w() - doneW, 4, doneW, 20));
        searchBox = region(content, 0, 42, content.w(), 22);
        search.bounds(region(searchBox, 22, 0, Math.max(0, searchBox.w() - 22), 22));
        int chipX = 0;
        for (Chip chip : chips) {
            int w = textWidth(chip.label) + 18;
            chip.bounds(region(content, chipX, 70, w, 16));
            chipX += w + 6;
        }
        optionList.bounds(region(content, 0, 92, content.w(), content.h() - 92));
        categoryList.bounds(rail);
        dirty = true;
        rebuild();
    }

    private void setFocus(Widget target) {
        if (focus != null) focus.focused = false;
        focus = target;
        if (focus != null) focus.focused = true;
    }

    private void rebuild() {
        if (!dirty) return;
        dirty = false;
        closePopup();
        search.placeholder = "Search " + categories.get(selected).options.size() + " settings";
        categoryList.categories(categories, selected, index -> {
            if (selected != index) {
                selected = index;
                optionList.scroll = 0;
                dirty = true;
            }
        });
        for (int i = 0; i < chips.length; i++) chips[i].selected = i == filter;
        List<Widget> rows = new ArrayList<>();
        String query = search.value.toLowerCase(Locale.ROOT).trim();
        append(rows, categories.get(selected).options, query, 0, true);
        optionList.setItems(rows);
        if (focus != search && focus != doneButton) setFocus(null);
    }

    private boolean matches(ConfigModel.Option<?> option, String query) {
        if (query.isEmpty() || (option.label + " " + option.description).toLowerCase(Locale.ROOT).contains(query)) return true;
        if (option instanceof ConfigModel.Folder folder) {
            for (ConfigModel.Option<?> child : folder.children) if (matches(child, query)) return true;
        }
        return false;
    }

    private void append(List<Widget> rows, List<ConfigModel.Option<?>> options, String query, int depth, boolean parentEnabled) {
        for (ConfigModel.Option<?> option : options) {
            if (!matches(option, query)) continue;
            if (filter != 0) {
                if (option instanceof ConfigModel.Folder folder) {
                    append(rows, folder.children, query, depth, parentEnabled && option.enabled);
                } else if (option instanceof ConfigModel.Bool bool && bool.value == (filter == 1)) {
                    OptionRow row = new OptionRow(option, depth, this::openPopup, () -> dirty = true);
                    row.enabled = parentEnabled && option.enabled;
                    if (row.control != null) row.control.enabled = row.enabled;
                    rows.add(row);
                }
                continue;
            }
            OptionRow row = new OptionRow(option, depth, this::openPopup, () -> dirty = true);
            row.enabled = parentEnabled && option.enabled;
            if (row.control != null) row.control.enabled = row.enabled;
            rows.add(row);
            if (option instanceof ConfigModel.Folder folder && (folder.expanded || !query.isEmpty())) {
                append(rows, folder.children, query, depth + 1, row.enabled);
            }
        }
    }

    private void openPopup(Dropdown dropdown) {
        closePopup();
        openDropdown = dropdown;
        popup = new ScrollList();
        List<Widget> choices = new ArrayList<>();
        for (String choice : dropdown.option.choices) {
            Button button = new Button(choice, () -> { dropdown.option.value = choice; closePopup(); });
            button.selected = choice.equals(dropdown.option.value);
            choices.add(button);
        }
        popup.setItems(choices);
        Rect anchor = dropdown.bounds, area = inset(panel, 8);
        int w = Math.min(Math.max(100, anchor.w() + 28), area.w());
        int h = Math.min(Math.max(0, choices.size() * 32 + 8), Math.min(area.h(), Math.max(48, area.h() / 2)));
        int x = clamp(anchor.x(), area.x(), area.x() + area.w() - w);
        int y = anchor.y() + anchor.h() + 8;
        if (y + h > area.y() + area.h()) y = anchor.y() - h - 8;
        y = clamp(y, area.y(), area.y() + area.h() - h);
        popup.bounds(new Rect(x, y, w, h));
        popupIndex = Math.max(0, dropdown.option.choices.indexOf(dropdown.option.value));
        setFocus(popup.items.get(popupIndex));
        popup.reveal(focus);
    }

    private void closePopup() {
        if (popup != null) {
            popup.cancel();
            if (focus != null && popup.items.contains(focus)) setFocus(openDropdown);
        }
        popup = null;
        openDropdown = null;
    }

    @Override public void render(DrawContext c, int rawX, int rawY, float delta) {
        if (capture == null && popup == null && Math.abs(configuredScale() - scale) > 0.001f) init();
        rebuild();
        drawBackdrop(c, width, height);
        int mx = Math.round(rawX / scale), my = Math.round(rawY / scale);
        int hx = popup == null ? mx : -10000, hy = popup == null ? my : -10000;
        c.getMatrices().push();
        c.getMatrices().scale(scale, scale, 1f);
        DrawUtil.scale = scale;
        try {
            rounded(c, panel, 8, PANEL);
            rounded(c, rail, 8, RAIL);
            categoryList.render(c, hx, hy);

            ConfigModel.Category category = categories.get(selected);
            int titleWidth = Math.max(0, header.w() - 70);
            bigText(c, trim(category.label, (int) (titleWidth / 1.35f)), header.x(), header.y() + 2, 1.35f, TEXT);
            text(c, category.options.size() + " settings", header.x(), header.y() + 21, titleWidth, MUTED);
            doneButton.render(c, hx, hy);

            rounded(c, searchBox, 6, INSET);
            drawMagnifier(c, searchBox.x() + 8, searchBox.y() + 6, MUTED, INSET);
            search.render(c, hx, hy);
            for (Chip chip : chips) chip.render(c, hx, hy);
            optionList.render(c, hx, hy);
            if (optionList.items.isEmpty()) {
                clip(c, optionList.bounds);
                text(c, "No matching options", optionList.bounds.x() + 10, optionList.bounds.y() + 10,
                        optionList.bounds.w() - 20, MUTED);
                unclip(c);
            }
            if (popup != null) {
                drawPlaceholder(c, popup.bounds);
                popup.render(c, mx, my);
            } else if (capture == null) {
                boolean shown = false;
                for (Widget item : categoryList.items) {
                    if (item instanceof RailButton button && button.bounds.contains(mx, my)) {
                        drawHint(c, inset(panel, 8), button.full, mx, my);
                        shown = true;
                        break;
                    }
                }
                if (!shown && optionList.bounds.contains(mx, my)) {
                    for (Widget item : optionList.items) {
                        if (item instanceof OptionRow row && row.bounds.contains(mx, my) && mx < row.controlX() - 10) {
                            String hint = row.option.label;
                            if (!row.option.description.equals(hint)) hint += " - " + row.option.description;
                            drawHint(c, inset(panel, 8), hint, mx, my);
                            break;
                        }
                    }
                }
            }
        } finally {
            DrawUtil.scale = 1f;
            c.getMatrices().pop();
        }
    }

    private Widget hit(double mx, double my) {
        if (doneButton.bounds.contains(mx, my)) return doneButton;
        if (search.bounds.contains(mx, my)) return search;
        for (Chip chip : chips) if (chip.bounds.contains(mx, my)) return chip;
        if (categoryList.bounds.contains(mx, my)) return categoryList;
        if (optionList.bounds.contains(mx, my)) return optionList;
        return null;
    }

    @Override public boolean mouseClicked(double rawX, double rawY, int button) {
        if (button != 0) return false;
        double mx = rawX / scale, my = rawY / scale;
        rebuild();
        if (capture != null) capture.cancel();
        capture = null;
        if (popup != null) {
            if (popup.bounds.contains(mx, my)) {
                setFocus(popup.focusAt(mx, my));
                int pointerIndex = popup.items.indexOf(focus);
                if (pointerIndex >= 0) popupIndex = pointerIndex;
                if (popup.down(mx, my)) capture = popup;
            } else closePopup();
            return true;
        }
        Widget target = hit(mx, my);
        setFocus(target == null ? null : target.focusAt(mx, my));
        if (target != null && target.down(mx, my)) { capture = target; return true; }
        return panel.contains(mx, my);
    }

    @Override public boolean mouseDragged(double rawX, double rawY, int button, double dx, double dy) {
        if (button == 0 && capture != null) { capture.drag(rawX / scale, rawY / scale); return true; }
        return false;
    }

    @Override public boolean mouseReleased(double rawX, double rawY, int button) {
        if (button != 0 || capture == null) return false;
        Widget target = capture;
        capture = null;
        target.up(rawX / scale, rawY / scale);
        rebuild();
        return true;
    }

    @Override public boolean mouseScrolled(double rawX, double rawY, double amount) {
        double mx = rawX / scale, my = rawY / scale;
        if (popup != null) return popup.wheel(mx, my, amount) || panel.contains(mx, my);
        return categoryList.wheel(mx, my, amount) || optionList.wheel(mx, my, amount);
    }

    @Override public boolean charTyped(char chr, int modifiers) {
        if (focus != null && focus.character(chr)) { rebuild(); return true; }
        return false;
    }

    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        rebuild();
        if (popup != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { closePopup(); return true; }
            if (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) {
                popupIndex = Math.floorMod(popupIndex + (key == GLFW.GLFW_KEY_UP ? -1 : 1), popup.items.size());
                setFocus(popup.items.get(popupIndex));
                popup.reveal(focus);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) {
                Widget target = popup.items.get(popupIndex);
                target.key(GLFW.GLFW_KEY_ENTER, modifiers);
                return true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) {
            List<Widget> controls = new ArrayList<>();
            controls.add(search);
            for (Chip chip : chips) controls.add(chip);
            controls.addAll(categoryList.focusables());
            controls.addAll(optionList.focusables());
            controls.add(doneButton);
            int direction = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            int current = controls.indexOf(focus);
            int next = current < 0 ? (direction > 0 ? 0 : controls.size() - 1)
                    : Math.floorMod(current + direction, controls.size());
            setFocus(controls.get(next));
            categoryList.reveal(focus);
            optionList.reveal(focus);
            return true;
        }
        if (focus != null && focus.key(key, modifiers)) { rebuild(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN) {
            optionList.page(key == GLFW.GLFW_KEY_PAGE_UP ? -1 : 1);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }

    @Override public void removed() {
        DrawUtil.scale = 1f;
        if (capture != null) capture.cancel();
        closePopup();
        if (!store.save() && client != null && client.player != null) {
            client.player.sendMessage(Text.literal("Zacktills: config save failed; see the log."), false);
        }
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }
}
