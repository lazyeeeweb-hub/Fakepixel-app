import com.sun.source.util.JavacTask;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Parse only: checks Java 17 grammar, NOT Minecraft/Fabric linkage or mixin targets. */
public final class SyntaxCheck {
    public static void main(String[] args) throws IOException {
        Path root = Path.of(args.length == 0 ? "src" : args[0]);
        List<Path> sources;
        try (var paths = Files.walk(root)) {
            sources = paths.filter(p -> p.toString().endsWith(".java")).sorted().toList();
        }
        if (sources.isEmpty()) throw new IllegalArgumentException("No Java sources in " + root);
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("Use a JDK 17, not a JRE");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager files = compiler.getStandardFileManager(diagnostics, null, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, files, diagnostics,
                    List.of("--release", "17", "-proc:none"), null,
                    files.getJavaFileObjectsFromPaths(sources));
            task.parse();
            long errors = diagnostics.getDiagnostics().stream()
                    .filter(d -> d.getKind() == Diagnostic.Kind.ERROR).count();
            diagnostics.getDiagnostics().forEach(System.out::println);
            if (errors != 0) throw new IllegalStateException(errors + " Java syntax error(s)");
        }
        System.out.println("PASS: parsed " + sources.size() + " Java files as Java 17 (syntax only)");
    }
}
