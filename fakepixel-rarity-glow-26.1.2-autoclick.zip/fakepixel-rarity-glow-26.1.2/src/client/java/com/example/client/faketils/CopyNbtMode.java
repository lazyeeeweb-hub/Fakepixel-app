package com.example.client.faketils;

public class CopyNbtMode {

    private static boolean active = false;

    public static final int BUTTON_SIZE = 16;
    public static final int BUTTON_MARGIN = 6;

    public static boolean isActive() {
        return active;
    }

    public static void toggle() {
        active = !active;
    }

    public static void set(boolean value) {
        active = value;
    }

    private CopyNbtMode() {}
}
