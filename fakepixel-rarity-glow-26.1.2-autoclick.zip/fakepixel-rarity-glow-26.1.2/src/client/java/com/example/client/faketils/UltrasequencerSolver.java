package com.example.client.faketils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Ultrasequencer solving logic, corrected against Skyblocker's real, current
 * implementation (the actual mechanic differs from Chronomatron/NEF-style
 * dye-count guesses): tiles are stained glass panes whose DISPLAY NAME is
 * literally the number text ("1", "2", "3"...) - not a stack count. Pane
 * COLOR is unrelated to solve order; it's only useful for detecting a new
 * round (not used here since we key phase off the real slot-49 status text
 * instead, matching Skyblocker's more reliable approach).
 *
 * Phase detection reads slot 49's item name directly:
 * - "Remember the pattern!" -> REMEMBER phase, panes show real numbers
 * - starts with "Timer: "   -> SHOW phase, panes hidden, must click by memory
 */
public class UltrasequencerSolver {

    public enum State {
        REMEMBER,
        WAIT,
        SHOW,
        END
    }

    private State state = State.REMEMBER;
    private final Map<Integer, Integer> slotToNumber = new HashMap<>();
    private int nextSlot = -1;
    private boolean active = false;

    private int lastAutoClickedNumber = -1;
    private long lastAutoClickTimeMs = 0;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        if (!active && this.active) {
            reset();
        }
        this.active = active;
    }

    public void reset() {
        state = State.REMEMBER;
        slotToNumber.clear();
        nextSlot = -1;
        lastAutoClickedNumber = -1;
        lastAutoClickTimeMs = 0;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void beginNewRound() { reset(); }

    public void beginSolvePhase() {
        state = hasCompleteSequence() ? State.SHOW : State.END;
        nextSlot = state == State.SHOW ? slotFor(1) : -1;
        if (nextSlot == -1) state = State.END;
    }

    private int slotFor(int number) {
        for (Map.Entry<Integer, Integer> entry : slotToNumber.entrySet())
            if (entry.getValue() == number) return entry.getKey();
        return -1;
    }

    private boolean hasCompleteSequence() {
        if (slotToNumber.isEmpty()) return false;
        Set<Integer> values = new HashSet<>(slotToNumber.values());
        if (values.size() != slotToNumber.size()) return false;
        for (int number = 1; number <= slotToNumber.size(); number++)
            if (!values.contains(number)) return false;
        return true;
    }

    /** Called once per REMEMBER-phase tick with (slot, parsedNumber) for every numbered pane found. */
    public void rememberSlot(int slot, int number) {
        if (state != State.REMEMBER || slot < 9 || slot > 44 || number < 1 || number > 36) return;
        slotToNumber.put(slot, number);
        if (number == 1) nextSlot = slot;
    }

    public boolean hasRemembered() {
        return !slotToNumber.isEmpty();
    }

    public int getNextSlot() {
        return nextSlot;
    }

    public boolean matchesExpected(int slotId) {
        return slotId != -1 && slotId == nextSlot;
    }

    /** Called when the correct slot was actually clicked - advances to the next number in sequence. */
    public void advance() {
        if (state != State.SHOW || nextSlot == -1) return;
        Integer clickedNumber = slotToNumber.get(nextSlot);
        if (clickedNumber == null) return;

        int nextNumber = clickedNumber + 1;
        nextSlot = -1;
        for (Map.Entry<Integer, Integer> entry : slotToNumber.entrySet()) {
            if (entry.getValue() == nextNumber) {
                nextSlot = entry.getKey();
                break;
            }
        }
        if (nextSlot == -1) state = State.END;
    }

    public boolean shouldAutoClickNow(long nowMs, long minDelayMs) {
        if (state != State.SHOW) return false;
        if (nextSlot == -1) return false;
        Integer currentNumber = slotToNumber.get(nextSlot);
        if (currentNumber == null) return false;
        if (lastAutoClickedNumber == currentNumber) return false;
        if (nowMs - lastAutoClickTimeMs < minDelayMs) return false;
        return true;
    }

    public void markAutoClicked(long nowMs) {
        Integer currentNumber = slotToNumber.get(nextSlot);
        lastAutoClickedNumber = currentNumber != null ? currentNumber : -1;
        lastAutoClickTimeMs = nowMs;
    }
}
