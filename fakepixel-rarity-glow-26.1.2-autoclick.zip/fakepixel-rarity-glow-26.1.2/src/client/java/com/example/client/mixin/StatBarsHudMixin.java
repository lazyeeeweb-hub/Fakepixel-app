package com.example.client.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.faketils.FakepixelRarityGlow;
import com.example.client.faketils.StatBarsHud;

@Mixin(InGameHud.class)
public class StatBarsHudMixin {

        @Inject(method = "setOverlayMessage", at = @At("HEAD"), cancellable = true)
        private void faketils$captureActionBar(Text message, boolean tinted, CallbackInfo ci) {
                if (message == null) return;

                StatBarsHud.onActionBar(message.getString());

                if (FakepixelRarityGlow.CONFIG.visual.statBarsEnabled) {
                        ci.cancel();
                }
        }

        @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
        private void faketils$hideStatusBars(net.minecraft.client.gui.DrawContext context, CallbackInfo ci) {
                if (FakepixelRarityGlow.CONFIG.visual.statBarsEnabled) {
                        ci.cancel();
                }
        }

        @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
        private void faketils$hideExp(net.minecraft.client.gui.DrawContext context, int x, CallbackInfo ci) {
                if (FakepixelRarityGlow.CONFIG.visual.statBarsEnabled) {
                        ci.cancel();
                }
        }
}
