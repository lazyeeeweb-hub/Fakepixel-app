package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.example.client.faketils.AccessoryPanelScrollState;
import com.example.faketils.AccessoryDetection;
import com.example.faketils.AccessoryStorage;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * Real Missing Accessories panel. Each render:
 *  1. Scans the bag's real chest slots, running AccessoryDetection on each
 *     and calling AccessoryStorage.noteSeen() for every real accessory
 *     found - grows/updates accessories.json over time.
 *  2. Displays AccessoryStorage.getMissing() (sorted A-Z) - every entry
 *     NOT marked owned, color-coded by rarity using the same RGB values
 *     RarityUtil.mapColor uses for the glow feature, for visual
 *     consistency across the mod.
 */
@Mixin(HandledScreen.class)
public class AccessoryPanelTestMixin {

    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;

    private static final String TITLE_PREFIX = "Accessory Bag";

    private static final int PANEL_PAD = 6;
    private static final int PANEL_W = 140;
    private static final int LINE_H = 11;
    private static final int HEADER_H = 18;
    private static final int SCROLLBAR_W = 3;

    private static final Map<String, Integer> RARITY_TEXT_COLOR = new LinkedHashMap<>();
    static {
        RARITY_TEXT_COLOR.put("VERY SPECIAL", 0xAA0000);
        RARITY_TEXT_COLOR.put("ADMIN", 0xAA0000);
        RARITY_TEXT_COLOR.put("UNOBTAINABLE", 0xAA0000);
        RARITY_TEXT_COLOR.put("SPECIAL", 0xFF5555);
        RARITY_TEXT_COLOR.put("DIVINE", 0x55FFFF);
        RARITY_TEXT_COLOR.put("MYTHIC", 0xFF55FF);
        RARITY_TEXT_COLOR.put("LEGENDARY", 0xFFAA00);
        RARITY_TEXT_COLOR.put("EPIC", 0xAA00AA);
        RARITY_TEXT_COLOR.put("RARE", 0x5555FF);
        RARITY_TEXT_COLOR.put("UNCOMMON", 0x55FF55);
        RARITY_TEXT_COLOR.put("COMMON", 0xAAAAAA);
    }

    private int faketils$scroll = 0;
    private int faketils$maxScroll = 0;
    private boolean faketils$draggingScrollbar = false;

    private boolean faketils$isTargetScreen() {
        return ((HandledScreen<?>) (Object) this).getTitle().getString().startsWith(TITLE_PREFIX);
    }

    private void faketils$scanAndRecordBag() {
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        if (!(self.getScreenHandler() instanceof GenericContainerScreenHandler containerHandler)) return;

        int chestSlotCount = containerHandler.getRows() * 9;
        var slots = containerHandler.slots;

        for (int i = 0; i < chestSlotCount && i < slots.size(); i++) {
            ItemStack stack = slots.get(i).getStack();
            if (stack.isEmpty()) continue;

            AccessoryDetection.Result result = AccessoryDetection.detect(stack);
            if (result != null) {
                AccessoryStorage.noteSeen(result.name, result.rarity);
            }
        }
    }

    private int faketils$panelX() {
        return x + backgroundWidth + PANEL_PAD;
    }

    private int faketils$panelY() {
        return y;
    }

    private int faketils$panelH() {
        return Math.min(180, backgroundHeight);
    }

    private int faketils$viewH() {
        return faketils$panelH() - HEADER_H - PANEL_PAD;
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void faketils$drawPanel(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!faketils$isTargetScreen()) return;

        faketils$scanAndRecordBag();

        List<AccessoryStorage.Entry> missing = AccessoryStorage.getMissing();

        int panelX = faketils$panelX();
        int panelY = faketils$panelY();
        int panelW = PANEL_W;
        int panelH = faketils$panelH();
        int viewH = faketils$viewH();
        int contentH = missing.size() * LINE_H;

        faketils$maxScroll = Math.max(0, contentH - viewH);
        AccessoryPanelScrollState.configure((HandledScreen<?>) (Object) this,
                panelX, panelY + HEADER_H, panelW, viewH, faketils$maxScroll > 0);

        int wheelDelta = AccessoryPanelScrollState.consume();
        if (wheelDelta != 0
                && mouseX >= panelX && mouseX <= panelX + panelW
                && mouseY >= panelY + HEADER_H && mouseY <= panelY + HEADER_H + viewH) {
            faketils$scroll -= wheelDelta * LINE_H;
        }

        if (faketils$scroll > faketils$maxScroll) faketils$scroll = faketils$maxScroll;
        if (faketils$scroll < 0) faketils$scroll = 0;

        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xB0000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + 1, 0x40FFFFFF);
        context.fill(panelX, panelY, panelX + 1, panelY + panelH, 0x40000000);
        context.fill(panelX + panelW - 1, panelY, panelX + panelW, panelY + panelH, 0x40000000);
        context.fill(panelX, panelY + panelH - 1, panelX + panelW, panelY + panelH, 0x40000000);

        context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                "Missing (" + missing.size() + ")", panelX + PANEL_PAD, panelY + 4, 0xFFFFFF, true);
        context.fill(panelX + PANEL_PAD, panelY + HEADER_H - 2, panelX + panelW - PANEL_PAD, panelY + HEADER_H - 1, 0x40FFFFFF);

        int listX = panelX + PANEL_PAD;
        int listY = panelY + HEADER_H;

        context.enableScissor(listX - 2, listY, panelX + panelW - PANEL_PAD, listY + viewH);

        int lineY = listY - faketils$scroll;
        for (AccessoryStorage.Entry entry : missing) {
            if (lineY > listY - LINE_H && lineY < listY + viewH) {
                int color = RARITY_TEXT_COLOR.getOrDefault(entry.rarity, 0xFFFFFF);
                context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                        entry.name, listX, lineY, color, false);
            }
            lineY += LINE_H;
        }

        context.disableScissor();

        if (faketils$maxScroll > 0) {
            int trackX = panelX + panelW - SCROLLBAR_W - 2;
            int trackY = listY;
            int trackH = viewH;

            int barH = Math.max(12, (int) (trackH * (viewH / (float) contentH)));
            int barY = trackY + (int) ((trackH - barH) * (faketils$scroll / (float) faketils$maxScroll));

            context.fill(trackX, trackY, trackX + SCROLLBAR_W, trackY + trackH, 0x40FFFFFF);
            int barColor = faketils$draggingScrollbar ? 0xFFFFFFFF : 0xFFAAAAAA;
            context.fill(trackX, barY, trackX + SCROLLBAR_W, barY + barH, barColor);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void faketils$scrollbarClick(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (!faketils$isTargetScreen() || button != 0) return;
        if (faketils$maxScroll <= 0) return;

        int panelX = faketils$panelX();
        int panelY = faketils$panelY();
        int panelW = PANEL_W;
        int viewH = faketils$viewH();
        int listY = panelY + HEADER_H;

        int trackX = panelX + panelW - SCROLLBAR_W - 2;

        if (mouseX >= trackX - 2 && mouseX <= trackX + SCROLLBAR_W + 2
                && mouseY >= listY && mouseY <= listY + viewH) {
            faketils$draggingScrollbar = true;
            faketils$scrollbarDragTo(mouseY, listY, viewH);
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void faketils$scrollbarDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
        if (!faketils$draggingScrollbar) return;

        int panelY = faketils$panelY();
        int viewH = faketils$viewH();
        int listY = panelY + HEADER_H;

        faketils$scrollbarDragTo(mouseY, listY, viewH);
        cir.setReturnValue(true);
    }

    @Inject(method = "mouseReleased", at = @At("HEAD"))
    private void faketils$scrollbarRelease(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        faketils$draggingScrollbar = false;
    }

    private void faketils$scrollbarDragTo(double mouseY, int listY, int viewH) {
        if (faketils$maxScroll <= 0) return;
        double ratio = (mouseY - listY) / (double) viewH;
        ratio = Math.max(0, Math.min(1, ratio));
        faketils$scroll = (int) Math.round(ratio * faketils$maxScroll);
    }
}
