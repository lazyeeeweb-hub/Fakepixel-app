package com.example.client.faketils;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.text.Text;

import com.example.faketils.FakepixelRarityGlow;

import java.util.regex.Pattern;

/**
 * Filters out specific server broadcast messages (game messages, not player
 * chat): friend-joined notices, watchdog/player-information announcements,
 * and "selling ranks" spam. Patterns adapted from NEF's ChatCleaner, ported
 * to plain (unformatted) text matching since Fabric's Text#getString()
 * already strips color codes.
 */
public class ChatFilter {

    private static final Pattern SELLING_RANK_PATTERN = Pattern.compile(
            "(\\[[A-Za-z0-9_+]+\\] )?\\w+: .*\\bselling\\b.*\\brank(s)?\\b.*"
    );
    private static final Pattern WATCHDOG_PATTERN = Pattern.compile("\\[WATCHDOG ANNOUNCEMENT]");
    private static final Pattern INFO_PATTERN = Pattern.compile("\\[PLAYER INFORMATION]");
    private static final Pattern FRIEND_JOIN_PATTERN = Pattern.compile("Friend > ");

    public static void register() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!FakepixelRarityGlow.CONFIG.qol.disableChatSpam) return true;

            String plain = message.getString();

            if (FRIEND_JOIN_PATTERN.matcher(plain).find()) return false;
            if (WATCHDOG_PATTERN.matcher(plain).find()) return false;
            if (INFO_PATTERN.matcher(plain).find()) return false;
            if (SELLING_RANK_PATTERN.matcher(plain).find()) return false;

            return true;
        });
    }

    private ChatFilter() {}
}
