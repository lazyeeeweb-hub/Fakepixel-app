package com.example.client.faketils;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import com.example.client.faketils.HudEditMode.BarType;

public class DrillFuelHud {

    private static int currentFuel = -1;

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            if (!FakepixelRarityGlow.CONFIG.mines.fuelOverlayEnabled) return;

            ItemStack held = client.player.getMainHandStack();
            Integer fuel = readFuel(held);
            currentFuel = fuel != null ? fuel : -1;

            if (currentFuel < 0) return;

            drawOverlay(context, client);
        });
    }

    private static Integer readFuel(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }

        NbtCompound extraAttributes = stack.getSubNbt("ExtraAttributes");
        if (extraAttributes == null) {
            return null;
        }

        String id = extraAttributes.getString("id");
        if (id == null || !id.contains("DRILL")) return null;

        if (!extraAttributes.contains("fuel")) return null;

        return extraAttributes.getInt("fuel");
    }

    public static int[] getRect(int screenW, int screenH) {
        ModConfig.MinesSettings m = FakepixelRarityGlow.CONFIG.mines;
        int configX = m.fuelOverlayX;
        int configY = m.fuelOverlayY;
        int x = configX >= 0 ? configX : screenW + configX;
        int y = configY >= 0 ? configY : screenH + configY;

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer fr = client.textRenderer;
        String preview = "Fuel: 0,000";
        int width = fr.getWidth(preview);
        return new int[]{ x, y, width, fr.fontHeight };
    }

    private static void drawOverlay(DrawContext context, MinecraftClient client) {
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int[] rect = getRect(screenW, screenH);

        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        if (v.hudBackgroundEnabled) {
            int alpha = Math.round(v.hudBackgroundOpacity / 100f * 255f);
            int bgColor = (alpha << 24);
            context.fill(rect[0] - 3, rect[1] - 2, rect[0] + rect[2] + 3, rect[1] + rect[3] + 2, bgColor);
        }

        TextRenderer fr = client.textRenderer;
        int x = rect[0];
        int y = rect[1];

        String labelText = "Fuel: ";
        String numberText = String.format("%,d", currentFuel);

        x = context.drawTextWithShadow(fr, labelText, x, y, 0xFFAAAAAA);
        context.drawTextWithShadow(fr, numberText, x, y, 0xFF55FFFF);

        if (HudEditMode.isActive() && (HudEditMode.getHoveredBar() == BarType.FUEL || HudEditMode.getDraggedBar() == BarType.FUEL)) {
            context.fill(rect[0] - 2, rect[1] - 2, rect[0] + rect[2] + 2, rect[1] + rect[3] + 2, 0x60FFFFFF);
        }
    }
}
