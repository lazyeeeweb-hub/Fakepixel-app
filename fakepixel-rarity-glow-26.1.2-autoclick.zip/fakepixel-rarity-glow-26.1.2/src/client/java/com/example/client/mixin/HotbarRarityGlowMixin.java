package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.faketils.RarityUtil;

@Mixin(InGameHud.class)
public class HotbarRarityGlowMixin {

@Inject(
method = "renderHotbarItem(Lnet/minecraft/client/gui/DrawContext;IIFLnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/item/ItemStack;I)V",
at = @At("HEAD")
)
private void faketils$drawHotbarGlow(DrawContext context, int x, int y, float tickDelta, PlayerEntity player, ItemStack stack, int seed, CallbackInfo ci) {
int color = RarityUtil.getRarityColor(stack);
if (color != 0) {
context.fill(x, y, x + 16, y + 16, color);
}
}
}
