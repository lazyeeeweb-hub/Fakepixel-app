package com.example.client.faketils;

import net.minecraft.client.gui.screen.Screen;
public class AccessoryPanelScrollState {
    private static Screen owner;
    private static int x, y, width, height;
    private static long renderedAt;
    private static boolean scrollable;
    private static double pending;
    public static void configure(Screen screen, int left, int top, int w, int h, boolean canScroll) {
        if (screen != owner || x != left || y != top || width != w || height != h || !canScroll) pending = 0;
        owner=screen; x=left; y=top; width=w; height=h; scrollable=canScroll; renderedAt=System.nanoTime();
    }
    public static boolean scrollAt(Screen screen, double mx, double my, double amount) {
        if (screen != owner || !scrollable || System.nanoTime()-renderedAt>250_000_000L
                || mx<x || mx>=x+width || my<y || my>=y+height || !Double.isFinite(amount) || amount==0) return false;
        double next=Math.max(-1000,Math.min(1000,pending+amount));
        if (next==pending) return false;
        pending=next; return true;
    }
    public static int consume() { int n=(int)pending; pending-=n; return n; }
    private AccessoryPanelScrollState() {}
}
