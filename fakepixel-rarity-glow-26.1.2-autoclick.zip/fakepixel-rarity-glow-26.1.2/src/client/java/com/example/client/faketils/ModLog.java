package com.example.client.faketils;

import com.example.faketils.FakepixelRarityGlow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Opt-in diagnostics using Minecraft's existing buffered/rotating logging backend. */
public final class ModLog {
    private static final Logger LOGGER = LoggerFactory.getLogger("Faketils");

    private ModLog() {}

    public static void log(String message) {
        if (FakepixelRarityGlow.CONFIG != null
                && FakepixelRarityGlow.CONFIG.debug != null
                && FakepixelRarityGlow.CONFIG.debug.verboseDebugLogging) {
            LOGGER.info("{}", message);
        }
    }
}
