package com.example.client.mixin;

import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes WorldRenderer's private bufferBuilders field so JerryGiftEsp can
 * reach BufferBuilderStorage.getOutlineVertexConsumers() (a real public
 * method - confirmed via javap against the 1.20.1 client jar) to draw the
 * Jerry Gift waypoint box into the same OutlineVertexConsumerProvider
 * vanilla uses for glowing-entity outlines, which renders through terrain
 * via WorldRenderer's entityOutlinesFramebuffer/post-processor.
 *
 * This is a plain @Accessor on a private field of the mixin's own target
 * class - not the RenderLayer.of()/MultiPhase approach that hit a real,
 * confirmed Java visibility wall (private nested classes referenced from
 * an accessor method signature outside the package). No such wall here:
 * bufferBuilders and BufferBuilderStorage.getOutlineVertexConsumers() are
 * both plain top-level-accessible from a mixin on WorldRenderer itself.
 */
@Mixin(WorldRenderer.class)
public interface WorldRendererBufferBuildersAccessor {
    @Accessor("bufferBuilders")
    BufferBuilderStorage faketils$getBufferBuilders();
}
