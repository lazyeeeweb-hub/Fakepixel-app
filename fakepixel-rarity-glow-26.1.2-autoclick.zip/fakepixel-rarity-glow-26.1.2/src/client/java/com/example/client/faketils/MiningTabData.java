package com.example.client.faketils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Holds Mining-related data parsed from the tablist (mithril/gemstone
 * powder, commissions) - separate from PlayerStats since that's specifically
 * for the stat-bar action-bar/tablist values, and this is Mining-category
 * scoped data reused across several Mining overlays.
 */
public class MiningTabData {

    private static long mithrilPowder = -1;
    private static long gemstonePowder = -1;
    private static List<String> commissions = new ArrayList<>();

    public static void setMithrilPowder(long value) {
        mithrilPowder = value;
    }

    public static long getMithrilPowder() {
        return mithrilPowder;
    }

    public static void setGemstonePowder(long value) {
        gemstonePowder = value;
    }

    public static long getGemstonePowder() {
        return gemstonePowder;
    }

    public static void setCommissions(List<String> lines) {
        commissions = new ArrayList<>(lines);
    }

    public static List<String> getCommissions() {
        return Collections.unmodifiableList(commissions);
    }

    private MiningTabData() {}
}
