package com.example.client.mixin;

import com.example.client.faketils.AccessoryPanelScrollState;
import com.example.client.faketils.TooltipScrollState;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = Mouse.class, priority = 1100)
public class AccessoryPanelWheelMixin {
    @Inject(method = "onMouseScroll", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/Screen;mouseScrolled(DDD)Z"), cancellable = true)
    private void faketils$captureScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (window != client.getWindow().getHandle()) return;
        if (!(client.currentScreen instanceof HandledScreen<?> screen)
                || !screen.getTitle().getString().startsWith("Accessory Bag")) return;
        double x=client.mouse.getX()*client.getWindow().getScaledWidth()/client.getWindow().getWidth();
        double y=client.mouse.getY()*client.getWindow().getScaledHeight()/client.getWindow().getHeight();
        if (TooltipScrollState.scrollAt(screen,x,y,vertical)) {
            ci.cancel();
            return;
        }
        if (AccessoryPanelScrollState.scrollAt(screen,x,y,vertical)) ci.cancel();
    }
}
