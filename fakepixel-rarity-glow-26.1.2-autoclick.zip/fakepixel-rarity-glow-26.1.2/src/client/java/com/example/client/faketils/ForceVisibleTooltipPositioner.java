package com.example.client.faketils;

import net.minecraft.client.gui.tooltip.TooltipPositioner;
import org.joml.Vector2i;
import org.joml.Vector2ic;

public class ForceVisibleTooltipPositioner implements TooltipPositioner {

	private final int mouseX;
	private final int mouseY;

	public ForceVisibleTooltipPositioner(int mouseX, int mouseY) {
		this.mouseX = mouseX;
		this.mouseY = mouseY;
	}

	@Override
	public Vector2ic getPosition(int screenWidth, int screenHeight, int x, int y, int width, int height) {
		int posX = mouseX + 12;
		int posY = mouseY - 12;

		if (posX + width > screenWidth) {
			posX = screenWidth - width;
		}
		if (posX < 0) {
			posX = 0;
		}

		if (posY < 0) {
			posY = 0;
		}
		if (posY + height > screenHeight) {
			posY = screenHeight - height;
			if (posY < 0) {
				posY = 0;
			}
		}

		return new Vector2i(posX, posY);
	}
}
