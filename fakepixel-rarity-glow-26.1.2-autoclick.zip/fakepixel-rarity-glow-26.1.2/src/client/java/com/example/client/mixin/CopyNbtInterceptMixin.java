package com.example.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.client.faketils.CopyNbtMode;

@Mixin(HandledScreen.class)
public class CopyNbtInterceptMixin {

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), cancellable = true)
    private void faketils$interceptForCopy(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
        if (!CopyNbtMode.isActive()) return;

        ci.cancel();

        if (slot == null || !slot.hasStack()) return;

        ItemStack stack = slot.getStack();
        NbtCompound nbt = stack.writeNbt(new NbtCompound());
        String nbtString = nbt.toString();

        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.keyboard.setClipboard(nbtString);
            if (client.player != null) {
                client.player.sendMessage(
                        net.minecraft.text.Text.literal("[Faketils] Copied NBT to clipboard"),
                        true
                );
            }
        }
    }
}
