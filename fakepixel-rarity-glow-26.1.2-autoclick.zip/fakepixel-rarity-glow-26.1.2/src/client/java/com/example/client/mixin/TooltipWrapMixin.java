package com.example.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.tooltip.Tooltip;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import com.example.faketils.FakepixelRarityGlow;

@Mixin(Tooltip.class)
public class TooltipWrapMixin {

	@ModifyConstant(method = "wrapLines", constant = @org.spongepowered.asm.mixin.injection.Constant(intValue = 170))
	private static int faketils$compressWidth(int original) {
		if (!FakepixelRarityGlow.CONFIG.tooltips.compressWidth) return original;

		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null) return original;
		int screenWidth = client.getWindow().getScaledWidth();
		return Math.min(original, Math.max(20, screenWidth - 15));
	}
}
