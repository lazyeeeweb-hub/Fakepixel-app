package com.example.client.faketils;

public class HudEditMode {

        public static final int CENTER_SENTINEL = -9999;

        public enum BarType {
                HEALTH, MANA, DEFENCE, EXP, SPEED, FUEL, COMMISSIONS, MITHRIL_POWDER, GEMSTONE_POWDER, ABILITY_COOLDOWN
        }

        private static boolean active = false;
        private static BarType hoveredBar = null;
        private static BarType draggedBar = null;
        private static int dragOffsetX = 0;
        private static int dragOffsetY = 0;

        public static void toggle() {
                active = !active;
                if (!active) {
                        hoveredBar = null;
                        draggedBar = null;
                }
        }

        public static boolean isActive() {
                return active;
        }

        public static BarType getHoveredBar() {
                return hoveredBar;
        }

        public static void setHoveredBar(BarType type) {
                hoveredBar = type;
        }

        public static BarType getDraggedBar() {
                return draggedBar;
        }

        public static void startDrag(BarType type, int offsetX, int offsetY) {
                draggedBar = type;
                dragOffsetX = offsetX;
                dragOffsetY = offsetY;
        }

        public static void stopDrag() {
                draggedBar = null;
        }

        public static int getDragOffsetX() {
                return dragOffsetX;
        }

        public static int getDragOffsetY() {
                return dragOffsetY;
        }
}
