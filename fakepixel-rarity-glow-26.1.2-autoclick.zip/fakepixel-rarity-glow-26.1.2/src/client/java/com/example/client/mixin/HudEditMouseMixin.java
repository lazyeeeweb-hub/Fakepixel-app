package com.example.client.mixin;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.client.faketils.HudEditMode;

@Mixin(Mouse.class)
public class HudEditMouseMixin {

	@Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
	private void faketils$blockCameraLook(CallbackInfo ci) {
		if (HudEditMode.isActive()) {
			ci.cancel();
		}
	}
}
