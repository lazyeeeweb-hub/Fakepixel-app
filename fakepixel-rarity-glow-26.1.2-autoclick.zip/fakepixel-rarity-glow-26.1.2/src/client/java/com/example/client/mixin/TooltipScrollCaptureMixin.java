package com.example.client.mixin;

import com.example.client.faketils.TooltipScrollState;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class TooltipScrollCaptureMixin {
    @Inject(method = "onMouseScroll", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/Screen;mouseScrolled(DDD)Z"), cancellable = true)
    private void faketils$captureTooltipScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (window != client.getWindow().getHandle()) return;
        Screen screen = client.currentScreen;
        if (screen == null || screen instanceof HandledScreen<?> h && !h.getScreenHandler().getCursorStack().isEmpty()) return;
        double x = client.mouse.getX() * client.getWindow().getScaledWidth() / client.getWindow().getWidth();
        double y = client.mouse.getY() * client.getWindow().getScaledHeight() / client.getWindow().getHeight();
        if (TooltipScrollState.scrollAt(screen, x, y, vertical)) ci.cancel();
    }
}
