package com.example.client.faketils;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import com.example.client.mixin.HandledScreenFocusedSlotAccessor;
import me.shedaniel.autoconfig.AutoConfig;
import com.example.faketils.MissingEnchants;
import com.example.faketils.ModConfig;
import com.example.client.faketils.TooltipScrollState;

import java.util.List;
import java.util.Set;

public class FakepixelRarityGlowClient implements ClientModInitializer {

        private static KeyBinding openConfigKey;
        private static KeyBinding toggleGlowKey;
        private static KeyBinding editHudPositionsKey;

        private static Screen lastScreen = null;
        private static ItemStack lastHoveredStack = ItemStack.EMPTY;
        private static Slot lastHoveredSlot = null;
        private static boolean lastShiftDown = false;

        @Override
        public void onInitializeClient() {
                System.out.println("[FakepixelRarityGlow] Client initialized!");

                StatBarsHud.register();
                DrillFuelHud.register();
                CommissionsHud.register();
                MithrilPowderHud.register();
                GemstonePowderHud.register();
                AbilityCooldownHud.register();
                VillagerTradeBlocker.register();
                ChatFilter.register();
                MiningAbilityNotifier.register();
                JerryGiftEsp.register();
                FaketilsCommands.register();

                ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
                        ModConfig config = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
                        if (!config.visual.goldenEnchantsEnabled) return;

                        for (int i = 0; i < lines.size(); i++) {
                                Text recolored = GoldenEnchants.recolor(lines.get(i));
                                lines.set(i, recolored);
                        }
                });

                ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
                        ModConfig config = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
                        if (!config.tooltips.missingEnchantsEnabled) return;
                        if (!Screen.hasShiftDown()) return;

                        String itemType = MissingEnchants.getItemType(stack);
                        if (itemType == null) return;

                        MissingEnchants.ScanResult scan = MissingEnchants.scanPresentEnchants(lines);
                        if (scan.lastEnchantLineIndex < 0) return;

                        Set<String> missing = MissingEnchants.computeMissing(itemType, scan.presentEnchantIds);
                        if (missing.isEmpty()) return;

                        TextRenderer fr = MinecraftClient.getInstance().textRenderer;
                        int maxWidth = 0;
                        for (Text line : lines) {
                                maxWidth = Math.max(maxWidth, fr.getWidth(line));
                        }

                        List<Text> missingLines = MissingEnchants.buildMissingLines(missing, maxWidth, fr::getWidth);
                        if (missingLines.isEmpty()) return;

                        for (int i = 0; i < missingLines.size(); i++) {
                                lines.add(scan.lastEnchantLineIndex + 1 + i, missingLines.get(i));
                        }
                });

                openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                                "key.faketils.openconfig",
                                InputUtil.Type.KEYSYM,
                                GLFW.GLFW_KEY_UNKNOWN,
                                "category.faketils"
                ));

                toggleGlowKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                                "key.faketils.toggleglow",
                                InputUtil.Type.KEYSYM,
                                GLFW.GLFW_KEY_UNKNOWN,
                                "category.faketils"
                ));

                editHudPositionsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                                "key.faketils.edithudpositions",
                                InputUtil.Type.KEYSYM,
                                GLFW.GLFW_KEY_UNKNOWN,
                                "category.faketils"
                ));

                ClientTickEvents.END_CLIENT_TICK.register(client -> {
                        while (openConfigKey.wasPressed()) {
                                if (client.currentScreen == null) {
                                        client.setScreen(AutoConfig.getConfigScreen(ModConfig.class, null).get());
                                }
                        }
                        while (toggleGlowKey.wasPressed()) {
                                ModConfig config = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
                                config.visual.glowEnabled = !config.visual.glowEnabled;
                                AutoConfig.getConfigHolder(ModConfig.class).save();

                                if (client.player != null) {
                                        client.player.sendMessage(
                                                        net.minecraft.text.Text.literal("[Rarity Glow] " + (config.visual.glowEnabled ? "Enabled" : "Disabled")),
                                                        true
                                        );
                                }
                        }
                        while (editHudPositionsKey.wasPressed()) {
                                HudEditMode.toggle();
                                boolean nowActive = HudEditMode.isActive();

                                long handle = client.getWindow().getHandle();
                                GLFW.glfwSetInputMode(handle, GLFW.GLFW_CURSOR,
                                                nowActive ? GLFW.GLFW_CURSOR_NORMAL : GLFW.GLFW_CURSOR_DISABLED);

                                if (client.player != null) {
                                        client.player.sendMessage(
                                                        net.minecraft.text.Text.literal("[Faketils] HUD Edit Mode " + (nowActive ? "Enabled - drag bars to reposition" : "Disabled")),
                                                        false
                                        );
                                }
                        }

                        Screen currentScreen = client.currentScreen;
                        ItemStack currentHoveredStack = ItemStack.EMPTY;
                        Slot currentHoveredSlot = null;
                        if (currentScreen instanceof HandledScreen<?> handledScreen
                                && handledScreen.getScreenHandler().getCursorStack().isEmpty()) {
                                Slot focusedSlot = ((HandledScreenFocusedSlotAccessor) handledScreen).faketils$getFocusedSlot();
                                if (focusedSlot != null && focusedSlot.hasStack()) {
                                        currentHoveredStack = focusedSlot.getStack(); currentHoveredSlot = focusedSlot;
                                }
                        }
                        boolean shiftDown = Screen.hasShiftDown();
                        boolean screenChanged = currentScreen != lastScreen;
                        boolean hoveredChanged = currentHoveredSlot != lastHoveredSlot
                                || !ItemStack.areEqual(currentHoveredStack, lastHoveredStack);
                        if (screenChanged || hoveredChanged || shiftDown != lastShiftDown) TooltipScrollState.reset();
                        lastScreen = currentScreen; lastHoveredSlot = currentHoveredSlot; lastShiftDown = shiftDown;
                        lastHoveredStack = currentHoveredStack.copy();
                });
        }
}

