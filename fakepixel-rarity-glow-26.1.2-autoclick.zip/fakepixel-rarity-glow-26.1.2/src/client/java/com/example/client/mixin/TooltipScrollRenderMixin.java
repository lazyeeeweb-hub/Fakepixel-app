package com.example.client.mixin;

import com.example.client.faketils.TooltipScrollState;
import com.example.faketils.FakepixelRarityGlow;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.HoveredTooltipPositioner;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.client.item.TooltipData;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.joml.Vector2ic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Mixin(DrawContext.class)
public class TooltipScrollRenderMixin {
    @Shadow private void drawTooltip(TextRenderer renderer, List<TooltipComponent> components,
                                    int x, int y, TooltipPositioner positioner) { throw new AssertionError(); }

    @Inject(method = "drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;Ljava/util/Optional;II)V",
            at = @At("HEAD"), cancellable = true)
    private void faketils$wrapItemTooltip(TextRenderer renderer, List<Text> lines,
            Optional<TooltipData> data, int x, int y, CallbackInfo ci) {
        if (!FakepixelRarityGlow.CONFIG.tooltips.compressWidth || lines.isEmpty()) return;
        int limit = Math.max(1, MinecraftClient.getInstance().getWindow().getScaledWidth() - 8);
        boolean wide = false;
        for (Text line : lines) if (renderer.getWidth(line) > limit) { wide = true; break; }
        if (!wide) return;
        List<TooltipComponent> components = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            List<OrderedText> wrapped = renderer.wrapLines(lines.get(i), limit);
            if (wrapped.isEmpty()) components.add(TooltipComponent.of(lines.get(i).asOrderedText()));
            else for (OrderedText part : wrapped) components.add(TooltipComponent.of(part));
            if (i == 0) data.ifPresent(value -> components.add(TooltipComponent.of(value)));
        }
        drawTooltip(renderer, components, x, y, HoveredTooltipPositioner.INSTANCE);
        ci.cancel();
    }
    @Redirect(method = "drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;IILnet/minecraft/client/gui/tooltip/TooltipPositioner;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/tooltip/TooltipPositioner;getPosition(IIIIII)Lorg/joml/Vector2ic;"))
    private Vector2ic faketils$scrollPosition(TooltipPositioner positioner, int sw, int sh,
            int x, int y, int width, int height) {
        return TooltipScrollState.position(positioner.getPosition(sw, sh, x, y, width, height), sw, sh, x, y, width, height);
    }
}
