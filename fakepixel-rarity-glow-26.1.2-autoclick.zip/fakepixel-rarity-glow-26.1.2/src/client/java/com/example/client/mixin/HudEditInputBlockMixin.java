package com.example.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.client.faketils.HudEditMode;

@Mixin(MinecraftClient.class)
public class HudEditInputBlockMixin {

	@Inject(method = "handleInputEvents", at = @At("HEAD"), cancellable = true)
	private void faketils$blockInputInEditMode(CallbackInfo ci) {
		if (HudEditMode.isActive()) {
			ci.cancel();
		}
	}
}
