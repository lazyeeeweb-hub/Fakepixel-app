package com.example.client.faketils;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SuperpairsSolver {

    private static boolean isFaceDown(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.WHITE_STAINED_GLASS || item == Items.ORANGE_STAINED_GLASS
                || item == Items.MAGENTA_STAINED_GLASS || item == Items.LIGHT_BLUE_STAINED_GLASS
                || item == Items.YELLOW_STAINED_GLASS || item == Items.LIME_STAINED_GLASS
                || item == Items.PINK_STAINED_GLASS || item == Items.GRAY_STAINED_GLASS
                || item == Items.LIGHT_GRAY_STAINED_GLASS || item == Items.CYAN_STAINED_GLASS
                || item == Items.PURPLE_STAINED_GLASS || item == Items.BLUE_STAINED_GLASS
                || item == Items.BROWN_STAINED_GLASS || item == Items.GREEN_STAINED_GLASS
                || item == Items.RED_STAINED_GLASS || item == Items.BLACK_STAINED_GLASS
                || item == Items.WHITE_STAINED_GLASS_PANE || item == Items.ORANGE_STAINED_GLASS_PANE
                || item == Items.MAGENTA_STAINED_GLASS_PANE || item == Items.LIGHT_BLUE_STAINED_GLASS_PANE
                || item == Items.YELLOW_STAINED_GLASS_PANE || item == Items.LIME_STAINED_GLASS_PANE
                || item == Items.PINK_STAINED_GLASS_PANE || item == Items.GRAY_STAINED_GLASS_PANE
                || item == Items.LIGHT_GRAY_STAINED_GLASS_PANE || item == Items.CYAN_STAINED_GLASS_PANE
                || item == Items.PURPLE_STAINED_GLASS_PANE || item == Items.BLUE_STAINED_GLASS_PANE
                || item == Items.BROWN_STAINED_GLASS_PANE || item == Items.GREEN_STAINED_GLASS_PANE
                || item == Items.RED_STAINED_GLASS_PANE || item == Items.BLACK_STAINED_GLASS_PANE;
    }

    private final Map<Integer, ItemStack> knownFaceDownItems = new HashMap<>();
    private final Set<Integer> successfulMatches = new HashSet<>();
    private final Set<Integer> possibleMatches = new HashSet<>();

    private boolean active = false;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
        if (!active) {
            reset();
        }
    }

    public void reset() {
        knownFaceDownItems.clear();
        successfulMatches.clear();
        possibleMatches.clear();
    }

    public void onTick(Map<Integer, ItemStack> gridSlots) {
        successfulMatches.clear();
        possibleMatches.clear();
        knownFaceDownItems.keySet().removeIf(slot -> {
            ItemStack current = gridSlots.get(slot);
            return current == null || current.isEmpty();
        });

        for (Map.Entry<Integer, ItemStack> entry : gridSlots.entrySet()) {
            int slot = entry.getKey();
            ItemStack stack = entry.getValue();
            if (stack == null || stack.isEmpty()) continue;
            if (!isFaceDown(stack)) {
                knownFaceDownItems.put(slot, stack.copy());
            }
        }

        for (Map.Entry<Integer, ItemStack> entry : gridSlots.entrySet()) {
            int slot = entry.getKey();
            ItemStack stack = entry.getValue();
            if (stack == null || stack.isEmpty()) continue;
            if (isFaceDown(stack)) continue;

            int numMatches = 0;
            for (Map.Entry<Integer, ItemStack> other : gridSlots.entrySet()) {
                ItemStack otherStack = other.getValue();
                if (otherStack == null || otherStack.isEmpty()) continue;
                if (isFaceDown(otherStack)) continue;
                if (itemsMatch(stack, otherStack)) numMatches++;
            }

            if (numMatches >= 2 && !successfulMatches.contains(slot)) {
                for (Map.Entry<Integer, ItemStack> other : gridSlots.entrySet()) {
                    int otherSlot = other.getKey();
                    if (otherSlot == slot) continue;
                    ItemStack otherStack = other.getValue();
                    if (otherStack == null || otherStack.isEmpty()) continue;
                    if (isFaceDown(otherStack)) continue;
                    if (itemsMatch(stack, otherStack)) {
                        successfulMatches.add(slot);
                        successfulMatches.add(otherSlot);
                    }
                }
            }
        }

        for (Map.Entry<Integer, ItemStack> entry : gridSlots.entrySet()) {
            int slot = entry.getKey();
            ItemStack stack = entry.getValue();
            if (stack == null || stack.isEmpty()) continue;
            if (!isFaceDown(stack)) continue;
            if (!knownFaceDownItems.containsKey(slot)) continue;
            if (possibleMatches.contains(slot)) continue;

            ItemStack known = knownFaceDownItems.get(slot);
            for (Map.Entry<Integer, ItemStack> other : gridSlots.entrySet()) {
                int otherSlot = other.getKey();
                if (otherSlot == slot) continue;
                ItemStack current = other.getValue();
                if (current == null || current.isEmpty() || !isFaceDown(current)) continue;
                ItemStack otherKnown = knownFaceDownItems.get(otherSlot);
                if (otherKnown != null && itemsMatch(known, otherKnown)) {
                    possibleMatches.add(slot);
                    possibleMatches.add(otherSlot);
                }
            }
        }
    }

    private boolean itemsMatch(ItemStack a, ItemStack b) {
        if (a.getItem() != b.getItem()) return false;
        return a.getName().getString().equals(b.getName().getString());
    }

    public boolean isSuccessfulMatch(int slot) {
        return successfulMatches.contains(slot);
    }

    public boolean isPossibleMatch(int slot) {
        return possibleMatches.contains(slot);
    }

    public int getKnownCount() {
        return knownFaceDownItems.size();
    }
}
