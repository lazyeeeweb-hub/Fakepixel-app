package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.client.faketils.HudEditMode;

@Mixin(InGameHud.class)
public class HudEditCrosshairMixin {

	@Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
	private void faketils$hideCrosshairInEditMode(DrawContext context, CallbackInfo ci) {
		if (HudEditMode.isActive()) {
			ci.cancel();
		}
	}
}
