package com.example.client.faketils;

import com.example.faketils.FakepixelRarityGlow;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.util.ActionResult;

/**
 * Prevents opening the vanilla villager/wandering-trader trade screen
 * client-side. Added as a workaround for a real crash: interacting with
 * villagers triggers a NullPointerException inside a Mixin from
 * fabric-object-builder-api-v1 (TradeOffersTypeAwareBuyForOneEmeraldFactoryMixin)
 * combined with a conflicting MixinExtras version bundled by another
 * installed mod. Since fakepixel's actual trading UI is chest-GUI based
 * anyway, blocking the vanilla trade screen has no real gameplay cost -
 * it just avoids the buggy code path entirely.
 */
public class VillagerTradeBlocker {

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (FakepixelRarityGlow.CONFIG == null || !FakepixelRarityGlow.CONFIG.qol.disableVillagerTrades) {
                return ActionResult.PASS;
            }

            if (entity instanceof MerchantEntity) {
                return ActionResult.FAIL;
            }

            return ActionResult.PASS;
        });
    }
}
