package com.example.client.faketils;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import com.example.faketils.FakepixelRarityGlow;

/**
 * Gift boxes use the configured head ExtraAttributes.id, color, and radius.
 * JerryGiftTargets.findIceBlock() restricts positions to the four ice blocks.
 *
 * Non-waypoints remain normal depth-tested world lines. Waypoints are drawn
 * directly to the final world framebuffer in LAST, after translucent terrain
 * and Fabulous framebuffer composition. Lines are not entity silhouettes:
 * passing getLines() to an outline provider does not create an outline layer.
 */
public class JerryGiftEsp {

    // Own these buffers: never cast context.consumers() or flush other mods'
    // pending layers. Both callbacks run sequentially on the render thread.
    private static final VertexConsumerProvider.Immediate BOX_CONSUMERS =
            VertexConsumerProvider.immediate(new BufferBuilder(256));

    // The public RenderLayer constructor works in Yarn 1.20.1; its private
    // MultiPhase implementation / private-return-type of() overload is unused.
    // Start/end actions run at the actual draw, not when vertices are queued.
    private static final RenderLayer WAYPOINT_LINES = new RenderLayer(
            "faketils_waypoint_lines", VertexFormats.LINES,
            VertexFormat.DrawMode.LINES, 256, false, false,
            JerryGiftEsp::beginWaypointLines, JerryGiftEsp::endWaypointLines) {};

    public static void register() {
        JerryGiftTargets.loadOnce();
        WorldRenderEvents.AFTER_ENTITIES.register(context -> renderBoxes(context, false));
        WorldRenderEvents.LAST.register(context -> renderBoxes(context, true));
    }

    private static void beginWaypointLines() {
        RenderSystem.setShader(GameRenderer::getRenderTypeLinesProgram);
        RenderSystem.lineWidth(2.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        // No target phase: LAST already has the final world framebuffer bound.
    }

    private static void endWaypointLines() {
        // Match the normal world-render defaults before hand/GUI rendering.
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1.0f);
    }

    private static void renderBoxes(WorldRenderContext context, boolean waypoints) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (!FakepixelRarityGlow.CONFIG.island.jerryGiftEspEnabled) return;

        int radius = FakepixelRarityGlow.CONFIG.island.jerryGiftEspRadius;
        Box searchBox = client.player.getBoundingBox().expand(radius);
        var armorStands = client.world.getEntitiesByClass(
                ArmorStandEntity.class, searchBox, stand -> true);
        if (armorStands.isEmpty()) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;
        Vec3d cameraPos = context.camera().getPos();
        RenderLayer layer = waypoints ? WAYPOINT_LINES : RenderLayer.getLines();

        matrices.push();
        try {
            for (ArmorStandEntity stand : armorStands) {
                ItemStack head = stand.getEquippedStack(EquipmentSlot.HEAD);
                if (head.isEmpty()) continue;

                NbtCompound extraAttributes = head.getSubNbt("ExtraAttributes");
                if (extraAttributes == null) continue;

                String targetId = extraAttributes.getString("id");
                float[] color = JerryGiftTargets.getColor(targetId);
                if (color == null) continue;
                if (JerryGiftTargets.showsWaypoint(targetId) != waypoints) continue;

                BlockPos icePos = JerryGiftTargets.findIceBlock(client, stand);
                if (icePos == null) continue;

                Box box = new Box(icePos).offset(
                        -cameraPos.x, -cameraPos.y, -cameraPos.z);
                WorldRenderer.drawBox(
                        matrices, BOX_CONSUMERS.getBuffer(layer), box,
                        color[0], color[1], color[2], 1f);
            }
        } finally {
            try {
                // Flush now, while the selected layer's draw-time state applies.
                // No geometry means draw(layer) is a no-op.
                BOX_CONSUMERS.draw(layer);
            } finally {
                matrices.pop();
            }
        }
    }

    private JerryGiftEsp() {}
}
