package com.example.client.faketils;

import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashSet;
import java.util.Set;

public class GoldenEnchants {

    private static final Set<String> MAX_LEVEL_ENCHANTS = new HashSet<>();

    static {
        String[] entries = {
                "Aiming IV", "Angler VI", "Aqua Affinity I", "Bane of Arthropods VII",
                "Big Brain V", "Blast Protection VII", "Blessing VI", "Caster VI",
                "Cayenne V", "Chance V", "Cleave VI", "Counter-Strike V", "Critical VII",
                "Cubism VI", "Charm V", "Corruption V", "Delicate V", "Depth Strider III",
                "Divine Gift III", "Dragon Hunter V", "Dragon Tracer V", "Efficiency X",
                "Ender Slayer VII", "Execute VI", "Experience IV", "Feather Falling X",
                "Fire Aspect III", "Fire Protection VII", "First Strike V", "Flame II",
                "Fortune IV", "Frail VI", "Frost Walker II", "Ferocious Mana X",
                "Giant Killer VII", "Growth VII", "Harvesting VI", "Hardened Mana X",
                "Impaling III", "Infinite Quiver X", "Knockback II", "Lethality VI",
                "Life Steal V", "Looting V", "Luck VII", "Luck of the Sea VI", "Lure VI",
                "Magnet VI", "Mana Steal III", "Mana Vampire X", "Overload V",
                "Piercing I", "Piscary VI", "Power VII", "Pristine V",
                "Projectile Protection VII", "Prosecute VI", "Protection VII", "Punch II",
                "Rainbow II", "Rejuvenate V", "Replenish I", "Respiration III",
                "Respite V", "Scavenger V", "Sharpness VII", "Silk Touch I",
                "Smarty Pants V", "Smelting Touch I", "Smite VII", "Snipe IV",
                "Spiked Hook VI", "Sugar Rush III", "Syphon V", "Smoldering V",
                "Strong Mana X", "Tabasco III", "Telekinesis I", "Thorns III",
                "Thunderbolt VI", "Thunderlord VII", "Titan Killer VII", "Triple-Strike V",
                "True Protection I", "Turbo-Cacti V", "Turbo-Cane V", "Turbo-Carrot V",
                "Turbo-Cocoa V", "Turbo-Melon V", "Turbo-Mushrooms V", "Turbo-Potato V",
                "Turbo-Pumpkin V", "Turbo-Warts V", "Turbo-Wheat V", "Vampirism VI",
                "Venomous VI", "Vicious V",
                "Compact X", "Cultivating X", "Expertise X", "Hecatomb X", "Champion X",
                "Ultimate Wise V"
        };
        for (String e : entries) {
            MAX_LEVEL_ENCHANTS.add(e);
        }
    }

    /**
     * Given a tooltip line, checks it for one or more comma-separated enchant
     * names (e.g. "Critical V, Cubism V, Ender Slayer V"). Any segment that
     * exactly matches a known max-level enchant gets recolored gold; other
     * segments and separators are preserved as-is.
     */
    public static Text recolor(Text line) {
        String plain = line.getString();
        if (plain.isEmpty()) return line;
        java.util.List<int[]> ranges = new java.util.ArrayList<>();
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("[^,]+").matcher(plain);
        while (matcher.find()) {
            int start = matcher.start(), end = matcher.end();
            while (start < end && Character.isWhitespace(plain.charAt(start))) start++;
            while (end > start && Character.isWhitespace(plain.charAt(end - 1))) end--;
            if (MAX_LEVEL_ENCHANTS.contains(plain.substring(start, end))) ranges.add(new int[]{start, end});
        }
        if (ranges.isEmpty()) return line;
        MutableText result = Text.literal("");
        int[] offset = {0};
        line.<Void>visit((style, chunk) -> {
            int begin = offset[0], end = begin + chunk.length(), cursor = begin;
            for (int[] range : ranges) {
                int a = Math.max(begin, range[0]), b = Math.min(end, range[1]);
                if (a >= b) continue;
                if (cursor < a) result.append(Text.literal(chunk.substring(cursor - begin, a - begin)).setStyle(style));
                result.append(Text.literal(chunk.substring(a - begin, b - begin)).setStyle(style.withColor(Formatting.GOLD)));
                cursor = b;
            }
            if (cursor < end) result.append(Text.literal(chunk.substring(cursor - begin)).setStyle(style));
            offset[0] = end;
            return java.util.Optional.empty();
        }, net.minecraft.text.Style.EMPTY);
        return result;
    }
}
