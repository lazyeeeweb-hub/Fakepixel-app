package com.example.client.faketils;

import com.example.faketils.FakepixelRarityGlow;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.joml.Vector2i;
import org.joml.Vector2ic;

public class TooltipScrollState {
    private static Screen owner;
    private static int mouseX, mouseY, baseY, screenHeight, tooltipHeight;
    private static float target, current;
    private static long lastRender, lastTick;

    public static Vector2ic position(Vector2ic base, int sw, int sh, int x, int y, int width, int height) {
        Screen screen = MinecraftClient.getInstance().currentScreen;
        if (screen == null || !FakepixelRarityGlow.CONFIG.tooltips.scrollEnabled || height <= sh - 8) {
            reset(); return base;
        }
        long now = System.nanoTime();
        boolean changed = owner != screen || mouseX != x || mouseY != y || baseY != base.y()
                || screenHeight != sh || tooltipHeight != height || now - lastRender > 250_000_000L;
        int min = sh - 4 - height - base.y(), max = 4 - base.y();
        if (changed) { target = current = max; lastTick = now; }
        owner = screen; mouseX = x; mouseY = y; baseY = base.y(); screenHeight = sh; tooltipHeight = height;
        target = Math.max(min, Math.min(max, target)); current = Math.max(min, Math.min(max, current));
        float dt = Math.min(.25f, Math.max(0f, (now - lastTick) / 1_000_000_000f));
        int smooth = Math.max(1, Math.min(100, FakepixelRarityGlow.CONFIG.tooltips.scrollSmoothness));
        current += (target - current) * (1f - (float)Math.exp(-dt * (2f + smooth * .18f)));
        lastTick = lastRender = now;
        return new Vector2i(base.x(), base.y() + Math.round(current));
    }
    public static boolean scrollAt(Screen screen, double x, double y, double amount) {
        if (!FakepixelRarityGlow.CONFIG.tooltips.scrollEnabled || owner != screen
                || System.nanoTime() - lastRender > 250_000_000L || Math.abs(x - mouseX) > 1
                || Math.abs(y - mouseY) > 1 || !Double.isFinite(amount) || amount == 0) return false;
        int min = screenHeight - 4 - tooltipHeight - baseY, max = 4 - baseY;
        int step = Math.max(1, Math.min(50, FakepixelRarityGlow.CONFIG.tooltips.scrollStepPixels));
        float next = (float)Math.max(min, Math.min(max, target + amount * step));
        if (next == target) return false;
        target = next;
        return true;
    }
    public static void reset() { owner = null; target = current = 0; lastRender = lastTick = 0; }
}
