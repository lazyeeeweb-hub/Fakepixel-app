package com.example.client.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fakepixel (and other 1.8.9-origin servers) never expected an off-hand
 * interaction packet at all, since off-hand didn't exist pre-1.9. Modern
 * clients still fire it on every right-click alongside the main-hand
 * interaction (confirmed: Minecraft calls interactBlock separately per
 * hand, main hand first). With nothing in the off-hand slot this produces
 * a purely client-side "ghost" effect - a shield-block animation with no
 * real server backing, and a spurious quick-equip attempt when clicking
 * server-side custom-head GUI blocks. Cancelling the off-hand call when
 * it's empty removes both symptoms without touching main-hand interaction
 * at all, which fires as a fully separate call.
 */
@Mixin(ClientPlayerInteractionManager.class)
public class EmptyOffhandInteractMixin {

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void faketils$blockEmptyOffhandInteract(ClientPlayerEntity player, Hand hand,
            BlockHitResult hitResult, CallbackInfoReturnable<ActionResult> cir) {
        if (hand == Hand.OFF_HAND && player.getOffHandStack().isEmpty()) {
            cir.setReturnValue(ActionResult.PASS);
        }
    }
}
