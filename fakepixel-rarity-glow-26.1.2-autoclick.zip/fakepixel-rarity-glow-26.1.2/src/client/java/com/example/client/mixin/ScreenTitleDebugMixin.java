package com.example.client.mixin;

import com.example.client.faketils.ModLog;
import com.example.faketils.FakepixelRarityGlow;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public class ScreenTitleDebugMixin {
    @Unique private static boolean faketils$hoverHookRegistered;
    @Unique private static String faketils$lastLoggedState = "";

    @Inject(method = "init", at = @At("TAIL"))
    private void faketils$logAnyScreenTitle(CallbackInfo ci) {
        HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
        ModLog.log("[TITLE-DEBUG] opened screen, title=[" + screen.getTitle().getString() + "]");
        if (faketils$hoverHookRegistered) return;
        faketils$hoverHookRegistered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (FakepixelRarityGlow.CONFIG == null
                    || !FakepixelRarityGlow.CONFIG.debug.verboseDebugLogging) return;
            if (!(client.currentScreen instanceof HandledScreen<?> current)
                    || !current.getTitle().getString().startsWith("Chronomatron (")) {
                faketils$lastLoggedState = "";
                return;
            }
            Slot focused = ((HandledScreenFocusedSlotAccessor) current).faketils$getFocusedSlot();
            if (focused == null) {
                faketils$lastLoggedState = "";
                return;
            }
            ItemStack stack = focused.getStack();
            String state = "slot=" + focused.id
                    + " item=" + (stack.isEmpty() ? "EMPTY" : stack.getItem().toString())
                    + " glint=" + (!stack.isEmpty() && stack.hasGlint());
            if (!state.equals(faketils$lastLoggedState)) {
                faketils$lastLoggedState = state;
                ModLog.log("[HOVER-DEBUG] " + state);
            }
        });
    }
}
