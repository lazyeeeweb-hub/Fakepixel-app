package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import com.example.client.faketils.CopyNbtMode;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.client.faketils.ChronomatronSolver;
import com.example.client.faketils.ModLog;
import com.example.faketils.FakepixelRarityGlow;

@Mixin(HandledScreen.class)
public class ChronomatronSolverMixin {

	private static final ChronomatronSolver SOLVER = new ChronomatronSolver();
	private static final int HIGHLIGHT_COLOR = 0x8000FF00;
	private static final int CHEST_CLOCK_SLOT = 49;
	private static boolean tickHookRegistered = false;
	private static boolean wasClockPresent = true;
	@Unique private boolean faketils$advanceAfterClick;

	private static final long MIN_CLICK_DELAY_MS = 500;
	private static final int REQUIRED_STABLE_TICKS = 3;

	private static int stableTickCount = 0;
	private static String lastSeenExpected = null;
	private static int lastSeenTargetSlot = -1;

	private static boolean isNoteSlot(int slotId) {
		return slotId >= 9 && slotId <= 37;
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void faketils$registerTickHook(CallbackInfo ci) {
		if (tickHookRegistered) return;
		tickHookRegistered = true;

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (!(client.currentScreen instanceof HandledScreen<?> screen)) {
				SOLVER.setActive(false);
				return;
			}

			String title = screen.getTitle().getString();
			if (!title.startsWith("Chronomatron (")) {
				if (SOLVER.isActive()) {
					ModLog.log("[SOLVER] deactivating, left Chronomatron screen");
				}
				SOLVER.setActive(false);
				return;
			}

			if (!SOLVER.isActive()) {
				ModLog.log("[SOLVER] activating, title=" + title);
				wasClockPresent = true;
			}
			SOLVER.setActive(true);

			var slots = screen.getScreenHandler().slots;
			if (CHEST_CLOCK_SLOT >= slots.size()) return;

			ItemStack clockCheck = slots.get(CHEST_CLOCK_SLOT).getStack();
			boolean isClock = !clockCheck.isEmpty() && clockCheck.getItem() == Items.CLOCK;

			if (isClock && !wasClockPresent) {
				SOLVER.beginSolvePhase();
				stableTickCount = 0;
				lastSeenExpected = null;
				lastSeenTargetSlot = -1;
				ModLog.log("[SOLVER] -> SHOW (clock appeared), sequence=" + SOLVER.getSequenceSnapshot());
			} else if (!isClock && wasClockPresent) {
				SOLVER.beginNewRound();
				stableTickCount = 0;
				lastSeenExpected = null;
				lastSeenTargetSlot = -1;
				ModLog.log("[SOLVER] -> REMEMBER (new round)");
			}
			wasClockPresent = isClock;

			if (!isClock) {
				int glintSlot = -1;
				Item glintItem = null;
				for (int i = 9; i <= 37 && i < slots.size(); i++) {
					ItemStack stack = slots.get(i).getStack();
					if (!stack.isEmpty() && stack.hasGlint()) {
						glintSlot = i;
						glintItem = stack.getItem();
						break;
					}
				}

				int sizeBefore = SOLVER.getSequenceSize();
				SOLVER.onTickReveal(glintSlot, glintItem);
				int sizeAfter = SOLVER.getSequenceSize();
				if (sizeAfter > sizeBefore) {
					ModLog.log("[REVEAL] recorded new note item=" + glintItem
							+ " slot=" + glintSlot
							+ " sequence=" + SOLVER.getSequenceSnapshot());
				}
			}

			// --- auto-click ---
			if (FakepixelRarityGlow.CONFIG.solvers.chronomatronAutoSolve
					&& SOLVER.getState() == ChronomatronSolver.State.SHOW) {

				long now = System.currentTimeMillis();
				String expected = SOLVER.getExpectedColor();

				if (expected == null) {
					stableTickCount = 0;
					lastSeenExpected = null;
					lastSeenTargetSlot = -1;
				} else {
					int targetSlot = -1;
					for (int i = 9; i <= 37 && i < slots.size(); i++) {
						ItemStack stack = slots.get(i).getStack();
						if (!stack.isEmpty() && expected.equals(ChronomatronSolver.colorFamily(stack.getItem()))) {
							targetSlot = i;
							break;
						}
					}

					if (targetSlot != -1 && expected.equals(lastSeenExpected) && targetSlot == lastSeenTargetSlot) {
						stableTickCount++;
					} else {
						stableTickCount = (targetSlot != -1) ? 1 : 0;
					}
					lastSeenExpected = expected;
					lastSeenTargetSlot = targetSlot;

					boolean stableEnough = stableTickCount >= REQUIRED_STABLE_TICKS;

					if (targetSlot != -1 && stableEnough
							&& SOLVER.shouldAutoClickNow(now, MIN_CLICK_DELAY_MS)
							&& client.player != null && client.interactionManager != null) {
						int syncId = screen.getScreenHandler().syncId;
						client.interactionManager.clickSlot(syncId, targetSlot, 0, SlotActionType.PICKUP, client.player);
						SOLVER.markAutoClicked(now);
						SOLVER.advance();
						stableTickCount = 0;
						lastSeenExpected = null;
						lastSeenTargetSlot = -1;
						ModLog.log("[AUTOCLICK] fired click on slot=" + targetSlot + " expected=" + expected
								+ " -> solvedCount now " + SOLVER.getSolvedCount());
					}
				}
			}
		});
	}

	@Inject(
		method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
		at = @At("HEAD"), cancellable = true)
	private void faketils$onSlotClicked(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
		faketils$advanceAfterClick = false;
		if (!SOLVER.isActive() || CopyNbtMode.isActive()) return;
		if (SOLVER.getState() != ChronomatronSolver.State.SHOW || !isNoteSlot(slotId) || slot == null
				|| actionType != SlotActionType.PICKUP || button != 0 || slot.getStack().isEmpty()) return;
		if (!SOLVER.matchesExpected(slot.getStack().getItem())) {
			if (com.example.faketils.FakepixelRarityGlow.CONFIG.solvers.chronomatronMispressBlock) ci.cancel();
			return;
		}
		faketils$advanceAfterClick = true;
	}

	@Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V", at = @At("TAIL"))
	private void faketils$advanceAfterClick(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
		if (!faketils$advanceAfterClick) return;
		faketils$advanceAfterClick = false;
		if (!CopyNbtMode.isActive() && SOLVER.isActive()) SOLVER.advance();
	}

	@Inject(method = "drawSlot", at = @At("HEAD"))
	private void faketils$highlightNote(DrawContext context, Slot slot, CallbackInfo ci) {
		if (!SOLVER.isActive()) return;
		if (SOLVER.getState() != ChronomatronSolver.State.SHOW) return;
		if (!isNoteSlot(slot.id)) return;

		String expected = SOLVER.getExpectedColor();
		if (expected == null) return;

		if (expected.equals(ChronomatronSolver.colorFamily(slot.getStack().getItem()))) {
			context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, HIGHLIGHT_COLOR);
		}
	}
}
