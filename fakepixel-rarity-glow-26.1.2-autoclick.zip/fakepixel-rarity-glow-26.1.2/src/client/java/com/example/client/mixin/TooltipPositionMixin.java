package com.example.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.tooltip.HoveredTooltipPositioner;
import org.joml.Vector2i;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.faketils.FakepixelRarityGlow;

@Mixin(HoveredTooltipPositioner.class)
public class TooltipPositionMixin {

	@Inject(method = "preventOverflow", at = @At("HEAD"), cancellable = true)
	private void faketils$forceVisible(int screenWidth, int screenHeight, Vector2i pos, int width, int height, CallbackInfo ci) {
		if (!FakepixelRarityGlow.CONFIG.tooltips.forceVisible) return;

		if (FakepixelRarityGlow.CONFIG.tooltips.smartCentering) {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client != null) {
				int mouseX = (int) (client.mouse.getX() * client.getWindow().getScaledWidth() / client.getWindow().getWidth());
				int mouseY = (int) (client.mouse.getY() * client.getWindow().getScaledHeight() / client.getWindow().getHeight());

				if (pos.x < 4) {
					pos.x = Math.max(6, Math.min(mouseX - width / 2, screenWidth - width - 6));
					pos.y = mouseY - height - 12;

					if (pos.y < 6) {
						int below = mouseY + 12;
						int belowObstruction = below + height - screenHeight;
						int aboveObstruction = -pos.y;

						if (belowObstruction < aboveObstruction) {
							pos.y = below;
						}
					}
					ci.cancel();
					return;
				} else if (pos.y + height > screenHeight + 2) {
					pos.y = Math.max(screenHeight - height - 4, 4);
					ci.cancel();
					return;
				}
			}
		}

		if (pos.y < 0) {
			pos.y = 0;
		}
		if (pos.y + height > screenHeight) {
			pos.y = Math.max(0, screenHeight - height);
		}

		if (pos.x < 0) {
			pos.x = 0;
		}
		if (pos.x + width > screenWidth) {
			pos.x = Math.max(0, screenWidth - width);
		}

		ci.cancel();
	}
}
