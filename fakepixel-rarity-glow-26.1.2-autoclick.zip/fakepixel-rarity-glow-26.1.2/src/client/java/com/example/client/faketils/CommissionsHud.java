package com.example.client.faketils;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import com.example.client.faketils.HudEditMode.BarType;

import java.util.List;

/**
 * Shows each active Skyblock commission and its completion percentage,
 * color-coded (red under 33%, yellow under 79%, green above), parsed from
 * the tablist by StatBarsHud.scanTabList() into MiningTabData.
 */
public class CommissionsHud {

    private static final int LINE_HEIGHT = 10;

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            if (!FakepixelRarityGlow.CONFIG.mines.commissionsOverlayEnabled) return;

            List<String> commissions = MiningTabData.getCommissions();
            if (commissions.isEmpty()) return;

            drawOverlay(context, client, commissions);
        });
    }

    public static int[] getRect(int screenW, int screenH) {
        ModConfig.MinesSettings m = FakepixelRarityGlow.CONFIG.mines;
        int configX = m.commissionsOverlayX;
        int configY = m.commissionsOverlayY;
        int x = configX >= 0 ? configX : screenW + configX;
        int y = configY >= 0 ? configY : screenH + configY;

        List<String> commissions = MiningTabData.getCommissions();
        int lineCount = Math.max(commissions.size(), 1);

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer fr = client.textRenderer;
        int maxWidth = 0;
        for (String c : commissions) {
            maxWidth = Math.max(maxWidth, fr.getWidth(formatCommission(c)));
        }
        if (maxWidth == 0) maxWidth = fr.getWidth("Commission: 000%");

        return new int[]{ x, y, maxWidth, lineCount * LINE_HEIGHT };
    }

    private static void drawOverlay(DrawContext context, MinecraftClient client, List<String> commissions) {
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int[] rect = getRect(screenW, screenH);

        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        if (v.hudBackgroundEnabled) {
            int alpha = Math.round(v.hudBackgroundOpacity / 100f * 255f);
            int bgColor = (alpha << 24);
            context.fill(rect[0] - 3, rect[1] - 2, rect[0] + rect[2] + 3, rect[1] + rect[3] + 2, bgColor);
        }

        TextRenderer fr = client.textRenderer;
        int y = rect[1];

        for (String commission : commissions) {
            String label = commission.contains(":") ? commission.substring(0, commission.indexOf(':')).trim() : commission;
            String percentStr = extractPercent(commission);

            int x = context.drawTextWithShadow(fr, label + ": ", rect[0], y, 0xFFAAAAAA);
            if (percentStr != null) {
                int color = percentColor(percentStr);
                context.drawTextWithShadow(fr, percentStr + "%", x, y, color);
            }
            y += LINE_HEIGHT;
        }

        if (HudEditMode.isActive() && (HudEditMode.getHoveredBar() == BarType.COMMISSIONS || HudEditMode.getDraggedBar() == BarType.COMMISSIONS)) {
            context.fill(rect[0] - 2, rect[1] - 2, rect[0] + rect[2] + 2, rect[1] + rect[3] + 2, 0x60FFFFFF);
        }
    }

    private static String extractPercent(String commission) {
        int colon = commission.indexOf(':');
        if (colon < 0) return null;
        String rest = commission.substring(colon + 1).replaceAll("[^0-9.]", "").trim();
        return rest.isEmpty() ? null : rest;
    }

    private static int percentColor(String percentStr) {
        try {
            double percent = Double.parseDouble(percentStr);
            if (percent <= 33) return 0xFFFF5555;
            if (percent <= 79) return 0xFFFFFF55;
            return 0xFF55FF55;
        } catch (NumberFormatException e) {
            return 0xFFAAAAAA;
        }
    }

    private static String formatCommission(String commission) {
        String label = commission.contains(":") ? commission.substring(0, commission.indexOf(':')).trim() : commission;
        String percentStr = extractPercent(commission);
        return percentStr != null ? label + ": " + percentStr + "%" : commission;
    }

    private CommissionsHud() {}
}
