package com.example.client.mixin;

import com.example.client.faketils.CopyNbtMode;
import com.example.client.faketils.UltrasequencerSolver;
import com.example.faketils.FakepixelRarityGlow;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public class UltrasequencerSolverMixin {
    @Unique private static final UltrasequencerSolver faketils$solver = new UltrasequencerSolver();
    @Unique private static ScreenHandler faketils$handler;
    @Unique private static String faketils$title;
    @Unique private static int faketils$phase;
    @Unique private static boolean faketils$ready;
    @Unique private static boolean faketils$hook;
    @Unique private boolean faketils$advance;

    @Unique private static void faketils$reset() {
        faketils$solver.setActive(false);
        faketils$handler = null;
        faketils$title = null;
        faketils$phase = 0;
        faketils$ready = false;
    }

    @Unique private static boolean faketils$owns(HandledScreen<?> screen) {
        MinecraftClient client = MinecraftClient.getInstance();
        return faketils$ready && faketils$solver.isActive() && client.currentScreen == screen
                && client.player != null && client.player.currentScreenHandler == faketils$handler
                && screen.getScreenHandler() == faketils$handler
                && screen.getTitle().getString().equals(faketils$title);
    }

    @Unique
    private static void faketils$autoSolve(MinecraftClient client, HandledScreen<?> screen) {
        if (!FakepixelRarityGlow.CONFIG.solvers.ultrasequencerAutoSolve
                || CopyNbtMode.isActive()
                || !faketils$owns(screen)
                || client.interactionManager == null
                || client.player == null) return;

        long now = System.currentTimeMillis();
        if (!faketils$solver.shouldAutoClickNow(now, 500L)) return;

        int slotId = faketils$solver.getNextSlot();
        ScreenHandler handler = screen.getScreenHandler();
        if (slotId < 9 || slotId > 44 || slotId >= handler.slots.size()
                || client.player.currentScreenHandler != handler) return;

        client.interactionManager.clickSlot(handler.syncId, slotId, 0,
                SlotActionType.PICKUP, client.player);
        faketils$solver.markAutoClicked(now);
        faketils$solver.advance();
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void faketils$register(CallbackInfo ci) {
        if (faketils$hook) return;
        faketils$hook = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!(client.currentScreen instanceof HandledScreen<?> screen)
                    || client.player == null || client.world == null
                    || client.player.currentScreenHandler != screen.getScreenHandler()) {
                faketils$reset(); return;
            }
            String title = screen.getTitle().getString();
            if (!title.startsWith("Ultrasequencer (") || !title.endsWith(")")) {
                faketils$reset(); return;
            }
            if (faketils$handler != screen.getScreenHandler() || !title.equals(faketils$title)) {
                faketils$reset();
                faketils$handler = screen.getScreenHandler();
                faketils$title = title;
            }
            faketils$solver.setActive(true);
            var slots = screen.getScreenHandler().slots;
            if (slots.size() <= 49) { faketils$ready = false; faketils$solver.setState(UltrasequencerSolver.State.WAIT); return; }
            ItemStack status = slots.get(49).getStack();
            String text = status.isEmpty() ? "" : status.getName().getString().trim();
            faketils$ready = false;
            if (text.equals("Remember the pattern!")) {
                if (faketils$phase != 1) { faketils$solver.beginNewRound(); faketils$phase = 1; }
                else if (faketils$solver.getState() == UltrasequencerSolver.State.WAIT)
                    faketils$solver.setState(UltrasequencerSolver.State.REMEMBER);
                for (int i = 9; i <= 44 && i < slots.size(); i++) {
                    ItemStack tile = slots.get(i).getStack();
                    if (tile.isEmpty()) continue;
                    String label = tile.getName().getString().trim();
                    if (label.matches("[0-9]{1,2}")) faketils$solver.rememberSlot(i, Integer.parseInt(label));
                }
            } else if (text.startsWith("Timer:")) {
                if (faketils$phase != 2) { faketils$solver.beginSolvePhase(); faketils$phase = 2; }
                else if (faketils$solver.getState() == UltrasequencerSolver.State.WAIT)
                    faketils$solver.setState(UltrasequencerSolver.State.SHOW);
                faketils$ready = faketils$solver.getState() == UltrasequencerSolver.State.SHOW;
            } else faketils$solver.setState(UltrasequencerSolver.State.WAIT);
            faketils$autoSolve(client, screen);
        });
    }

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V", at = @At("HEAD"), cancellable = true)
    private void faketils$beforeClick(Slot slot, int slotId, int button, SlotActionType action, CallbackInfo ci) {
        faketils$advance = false;
        if (!faketils$owns((HandledScreen<?>)(Object)this) || CopyNbtMode.isActive()
                || faketils$solver.getState() != UltrasequencerSolver.State.SHOW || slot == null
                || slotId < 9 || slotId > 44 || action != SlotActionType.PICKUP || button != 0) return;
        if (faketils$solver.matchesExpected(slotId)) faketils$advance = true;
        else if (FakepixelRarityGlow.CONFIG.solvers.ultrasequencerMispressBlock) ci.cancel();
        else faketils$solver.setState(UltrasequencerSolver.State.END);
    }

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V", at = @At("TAIL"))
    private void faketils$afterClick(Slot slot, int slotId, int button, SlotActionType action, CallbackInfo ci) {
        if (!faketils$advance) return;
        faketils$advance = false;
        if (!CopyNbtMode.isActive() && faketils$owns((HandledScreen<?>)(Object)this)) faketils$solver.advance();
    }

    @Inject(method = "drawSlot", at = @At("HEAD"))
    private void faketils$highlight(DrawContext context, Slot slot, CallbackInfo ci) {
        if (faketils$owns((HandledScreen<?>)(Object)this) && faketils$solver.matchesExpected(slot.id))
            context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0x8000FF00);
    }
}
