package com.example.client.faketils;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/** Local-only shortcuts: never sends a server command or changes feature settings. */
public final class FaketilsCommands {
    private static boolean openConfigRequested;

    private FaketilsCommands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(literal("faketils")
                        .executes(context -> requestConfig())
                        .then(literal("config").executes(context -> requestConfig()))
                        .then(literal("status").executes(context -> {
                            ModConfig config = FakepixelRarityGlow.CONFIG;
                            context.getSource().sendFeedback(Text.literal(
                                    "[Faketils] Minecraft 1.20.1 | HUD: " + config.visual.statBarsEnabled
                                            + " | Rarity glow: " + config.visual.glowEnabled
                                            + " | Debug logging: " + config.debug.verboseDebugLogging
                                            + " | /faketils config to open settings"));
                            return 1;
                        }))));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!openConfigRequested) return;
            openConfigRequested = false;
            if (client.player != null) {
                // Delay until chat has closed; opening a screen inside command dispatch
                // would otherwise be immediately undone by ChatScreen.
                client.setScreen(AutoConfig.getConfigScreen(ModConfig.class, null).get());
            }
        });
    }

    private static int requestConfig() {
        openConfigRequested = true;
        return 1;
    }
}
