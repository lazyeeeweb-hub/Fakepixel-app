package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.ScreenHandler;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.Map;

import com.example.client.faketils.SuperpairsSolver;
import com.example.faketils.FakepixelRarityGlow;

@Mixin(HandledScreen.class)
public class SuperpairsSolverMixin {

	private static final SuperpairsSolver SOLVER = new SuperpairsSolver();
	@Unique private static ScreenHandler faketils$pairsHandler;

	private static final int SUCCESSFUL_COLOR = 0x8000FF00;
	private static final int POSSIBLE_COLOR = 0x80FFFF00;

	private static boolean faketils$superpairsDebugOn() {
		return FakepixelRarityGlow.CONFIG.debug.verboseDebugLogging;
	}

	private static boolean isGridSlot(int slotId) {
		return slotId >= 9 && slotId <= 44;
	}

	static {
		if (faketils$superpairsDebugOn()) System.out.println("[SUPERPAIRS-INIT-DEBUG] registering tick hook (static init)");

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			try {
				if (!(client.currentScreen instanceof HandledScreen<?> screen)) {
					SOLVER.setActive(false);
					return;
				}

				String title = screen.getTitle().getString();

				if (!title.startsWith("Superpairs") || title.contains("Stakes")) {
					if (SOLVER.isActive() && faketils$superpairsDebugOn()) {
						System.out.println("[SUPERPAIRS-TICK-DEBUG] deactivating, left screen (title=" + title + ")");
					}
					SOLVER.setActive(false);
					return;
				}

				if (faketils$pairsHandler != screen.getScreenHandler()) {
					SOLVER.setActive(false);
					faketils$pairsHandler = screen.getScreenHandler();
				}
				if (!SOLVER.isActive() && faketils$superpairsDebugOn()) {
					System.out.println("[SUPERPAIRS-TICK-DEBUG] activating, title=" + title);
				}
				SOLVER.setActive(true);

				var slots = screen.getScreenHandler().slots;
				Map<Integer, ItemStack> gridSnapshot = new HashMap<>();
				for (int i = 9; i < slots.size() && i <= 44; i++) {
					gridSnapshot.put(i, slots.get(i).getStack());
				}
				SOLVER.onTick(gridSnapshot);

				if (faketils$superpairsDebugOn() && client.player != null && client.player.age % 20 == 0) {
					System.out.println("[SUPERPAIRS-TICK-DEBUG] alive, knownCount=" + SOLVER.getKnownCount());
				}
			} catch (Throwable t) {
				if (faketils$superpairsDebugOn()) {
					System.out.println("[SUPERPAIRS-TICK-ERROR] exception in tick lambda: " + t);
					t.printStackTrace();
				}
			}
		});
	}

	@Inject(method = "drawSlot", at = @At("HEAD"))
	private void faketils$highlightSuperpairs(DrawContext context, Slot slot, CallbackInfo ci) {
		if (!SOLVER.isActive()) return;
		if (!isGridSlot(slot.id)) return;

		if (SOLVER.isSuccessfulMatch(slot.id)) {
			context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, SUCCESSFUL_COLOR);
		} else if (SOLVER.isPossibleMatch(slot.id)) {
			context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, POSSIBLE_COLOR);
		}
	}
}
