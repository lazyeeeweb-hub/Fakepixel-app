package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.example.client.faketils.CopyNbtMode;

@Mixin(HandledScreen.class)
public class CopyNbtButtonMixin {

    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundHeight;

    private static final Identifier TEXTURE_ON = Identifier.of("faketils", "skyblock/gui/copy_nbt_on.png");
    private static final Identifier TEXTURE_OFF = Identifier.of("faketils", "skyblock/gui/copy_nbt_off.png");

    private int faketils$buttonX() {
        int bx = x - CopyNbtMode.BUTTON_MARGIN - CopyNbtMode.BUTTON_SIZE;
        return bx < 0 ? CopyNbtMode.BUTTON_MARGIN : bx;
    }

    private int faketils$buttonY() {
        return y + backgroundHeight - CopyNbtMode.BUTTON_SIZE;
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void faketils$drawCopyNbtButton(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        int bx = faketils$buttonX();
        int by = faketils$buttonY();

        Identifier texture = CopyNbtMode.isActive() ? TEXTURE_ON : TEXTURE_OFF;
        context.drawTexture(texture, bx, by, 0f, 0f, CopyNbtMode.BUTTON_SIZE, CopyNbtMode.BUTTON_SIZE,
                CopyNbtMode.BUTTON_SIZE, CopyNbtMode.BUTTON_SIZE);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void faketils$clickCopyNbtButton(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        int bx = faketils$buttonX();
        int by = faketils$buttonY();

        if (mouseX >= bx && mouseX <= bx + CopyNbtMode.BUTTON_SIZE
                && mouseY >= by && mouseY <= by + CopyNbtMode.BUTTON_SIZE) {
            CopyNbtMode.toggle();
            cir.setReturnValue(true);
        }
    }
}
