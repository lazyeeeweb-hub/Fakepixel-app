package com.example.client.faketils;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.world.GameMode;
import net.minecraft.util.Identifier;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import com.example.client.faketils.HudEditMode.BarType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StatBarsHud {

    public static final PlayerStats STATS = new PlayerStats();

    private static final Pattern HEALTH_PATTERN =
            Pattern.compile("(?<health>[0-9,]+)/(?<maxHealth>[0-9,]+)\u2764.*");
    private static final Pattern MANA_PATTERN =
            Pattern.compile("(?<mana>[0-9,]+)/(?<maxMana>[0-9,]+)\u270E Mana( ?(?<overflow>-?[0-9,]+)\u02AC)?.*");
    private static final Pattern DEFENSE_PATTERN =
            Pattern.compile("(?<defense>[0-9,]+)\u2747 Defense.*");

    private static final List<String> OTHER_SECTION_HEADERS = List.of(
            "Powders", "\u26CF Powders", "Forges", "Skills:", "Stats:", "Account Info", "Server Info"
    );

    private static final Comparator<PlayerListEntry> TABLIST_ORDER = (a, b) -> {
        boolean aSpec = a.getGameMode() == GameMode.SPECTATOR;
        boolean bSpec = b.getGameMode() == GameMode.SPECTATOR;
        if (aSpec != bSpec) return aSpec ? 1 : -1;

        Team teamA = a.getScoreboardTeam();
        Team teamB = b.getScoreboardTeam();
        String teamNameA = teamA != null ? teamA.getName() : "";
        String teamNameB = teamB != null ? teamB.getName() : "";
        int teamCmp = teamNameA.compareTo(teamNameB);
        if (teamCmp != 0) return teamCmp;

        return a.getProfile().getName().compareTo(b.getProfile().getName());
    };

    private static final int BAR_H = 7;
    private static final float Z_OFFSET = 500f;
    private static String lastActionBarText = "";
    private static int tabScanCounter = 0;
    private static boolean debugDumped = false;

    public static boolean previewMode = false;

    private static boolean verbose() {
        return FakepixelRarityGlow.CONFIG.debug.verboseDebugLogging;
    }

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            if (!FakepixelRarityGlow.CONFIG.visual.statBarsEnabled) return;

            STATS.setExp(client.player.experienceProgress, client.player.experienceLevel);

            tabScanCounter++;
            if (tabScanCounter % 20 == 0) {
                scanTabList(client);
            }

            if (HudEditMode.isActive()) {
                updateEditModeInteraction(client);
            }

            if (!STATS.isValid()) return;

            context.getMatrices().push();
            context.getMatrices().translate(0, 0, Z_OFFSET);
            drawAllBars(context);
            context.getMatrices().pop();
        });
    }

    private static void updateEditModeInteraction(MinecraftClient client) {
        double mouseX = client.mouse.getX() * client.getWindow().getScaledWidth() / client.getWindow().getWidth();
        double mouseY = client.mouse.getY() * client.getWindow().getScaledHeight() / client.getWindow().getHeight();

        BarType dragged = HudEditMode.getDraggedBar();
        if (dragged != null) {
            int newX = (int) Math.round(mouseX) - HudEditMode.getDragOffsetX();
            int newY = (int) Math.round(mouseY) - HudEditMode.getDragOffsetY();
            setBarPosition(dragged, newX, newY);
            HudEditMode.setHoveredBar(dragged);
            return;
        }

        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        BarType hovered = null;
        for (BarType type : BarType.values()) {
            if (!isBarEnabled(type)) continue;
            int[] rect = getBarRect(type, screenW, screenH);
            if (mouseX >= rect[0] && mouseX <= rect[0] + rect[2] && mouseY >= rect[1] && mouseY <= rect[1] + rect[3]) {
                hovered = type;
            }
        }
        HudEditMode.setHoveredBar(hovered);
    }

    private static boolean isBarEnabled(BarType type) {
        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        ModConfig.MinesSettings mn = FakepixelRarityGlow.CONFIG.mines;
        return switch (type) {
            case HEALTH -> v.healthBarEnabled;
            case MANA -> v.manaBarEnabled;
            case DEFENCE -> v.defenceBarEnabled;
            case EXP -> v.expBarEnabled;
            case SPEED -> v.speedBarEnabled;
            case FUEL -> mn.fuelOverlayEnabled;
            case COMMISSIONS -> mn.commissionsOverlayEnabled;
            case MITHRIL_POWDER -> mn.mithrilPowderOverlayEnabled;
            case GEMSTONE_POWDER -> mn.gemstonePowderOverlayEnabled;
            case ABILITY_COOLDOWN -> mn.abilityNotifierEnabled;
        };
    }

    private static void setBarPosition(BarType type, int x, int y) {
        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        ModConfig.MinesSettings mn = FakepixelRarityGlow.CONFIG.mines;
        switch (type) {
            case HEALTH -> { v.healthBarX = x; v.healthBarY = y; }
            case MANA -> { v.manaBarX = x; v.manaBarY = y; }
            case DEFENCE -> { v.defenceBarX = x; v.defenceBarY = y; }
            case EXP -> { v.expBarX = x; v.expBarY = y; }
            case SPEED -> { v.speedBarX = x; v.speedBarY = y; }
            case FUEL -> { mn.fuelOverlayX = x; mn.fuelOverlayY = y; }
            case COMMISSIONS -> { mn.commissionsOverlayX = x; mn.commissionsOverlayY = y; }
            case MITHRIL_POWDER -> { mn.mithrilPowderOverlayX = x; mn.mithrilPowderOverlayY = y; }
            case GEMSTONE_POWDER -> { mn.gemstonePowderOverlayX = x; mn.gemstonePowderOverlayY = y; }
            case ABILITY_COOLDOWN -> { mn.abilityCooldownOverlayX = x; mn.abilityCooldownOverlayY = y; }
        }
    }

    public static int[] getBarRect(BarType type, int screenW, int screenH) {
        switch (type) {
            case FUEL: return DrillFuelHud.getRect(screenW, screenH);
            case COMMISSIONS: return CommissionsHud.getRect(screenW, screenH);
            case MITHRIL_POWDER: return MithrilPowderHud.getRect(screenW, screenH);
            case GEMSTONE_POWDER: return GemstonePowderHud.getRect(screenW, screenH);
            case ABILITY_COOLDOWN: return AbilityCooldownHud.getRect(screenW, screenH);
            default: break;
        }

        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        int configX, configY, length;
        switch (type) {
            case HEALTH -> { configX = v.healthBarX; configY = v.healthBarY; length = v.healthBarLength; }
            case MANA -> { configX = v.manaBarX; configY = v.manaBarY; length = v.manaBarLength; }
            case DEFENCE -> { configX = v.defenceBarX; configY = v.defenceBarY; length = v.defenceBarLength; }
            case EXP -> { configX = v.expBarX; configY = v.expBarY; length = v.expBarLength; }
            default -> { configX = v.speedBarX; configY = v.speedBarY; length = v.speedBarLength; }
        }
        int x = configX >= 0 ? configX : screenW + configX;
        int y = configY >= 0 ? configY : screenH + configY;
        return new int[]{ x - 11, y - 1, Math.max(4, length) + 11, BAR_H + 2 };
    }

    private static void scanTabList(MinecraftClient client) {
        if (client.getNetworkHandler() == null) return;

        List<PlayerListEntry> sorted = new ArrayList<>(client.getNetworkHandler().getPlayerList());
        sorted.sort(TABLIST_ORDER);

        if (verbose() && !debugDumped) {
            debugDumped = true;
            System.out.println("[TAB-SCAN-DEBUG] player list size=" + sorted.size());
            int i = 0;
            for (PlayerListEntry entry : sorted) {
                String raw = entry.getDisplayName() != null ? entry.getDisplayName().getString() : "(null displayName)";
                System.out.println("[TAB-SCAN-DEBUG] entry[" + i + "] profileName=" + entry.getProfile().getName()
                                + " displayName=[" + raw.replace("\n", "\\n") + "]");
                i++;
            }
        }

        boolean readingCommissions = false;
        List<String> commissions = new ArrayList<>();
        boolean mithrilSeen = false;
        boolean gemstoneSeen = false;

        for (PlayerListEntry entry : sorted) {
            if (entry.getDisplayName() == null) continue;
            String raw = entry.getDisplayName().getString();

            String[] lines = raw.split("\n");
            for (String line : lines) {
                String stripped = line.replaceAll("\u00A7[0-9a-fk-or]", "").trim();

                if (stripped.startsWith("Speed: ")) {
                    String speedStr = stripped.substring("Speed: ".length()).replace("\u2726", "").trim();
                    int speed = parseNum(speedStr);
                    if (speed > 0) {
                        STATS.setSpeed(speed);
                    }
                }

                if (stripped.startsWith("Mithril Powder: ")) {
                    MiningTabData.setMithrilPowder(parseNum(stripped.substring("Mithril Powder: ".length())));
                    mithrilSeen = true;
                }

                if (stripped.startsWith("Gemstone Powder: ")) {
                    MiningTabData.setGemstonePowder(parseNum(stripped.substring("Gemstone Powder: ".length())));
                    gemstoneSeen = true;
                }

                if (readingCommissions) {
                    boolean isOtherHeader = false;
                    for (String header : OTHER_SECTION_HEADERS) {
                        if (stripped.equals(header) || stripped.endsWith(header)) {
                            isOtherHeader = true;
                            break;
                        }
                    }
                    if (stripped.isEmpty() || isOtherHeader) {
                        readingCommissions = false;
                    } else {
                        commissions.add(stripped);
                    }
                } else if (stripped.equals("Commissions")) {
                    readingCommissions = true;
                }
            }
        }

        if (!mithrilSeen) {
            MiningTabData.setMithrilPowder(-1);
        }
        if (!gemstoneSeen) {
            MiningTabData.setGemstonePowder(-1);
        }

        MiningTabData.setCommissions(commissions);
    }

    public static void onActionBar(String raw) {
        if (raw.equals(lastActionBarText)) return;
        lastActionBarText = raw;

        if (!raw.contains("\u2764") && !raw.contains("\u270E") && !raw.contains("\u2747")) return;

        String[] sections = raw.split(" {3,}");
        for (String section : sections) {
            String stripped = section.replaceAll("\u00A7[0-9a-fk-or]", "").trim();
            try {
                if (section.contains("\u2764")) {
                    parseHealth(stripped);
                } else if (section.contains("\u2747")) {
                    parseDefense(stripped);
                } else if (section.contains("\u270E")) {
                    parseMana(stripped);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static void parseHealth(String stripped) {
        String cleaned = stripped.replaceAll("\\+[0-9,]+[\u2586\u2585\u2584\u2583\u2582\u2581]", "").trim();
        Matcher m = HEALTH_PATTERN.matcher(cleaned);
        if (m.matches()) {
            STATS.setHealth(parseNum(m.group("health")), parseNum(m.group("maxHealth")));
        }
    }

    private static void parseMana(String stripped) {
        Matcher m = MANA_PATTERN.matcher(stripped);
        if (m.matches()) {
            String ovStr = m.group("overflow");
            STATS.setMana(parseNum(m.group("mana")), parseNum(m.group("maxMana")),
                    ovStr != null ? parseNum(ovStr) : 0);
        }
    }

    private static void parseDefense(String stripped) {
        Matcher m = DEFENSE_PATTERN.matcher(stripped);
        if (m.matches()) {
            STATS.setDefence(parseNum(m.group("defense")));
        }
    }

    private static int parseNum(String s) {
        if (s == null) return 0;
        try {
            return Integer.parseInt(s.replaceAll("[^0-9-]", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    static void drawAllBars(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        if (FakepixelRarityGlow.CONFIG.visual.healthBarEnabled) {
            drawBar(context, BarType.HEALTH, screenW, screenH);
        }
        if (FakepixelRarityGlow.CONFIG.visual.manaBarEnabled) {
            drawBar(context, BarType.MANA, screenW, screenH);
        }
        if (FakepixelRarityGlow.CONFIG.visual.defenceBarEnabled) {
            drawBar(context, BarType.DEFENCE, screenW, screenH);
        }
        if (FakepixelRarityGlow.CONFIG.visual.expBarEnabled) {
            drawBar(context, BarType.EXP, screenW, screenH);
        }
        if (FakepixelRarityGlow.CONFIG.visual.speedBarEnabled) {
            drawBar(context, BarType.SPEED, screenW, screenH);
        }
    }

    /** Keep 2px end caps and tile the native 76px center, clipping the assembled bar. */
    private static void drawBarTexture(DrawContext context, Identifier texture, int x, int y, int width, int visible) {
        final int textureWidth = 80, cap = 2, center = 76;
        int clip = Math.max(0, Math.min(width, visible));
        int left = Math.min(cap, clip);
        if (left > 0) context.drawTexture(texture, x, y, 0f, 0f, left, BAR_H, textureWidth, BAR_H);
        int centerEnd = width - cap;
        for (int dx = cap; dx < Math.min(centerEnd, clip); dx += center) {
            int part = Math.min(center, Math.min(centerEnd, clip) - dx);
            context.drawTexture(texture, x + dx, y, (float) cap, 0f, part, BAR_H, textureWidth, BAR_H);
        }
        int right = Math.min(cap, clip - centerEnd);
        if (right > 0) context.drawTexture(texture, x + centerEnd, y, (float) (textureWidth - cap),
                0f, right, BAR_H, textureWidth, BAR_H);
    }

    private static void drawBar(DrawContext context, BarType type, int screenW, int screenH) {
        int configX;
        int configY;
        int barWidth;
        Identifier icon;
        float r, g, b;
        float fill;
        String label;

        switch (type) {
            case HEALTH -> {
                configX = FakepixelRarityGlow.CONFIG.visual.healthBarX;
                configY = FakepixelRarityGlow.CONFIG.visual.healthBarY;
                barWidth = FakepixelRarityGlow.CONFIG.visual.healthBarLength;
                icon = Identifier.of("faketils", "skyblock/stats/heart.png");
                r = 1f; g = 0f; b = 0f;
                fill = STATS.getMaxHealth() == 0 ? 0f : Math.min(1f, (float) STATS.getHealth() / STATS.getMaxHealth());
                label = STATS.getHealth() + "/" + STATS.getMaxHealth();
            }
            case MANA -> {
                configX = FakepixelRarityGlow.CONFIG.visual.manaBarX;
                configY = FakepixelRarityGlow.CONFIG.visual.manaBarY;
                barWidth = FakepixelRarityGlow.CONFIG.visual.manaBarLength;
                icon = Identifier.of("faketils", "skyblock/stats/mana.png");
                r = 0.075f; g = 0.906f; b = 1f;
                fill = STATS.getMaxMana() == 0 ? 0f : Math.min(1f, (float) STATS.getMana() / STATS.getMaxMana());
                label = STATS.getMana() + "/" + STATS.getMaxMana();
            }
            case DEFENCE -> {
                configX = FakepixelRarityGlow.CONFIG.visual.defenceBarX;
                configY = FakepixelRarityGlow.CONFIG.visual.defenceBarY;
                barWidth = FakepixelRarityGlow.CONFIG.visual.defenceBarLength;
                icon = Identifier.of("faketils", "skyblock/stats/defense.png");
                r = 0.5f; g = 1f; b = 0.5f;
                fill = Math.min(1f, STATS.getDefence() / 1000f);
                label = String.valueOf(STATS.getDefence());
            }
            case EXP -> {
                configX = FakepixelRarityGlow.CONFIG.visual.expBarX;
                configY = FakepixelRarityGlow.CONFIG.visual.expBarY;
                barWidth = FakepixelRarityGlow.CONFIG.visual.expBarLength;
                icon = Identifier.of("faketils", "skyblock/stats/exp.png");
                r = 0.784f; g = 1f; b = 0.561f;
                fill = Math.min(1f, STATS.getExp());
                label = "Lvl " + STATS.getExpLevel();
            }
            default -> {
                configX = FakepixelRarityGlow.CONFIG.visual.speedBarX;
                configY = FakepixelRarityGlow.CONFIG.visual.speedBarY;
                barWidth = FakepixelRarityGlow.CONFIG.visual.speedBarLength;
                icon = Identifier.of("faketils", "skyblock/stats/speed.png");
                r = 1f; g = 1f; b = 1f;
                fill = Math.min(1f, STATS.getSpeed() / 400f);
                label = String.valueOf(STATS.getSpeed());
            }
        }

        int x = configX >= 0 ? configX : screenW + configX;
        int y = configY >= 0 ? configY : screenH + configY;

        Identifier baseTexture = Identifier.of("faketils", "skyblock/stats/bars/size_2_base.png");
        Identifier fillTexture = Identifier.of("faketils", "skyblock/stats/bars/size_2_fill.png");

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        context.drawTexture(icon, x - 11, y - 1, 0, 0, 9, 9, 9, 9);

        barWidth = Math.max(4, barWidth);
        drawBarTexture(context, baseTexture, x, y, barWidth, barWidth);
        float safeFill = Float.isFinite(fill) ? Math.max(0f, Math.min(1f, fill)) : 0f;
        int fillPx = Math.round(barWidth * safeFill);
        if (fillPx > 0) {
            RenderSystem.setShaderColor(r, g, b, 1f);
            try { drawBarTexture(context, fillTexture, x, y, barWidth, fillPx); }
            finally { RenderSystem.setShaderColor(1f, 1f, 1f, 1f); }
        }

        if (!previewMode) {
            TextRenderer fr = MinecraftClient.getInstance().textRenderer;
            int textX = x + barWidth / 2 - fr.getWidth(label) / 2;
            int textColor = (0xFF << 24) | (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
            context.drawTextWithShadow(fr, label, textX, y + 1, textColor);
        }

        if (HudEditMode.isActive() && (HudEditMode.getHoveredBar() == type || HudEditMode.getDraggedBar() == type)) {
            int[] rect = getBarRect(type, screenW, screenH);
            context.fill(rect[0], rect[1], rect[0] + rect[2], rect[1] + rect[3], 0x60FFFFFF);
        }
    }
}
