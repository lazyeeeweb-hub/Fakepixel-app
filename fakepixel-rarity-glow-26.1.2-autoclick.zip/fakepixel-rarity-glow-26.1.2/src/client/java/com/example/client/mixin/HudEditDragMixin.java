package com.example.client.mixin;

import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;

import com.example.client.faketils.HudEditMode;
import com.example.client.faketils.HudEditMode.BarType;
import com.example.client.faketils.StatBarsHud;

@Mixin(Mouse.class)
public class HudEditDragMixin {

	@Inject(method = "onMouseButton", at = @At("HEAD"))
	private void faketils$handleEditModeClick(long window, int button, int action, int mods, CallbackInfo ci) {
		if (!HudEditMode.isActive()) return;
		if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return;

		MinecraftClient client = MinecraftClient.getInstance();

		if (action == GLFW.GLFW_PRESS) {
			BarType hovered = HudEditMode.getHoveredBar();
			if (hovered != null) {
				double mouseX = client.mouse.getX() * client.getWindow().getScaledWidth() / client.getWindow().getWidth();
				double mouseY = client.mouse.getY() * client.getWindow().getScaledHeight() / client.getWindow().getHeight();
				int[] rect = StatBarsHud.getBarRect(hovered, client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
				int offsetX = (int) Math.round(mouseX) - rect[0];
				int offsetY = (int) Math.round(mouseY) - rect[1];
				HudEditMode.startDrag(hovered, offsetX, offsetY);
			}
		} else if (action == GLFW.GLFW_RELEASE) {
			if (HudEditMode.getDraggedBar() != null) {
				HudEditMode.stopDrag();
				me.shedaniel.autoconfig.AutoConfig.getConfigHolder(com.example.faketils.ModConfig.class).save();
			}
		}
	}
}
