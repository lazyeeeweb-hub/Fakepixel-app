package com.example.client.faketils;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import com.example.client.faketils.HudEditMode.BarType;

public class AbilityCooldownHud {

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            if (!FakepixelRarityGlow.CONFIG.mines.abilityNotifierEnabled) return;

            int secondsLeft = MiningAbilityNotifier.getSecondsRemaining();
            if (secondsLeft < 0) return;

            drawOverlay(context, client, secondsLeft);
        });
    }

    public static int[] getRect(int screenW, int screenH) {
        ModConfig.MinesSettings m = FakepixelRarityGlow.CONFIG.mines;
        int x = resolveX(m.abilityCooldownOverlayX, screenW);
        int y = resolveY(m.abilityCooldownOverlayY, screenH);

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer fr = client.textRenderer;
        String preview = "Ability Ready: 000s";
        int width = fr.getWidth(preview);
        return new int[]{ x, y, width, fr.fontHeight };
    }

    private static int resolveX(int configX, int screenW) {
        if (configX == HudEditMode.CENTER_SENTINEL) {
            MinecraftClient client = MinecraftClient.getInstance();
            int width = client.textRenderer.getWidth("Ability Ready: 000s");
            return screenW / 2 - width / 2;
        }
        return configX >= 0 ? configX : screenW + configX;
    }

    private static int resolveY(int configY, int screenH) {
        if (configY == HudEditMode.CENTER_SENTINEL) {
            return screenH / 2 - 12;
        }
        return configY >= 0 ? configY : screenH + configY;
    }

    private static void drawOverlay(DrawContext context, MinecraftClient client, int secondsLeft) {
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int[] rect = getRect(screenW, screenH);

        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        if (v.hudBackgroundEnabled) {
            int alpha = Math.round(v.hudBackgroundOpacity / 100f * 255f);
            int bgColor = (alpha << 24);
            context.fill(rect[0] - 3, rect[1] - 2, rect[0] + rect[2] + 3, rect[1] + rect[3] + 2, bgColor);
        }

        TextRenderer fr = client.textRenderer;
        int x = rect[0];
        int y = rect[1];

        x = context.drawTextWithShadow(fr, "Ability Ready: ", x, y, 0xFFAAAAAA);
        context.drawTextWithShadow(fr, secondsLeft + "s", x, y, 0xFFFFAA00);

        if (HudEditMode.isActive() && (HudEditMode.getHoveredBar() == BarType.ABILITY_COOLDOWN || HudEditMode.getDraggedBar() == BarType.ABILITY_COOLDOWN)) {
            context.fill(rect[0] - 2, rect[1] - 2, rect[0] + rect[2] + 2, rect[1] + rect[3] + 2, 0x60FFFFFF);
        }
    }

    private AbilityCooldownHud() {}
}
