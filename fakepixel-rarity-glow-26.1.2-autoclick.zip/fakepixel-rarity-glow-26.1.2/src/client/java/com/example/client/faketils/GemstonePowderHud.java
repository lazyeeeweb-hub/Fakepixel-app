package com.example.client.faketils;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import com.example.faketils.FakepixelRarityGlow;
import com.example.faketils.ModConfig;
import com.example.client.faketils.HudEditMode.BarType;

public class GemstonePowderHud {

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            if (!FakepixelRarityGlow.CONFIG.mines.gemstonePowderOverlayEnabled) return;

            long powder = MiningTabData.getGemstonePowder();
            if (powder < 0) return;

            drawOverlay(context, client, powder);
        });
    }

    public static int[] getRect(int screenW, int screenH) {
        ModConfig.MinesSettings m = FakepixelRarityGlow.CONFIG.mines;
        int x = resolveX(m.gemstonePowderOverlayX, screenW);
        int y = resolveY(m.gemstonePowderOverlayY, screenH);

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer fr = client.textRenderer;
        String preview = "Gemstone Powder: 0,000,000";
        int width = fr.getWidth(preview);
        return new int[]{ x, y, width, fr.fontHeight };
    }

    private static int resolveX(int configX, int screenW) {
        if (configX == HudEditMode.CENTER_SENTINEL) {
            MinecraftClient client = MinecraftClient.getInstance();
            int width = client.textRenderer.getWidth("Gemstone Powder: 0,000,000");
            return screenW / 2 - width / 2;
        }
        return configX >= 0 ? configX : screenW + configX;
    }

    private static int resolveY(int configY, int screenH) {
        if (configY == HudEditMode.CENTER_SENTINEL) {
            return screenH / 2 + 12;
        }
        return configY >= 0 ? configY : screenH + configY;
    }

    private static void drawOverlay(DrawContext context, MinecraftClient client, long powder) {
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int[] rect = getRect(screenW, screenH);

        ModConfig.VisualSettings v = FakepixelRarityGlow.CONFIG.visual;
        if (v.hudBackgroundEnabled) {
            int alpha = Math.round(v.hudBackgroundOpacity / 100f * 255f);
            int bgColor = (alpha << 24);
            context.fill(rect[0] - 3, rect[1] - 2, rect[0] + rect[2] + 3, rect[1] + rect[3] + 2, bgColor);
        }

        TextRenderer fr = client.textRenderer;
        int x = rect[0];
        int y = rect[1];

        x = context.drawTextWithShadow(fr, "Gemstone Powder: ", x, y, 0xFFAAAAAA);
        context.drawTextWithShadow(fr, String.format("%,d", powder), x, y, 0xFFFF55FF);

        if (HudEditMode.isActive() && (HudEditMode.getHoveredBar() == BarType.GEMSTONE_POWDER || HudEditMode.getDraggedBar() == BarType.GEMSTONE_POWDER)) {
            context.fill(rect[0] - 2, rect[1] - 2, rect[0] + rect[2] + 2, rect[1] + rect[3] + 2, 0x60FFFFFF);
        }
    }

    private GemstonePowderHud() {}
}
