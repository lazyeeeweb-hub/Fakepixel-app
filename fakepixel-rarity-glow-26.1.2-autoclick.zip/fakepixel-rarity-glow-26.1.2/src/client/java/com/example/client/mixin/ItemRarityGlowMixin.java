package com.example.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.faketils.RarityUtil;
import com.example.faketils.FakepixelRarityGlow;

@Mixin(DrawContext.class)
public class ItemRarityGlowMixin {

private static boolean faketils$rarityDebugOn() {
return FakepixelRarityGlow.CONFIG.debug.verboseDebugLogging;
}

@Inject(method = "drawItem(Lnet/minecraft/item/ItemStack;II)V", at = @At("HEAD"))
private void faketils$drawGlowCursor(ItemStack stack, int x, int y, CallbackInfo ci) {
if (!stack.isEmpty() && faketils$rarityDebugOn()) {
System.out.println("[RarityGlow-HOTBAR-DEBUG] 3-arg drawItem: " + stack.getItem() + " at " + x + "," + y);
}
drawGlow(stack, x, y);
}

@Inject(method = "drawItem(Lnet/minecraft/item/ItemStack;III)V", at = @At("HEAD"))
private void faketils$drawGlowSlot(ItemStack stack, int x, int y, int seed, CallbackInfo ci) {
if (!stack.isEmpty() && faketils$rarityDebugOn()) {
System.out.println("[RarityGlow-HOTBAR-DEBUG] 4-arg drawItem: " + stack.getItem() + " at " + x + "," + y);
}
drawGlow(stack, x, y);
}

private void drawGlow(ItemStack stack, int x, int y) {
int color = RarityUtil.getRarityColor(stack);
if (color != 0) {
DrawContext ctx = (DrawContext) (Object) this;
ctx.fill(x, y, x + 16, y + 16, color);
}
}
}
