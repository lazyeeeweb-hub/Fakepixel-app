package com.example.client.faketils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class JerryGiftTargets {

    private static final Path FILE_PATH = Path.of("config", "faketils", "jerry_gift_targets.json");
    private static final Gson GSON = new Gson();

    private static class TargetInfo {
        int rgb;
        boolean showWaypoint;

        TargetInfo(int rgb, boolean showWaypoint) {
            this.rgb = rgb;
            this.showWaypoint = showWaypoint;
        }
    }

    private static Map<String, TargetInfo> targetsById = new LinkedHashMap<>();
    private static boolean loaded = false;

    private static class TargetEntry {
        String id;
        String color;
        Boolean showWaypoint;
    }

    private static class TargetsFile {
        List<TargetEntry> targets;
    }

    public static void loadOnce() {
        if (loaded) return;
        loaded = true;

        try {
            if (!Files.exists(FILE_PATH)) {
                writeDefaultFile();
            }

            try (Reader reader = Files.newBufferedReader(FILE_PATH, StandardCharsets.UTF_8)) {
                TargetsFile parsed = GSON.fromJson(reader, TargetsFile.class);
                Map<String, TargetInfo> result = new LinkedHashMap<>();
                if (parsed != null && parsed.targets != null) {
                    for (TargetEntry entry : parsed.targets) {
                        if (entry.id == null || entry.color == null) continue;
                        Integer rgb = parseHexColor(entry.color);
                        if (rgb == null) continue;
                        boolean showWaypoint = entry.showWaypoint != null && entry.showWaypoint;
                        result.put(entry.id, new TargetInfo(rgb, showWaypoint));
                    }
                }
                targetsById = result;
                System.out.println("[JerryGiftTargets] loaded " + targetsById.size() + " target(s) from " + FILE_PATH);
            }
        } catch (IOException | JsonSyntaxException e) {
            System.out.println("[JerryGiftTargets] failed to load " + FILE_PATH + ": " + e);
            targetsById = defaultTargets();
        }
    }

    public static float[] getColor(String id) {
        TargetInfo info = targetsById.get(id);
        if (info == null) return null;
        float r = ((info.rgb >> 16) & 0xFF) / 255f;
        float g = ((info.rgb >> 8) & 0xFF) / 255f;
        float b = (info.rgb & 0xFF) / 255f;
        return new float[]{ r, g, b };
    }

    public static boolean isKnownTarget(String id) {
        return targetsById.containsKey(id);
    }

    public static boolean showsWaypoint(String id) {
        TargetInfo info = targetsById.get(id);
        return info != null && info.showWaypoint;
    }

    private static Integer parseHexColor(String hex) {
        try {
            String cleaned = hex.startsWith("#") ? hex.substring(1) : hex;
            return Integer.parseInt(cleaned, 16);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Map<String, TargetInfo> defaultTargets() {
        Map<String, TargetInfo> defaults = new LinkedHashMap<>();
        defaults.put("WHITE_GIFT", new TargetInfo(0xFFFFFF, true));
        defaults.put("GREEN_GIFT", new TargetInfo(0x33FF33, true));
        defaults.put("RED_GIFT", new TargetInfo(0xFF3333, true));
        return defaults;
    }

    private static void writeDefaultFile() throws IOException {
        Files.createDirectories(FILE_PATH.getParent());
        String defaultJson = """
                {
                  "targets": [
                    { "id": "WHITE_GIFT", "color": "#FFFFFF", "showWaypoint": true },
                    { "id": "GREEN_GIFT", "color": "#33FF33", "showWaypoint": true },
                    { "id": "RED_GIFT", "color": "#FF3333", "showWaypoint": true }
                  ]
                }
                """;
        Files.writeString(FILE_PATH, defaultJson, StandardCharsets.UTF_8);
    }

    private static boolean isIceFamily(Block block) {
        return block == Blocks.ICE
                || block == Blocks.PACKED_ICE
                || block == Blocks.BLUE_ICE
                || block == Blocks.FROSTED_ICE;
    }

    /**
     * Finds the HIGHEST ice-family block overlapping the given armor
     * stand's real bounding box (expanded by a small margin). Scans top-
     * down and returns the first (i.e. highest) match, since a stand's
     * bounding box spans roughly its full ~2-block height and can overlap
     * both the actual gift ice (near the head, where the gift visually
     * sits) AND unrelated ice/floor blocks near its feet - taking the
     * highest match reliably picks the gift ice instead of the floor.
     * Returns null if no ice-family block is found touching the stand.
     */
    public static BlockPos findIceBlock(MinecraftClient client, ArmorStandEntity stand) {
        Box box = stand.getBoundingBox().expand(0.25);
        int minX = MathHelper.floor(box.minX);
        int maxX = MathHelper.floor(box.maxX);
        int minY = MathHelper.floor(box.minY);
        int maxY = MathHelper.floor(box.maxY);
        int minZ = MathHelper.floor(box.minZ);
        int maxZ = MathHelper.floor(box.maxZ);

        for (int y = maxY; y >= minY; y--) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    var state = client.world.getBlockState(pos);
                    if (isIceFamily(state.getBlock())) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    private JerryGiftTargets() {}
}
