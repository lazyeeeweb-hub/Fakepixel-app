package com.example.client.faketils;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import com.example.faketils.FakepixelRarityGlow;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Watches for the "You used your ... Pickaxe Ability!" chat message and
 * tracks a (hardcoded, matching NEF's own simplification) 120-second
 * cooldown. Exposes live remaining-seconds state for AbilityCooldownHud,
 * and still shows a one-time title when the cooldown finishes.
 */
public class MiningAbilityNotifier {

    private static final Pattern ABILITY_USED_PATTERN =
            Pattern.compile("You used your (.+) Pickaxe Ability!");
    private static final long COOLDOWN_MS = 120_000L;

    private static long readyAtMs = -1;
    private static boolean notifyPending = false;

    public static void register() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!FakepixelRarityGlow.CONFIG.mines.abilityNotifierEnabled) return true;

            Matcher m = ABILITY_USED_PATTERN.matcher(message.getString());
            if (m.find()) {
                readyAtMs = System.currentTimeMillis() + COOLDOWN_MS;
                notifyPending = true;
            }
            return true;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!FakepixelRarityGlow.CONFIG.mines.abilityNotifierEnabled) return;
            if (!notifyPending || readyAtMs < 0) return;
            if (System.currentTimeMillis() < readyAtMs) return;

            if (client.inGameHud != null) {
                client.inGameHud.setTitle(Text.literal("Mining Ability Ready").formatted(Formatting.GOLD));
                client.inGameHud.setSubtitle(Text.literal(""));
                client.inGameHud.setTitleTicks(2, 70, 2);
            }
            notifyPending = false;
        });
    }

    /** Returns seconds remaining on cooldown, or -1 if not on cooldown / never used. */
    public static int getSecondsRemaining() {
        if (readyAtMs < 0) return -1;
        long remainingMs = readyAtMs - System.currentTimeMillis();
        if (remainingMs <= 0) return -1;
        return (int) Math.ceil(remainingMs / 1000.0);
    }

    private MiningAbilityNotifier() {}
}
