package com.example.client.faketils;

public class PlayerStats {

    private int health;
    private int maxHealth;
    private int overflowHealth;

    private int mana;
    private int maxMana;
    private int overflowMana;

    private int defence;
    private int speed = 100;
    private int expLevel;
    private float exp;

    public void setHealth(int health, int maxHealth) {
        this.health = health;
        this.maxHealth = maxHealth;
        this.overflowHealth = Math.max(0, health - maxHealth);
    }

    public void setMana(int mana, int maxMana, int overflowMana) {
        this.mana = mana;
        this.maxMana = maxMana;
        this.overflowMana = overflowMana;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setExp(float exp, int expLevel) {
        this.exp = exp;
        this.expLevel = expLevel;
    }

    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public int getOverflowHealth() { return overflowHealth; }
    public int getMana() { return mana; }
    public int getMaxMana() { return maxMana; }
    public int getOverflowMana() { return overflowMana; }
    public int getDefence() { return defence; }
    public int getSpeed() { return speed; }
    public int getExpLevel() { return expLevel; }
    public float getExp() { return exp; }

    public boolean isValid() {
        return maxHealth > 0 && maxMana > 0;
    }
}
