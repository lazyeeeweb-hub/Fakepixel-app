package com.example.client.mixin;

import com.example.faketils.FakepixelRarityGlow;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AttachedStemBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.FarmlandBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.MushroomPlantBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.StemBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-side only. Block targets:
 *   - Lever (LeverBlock) - outline only, no collision (never had real
 *     collision in vanilla)
 *   - Button (ButtonBlock) - outline only, no collision (same reasoning)
 *   - Glass panes (PaneBlock) - full collision + outline
 *   - Farmland (FarmlandBlock) - outline only, stays walkable
 *   - Small mushroom plant (MushroomPlantBlock) - outline only, stays walkable
 *   - Crops (CropBlock) - outline only, ONLY at max growth stage (uses the
 *     block's own real isMature() check, same as vanilla)
 *   - Cocoa beans (CocoaBlock) - outline only, ONLY at max growth stage
 *   - Melon/pumpkin stems (StemBlock) - outline only, ONLY at max growth
 *     stage (AGE == MAX_AGE, no isMature() helper exists on this class)
 *   - Attached melon/pumpkin stems (AttachedStemBlock) - outline only,
 *     unconditionally full - this block only exists once the gourd has
 *     already grown and attached, it has no age/growth property at all,
 *     so there's no partial-growth state to check
 */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class FullBlockHitboxMixin {

	private static boolean fakepixelrarityglow$isOutlineTarget(BlockState state) {
		if (state == null) return false;

		if (state.getBlock() instanceof CocoaBlock) {
			int age = state.get(CocoaBlock.AGE);
			return age == CocoaBlock.MAX_AGE;
		}

		if (state.getBlock() instanceof CropBlock cropBlock) {
			return cropBlock.isMature(state);
		}

		if (state.getBlock() instanceof StemBlock) {
			int age = state.get(StemBlock.AGE);
			return age == StemBlock.MAX_AGE;
		}

		return state.getBlock() instanceof LeverBlock
				|| state.getBlock() instanceof ButtonBlock
				|| state.getBlock() instanceof FarmlandBlock
				|| state.getBlock() instanceof MushroomPlantBlock
				|| state.getBlock() instanceof PaneBlock
				|| state.getBlock() instanceof AttachedStemBlock;
	}

	private static boolean fakepixelrarityglow$isCollisionTarget(BlockState state) {
		if (state == null) return false;
		return state.getBlock() instanceof PaneBlock;
	}

	@Inject(method = "getRaycastShape", at = @At("HEAD"), cancellable = true)
	private void fakepixelrarityglow$fullRaycast(BlockView world, BlockPos pos, CallbackInfoReturnable<VoxelShape> cir) {
		if (FakepixelRarityGlow.CONFIG == null || !FakepixelRarityGlow.CONFIG.visual.fullBlockHitboxes) return;

		BlockState state = (BlockState) (Object) this;
		if (fakepixelrarityglow$isOutlineTarget(state)) {
			cir.setReturnValue(VoxelShapes.fullCube());
		}
	}

	@Inject(
		method = "getOutlineShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;",
		at = @At("HEAD"),
		cancellable = true
	)
	private void fakepixelrarityglow$fullOutline(BlockView world, BlockPos pos, ShapeContext context, CallbackInfoReturnable<VoxelShape> cir) {
		if (FakepixelRarityGlow.CONFIG == null || !FakepixelRarityGlow.CONFIG.visual.fullBlockHitboxes) return;

		BlockState state = (BlockState) (Object) this;
		if (fakepixelrarityglow$isOutlineTarget(state)) {
			cir.setReturnValue(VoxelShapes.fullCube());
		}
	}

	@Inject(
		method = "getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;",
		at = @At("HEAD"),
		cancellable = true
	)
	private void fakepixelrarityglow$fullCollision(BlockView world, BlockPos pos, ShapeContext context, CallbackInfoReturnable<VoxelShape> cir) {
		if (FakepixelRarityGlow.CONFIG == null || !FakepixelRarityGlow.CONFIG.visual.fullBlockHitboxes) return;

		BlockState state = (BlockState) (Object) this;
		if (fakepixelrarityglow$isCollisionTarget(state)) {
			cir.setReturnValue(VoxelShapes.fullCube());
		}
	}

	@Inject(
		method = "getCullingShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/shape/VoxelShape;",
		at = @At("HEAD"),
		cancellable = true
	)
	private void fakepixelrarityglow$fullCulling(BlockView world, BlockPos pos, CallbackInfoReturnable<VoxelShape> cir) {
		if (FakepixelRarityGlow.CONFIG == null || !FakepixelRarityGlow.CONFIG.visual.fullBlockHitboxes) return;

		BlockState state = (BlockState) (Object) this;
		if (fakepixelrarityglow$isOutlineTarget(state)) {
			cir.setReturnValue(VoxelShapes.empty());
		}
	}
}
