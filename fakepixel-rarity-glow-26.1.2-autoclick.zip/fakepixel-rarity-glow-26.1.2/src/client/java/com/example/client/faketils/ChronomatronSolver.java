package com.example.client.faketils;

import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

public class ChronomatronSolver {

        public enum State {
                REMEMBER,
                SHOW,
                END
        }

        private State state = State.REMEMBER;
        private final List<String> sequence = new ArrayList<>();
        private int solvedCount = 0;
        private int replayPosition = 0;
        private int currentGlintSlot = -1;
        private boolean active = false;

        // --- auto-click tracking ---
        private int lastAutoClickedSolvedCount = -1;
        private long lastAutoClickTimeMs = 0;

        public boolean isActive() {
                return active;
        }

        public void setActive(boolean active) {
                if (!active && this.active) {
                        reset();
                }
                this.active = active;
        }

        public void reset() {
                state = State.REMEMBER;
                sequence.clear();
                solvedCount = 0;
                replayPosition = 0;
                currentGlintSlot = -1;
                lastAutoClickedSolvedCount = -1;
                lastAutoClickTimeMs = 0;
        }

        public State getState() {
                return state;
        }

        public void beginNewRound() {
                state = State.REMEMBER;
                solvedCount = 0;
                replayPosition = 0;
                currentGlintSlot = -1;
                lastAutoClickedSolvedCount = -1;
        }

        public void beginSolvePhase() {
                state = State.SHOW;
                solvedCount = 0;
                lastAutoClickedSolvedCount = -1;
        }

        public void onTickReveal(int glintSlot, Item glintItem) {
                if (state != State.REMEMBER) return;
                if (glintSlot == -1) {
                        currentGlintSlot = -1;
                        return;
                }
                if (glintSlot == currentGlintSlot) return;
                currentGlintSlot = glintSlot;
                String color = colorFamily(glintItem);
                if (!color.isEmpty()) {
                        if (replayPosition < sequence.size()) {
                                replayPosition++;
                        } else {
                                sequence.add(color);
                                replayPosition++;
                        }
                }
        }

        public int getSequenceSize() {
                return sequence.size();
        }

        public String getExpectedColor() {
                if (solvedCount >= sequence.size()) return null;
                return sequence.get(solvedCount);
        }

        public boolean matchesExpected(Item item) {
                String expected = getExpectedColor();
                if (expected == null) return false;
                return expected.equals(colorFamily(item));
        }

        public void advance() {
                if (state != State.SHOW) return;
                if (solvedCount < sequence.size()) {
                        solvedCount++;
                }
                if (solvedCount >= sequence.size()) {
                        state = State.END;
                }
        }

        public int getSolvedCount() {
                return solvedCount;
        }

        public String getSequenceSnapshot() {
                return sequence.toString();
        }

        /**
         * Whether the auto-clicker should fire a click right now. True only if:
         * - we're in SHOW state with a known expected note
         * - we have NOT already auto-clicked for this exact solvedCount value
         * - at least minDelayMs has passed since our last auto-click (paces clicks,
         *   avoids spamming even when not laggy)
         */
        public boolean shouldAutoClickNow(long nowMs, long minDelayMs) {
                if (state != State.SHOW) return false;
                if (getExpectedColor() == null) return false;
                if (lastAutoClickedSolvedCount == solvedCount) return false;
                if (nowMs - lastAutoClickTimeMs < minDelayMs) return false;
                return true;
        }

        /** Call immediately after firing an auto-click, to record it. */
        public void markAutoClicked(long nowMs) {
                lastAutoClickedSolvedCount = solvedCount;
                lastAutoClickTimeMs = nowMs;
        }

        /** How long (ms) since the last auto-click was fired - for the safety timeout check. */
        public long msSinceLastAutoClick(long nowMs) {
                return nowMs - lastAutoClickTimeMs;
        }

        /** Whether we're currently "waiting" on a fired click to be confirmed (solvedCount hasn't moved yet). */
        public boolean isWaitingOnAutoClickConfirmation() {
                return lastAutoClickedSolvedCount == solvedCount && lastAutoClickedSolvedCount != -1;
        }

        public static String colorFamily(Item item) {
                if (item == null) return "";
                String id = item.toString();
                String name = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;

                String[] knownColors = {
                        "white", "orange", "magenta", "light_blue", "yellow", "lime",
                        "pink", "gray", "light_gray", "cyan", "purple", "blue",
                        "brown", "green", "red", "black"
                };
                for (String color : knownColors) {
                        if (name.startsWith(color + "_")) {
                                return color;
                        }
                }
                return name;
        }
}
