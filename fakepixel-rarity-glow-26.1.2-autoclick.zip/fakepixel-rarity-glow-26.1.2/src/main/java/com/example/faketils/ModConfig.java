package com.example.faketils;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

@Config(name = "faketils")
public class ModConfig implements ConfigData {

    @ConfigEntry.Gui.CollapsibleObject(startExpanded = true)
    public VisualSettings visual = new VisualSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public SolverSettings solvers = new SolverSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public QolSettings qol = new QolSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public TooltipSettings tooltips = new TooltipSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public DebugSettings debug = new DebugSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public EventsSettings events = new EventsSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public GardenSettings garden = new GardenSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public MinesSettings mines = new MinesSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public DungeonsSettings dungeons = new DungeonsSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public IslandSettings island = new IslandSettings();

    @ConfigEntry.Gui.CollapsibleObject
    public CrimsonIsleSettings crimsonIsle = new CrimsonIsleSettings();

    public static class VisualSettings {
        @ConfigEntry.Gui.Tooltip
        public int opacityPercent = 60;

        @ConfigEntry.Gui.Tooltip
        public boolean glowEnabled = true;

        @ConfigEntry.Gui.Tooltip
        public boolean goldenEnchantsEnabled = true;

        @ConfigEntry.Gui.Tooltip
        public boolean fullBlockHitboxes = false;

        @ConfigEntry.Gui.Tooltip
        public boolean statBarsEnabled = true;

        @ConfigEntry.Gui.Tooltip
        public boolean healthBarEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int healthBarX = 160;
        @ConfigEntry.Gui.Tooltip
        public int healthBarY = -35;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 20, max = 200)
        public int healthBarLength = 80;

        @ConfigEntry.Gui.Tooltip
        public boolean manaBarEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int manaBarX = 160;
        @ConfigEntry.Gui.Tooltip
        public int manaBarY = -45;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 20, max = 200)
        public int manaBarLength = 80;

        @ConfigEntry.Gui.Tooltip
        public boolean defenceBarEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int defenceBarX = 255;
        @ConfigEntry.Gui.Tooltip
        public int defenceBarY = -55;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 20, max = 200)
        public int defenceBarLength = 80;

        @ConfigEntry.Gui.Tooltip
        public boolean expBarEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int expBarX = 255;
        @ConfigEntry.Gui.Tooltip
        public int expBarY = -45;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 20, max = 200)
        public int expBarLength = 80;

        @ConfigEntry.Gui.Tooltip
        public boolean speedBarEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int speedBarX = 255;
        @ConfigEntry.Gui.Tooltip
        public int speedBarY = -35;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 20, max = 200)
        public int speedBarLength = 80;

        @ConfigEntry.Gui.Tooltip
        public boolean hudBackgroundEnabled = true;
        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 0, max = 100)
        public int hudBackgroundOpacity = 50;
    }

    public static class SolverSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean chronomatronMispressBlock = false;

        @ConfigEntry.Gui.Tooltip
        public boolean chronomatronAutoSolve = false;

        @ConfigEntry.Gui.Tooltip
        public boolean ultrasequencerMispressBlock = false;

        @ConfigEntry.Gui.Tooltip
        public boolean ultrasequencerAutoSolve = false;
    }

    public static class QolSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean disableVillagerTrades = false;

        @ConfigEntry.Gui.Tooltip
        public boolean disableChatSpam = false;
    }

    public static class TooltipSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean forceVisible = true;

        @ConfigEntry.Gui.Tooltip
        public boolean smartCentering = false;

        @ConfigEntry.Gui.Tooltip
        public boolean compressWidth = true;

        @ConfigEntry.Gui.Tooltip
        public boolean scrollEnabled = true;

        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 1, max = 50)
        public int scrollStepPixels = 10;

        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 1, max = 100)
        public int scrollSmoothness = 50;

        @ConfigEntry.Gui.Tooltip
        public boolean missingEnchantsEnabled = true;
    }

    public static class DebugSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean debugMode = false;

        @ConfigEntry.Gui.Tooltip
        public boolean verboseDebugLogging = false;
    }

    public static class EventsSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean eventsPlaceholder = false;
    }

    public static class GardenSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean gardenPlaceholder = false;
    }

    public static class MinesSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean fuelOverlayEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int fuelOverlayX = 76;
        @ConfigEntry.Gui.Tooltip
        public int fuelOverlayY = 15;

        @ConfigEntry.Gui.Tooltip
        public boolean abilityNotifierEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int abilityCooldownOverlayX = -9999;
        @ConfigEntry.Gui.Tooltip
        public int abilityCooldownOverlayY = -9999;

        @ConfigEntry.Gui.Tooltip
        public boolean commissionsOverlayEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int commissionsOverlayX = 10;
        @ConfigEntry.Gui.Tooltip
        public int commissionsOverlayY = 40;

        @ConfigEntry.Gui.Tooltip
        public boolean mithrilPowderOverlayEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int mithrilPowderOverlayX = -9999;
        @ConfigEntry.Gui.Tooltip
        public int mithrilPowderOverlayY = -9999;

        @ConfigEntry.Gui.Tooltip
        public boolean gemstonePowderOverlayEnabled = true;
        @ConfigEntry.Gui.Tooltip
        public int gemstonePowderOverlayX = -9999;
        @ConfigEntry.Gui.Tooltip
        public int gemstonePowderOverlayY = -9999;
    }

    public static class DungeonsSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean dungeonsPlaceholder = false;
    }

    public static class IslandSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean islandPlaceholder = false;

        @ConfigEntry.Gui.Tooltip
        public boolean jerryGiftEspEnabled = false;

        @ConfigEntry.Gui.Tooltip
        @ConfigEntry.BoundedDiscrete(min = 1, max = 16)
        public int jerryGiftEspRadius = 8;
    }

    public static class CrimsonIsleSettings {
        @ConfigEntry.Gui.Tooltip
        public boolean crimsonIslePlaceholder = false;
    }
}
