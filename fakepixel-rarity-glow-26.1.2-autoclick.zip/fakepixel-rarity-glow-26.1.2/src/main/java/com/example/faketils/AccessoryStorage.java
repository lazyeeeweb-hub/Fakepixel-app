package com.example.faketils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Single-file accessory tracker: config/faketils/accessories.json holds
 * every accessory name+rarity ever seen across ANY bag scan, each tagged
 * with an "owned" flag. On a bag scan, any NEW accessory name gets
 * appended with owned=true (seeing it in the bag means you own it). An
 * existing entry not yet marked owned gets flipped to owned=true. Nothing
 * is ever removed automatically. To seed the file with accessories NOT
 * yet owned (so they show as "missing"), hand-add entries directly to the
 * JSON with "owned": false.
 */
public class AccessoryStorage {

    private static final Path FILE_PATH = Path.of("config", "faketils", "accessories.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class Entry {
        public String name;
        public String rarity;
        public boolean owned;
    }

    private static class ListFile {
        List<Entry> accessories;
    }

    private static final Map<String, Entry> data = new LinkedHashMap<>();
    private static boolean loaded = false;

    public static void loadOnce() {
        if (loaded) return;
        loaded = true;

        try {
            if (!Files.exists(FILE_PATH)) {
                writeEmptyFile();
                return;
            }
            try (Reader reader = Files.newBufferedReader(FILE_PATH, StandardCharsets.UTF_8)) {
                ListFile parsed = GSON.fromJson(reader, ListFile.class);
                if (parsed != null && parsed.accessories != null) {
                    for (Entry e : parsed.accessories) {
                        if (e.name == null || e.rarity == null) continue;
                        data.put(e.name, e);
                    }
                }
                System.out.println("[AccessoryStorage] loaded " + data.size() + " from " + FILE_PATH);
            }
        } catch (IOException | JsonSyntaxException e) {
            System.out.println("[AccessoryStorage] failed to load " + FILE_PATH + ": " + e);
        }
    }

    private static void writeEmptyFile() throws IOException {
        Files.createDirectories(FILE_PATH.getParent());
        Files.writeString(FILE_PATH, "{\n  \"accessories\": []\n}\n", StandardCharsets.UTF_8);
    }

    public static void noteSeen(String name, String rarity) {
        loadOnce();

        Entry entry = data.get(name);
        boolean changed = false;

        if (entry == null) {
            entry = new Entry();
            entry.name = name;
            entry.rarity = rarity;
            entry.owned = true;
            data.put(name, entry);
            changed = true;
        } else if (!entry.owned) {
            entry.owned = true;
            changed = true;
        }

        if (changed) {
            flush();
        }
    }

    private static void flush() {
        try {
            Files.createDirectories(FILE_PATH.getParent());
            ListFile out = new ListFile();
            out.accessories = new ArrayList<>(data.values());
            Files.writeString(FILE_PATH, GSON.toJson(out), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("[AccessoryStorage] failed to write " + FILE_PATH + ": " + e);
        }
    }

    public static List<Entry> getMissing() {
        loadOnce();
        List<Entry> missing = new ArrayList<>();
        for (Entry e : data.values()) {
            if (!e.owned) missing.add(e);
        }
        missing.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        return missing;
    }

    private AccessoryStorage() {}
}
