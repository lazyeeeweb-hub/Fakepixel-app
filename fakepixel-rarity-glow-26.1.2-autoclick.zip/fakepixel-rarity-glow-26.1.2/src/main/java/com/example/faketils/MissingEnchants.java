package com.example.faketils;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.ToIntFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MissingEnchants {

    private static final Pattern ROMAN_SUFFIX = Pattern.compile(
            "^(.*?)\\s+(X|IX|VIII|VII|VI|V|IV|III|II|I)$"
    );

    public static String getItemType(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        Item item = stack.getItem();

        if (item instanceof SwordItem) return "SWORD";
        if (item instanceof RangedWeaponItem) return "BOW";
        if (item instanceof PickaxeItem) return "PICKAXE";
        if (item instanceof AxeItem) return "AXE";
        if (item instanceof ShovelItem) return "SHOVEL";
        if (item instanceof HoeItem) return "FARMING_TOOL";
        if (item instanceof FishingRodItem) return "FISHING_ROD";

        if (item instanceof ArmorItem armor) {
            switch (armor.getSlotType()) {
                case HEAD: return "HELMET";
                case CHEST: return "CHESTPLATE";
                case LEGS: return "LEGGINGS";
                case FEET: return "BOOTS";
                default: return null;
            }
        }

        return null;
    }

    public static Set<String> extractEnchantIds(String plainLine) {
        Set<String> found = new HashSet<>();
        if (plainLine == null || plainLine.isEmpty()) return found;

        String[] segments = plainLine.contains(",") ? plainLine.split(", ") : new String[]{plainLine};
        for (String seg : segments) {
            Matcher m = ROMAN_SUFFIX.matcher(seg.trim());
            if (!m.matches()) continue;
            String name = m.group(1).trim();
            if (name.isEmpty()) continue;
            found.add(toEnchantId(name));
        }
        return found;
    }

    private static String toEnchantId(String displayName) {
        return displayName.trim().toLowerCase().replace(" ", "_").replace("-", "_");
    }

    public static ScanResult scanPresentEnchants(List<Text> lines) {
        Set<String> present = new HashSet<>();
        int lastEnchantLine = -1;
        for (int i = 0; i < lines.size(); i++) {
            Set<String> found = extractEnchantIds(lines.get(i).getString());
            if (!found.isEmpty()) {
                present.addAll(found);
                lastEnchantLine = i;
            }
        }
        return new ScanResult(present, lastEnchantLine);
    }

    public static class ScanResult {
        public final Set<String> presentEnchantIds;
        public final int lastEnchantLineIndex;

        public ScanResult(Set<String> presentEnchantIds, int lastEnchantLineIndex) {
            this.presentEnchantIds = presentEnchantIds;
            this.lastEnchantLineIndex = lastEnchantLineIndex;
        }
    }

    public static Set<String> computeMissing(String itemType, Set<String> present) {
        Set<String> applicable = EnchantData.ITEM_TYPE_ENCHANTS.get(itemType);
        if (applicable == null) return new HashSet<>();

        Set<String> missing = new HashSet<>();
        for (String id : applicable) {
            if (id.startsWith("ultimate_")) continue;
            if (present.contains(id)) continue;
            missing.add(id);
        }

        for (Set<String> pool : EnchantData.ENCHANT_POOLS) {
            boolean poolSatisfied = false;
            for (String id : pool) {
                if (present.contains(id)) {
                    poolSatisfied = true;
                    break;
                }
            }
            if (poolSatisfied) {
                missing.removeAll(pool);
            }
        }

        return missing;
    }

    /**
     * Builds one or more "Missing: ..." tooltip lines, wrapped so no line's
     * measured pixel width (via the caller-supplied widthMeasurer, since
     * this class has no access to client-only rendering code) exceeds
     * maxWidth. Continuation lines carry no "Missing:" label, just more
     * names.
     */
    public static List<Text> buildMissingLines(Set<String> missingIds, int maxWidth, ToIntFunction<String> widthMeasurer) {
        List<Text> result = new ArrayList<>();
        if (missingIds.isEmpty()) return result;
        if (maxWidth <= 0) maxWidth = 150;

        List<String> names = new ArrayList<>();
        for (String id : missingIds) {
            names.add(EnchantData.DISPLAY_NAMES.getOrDefault(id, id));
        }

        StringBuilder currentPlain = new StringBuilder("Missing: ");
        List<String> currentNames = new ArrayList<>();
        boolean firstLine = true;

        for (int i = 0; i < names.size(); i++) {
            String candidateSuffix = names.get(i) + (i < names.size() - 1 ? ", " : "");
            String testPlain = currentPlain + candidateSuffix;
            int testWidth = widthMeasurer.applyAsInt(testPlain);

            if (testWidth > maxWidth && !currentNames.isEmpty()) {
                result.add(buildLineText(currentNames, firstLine));
                firstLine = false;
                currentNames = new ArrayList<>();
                currentPlain = new StringBuilder();
            }

            currentNames.add(names.get(i));
            currentPlain.append(names.get(i));
            if (i < names.size() - 1) currentPlain.append(", ");
        }

        if (!currentNames.isEmpty()) {
            result.add(buildLineText(currentNames, firstLine));
        }

        return result;
    }

    private static Text buildLineText(List<String> names, boolean withLabel) {
        MutableText line = withLabel
                ? Text.literal("Missing: ").formatted(Formatting.RED)
                : Text.literal("").formatted(Formatting.GRAY);

        for (int i = 0; i < names.size(); i++) {
            line.append(Text.literal(names.get(i)).formatted(Formatting.GRAY));
            if (i < names.size() - 1) {
                line.append(Text.literal(", ").formatted(Formatting.GRAY));
            }
        }
        return line;
    }

    private MissingEnchants() {}
}
