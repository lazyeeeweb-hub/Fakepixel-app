package com.example.faketils;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import me.shedaniel.autoconfig.AutoConfig;

import java.util.LinkedHashMap;
import java.util.Map;

public class RarityUtil {

	private static final Map<String, String> RARITY_COLORS = new LinkedHashMap<>();
	static {
		RARITY_COLORS.put("VERY SPECIAL", "dark_red");
		RARITY_COLORS.put("ADMIN", "dark_red");
		RARITY_COLORS.put("UNOBTAINABLE", "dark_red");
		RARITY_COLORS.put("SPECIAL", "red");
		RARITY_COLORS.put("DIVINE", "aqua");
		RARITY_COLORS.put("MYTHIC", "light_purple");
		RARITY_COLORS.put("LEGENDARY", "gold");
		RARITY_COLORS.put("EPIC", "dark_purple");
		RARITY_COLORS.put("RARE", "blue");
		RARITY_COLORS.put("UNCOMMON", "green");
		RARITY_COLORS.put("COMMON", "gray");
	}

	public static int getRarityColor(ItemStack stack) {
		ModConfig config = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
		if (!config.visual.glowEnabled) return 0;

		if (stack.isEmpty()) return 0;

		NbtCompound display = stack.getSubNbt("display");
		if (display == null) return 0;

		NbtList loreList = display.getList("Lore", 8);
		if (loreList == null || loreList.isEmpty()) return 0;

		for (int i = 0; i < loreList.size(); i++) {
			String rawLine = loreList.getString(i);
			if (rawLine == null || rawLine.isBlank()) continue;

			try {
				Text parsed = Text.Serializer.fromJson(rawLine);
				if (parsed == null) continue;

				String plainText = parsed.getString()
						.replaceAll("[^A-Za-z ]", " ")
						.trim()
						.replaceAll("\\s+", " ")
						.toUpperCase();

				if (plainText.isEmpty()) continue;

				for (Map.Entry<String, String> entry : RARITY_COLORS.entrySet()) {
					if (plainText.contains(entry.getKey())) {
						return applyAlpha(mapColor(entry.getValue()));
					}
				}
			} catch (Exception e) {
				// skip malformed lines, keep scanning
			}
		}
		return 0;
	}

	private static int applyAlpha(int rgb) {
		ModConfig config = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
		int alphaByte = (int) (config.visual.opacityPercent / 100.0 * 255);
		return (alphaByte << 24) | rgb;
	}

	private static int mapColor(String colorName) {
		return switch (colorName) {
			case "gray" -> 0xAAAAAA;
			case "green" -> 0x55FF55;
			case "aqua" -> 0x55FFFF;
			case "blue" -> 0x5555FF;
			case "dark_purple" -> 0xAA00AA;
			case "gold" -> 0xFFAA00;
			case "light_purple" -> 0xFF55FF;
			case "red" -> 0xFF5555;
			case "dark_red" -> 0xAA0000;
			default -> 0;
		};
	}
}
