package com.example.faketils;

import net.fabricmc.api.ModInitializer;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;

public class FakepixelRarityGlow implements ModInitializer {

        public static ModConfig CONFIG;

        @Override
        public void onInitialize() {
                AutoConfig.register(ModConfig.class, GsonConfigSerializer::new);
                CONFIG = AutoConfig.getConfigHolder(ModConfig.class).getConfig();
                System.out.println("[FakepixelRarityGlow] Mod loaded!");
        }
}
