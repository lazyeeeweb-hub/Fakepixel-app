package com.example.faketils;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;

/**
 * Detects whether an ItemStack is a Skyblock accessory/talisman by reading
 * its raw lore (same technique as RarityUtil.getRarityColor - NbtCompound
 * "display"/"Lore", Text.Serializer.fromJson per line), independent of
 * the visual.glowEnabled config gate that RarityUtil applies.
 *
 * Real mechanic, confirmed via NEU's own AccessoryBagOverlay.isAccessory
 * AND via real NBT the user supplied from their own bag: an accessory's
 * lore contains a line reading "<RARITY> ACCESSORY" (confirmed real
 * examples: "COMMON ACCESSORY", "EPIC ACCESSORY", "UNCOMMON ACCESSORY").
 * Also checks "HATCCESSORY" and "DUNGEON ACCESSORY" per NEU's source,
 * though neither has been independently confirmed against real Fakepixel
 * NBT yet. Rarity word is extracted from the SAME line via the same
 * ordered rarity-name list RarityUtil uses (longest-first, so "VERY
 * SPECIAL" is checked before "SPECIAL").
 */
public class AccessoryDetection {

    private static final String[] RARITY_ORDER = {
            "VERY SPECIAL", "ADMIN", "UNOBTAINABLE", "SPECIAL",
            "DIVINE", "MYTHIC", "LEGENDARY", "EPIC", "RARE", "UNCOMMON", "COMMON"
    };

    private static final String[] ACCESSORY_MARKERS = {
            "DUNGEON ACCESSORY", "HATCCESSORY", "ACCESSORY"
    };

    public static class Result {
        public final String name;
        public final String rarity;

        public Result(String name, String rarity) {
            this.name = name;
            this.rarity = rarity;
        }
    }

    public static Result detect(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;

        NbtCompound display = stack.getSubNbt("display");
        if (display == null) return null;

        NbtList loreList = display.getList("Lore", 8);
        if (loreList == null || loreList.isEmpty()) return null;

        for (int i = 0; i < loreList.size(); i++) {
            String rawLine = loreList.getString(i);
            if (rawLine == null || rawLine.isBlank()) continue;

            try {
                Text parsed = Text.Serializer.fromJson(rawLine);
                if (parsed == null) continue;

                String plainText = parsed.getString()
                        .replaceAll("[^A-Za-z ]", " ")
                        .trim()
                        .replaceAll("\\s+", " ")
                        .toUpperCase();

                if (plainText.isEmpty()) continue;

                boolean isAccessoryLine = false;
                for (String marker : ACCESSORY_MARKERS) {
                    if (plainText.contains(marker)) {
                        isAccessoryLine = true;
                        break;
                    }
                }
                if (!isAccessoryLine) continue;

                for (String rarity : RARITY_ORDER) {
                    if (plainText.contains(rarity)) {
                        String name = stack.getName().getString();
                        return new Result(name, rarity);
                    }
                }
            } catch (Exception e) {
                // skip malformed lines, keep scanning
            }
        }
        return null;
    }

    private AccessoryDetection() {}
}
