package com.example.faketils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Static enchant applicability data sourced from the NotEnoughUpdates-REPO
 * project (constants/enchants.json), the real data Hypixel-Skyblock mods
 * like NEU use to know which enchants are valid for which item types.
 * "ultimate_" enchants are intentionally excluded from missing-enchant
 * detection (they come from special sources, not the enchant table) - same
 * behavior as NEU's own Missing Enchant List feature.
 */
public class EnchantData {

    public static final Map<String, Set<String>> ITEM_TYPE_ENCHANTS = new HashMap<>();
    public static final List<Set<String>> ENCHANT_POOLS = new ArrayList<>();
    public static final Map<String, String> DISPLAY_NAMES = new HashMap<>();

    private static Set<String> set(String... values) {
        return new HashSet<>(Arrays.asList(values));
    }

    static {
        ITEM_TYPE_ENCHANTS.put("SWORD", set(
                "bane_of_arthropods", "cleave", "critical", "cubism", "dragon_hunter",
                "ender_slayer", "execute", "experience", "fire_aspect", "first_strike",
                "giant_killer", "impaling", "knockback", "lethality", "life_steal",
                "looting", "luck", "mana_steal", "prosecute", "scavenger", "sharpness",
                "smite", "syphon", "titan_killer", "thunderlord", "thunderbolt",
                "triple_strike", "vampirism", "venomous", "vicious", "smoldering",
                "tabasco", "champion", "divine_gift", "magmarizer"
        ));

        ITEM_TYPE_ENCHANTS.put("BOW", set(
                "aiming", "chance", "cubism", "dragon_hunter", "flame", "impaling",
                "infinite_quiver", "piercing", "overload", "power", "punch", "snipe",
                "smoldering", "divine_gift", "tabasco", "vicious", "toxophilite"
        ));

        ITEM_TYPE_ENCHANTS.put("AXE", set(
                "efficiency", "silk_touch", "absorb", "karma", "petalfall"
        ));

        ITEM_TYPE_ENCHANTS.put("PICKAXE", set(
                "compact", "efficiency", "experience", "fortune", "silk_touch",
                "pristine", "smelting_touch", "paleontologist", "lapidary"
        ));

        ITEM_TYPE_ENCHANTS.put("SHOVEL", set(
                "efficiency", "silk_touch"
        ));

        ITEM_TYPE_ENCHANTS.put("FARMING_TOOL", set(
                "replenish", "harvesting", "turbo_wheat", "turbo_cactus", "turbo_cane",
                "turbo_warts", "turbo_carrot", "turbo_potato", "turbo_mushrooms",
                "turbo_rose", "turbo_moonflower", "turbo_sunflower", "turbo_coco",
                "turbo_melon", "turbo_pumpkin", "cultivating", "delicate", "dedication"
        ));

        ITEM_TYPE_ENCHANTS.put("FISHING_ROD", set(
                "angler", "blessing", "caster", "expertise", "frail", "looting",
                "luck_of_the_sea", "lure", "magnet", "spiked_hook", "impaling",
                "charm", "corruption", "tabasco", "piscary", "quick_bite", "magmarizer"
        ));

        ITEM_TYPE_ENCHANTS.put("HELMET", set(
                "big_brain", "blast_protection", "fire_protection", "projectile_protection",
                "protection", "growth", "rejuvenate", "respite", "aqua_affinity", "thorns",
                "respiration", "hardened_mana", "strong_mana", "mana_vampire",
                "ferocious_mana", "hecatomb", "transylvanian", "pesterminator",
                "ice_cold", "small_brain"
        ));

        ITEM_TYPE_ENCHANTS.put("CHESTPLATE", set(
                "protection", "blast_protection", "fire_protection", "projectile_protection",
                "growth", "rejuvenate", "respite", "thorns", "counter_strike",
                "true_protection", "hardened_mana", "strong_mana", "mana_vampire",
                "ferocious_mana", "reflection", "pesterminator", "ice_cold"
        ));

        ITEM_TYPE_ENCHANTS.put("LEGGINGS", set(
                "protection", "blast_protection", "fire_protection", "projectile_protection",
                "growth", "rejuvenate", "respite", "smarty_pants", "thorns",
                "hardened_mana", "strong_mana", "mana_vampire", "ferocious_mana",
                "pesterminator", "ice_cold", "tidal"
        ));

        ITEM_TYPE_ENCHANTS.put("BOOTS", set(
                "protection", "blast_protection", "fire_protection", "projectile_protection",
                "growth", "sugar_rush", "rejuvenate", "respite", "feather_falling",
                "depth_strider", "frost_walker", "thorns", "hardened_mana", "strong_mana",
                "mana_vampire", "ferocious_mana", "pesterminator", "ice_cold"
        ));
    }

    static {
        ENCHANT_POOLS.add(set("silk_touch", "smelting_touch", "fortune"));
        ENCHANT_POOLS.add(set("protection", "blast_protection", "fire_protection", "projectile_protection"));
        ENCHANT_POOLS.add(set("rejuvenate", "respite"));
        ENCHANT_POOLS.add(set("thunderlord", "thunderbolt"));
        ENCHANT_POOLS.add(set("syphon", "life_steal", "mana_steal"));
        ENCHANT_POOLS.add(set("execute", "prosecute"));
        ENCHANT_POOLS.add(set("depth_strider", "frost_walker"));
        ENCHANT_POOLS.add(set("first_strike", "triple_strike"));
        ENCHANT_POOLS.add(set("giant_killer", "titan_killer"));
        ENCHANT_POOLS.add(set(
                "turbo_pumpkin", "turbo_warts", "turbo_cactus", "turbo_cane", "turbo_carrot",
                "turbo_coco", "turbo_melon", "turbo_mushrooms", "turbo_potato", "turbo_wheat",
                "turbo_rose", "turbo_moonflower", "turbo_sunflower"
        ));
        ENCHANT_POOLS.add(set("hardened_mana", "strong_mana", "mana_vampire", "ferocious_mana"));
        ENCHANT_POOLS.add(set("reflection", "thorns"));
        ENCHANT_POOLS.add(set("big_brain", "small_brain"));
    }

    static {
        Set<String> all = new HashSet<>();
        for (Set<String> s : ITEM_TYPE_ENCHANTS.values()) {
            all.addAll(s);
        }
        for (String id : all) {
            if (id.startsWith("ultimate_")) continue;
            String[] parts = id.split("_");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) sb.append(' ');
                String p = parts[i];
                sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
            }
            DISPLAY_NAMES.put(id, sb.toString());
        }
    }

    private EnchantData() {}
}
