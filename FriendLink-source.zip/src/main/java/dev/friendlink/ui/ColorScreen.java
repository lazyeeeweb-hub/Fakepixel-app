package dev.friendlink.ui;

import dev.friendlink.FriendLink;
import dev.friendlink.Models.Friend;
import java.util.Locale;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class ColorScreen extends Screen {
    private final Screen parent;
    private final Friend friend;
    private final Channel[] channels = new Channel[3];
    private TextFieldWidget hex;
    private int rgb;
    private boolean updating;
    public ColorScreen(Screen parent, Friend friend) {
        super(Text.literal("Glow color: " + friend.name)); this.parent = parent; this.friend = friend; rgb = friend.color;
    }
    @Override protected void init() {
        int x = width / 2 - 100, y = Math.max(32, height / 2 - 76);
        hex = new TextFieldWidget(textRenderer, x, y, 152, 20, Text.literal("Hex RGB"));
        hex.setMaxLength(7); hex.setText(String.format(Locale.ROOT, "#%06X", rgb)); addDrawableChild(hex);
        for (int i = 0; i < 3; i++) {
            channels[i] = new Channel(x, y + 28 + 24 * i, i);
            addDrawableChild(channels[i]);
        }
        hex.setChangedListener(s -> {
            if (updating) return;
            String h = s.startsWith("#") ? s.substring(1) : s;
            if (!h.matches("[0-9a-fA-F]{6}")) return;
            rgb = Integer.parseInt(h, 16);
            for (Channel c : channels) c.sync();
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> {
            friend.color = rgb; FriendLink.INSTANCE.touch(); close();
        }).dimensions(x, y + 108, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x + 104, y + 108, 96, 20).build());
    }
    private final class Channel extends SliderWidget {
        final int channel, shift;
        Channel(int x, int y, int channel) {
            super(x, y, 200, 20, Text.empty(), ((rgb >> (16 - channel * 8)) & 255) / 255.0);
            this.channel = channel; shift = 16 - channel * 8; updateMessage();
        }
        void sync() { value = ((rgb >> shift) & 255) / 255.0; updateMessage(); }
        @Override protected void updateMessage() {
            setMessage(Text.literal((channel == 0 ? "Red: " : channel == 1 ? "Green: " : "Blue: ") + Math.round(value * 255)));
        }
        @Override protected void applyValue() {
            rgb = (rgb & ~(255 << shift)) | ((int) Math.round(value * 255) << shift);
            updating = true; hex.setText(String.format(Locale.ROOT, "#%06X", rgb)); updating = false;
        }
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFF);
        if (hex != null) context.fill(width / 2 + 62, hex.getY(), width / 2 + 100, hex.getY() + 20, 0xFF000000 | rgb);
        super.render(context, mouseX, mouseY, delta);
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
