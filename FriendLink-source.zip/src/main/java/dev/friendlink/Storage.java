package dev.friendlink;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.friendlink.Models.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Snapshots are serialized on a client tick; all ongoing disk writes use one ordered worker. */
public final class Storage implements AutoCloseable {
    public static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path root;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "FriendLink-storage"); t.setDaemon(true); return t;
    });
    public Storage(Path root) { this.root = root; }
    public Path root() { return root; }
    public <T> T read(String file, Class<T> type, T fallback) {
        Path path = root.resolve(file);
        if (!Files.exists(path)) return fallback;
        try {
            if (Files.size(path) > 64L * 1024 * 1024) throw new IOException("File exceeds 64 MiB safety limit");
            T value = JSON.fromJson(Files.readString(path), type);
            return value == null ? fallback : value;
        } catch (Exception e) {
            FriendLink.LOG.warn("Could not read {}. Keeping a corrupt-file backup.", path, e);
            try { Files.move(path, path.resolveSibling(file + ".broken-" + System.currentTimeMillis())); }
            catch (IOException backup) { FriendLink.LOG.error("Could not back up {}", path, backup); }
            return fallback;
        }
    }
    public void write(String file, Object data) {
        String snapshot = JSON.toJson(data);
        io.execute(() -> {
            try {
                Files.createDirectories(root);
                Path dest = root.resolve(file), temp = root.resolve(file + ".tmp");
                Files.writeString(temp, snapshot, StandardCharsets.UTF_8);
                try { Files.move(temp, dest, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException e) { Files.move(temp, dest, StandardCopyOption.REPLACE_EXISTING); }
            } catch (IOException e) { FriendLink.LOG.error("Could not save FriendLink {}", file, e); }
        });
    }
    public static State normalize(State s, Config config) {
        LinkedHashMap<String, Friend> friends = new LinkedHashMap<>();
        if (s.friends != null) for (Friend f : s.friends.values()) {
            if (f == null || !Protocol.validName(f.name) || friends.size() >= 512) continue;
            f.color &= 0xFFFFFF; f.unread = Math.max(0, f.unread);
            f.messages = clean(f.messages, config.maxMessages);
            friends.putIfAbsent(Protocol.key(f.name), f);
        }
        s.friends = friends;
        LinkedHashMap<String, Group> groups = new LinkedHashMap<>();
        if (s.groups != null) for (Group g : s.groups.values()) {
            if (g == null || !Protocol.validId(g.id) || groups.size() >= 128) continue;
            if (g.members == null) g.members = new ArrayList<>();
            g.members.removeIf(n -> !Protocol.validName(n));
            if (g.name == null || g.name.isBlank()) g.name = "Unknown group";
            g.name = g.name.substring(0, Math.min(g.name.length(), 32));
            if (!Protocol.validName(g.owner)) g.owner = g.members.isEmpty() ? "Unknown" : g.members.get(0);
            g.unread = Math.max(0, g.unread); g.messages = clean(g.messages, config.maxMessages);
            groups.put(g.id, g);
        }
        s.groups = groups;
        return s;
    }
    private static java.util.List<Message> clean(java.util.List<Message> messages, int max) {
        if (messages == null) return new ArrayList<>();
        messages.removeIf(m -> m == null || m.sender == null || m.text == null);
        if (messages.size() > max) messages = new ArrayList<>(messages.subList(messages.size() - max, messages.size()));
        for (Message m : messages) {
            if (m.delivery == null) m.delivery = new LinkedHashMap<>();
            m.delivery.values().removeIf(d -> d == null);
            for (Delivery d : m.delivery.values()) {
                // A previous process cannot still be delivering a persisted message.
                d.unconfirmed += Math.max(0, d.total - d.completed); d.completed = d.total;
            }
        }
        return messages;
    }
    @Override public void close() {
        io.shutdown();
        try { if (!io.awaitTermination(5, TimeUnit.SECONDS)) FriendLink.LOG.warn("Storage shutdown timed out"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
