package dev.friendlink;

import java.util.Arrays;
import java.util.Comparator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Reuses row objects. Entity filtering, sorting, strings and font measurements happen on ticks only. */
public final class RadiusHud {
    private final FriendLink mod;
    private final Row[] rows = new Row[512];
    private int count;
    private static final Comparator<Row> BY_DISTANCE = Comparator.comparingDouble(r -> r.distance);
    private static final class Row {
        Identifier face;
        String label = "";
        int labelWidth;
        double distance;
    }
    public RadiusHud(FriendLink mod) { this.mod = mod; for (int i = 0; i < rows.length; i++) rows[i] = new Row(); }
    public void clear() { count = 0; }
    public void update() {
        count = 0;
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = mod.config;
        if (!c.hudEnabled || mc.world == null || mc.player == null) return;
        var players = mc.world.getPlayers();
        double maxSquared = (double) c.radius * c.radius;
        for (int i = 0; i < players.size() && count < rows.length; i++) {
            var p = players.get(i);
            if (p == mc.player || p.isRemoved()) continue;
            String name = p.getGameProfile().getName();
            if (mod.friend(name) == null) continue;
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            double dy = c.distance3d ? p.getY() - mc.player.getY() : 0;
            double squared = dx * dx + dy * dy + dz * dz;
            if (squared > maxSquared) continue;
            Row r = rows[count++]; r.distance = Math.sqrt(squared); r.face = mod.skins.face(name);
            r.label = (c.showName ? name : "") + (c.showName && c.showDistance ? " · " : "")
                + (c.showDistance ? Math.round(r.distance) + "m" : "");
            r.labelWidth = mc.textRenderer.getWidth(r.label);
        }
        if (c.sortByDistance) Arrays.sort(rows, 0, count, BY_DISTANCE);
    }
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = mod.config;
        if (!c.hudEnabled || count == 0 || mc.options.hudHidden || mc.world == null) return;
        float scale = (float) c.scale;
        int w = (int) (mc.getWindow().getScaledWidth() / scale), h = (int) (mc.getWindow().getScaledHeight() / scale);
        int step = c.iconSize + 4;
        int shown = Math.min(Math.min(count, c.maxIcons), Math.max(0, (h - c.offsetY) / step));
        boolean right = c.anchor == Config.Anchor.TOP_RIGHT || c.anchor == Config.Anchor.BOTTOM_RIGHT;
        boolean bottom = c.anchor == Config.Anchor.BOTTOM_LEFT || c.anchor == Config.Anchor.BOTTOM_RIGHT;
        // MatrixStack internals and Minecraft's draw calls are engine-owned, not FriendLink cache allocations.
        context.getMatrices().push(); context.getMatrices().scale(scale, scale, 1);
        int y = bottom ? h - c.offsetY - shown * step : c.offsetY;
        for (int i = 0; i < shown; i++) {
            Row r = rows[i];
            int rowWidth = c.iconSize + (r.label.isEmpty() ? 0 : 5 + r.labelWidth);
            int x = right ? w - c.offsetX - rowWidth : c.offsetX;
            context.fill(x - 2, y - 2, x + rowWidth + 2, y + c.iconSize + 2, 0x880C1018);
            Faces.draw(context, r.face, x, y, c.iconSize);
            if (!r.label.isEmpty()) context.drawText(mc.textRenderer, r.label, x + c.iconSize + 5,
                y + (c.iconSize - 8) / 2, 0xFFFFFFFF, true);
            y += step;
        }
        context.getMatrices().pop();
    }
}
