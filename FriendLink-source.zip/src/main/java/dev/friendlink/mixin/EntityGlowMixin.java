package dev.friendlink.mixin;

import dev.friendlink.FriendLink;
import dev.friendlink.Models.Friend;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client-only via fabric.mod.json and mixins.json. Never changes tracked data or potion effects. */
@Mixin(Entity.class)
public abstract class EntityGlowMixin {
    /** Entity.isGlowing feeds MinecraftClient.hasOutline and vanilla's outline framebuffer. */
    @Inject(method = "isGlowing()Z", at = @At("RETURN"), cancellable = true)
    private void friendlink$glow(CallbackInfoReturnable<Boolean> cir) {
        FriendLink mod = FriendLink.INSTANCE;
        if (mod != null && mod.config != null && mod.glowFriend((Entity) (Object) this) != null) cir.setReturnValue(true);
        // Otherwise preserve vanilla's glow flag, including effects set by the server.
    }
    /** WorldRenderer obtains the outline RGB from Entity.getTeamColorValue(). Override only our friends. */
    @Inject(method = "getTeamColorValue()I", at = @At("RETURN"), cancellable = true)
    private void friendlink$color(CallbackInfoReturnable<Integer> cir) {
        FriendLink mod = FriendLink.INSTANCE;
        if (mod == null || mod.config == null) return;
        Friend friend = mod.glowFriend((Entity) (Object) this);
        if (friend != null) cir.setReturnValue(friend.color & 0xFFFFFF);
    }
}
