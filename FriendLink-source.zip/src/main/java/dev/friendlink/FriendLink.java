package dev.friendlink;

import dev.friendlink.Models.*;
import dev.friendlink.ui.ChatScreen;
import dev.friendlink.ui.PromptScreen;
import java.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class FriendLink implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("FriendLink");
    public static FriendLink INSTANCE;
    public Config config;
    public State state;
    public Storage storage;
    public SendQueue queue;
    public WhisperRouter router;
    public Skins skins;
    public RadiusHud hud;
    public Notifications notifications;
    public long version;
    private boolean dirty;
    private int ticks;
    private final IdentityHashMap<Entity, Friend> loadedFriends = new IdentityHashMap<>();
    private KeyBinding open, glow, radius, accept, decline;

    @Override public void onInitializeClient() {
        INSTANCE = this;
        storage = new Storage(FabricLoader.getInstance().getConfigDir().resolve("friendlink"));
        config = storage.read("config.json", Config.class, new Config()); config.normalize();
        state = Storage.normalize(storage.read("conversations.json", State.class, new State()), config);
        queue = new SendQueue(this); router = new WhisperRouter(this);
        notifications = new Notifications(this); skins = new Skins(this); hud = new RadiusHud(this);
        open = key("open", GLFW.GLFW_KEY_K); glow = key("glow", GLFW.GLFW_KEY_G);
        radius = key("hud", GLFW.GLFW_KEY_H); accept = key("accept", GLFW.GLFW_KEY_Y);
        decline = key("decline", GLFW.GLFW_KEY_N);
        // Vanilla /msg arrives as a game message; plugins may use signed/decorated chat instead.
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> overlay || !router.receive(message.getString()));
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, timestamp) -> !router.receive(message.getString()));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            queue.cancel("Disconnected"); router.clear(); loadedFriends.clear(); hud.clear(); flush();
        });
        HudRenderCallback.EVENT.register(hud::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { queue.cancel("Client closed"); flush(); skins.close(); storage.close(); });
        storage.write("config.json", config);
    }
    private KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.friendlink." + name,
            InputUtil.Type.KEYSYM, code, "key.categories.friendlink"));
    }
    private void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        while (open.wasPressed()) if (mc.currentScreen == null) mc.setScreen(new ChatScreen(null));
        while (glow.wasPressed()) { config.glowEnabled = !config.glowEnabled; saveConfig(); }
        while (radius.wasPressed()) { config.hudEnabled = !config.hudEnabled; saveConfig(); }
        while (accept.wasPressed()) if (mc.currentScreen == null) notifications.respond(true, now);
        while (decline.wasPressed()) if (mc.currentScreen == null) notifications.respond(false, now);
        queue.tick(now);
        if (++ticks % 5 == 0) { refreshLoaded(); skins.tick(); hud.update(); }
        if (ticks % 20 == 0) { router.tick(now); if (dirty) flush(); }
    }
    private void refreshLoaded() {
        loadedFriends.clear();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        var players = mc.world.getPlayers();
        for (int i = 0; i < players.size(); i++) {
            PlayerEntity p = players.get(i);
            if (p == mc.player) continue;
            Friend f = friend(p.getGameProfile().getName());
            if (f != null) loadedFriends.put(p, f);
        }
    }
    /** Render/mixin fast path: identity lookup, no lowercase conversion, streams, or allocations. */
    public Friend glowFriend(Entity entity) {
        if (!config.glowEnabled) return null;
        Friend f = loadedFriends.get(entity); return f != null && f.glow ? f : null;
    }
    public Friend friend(String name) { return name == null ? null : state.friends.get(Protocol.key(name)); }
    public String self() { return MinecraftClient.getInstance().getSession().getUsername(); }
    public String acceptHint() { return accept.getBoundKeyLocalizedText().getString(); }
    public String declineHint() { return decline.getBoundKeyLocalizedText().getString(); }
    public void replaceFriendNames(List<String> names) {
        LinkedHashMap<String, String> unique = new LinkedHashMap<>();
        for (String n : names) if (Protocol.validName(n) && !n.equalsIgnoreCase(self())) unique.putIfAbsent(Protocol.key(n), n);
        for (String old : new ArrayList<>(state.friends.keySet())) if (!unique.containsKey(old)) removeFriend(old);
        for (String n : unique.values()) if (friend(n) == null) addFriend(n);
        touch();
    }
    public static boolean contains(List<String> names, String name) {
        for (String n : names) if (n.equalsIgnoreCase(name)) return true;
        return false;
    }
    public void touch() { version++; dirty = true; }
    public void flush() { storage.write("conversations.json", state); dirty = false; }
    public void saveConfig() { config.normalize(); router.reload(); storage.write("config.json", config); touch(); }
    public String addFriend(String name) {
        name = name.trim();
        if (!Protocol.validName(name)) return "Use a Java username: 3-16 letters, digits or underscores.";
        if (name.equalsIgnoreCase(self())) return "You cannot add yourself.";
        if (friend(name) != null) return "That friend already exists.";
        if (state.friends.size() >= 512) return "Friend limit reached (512).";
        Friend f = new Friend(); f.name = name; f.color = config.defaultGlowColor;
        state.friends.put(Protocol.key(name), f); skins.request(name); touch(); return null;
    }
    public void removeFriend(String name) {
        queue.cancelConversation("f:" + Protocol.key(name));
        state.friends.remove(Protocol.key(name)); refreshLoaded(); touch();
    }
    public List<Message> messages(String key) {
        if (key == null) return Collections.emptyList();
        if (key.startsWith("f:")) { Friend f = state.friends.get(key.substring(2)); return f == null ? Collections.emptyList() : f.messages; }
        Group g = state.groups.get(key.substring(2)); return g == null ? Collections.emptyList() : g.messages;
    }
    public boolean visible(String key) {
        Screen screen = MinecraftClient.getInstance().currentScreen;
        return screen instanceof ChatScreen chat && key.equals(chat.conversation());
    }
    public void read(String key) {
        if (key == null) return;
        if (key.startsWith("f:")) { Friend f = state.friends.get(key.substring(2)); if (f != null && f.unread != 0) { f.unread = 0; touch(); } }
        else { Group g = state.groups.get(key.substring(2)); if (g != null && g.unread != 0) { g.unread = 0; touch(); } }
    }
    public void append(String key, Message message, boolean incoming) {
        List<Message> log = messages(key);
        if (!(log instanceof ArrayList)) return;
        log.add(message); if (log.size() > config.maxMessages) log.remove(0);
        if (Protocol.validName(message.sender)) skins.request(message.sender);
        if (incoming && !visible(key)) {
            if (key.startsWith("f:")) { Friend f = state.friends.get(key.substring(2)); if (f != null) f.unread = Math.min(9999, f.unread + 1); }
            else { Group g = state.groups.get(key.substring(2)); if (g != null) g.unread = Math.min(9999, g.unread + 1); }
            notifications.message(key, message);
        }
        touch();
    }
    public void system(String key, String text) { append(key, new Message("FriendLink", text, true), false); }
    public String send(String key, String text) {
        if (key == null || text.isBlank()) return "Select a conversation and enter a message.";
        if (text.length() > 4096 || text.chars().anyMatch(c -> c < 32 || c == 127 || c == 167)) return "Message contains unsupported characters or exceeds 4096 characters.";
        if (MinecraftClient.getInstance().getNetworkHandler() == null) { system(key, "player not found: not connected"); return "Not connected."; }
        List<String> targets;
        String prefix = "";
        if (key.startsWith("f:")) {
            Friend f = state.friends.get(key.substring(2)); if (f == null) return "Friend removed.";
            targets = List.of(f.name);
        } else {
            Group g = state.groups.get(key.substring(2));
            if (g == null || g.left || g.pending) return "Accept this group before sending.";
            targets = g.members; prefix = Protocol.prefix(config.groupTag, g.id);
        }
        Message msg = new Message(self(), text, false);
        List<SendQueue.Job> jobs = new ArrayList<>();
        for (String target : targets) {
            if (target.equalsIgnoreCase(self())) continue;
            for (String part : Protocol.split(text, Protocol.bodyLimit(target) - prefix.length()))
                jobs.add(new SendQueue.Job(target, prefix + part, key, msg));
        }
        if (jobs.isEmpty()) return "There are no other members to send to.";
        if (!queue.offer(jobs)) return "Send queue full. Wait for current messages to finish.";
        append(key, msg, false); return null;
    }
    public void inviteNotice(Group group, String sender) { notifications.invite(group, sender); touch(); }
    public void acceptGroup(String id, boolean accepted) {
        Group g = state.groups.get(id); if (g == null || !g.pending || g.left) return;
        g.pending = false; g.left = !accepted;
        system("g:" + id, accepted ? "Group accepted." : "Group declined."); touch();
    }
    public String saveGroup(Group existing, String name, List<String> chosen) {
        name = name.trim();
        if (name.isEmpty() || name.length() > 32 || name.chars().anyMatch(c -> c < 32 || c == 127)) return "Group name must contain 1-32 printable characters.";
        LinkedHashMap<String, String> unique = new LinkedHashMap<>();
        unique.put(Protocol.key(self()), self());
        for (String n : chosen) if (Protocol.validName(n)) unique.putIfAbsent(Protocol.key(n), n);
        if (unique.size() < 2 || unique.size() > config.maxGroupSize) return "Choose 1 to " + (config.maxGroupSize - 1) + " other members.";
        if (existing != null && !existing.owner.equalsIgnoreCase(self())) return "Only the owner can rename or change membership.";
        if (existing == null && state.groups.size() >= 128) return "Group limit reached (128).";
        Group g = existing == null ? new Group() : existing;
        List<String> old = new ArrayList<>(g.members);
        Protocol.Invite invite = new Protocol.Invite();
        invite.id = existing == null ? UUID.randomUUID().toString() : g.id;
        invite.name = name; invite.owner = self(); invite.members = new ArrayList<>(unique.values());
        invite.revision = Math.max(0, g.revision) + 1;
        LinkedHashSet<String> recipients = new LinkedHashSet<>(old); recipients.addAll(invite.members);
        if (!sync(invite, recipients)) return "Send queue full or not connected; group was not changed.";
        g.id = invite.id; g.name = name; g.owner = self(); g.members = invite.members;
        g.revision = invite.revision; g.pending = false; g.left = false;
        state.groups.put(g.id, g); system("g:" + g.id, "Group synchronized. Invites are queued."); touch(); return null;
    }
    private boolean sync(Protocol.Invite invite, Collection<String> recipients) {
        if (MinecraftClient.getInstance().getNetworkHandler() == null) return false;
        List<String> chunks = Protocol.inviteParts(invite);
        List<SendQueue.Job> jobs = new ArrayList<>();
        for (String target : recipients) if (!target.equalsIgnoreCase(self()))
            for (String part : chunks) jobs.add(new SendQueue.Job(target, part, "g:" + invite.id, null));
        return queue.offer(jobs);
    }
    public void receiveInvite(String sender, Protocol.Invite i) {
        Group g = state.groups.get(i.id);
        if ("leave".equals(i.kind)) {
            if (g == null || g.left || !contains(g.members, sender) || sender.equalsIgnoreCase(g.owner)) return;
            g.members.removeIf(n -> n.equalsIgnoreCase(sender));
            system("g:" + g.id, sender + " left the group."); return;
        }
        if (!sender.equalsIgnoreCase(i.owner)) return;
        if (g != null && !(g.pending && g.revision < 0) && !sender.equalsIgnoreCase(g.owner)) return;
        if ("close".equals(i.kind)) {
            if (g != null && i.revision > g.revision) { g.left = true; g.revision = i.revision; system("g:" + g.id, "Owner closed this group."); }
            return;
        }
        if (g != null && i.revision <= g.revision) return;
        if (!contains(i.members, self())) {
            if (g != null) { g.left = true; g.revision = i.revision; system("g:" + g.id, "You were removed from this group."); }
            return;
        }
        boolean ask = g == null || g.left || g.pending;
        if (g == null) {
            if (state.groups.size() >= 128) return;
            g = new Group(); g.id = i.id; state.groups.put(i.id, g);
        }
        g.name = i.name; g.owner = i.owner; g.members = new ArrayList<>(i.members);
        g.revision = i.revision; g.left = false; g.pending = ask;
        if (ask) inviteNotice(g, sender);
        else system("g:" + g.id, "Group name/membership updated by " + sender + ".");
        touch();
    }
    public String leaveGroup(Group g) {
        if (g.pending) { acceptGroup(g.id, false); return null; }
        Protocol.Invite i = new Protocol.Invite(); i.id = g.id; i.name = g.name; i.owner = g.owner;
        i.members = new ArrayList<>(g.members); i.revision = g.revision + 1;
        i.kind = g.owner.equalsIgnoreCase(self()) ? "close" : "leave";
        queue.cancelConversation("g:" + g.id);
        if (!sync(i, g.members)) return "Could not queue the leave notification; retry when connected.";
        g.left = true; system("g:" + g.id, "You left the group."); touch(); return null;
    }
    public void openConfig(Screen parent) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (FabricLoader.getInstance().isModLoaded("cloth-config")) mc.setScreen(dev.friendlink.compat.ClothScreen.create(parent));
        else mc.setScreen(new PromptScreen(parent, "Install Cloth Config 11.x for settings", "", s -> null));
    }
}
