package dev.friendlink.compat;

import dev.friendlink.*;
import dev.friendlink.Models.Friend;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Loaded only behind FabricLoader.isModLoaded("cloth-config"). Cloth is optional at runtime. */
public final class ClothScreen {
    private ClothScreen() {}
    private static Text t(String text) { return Text.literal(text); }
    public static Screen create(Screen parent) {
        FriendLink m = FriendLink.INSTANCE; Config c = m.config;
        ConfigBuilder b = ConfigBuilder.create().setParentScreen(parent).setTitle(t("FriendLink"));
        ConfigEntryBuilder e = b.entryBuilder();
        ConfigCategory general = b.getOrCreateCategory(t("General"));
        general.addEntry(e.startBooleanToggle(t("Master friend glow"), c.glowEnabled).setDefaultValue(true).setSaveConsumer(v -> c.glowEnabled = v).build());
        general.addEntry(e.startColorField(t("Default glow RGB"), c.defaultGlowColor).setDefaultValue(0xFFFF00).setSaveConsumer(v -> c.defaultGlowColor = v).build());
        general.addEntry(e.startBooleanToggle(t("Notification sound"), c.notificationSound).setDefaultValue(true).setSaveConsumer(v -> c.notificationSound = v).build());
        general.addEntry(e.startBooleanToggle(t("Notification toasts"), c.notificationToast).setDefaultValue(true).setSaveConsumer(v -> c.notificationToast = v).build());
        general.addEntry(e.startIntField(t("Messages retained per conversation"), c.maxMessages).setMin(100).setMax(10000).setDefaultValue(1000).setSaveConsumer(v -> c.maxMessages = v).build());
        ConfigCategory hud = b.getOrCreateCategory(t("Radius HUD"));
        hud.addEntry(e.startBooleanToggle(t("Enable HUD"), c.hudEnabled).setDefaultValue(true).setSaveConsumer(v -> c.hudEnabled = v).build());
        hud.addEntry(e.startIntField(t("Radius (blocks)"), c.radius).setMin(1).setMax(4096).setDefaultValue(100).setSaveConsumer(v -> c.radius = v).build());
        hud.addEntry(e.startBooleanToggle(t("Use 3D distance instead of horizontal"), c.distance3d).setDefaultValue(false).setSaveConsumer(v -> c.distance3d = v).build());
        hud.addEntry(e.startEnumSelector(t("Anchor"), Config.Anchor.class, c.anchor).setDefaultValue(Config.Anchor.TOP_RIGHT).setSaveConsumer(v -> c.anchor = v).build());
        hud.addEntry(e.startIntField(t("X offset (scaled HUD units)"), c.offsetX).setMin(0).setMax(4096).setDefaultValue(8).setSaveConsumer(v -> c.offsetX = v).build());
        hud.addEntry(e.startIntField(t("Y offset (scaled HUD units)"), c.offsetY).setMin(0).setMax(4096).setDefaultValue(8).setSaveConsumer(v -> c.offsetY = v).build());
        hud.addEntry(e.startIntField(t("Icon size"), c.iconSize).setMin(8).setMax(64).setDefaultValue(20).setSaveConsumer(v -> c.iconSize = v).build());
        hud.addEntry(e.startDoubleField(t("Scale"), c.scale).setMin(.5).setMax(3).setDefaultValue(1.0).setSaveConsumer(v -> c.scale = v).build());
        hud.addEntry(e.startBooleanToggle(t("Show names"), c.showName).setDefaultValue(true).setSaveConsumer(v -> c.showName = v).build());
        hud.addEntry(e.startBooleanToggle(t("Show distance"), c.showDistance).setDefaultValue(true).setSaveConsumer(v -> c.showDistance = v).build());
        hud.addEntry(e.startIntField(t("Maximum icons"), c.maxIcons).setMin(1).setMax(64).setDefaultValue(8).setSaveConsumer(v -> c.maxIcons = v).build());
        hud.addEntry(e.startBooleanToggle(t("Sort by distance"), c.sortByDistance).setDefaultValue(true).setSaveConsumer(v -> c.sortByDistance = v).build());
        ConfigCategory groups = b.getOrCreateCategory(t("Groups"));
        groups.addEntry(e.startIntField(t("Minimum send interval (ms)"), c.sendDelayMs).setMin(100).setMax(10000).setDefaultValue(400).setSaveConsumer(v -> c.sendDelayMs = v).build());
        groups.addEntry(e.startIntField(t("Wait for server echo (ms)"), c.echoTimeoutMs).setMin(500).setMax(15000).setDefaultValue(2500).setSaveConsumer(v -> c.echoTimeoutMs = v).build());
        groups.addEntry(e.startIntField(t("Maximum group members (including you)"), c.maxGroupSize).setMin(2).setMax(32).setDefaultValue(8).setSaveConsumer(v -> c.maxGroupSize = v).build());
        groups.addEntry(e.startStrField(t("Group tag; one %s for UUID"), c.groupTag).setDefaultValue("[FL:%s]")
            .setErrorSupplier(v -> Protocol.validTag(v) ? Optional.empty() : Optional.of(t("Use delimiters around exactly one %s; max 40 ASCII characters.")))
            .setSaveConsumer(v -> c.groupTag = v).build());
        for (var g : m.state.groups.values()) if (!g.left) {
            groups.addEntry(e.startBooleanToggle(t(g.name + " / muted"), g.muted).setSaveConsumer(v -> { g.muted = v; m.touch(); }).build());
            groups.addEntry(e.startBooleanToggle(t(g.name + " / sound"), g.sound).setSaveConsumer(v -> { g.sound = v; m.touch(); }).build());
        }
        ConfigCategory regex = b.getOrCreateCategory(t("Whisper patterns"));
        regex.addEntry(e.startStrList(t("Incoming: named groups name and message"), new ArrayList<>(c.incomingRegex))
            .setDefaultValue(new Config().incomingRegex).setCellErrorSupplier(v -> regexError(v, true)).setSaveConsumer(v -> c.incomingRegex = new ArrayList<>(v)).build());
        regex.addEntry(e.startStrList(t("Outgoing: named groups name and message"), new ArrayList<>(c.outgoingRegex))
            .setDefaultValue(new Config().outgoingRegex).setCellErrorSupplier(v -> regexError(v, true)).setSaveConsumer(v -> c.outgoingRegex = new ArrayList<>(v)).build());
        regex.addEntry(e.startStrList(t("Player not found errors (anchored regex)"), new ArrayList<>(c.notFoundRegex))
            .setDefaultValue(new Config().notFoundRegex).setCellErrorSupplier(v -> regexError(v, false)).setSaveConsumer(v -> c.notFoundRegex = new ArrayList<>(v)).build());
        ConfigCategory friends = b.getOrCreateCategory(t("Friends"));
        List<String> names = new ArrayList<>(); for (Friend f : m.state.friends.values()) names.add(f.name);
        friends.addEntry(e.startStrList(t("Friend usernames; removing a name deletes its history"), names)
            .setCellErrorSupplier(v -> Protocol.validName(v) && !v.equalsIgnoreCase(m.self()) ? Optional.empty() : Optional.of(t("Use another player's Java username (3-16 characters).")))
            .setSaveConsumer(m::replaceFriendNames).build());
        for (Friend f : m.state.friends.values()) {
            friends.addEntry(e.startBooleanToggle(t(f.name + " / glow"), f.glow).setSaveConsumer(v -> { f.glow = v; m.touch(); }).build());
            friends.addEntry(e.startColorField(t(f.name + " / RGB"), f.color).setSaveConsumer(v -> { f.color = v; m.touch(); }).build());
        }
        b.setSavingRunnable(m::saveConfig); return b.build();
    }
    private static Optional<Text> regexError(String value, boolean whisper) {
        return value.length() <= 1024 && Config.validRegex(value, whisper) ? Optional.empty()
            : Optional.of(t("Invalid regex, or missing (?<name>...) / (?<message>...)."));
    }
}
