package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Plain JSON configuration. No optional UI types may appear in this class. */
public final class Config {
    public enum Anchor { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }
    public boolean glowEnabled = true;
    public boolean hudEnabled = true;
    public int defaultGlowColor = 0xFFFF00;
    public int radius = 100;
    public boolean distance3d = false;
    public Anchor anchor = Anchor.TOP_RIGHT;
    public int offsetX = 8, offsetY = 8, iconSize = 20, maxIcons = 8;
    public double scale = 1.0;
    public boolean showName = true, showDistance = true, sortByDistance = true;
    public boolean notificationSound = true, notificationToast = true;
    public int sendDelayMs = 400, echoTimeoutMs = 2500, maxGroupSize = 8;
    public int maxMessages = 1000;
    public String groupTag = "[FL:%s]";
    public List<String> incomingRegex = new ArrayList<>(List.of(
        "^<?(?<name>[A-Za-z0-9_]{3,16})>? whispers to you: (?<message>.*)$",
        "^<?(?<name>[A-Za-z0-9_]{3,16})>? whispers: (?<message>.*)$",
        "^\\[(?<name>[A-Za-z0-9_]{3,16}) -> (?:me|you)\\] (?<message>.*)$",
        "^From (?<name>[A-Za-z0-9_]{3,16}): (?<message>.*)$"));
    public List<String> outgoingRegex = new ArrayList<>(List.of(
        "^You whisper to <?(?<name>[A-Za-z0-9_]{3,16})>?: (?<message>.*)$",
        "^\\[(?:me|you) -> (?<name>[A-Za-z0-9_]{3,16})\\] (?<message>.*)$",
        "^To (?<name>[A-Za-z0-9_]{3,16}): (?<message>.*)$"));
    public List<String> notFoundRegex = new ArrayList<>(List.of(
        "^(?:No player was found|Player not found|That player does not exist)[.!]?$",
        "^No entity was found[.!]?$"));

    public void normalize() {
        radius = clamp(radius, 1, 4096);
        offsetX = clamp(offsetX, 0, 4096); offsetY = clamp(offsetY, 0, 4096);
        iconSize = clamp(iconSize, 8, 64); maxIcons = clamp(maxIcons, 1, 64);
        scale = Double.isFinite(scale) ? Math.max(.5, Math.min(3, scale)) : 1;
        sendDelayMs = clamp(sendDelayMs, 100, 10000);
        echoTimeoutMs = clamp(echoTimeoutMs, 500, 15000);
        maxGroupSize = clamp(maxGroupSize, 2, 32);
        maxMessages = clamp(maxMessages, 100, 10000);
        defaultGlowColor &= 0xFFFFFF;
        if (anchor == null) anchor = Anchor.TOP_RIGHT;
        if (!Protocol.validTag(groupTag)) groupTag = "[FL:%s]";
        if (incomingRegex == null) incomingRegex = new Config().incomingRegex;
        if (outgoingRegex == null) outgoingRegex = new Config().outgoingRegex;
        if (notFoundRegex == null) notFoundRegex = new Config().notFoundRegex;
    }
    public static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    public static boolean validRegex(String regex, boolean whisper) {
        try {
            Pattern.compile(regex);
            return !whisper || (regex.contains("(?<name>") && regex.contains("(?<message>"));
        } catch (RuntimeException e) { return false; }
    }
}
