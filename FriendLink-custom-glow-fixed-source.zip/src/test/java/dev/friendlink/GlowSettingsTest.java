package dev.friendlink;

import com.google.gson.Gson;
import dev.friendlink.Models.Friend;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Pure settings tests; visual rendering acceptance remains an in-game test. */
final class GlowSettingsTest {
    private final Gson json = new Gson();
    @Test void newDefaults() {
        Config c = new Config(); c.normalize();
        assertTrue(c.glowEnabled); assertTrue(c.glowNewFriends); assertTrue(c.glowThroughWalls);
        assertFalse(c.glowFadeBehindBlocks); assertTrue(c.glowMarkerPulse);
        assertEquals(GlowStyle.SILHOUETTE, c.defaultGlowStyle);
        assertEquals(128, c.glowMaxDistance); assertEquals(0xFFFF00, c.defaultGlowColor);
        assertEquals(55, c.glowOpacity); assertEquals(1.06, c.glowThickness, 0.00001);
    }
    @Test void stylesAndDepthInheritForAllStyles() {
        for (GlowStyle style : new GlowStyle[] {GlowStyle.SILHOUETTE, GlowStyle.HALO, GlowStyle.MARKER}) {
            assertEquals(style, GlowStyle.resolve(GlowStyle.DEFAULT, style));
            assertEquals(style, GlowStyle.resolve(style, GlowStyle.HALO));
            Friend f = new Friend(); f.normalizeGlow();
            assertTrue(f.glowThroughWalls.resolve(new Config().glowThroughWalls));
        }
        assertEquals(GlowStyle.SILHOUETTE, GlowStyle.resolve(null, null));
        assertFalse(GlowToggle.OFF.resolve(true)); assertTrue(GlowToggle.ON.resolve(false));
        assertFalse(GlowToggle.DEFAULT.resolve(false));
    }
    @Test void legacyJsonKeepsFriendFlagsAndColours() {
        Friend old = json.fromJson("{\"name\":\"Alex\",\"glow\":false,\"color\":1193046}", Friend.class);
        old.normalizeGlow();
        assertFalse(old.glow); assertEquals(0x123456, old.color);
        assertEquals(GlowStyle.DEFAULT, old.glowStyle); assertEquals(-1, old.glowOpacity);
        assertEquals(0, old.glowMaxDistance); assertEquals(0, old.glowThickness);
        Config c = json.fromJson("{\"glowEnabled\":false}", Config.class); c.normalize();
        assertFalse(c.glowEnabled); assertTrue(c.glowNewFriends); assertTrue(c.glowThroughWalls);
        assertEquals(GlowStyle.SILHOUETTE, c.defaultGlowStyle);
    }
    @Test void corruptSettingsAreNormalized() {
        Config c = new Config(); c.defaultGlowStyle = null; c.glowOpacity = 500;
        c.glowMaxDistance = 0; c.glowThickness = Double.NaN; c.glowOccludedOpacity = -9; c.normalize();
        assertEquals(100, c.glowOpacity); assertEquals(1, c.glowMaxDistance);
        assertEquals(1.06, c.glowThickness, 0.00001); assertEquals(10, c.glowOccludedOpacity);
        Friend f = new Friend(); f.glowStyle = null; f.glowThroughWalls = null; f.glowPulse = null;
        f.color = 0xFF123456; f.glowOpacity = -99; f.glowMaxDistance = 99999;
        f.glowThickness = 2; f.normalizeGlow();
        assertEquals(0x123456, f.color); assertEquals(-1, f.glowOpacity);
        assertEquals(4096, f.glowMaxDistance); assertEquals(1.08, f.glowThickness, 0.00001);
        assertEquals(GlowStyle.DEFAULT, f.glowStyle); assertEquals(GlowToggle.DEFAULT, f.glowThroughWalls);
        f.glowThickness = Double.NaN; f.normalizeGlow(); assertEquals(0, f.glowThickness);
    }
    @Test void perFriendOverridesSurviveRoundTrip() {
        Friend f = new Friend(); f.glow = true; f.glowStyle = GlowStyle.MARKER;
        f.glowThroughWalls = GlowToggle.OFF; f.glowPulse = GlowToggle.OFF;
        f.glowOpacity = 33; f.glowMaxDistance = 64; f.glowThickness = 1.04;
        Friend read = json.fromJson(json.toJson(f), Friend.class); read.normalizeGlow();
        assertTrue(read.glow); assertEquals(GlowStyle.MARKER, read.glowStyle);
        assertEquals(GlowToggle.OFF, read.glowThroughWalls); assertEquals(GlowToggle.OFF, read.glowPulse);
        assertEquals(33, read.glowOpacity); assertEquals(64, read.glowMaxDistance);
        assertEquals(1.04, read.glowThickness, 0.00001);
    }
}
