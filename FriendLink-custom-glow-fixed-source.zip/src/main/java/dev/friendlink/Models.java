package dev.friendlink;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Models {
    private Models() {}
    public static final class Delivery {
        public int total, completed, failed, unconfirmed;
    }
    public static final class Message {
        public long time = System.currentTimeMillis();
        public String sender = "", text = "";
        public boolean system;
        public LinkedHashMap<String, Delivery> delivery = new LinkedHashMap<>();
        public Message() {}
        public Message(String sender, String text, boolean system) {
            this.sender = sender; this.text = text; this.system = system;
        }
        /** Called only while rebuilding a cached screen layout, never in render(). */
        public String status() {
            if (delivery.isEmpty()) return "";
            StringBuilder b = new StringBuilder();
            for (var e : delivery.entrySet()) {
                Delivery d = e.getValue();
                if (b.length() > 0) b.append(" | ");
                b.append(e.getKey()).append(": ");
                if (d.completed < d.total) b.append("sending... ").append(d.completed).append('/').append(d.total);
                else if (d.failed > 0) b.append("unreachable (").append(d.failed).append(" parts)");
                else if (d.unconfirmed > 0) b.append("unconfirmed");
                else b.append("server echoed");
            }
            return b.toString();
        }
    }
    public static final class Friend {
        public String name = "";
        public boolean glow = false;
        public int color = 0xFFFF00, unread;
        public GlowStyle glowStyle = GlowStyle.DEFAULT;
        public GlowToggle glowThroughWalls = GlowToggle.DEFAULT, glowPulse = GlowToggle.DEFAULT;
        public int glowOpacity = -1, glowMaxDistance = 0;
        public double glowThickness = 0;
        /** Called at load and on cache rebuild, never in the frame loop. */
        public void normalizeGlow() {
            color &= 0xFFFFFF;
            if (glowStyle == null) glowStyle = GlowStyle.DEFAULT;
            if (glowThroughWalls == null) glowThroughWalls = GlowToggle.DEFAULT;
            if (glowPulse == null) glowPulse = GlowToggle.DEFAULT;
            glowOpacity = Config.clamp(glowOpacity, -1, 100);
            glowMaxDistance = Config.clamp(glowMaxDistance, 0, 4096);
            if (!Double.isFinite(glowThickness) || glowThickness <= 0) glowThickness = 0;
            else glowThickness = Math.max(1.04, Math.min(1.08, glowThickness));
        }
        public List<Message> messages = new ArrayList<>();
    }
    public static final class Group {
        public String id = "", name = "Unknown group", owner = "";
        public List<String> members = new ArrayList<>();
        public boolean pending = true, muted, sound = true, left;
        public long revision;
        public int unread;
        public List<Message> messages = new ArrayList<>();
    }
    public static final class State {
        public int schema = 1;
        public LinkedHashMap<String, Friend> friends = new LinkedHashMap<>();
        public LinkedHashMap<String, Group> groups = new LinkedHashMap<>();
    }
}
