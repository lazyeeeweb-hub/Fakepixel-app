# FriendLink — Fabric 1.20.1

Client-only Java 17 mod: friend whispers in a separate Discord-style screen, custom friend auras, a loaded-player radius HUD, and whisper-based groups. No server installation is needed. **Whispers are not encrypted. Server operators/plugins can read them.**

## Versions / install

- Minecraft **1.20.1**, Java **17**, Fabric Loader **0.14.21+**.
- Required: Fabric API for 1.20.1 (project builds with 0.92.2+1.20.1).
- Recommended: Cloth Config **11.1.118 / 11.x** for all settings, Mod Menu **7.2.2 / 7.x** for its config button. Both are compile dependencies but optional at runtime. Without Cloth, edit JSON with the game closed; friend/group controls still work in K.
- Put the built `friendlink-1.0.0.jar` and the runtime dependencies into your launcher's `mods` folder. Do not install on a dedicated server. Phone launchers must actually support Java Edition, Fabric 1.20.1 and Java 17; this is not a Bedrock add-on.

## Build from your phone / GitHub only

No Gradle installation, wrapper, local PC or repository secrets are required. CI provisions Gradle 8.6 and Temurin Java 17.

1. Download and extract the source ZIP with your phone's Files/archive app. Keep hidden folders, especially `.github`.
2. In a browser, create a GitHub repository. Initialize it with a README so the default branch exists.
3. Use **Add file → Upload files** and upload the **contents** of the extracted project, not the ZIP and not an extra containing folder. `build.gradle`, `settings.gradle`, `gradle.properties` and `src/` must be at the repository root. Upload in several commits if your mobile browser limits file selection. Desktop-site mode can help with folder uploads.
4. Make sure `.github/workflows/build.yml` is present. If your file picker hides `.github`, use **Add file → Create new file**, type that complete path, and paste the included workflow. A committed ZIP alone will NOT build.
5. If your phone cannot upload folders, use **Code → Codespaces → Create codespace** in the browser (if available for your account). Upload the ZIP into the browser editor's Explorer and extract it in the cloud terminal into the repository root. Commit/sync all project files using Source Control. Codespaces availability/quotas depend on your GitHub account; Actions itself does not require it.
6. Open **Actions → Build FriendLink**. Approve workflows if GitHub asks. The push triggers a build; you can also choose **Run workflow**. Wait for a green check.
7. Open the successful run. Under **Artifacts**, download **FriendLink-1.20.1** (sign in if prompted). Unzip that artifact; the installable remapped JAR is inside. Do not use `-sources.jar` or development JARs.
8. If red, open the failed step's log. Test reports are uploaded as `build-diagnostics` when available. Artifacts expire according to repository retention; rerun to recreate one.

Local/cloud terminal equivalent: `gradle build stageJar` with Gradle 8.6 and Java 17. A Gradle wrapper is deliberately not needed by the workflow.

## Controls / UI

All bindings are rebindable in **Options → Controls → Key Binds → FriendLink**:

| Default | Action |
|---|---|
| K | Open FriendLink |
| G | Master friend glow on/off |
| H | Radius HUD on/off |
| Y / N | Accept / decline the currently visible invitation toast |

- **+** adds a Java username (case-insensitive duplicates rejected). Click a friend to select a private conversation; right-click to confirm removing the friend and their private history.
- Select a friend: **✦ Glow: ON/OFF**, the style dropdown, and **RGB** sit together above the chat. The square or **Manage** also opens RGB sliders plus a hex field. With no friend selected, this toolbar edits the master toggle and global defaults. Default colour is yellow. The G key still toggles all FriendLink glow.
- **Cfg** opens Cloth settings; Mod Menu exposes the same screen. Friends can also be added/removed and glow/color edited there. Saving a removed name deletes that private log.
- The message area wraps; mouse wheel or Page Up / Page Down scrolls history. Wheel over the sidebar scrolls friends/groups. Resizing preserves the input draft.
- **Group +**: enter a name, select friends, Save + sync. You are included automatically; default maximum is 8 including you. Groups use a collage of member faces.
- Select a group → **Manage** to accept/decline, rename, add/remove members, mute, toggle that group's sound, or leave. Only the creator/owner edits name/membership; each change re-sends the metadata to old and new members. Owner leaving closes the group for reachable members.
- Native Minecraft toasts are not clickable screens: invite toasts show the actual rebindable Accept/Decline keys and remain visible for 10 seconds. Alternatively use K → pending group → Manage → Accept/Decline. Unknown tagged groups are created as **Unknown group**, pending approval; you cannot send until accepted.

## How transport works / honest limitations

- Private sends are vanilla `msg Name text` commands. Matched friend whispers and outgoing echoes are canceled **before** normal chat HUD insertion. Normal whispers from non-friends remain vanilla, except FriendLink protocol traffic, which is hidden when recognized.
- Group sends fan out `[FL:<uuid>] text` to every other member. Every member needs FriendLink and the same tag configuration for the group UI. Base64 multipart `[FLI:...]` invite/control whispers carry group id, name, owner, members and revision. Base64 is encoding, **not secrecy**. A recipient without the mod sees raw tags/invites.
- Default spacing is at least **400 ms**, shared by all messages/invite fragments. One command waits for its echo/error before the next, up to 2500 ms by default. This is intentionally slower on servers without echoes, so nameless `player not found` errors can be correlated as well as vanilla allows. Servers may demand a higher interval or disallow this automation entirely; respect their rules.
- Each outgoing message shows per-member `sending...`, `server echoed`, `unreachable`, or `unconfirmed`. Echoes are not read receipts. Missing echoes/timeouts are never claimed as successful delivery. Messages over command limits are split without breaking surrogate pairs; each received part is its own log entry.
- Offline recipients have no reliable preflight/offline mailbox. A matched server error adds a **player not found** private system line. With a nonstandard error/echo format the result stays unconfirmed; do not rely on absence from the tab list as proof that messaging is impossible.
- Vanilla English and several common whisper layouts are included. Configure **anchored regexes** in Cloth, with named `(?<name>...)` and `(?<message>...)` captures. Localized/plugin/proxy messages may need new patterns. Only matching messages can be hidden: **no client mod can promise that an unknown server format will never reach normal chat.** Regexes are trusted local configuration; avoid pathological backtracking patterns. Invalid patterns are ignored/logged.
- Invites/updates are best-effort whispers, not a reliable server membership service. Offline members miss them; the owner can re-save to resync. Pending previews are bounded. Owner identity is checked against the whisper sender, but names/tags are not cryptographic authentication and a malicious/offline-mode server can impersonate senders. No executable data, links or arbitrary skin URLs are accepted from invites.
- Friends and histories are **global to this Minecraft installation**, not per-server. A group should be used on one server/account. Disconnecting cancels the send queue so it cannot spill onto another server. No replay after reconnect.
- HUD/glow can use only player entities loaded in the current client world/dimension. Outside render/entity-tracking distance, friends cannot be detected without server support. Horizontal radius is the default; 3D distance is optional. HUD refreshes every 5 client ticks. No distance telemetry is requested from a server.
- Custom glow never uses vanilla glow flags, teams or an outline framebuffer. Renderer/shader packs can still change world rendering; use Marker if a pack makes the silhouette look wrong. Follow server rules for through-wall visuals.

## Custom friend glow

- **Silhouette (default):** flat solid-colour, unlit player-model pass, additive blend, scale 1.06 (configurable 1.04–1.08). No skin/armour/held-item/nametag/shadow passes are repeated.
- **Halo:** soft radial-alpha sprite at body height, billboarded to the camera, placed slightly behind the body centre.
- **Marker:** plain, untextured camera-facing diamond above the head. Optional pulse; no silhouette shader/texture dependency. This is the manual Iris/shader-pack fallback, not a promise of compatibility with every shader pack.
- **Through walls defaults ON for every style.** The custom layer disables depth testing at draw time and never writes depth. LAST runs after world geometry and Fabulous compositing. Turn it off globally or per friend to use normal depth occlusion.
- Master toggle and **G** keybind; configurable default-on glow for newly added friends. Existing saved glow flags/colours are preserved. Old disabled friends are not silently enabled.
- Yellow default RGB, 55% opacity, maximum 128 blocks measured from the camera in 3D. Only loaded client-world players can render. Self, dead, invisible and spectator players are skipped (including potion-invisible friends). No server data is requested.
- Optional block-only occlusion fade: off by default, defaults to 55% of chosen opacity when enabled. Raycasts run every 5 client ticks (or on settings changes), from the camera to the body centre; this is whole-glow fading, not per-pixel intersection fading. Entities do not trigger block fading.
- **Cfg → Friend glow** holds global defaults; **Cfg → Friends** holds overrides: style, RGB, opacity, distance, thickness, through walls and pulse. Default/-1/0 values follow the corresponding global setting. Chat's style dropdown offers **Default** for inheritance.
- Cached: six RenderLayers (style × depth mode), shader suppliers, BufferBuilder, MatrixStack, flat vertex adapter, resolved settings/RGB channels and 512 reusable cache entries. Name lookup, colour decoding and fade raycasts happen on ticks, never per-frame. Frame code does not instantiate app-owned layers/colours/lists/wrappers. Minecraft's model/matrix/buffer internals may still allocate; this is not a claim of zero allocation inside Minecraft or Iris.
- No debug command is added. Vanilla/server potion/arrow/team visuals remain entirely independent.

### Glow acceptance checklist (in-game validation required)

1. Add a newly loaded friend: enabled, yellow Silhouette. Confirm self/non-friends/invisible/spectator/dead/unloaded friends never get custom visuals; verify reconnect and dimension changes.
2. Test each style behind solid blocks, terrain, glass/water and other entities, with through-walls ON; turn it OFF and verify depth occlusion. Test Fast/Fancy/Fabulous and first/third-person views.
3. Verify 128-block cutoff (also while moving camera), opacity 0/100, scale 1.04/1.08, block fade on/off and pulse on/off. An entity outside server tracking range cannot be shown.
4. Toggle G and the labeled chat button. Change dropdown including Default inheritance and RGB/hex; save/restart to verify global and per-friend persistence. Resize and operate dropdown by mouse and keyboard.
5. Test standing, sneaking, walking, swimming, sleeping, riding and elytra poses. Compare the expanded silhouette to the actual posed player model.
6. Test Iris with shaders disabled/enabled: switch manually to Marker if Silhouette is distorted. Check that normal entity/team/potion glow, GUI, particles and subsequent frame depth/blend state are unaffected.

## Data / performance

`config/friendlink/config.json` stores settings. `conversations.json` stores friend/group metadata and separate message arrays per conversation, including unread counts and delivery state. `skins/<lowercase-name>.png` and `.json` store disk-cached PNG/UUID/URL data (7-day refresh; fallback Steve/Alex-style default heads). Back up this folder; it contains plaintext private chat.

JSON loads on startup, is snapshotted on ticks, and writes atomically through one background worker. Dirty conversation data saves about once per second and on disconnect/shutdown. Mojang HTTP, disk skin reads and PNG decoding use two workers with timeouts and size limits; GL texture upload occurs on the client thread. Online tab-list skins take precedence. There are no render-time network/disk calls, stream pipelines, message rewrapping, new row objects or changing label strings. Minecraft/Cloth renderer internals (including matrix stacks and text buffers) may allocate; literal zero allocations inside third-party rendering cannot be promised.

Safety bounds: 512 friends, 128 groups, 512 queued commands, 32 incomplete invite assemblies; histories default to 1000 messages per conversation. Closing the game discards in-flight sends and marks them failed/unconfirmed. Corrupt JSON files get a `.broken-<timestamp>` backup. Storage failures are logged.

## Validation / smoke test

The source is supplied with protocol JUnit tests and a CI build. API signatures were checked against 1.20.1 Yarn/Fabric/Cloth metadata, but this distribution has **not been compiled or run in Minecraft in the generation environment**. A green GitHub build verifies compilation and unit tests, not in-game behavior.

Before regular use, test with two modded clients: add each other; send both directions and confirm the normal HUD stays empty; test an offline player and unread/sound/toasts; change a glow color behind a wall; test HUD radius/dimension/unload; create/approve a group; rename/add/remove/mute/leave; restart and verify logs; test resize/scroll and long messages. Repeat on your actual server format and renderer. Test inviting a third offline member, then re-save once online to resync.

MIT licensed. `FriendGlow.java` documents the WorldRenderEvents.LAST hook. `mixin/PlayerGlowPoseAccessor.java` only exposes player pose/transform helpers. Message suppression uses Fabric events rather than an extra chat mixin.
