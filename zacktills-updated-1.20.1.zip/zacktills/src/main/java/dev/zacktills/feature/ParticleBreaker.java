package dev.zacktills.feature;

import dev.zacktills.config.FeatureSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.List;

/** Conservative, ordinary interaction-manager block breaking gated by an exact current ray hit. */
final class ParticleBreaker {
    private static BlockPos breakingPos;
    private static Direction breakingSide;
    private static long lastAimNanos;

    private ParticleBreaker() { }

    static void tick(MinecraftClient client, List<BlockPos> targets) {
        if (!FeatureSettings.boolValue("particle.auto_break", false)) { cancel(client); return; }
        PlayerEntity player = client.player;
        ClientPlayerInteractionManager manager = client.interactionManager;
        if (client.world == null || player == null || manager == null || player.isDead() || player.isSpectator()
                || client.currentScreen != null || client.options.getPerspective() != Perspective.FIRST_PERSON
                || targets == null || targets.isEmpty()) { cancel(client); return; }
        BlockPos target = targets.get(0);
        Vec3d eye = player.getCameraPosVec(1.0F);
        Vec3d center = Vec3d.ofCenter(target);
        double reach = Math.min(4.5, manager.getReachDistance());
        double distanceSquared = eye.squaredDistanceTo(center);
        if (!Double.isFinite(reach) || reach <= 0 || distanceSquared > reach * reach
                || client.world.getBlockState(target).isAir()) { cancel(client); return; }

        aimAt(player, center);
        Vec3d start = player.getCameraPosVec(1.0F);
        Vec3d end = start.add(player.getRotationVec(1.0F).multiply(reach));
        HitResult result = client.world.raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (!(result instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK
                || !hit.getBlockPos().equals(target)) { cancel(client); return; }

        if (!target.equals(breakingPos)) {
            cancel(client);
            if (!manager.attackBlock(target, hit.getSide())) return;
            breakingPos = target.toImmutable();
            breakingSide = hit.getSide();
        } else {
            breakingSide = hit.getSide();
            manager.updateBlockBreakingProgress(target, breakingSide);
        }
    }

    private static void aimAt(PlayerEntity player, Vec3d target) {
        long now = System.nanoTime();
        if (lastAimNanos == 0) lastAimNanos = now;
        double dt = Math.max(0, Math.min(.1, (now - lastAimNanos) / 1_000_000_000.0));
        lastAimNanos = now;
        Vec3d eye = player.getCameraPosVec(1.0F);
        double dx = target.x-eye.x, dy=target.y-eye.y, dz=target.z-eye.z;
        double horizontal = Math.sqrt(dx*dx + dz*dz);
        float desiredYaw = (float)(Math.toDegrees(Math.atan2(dz,dx)) - 90.0);
        float desiredPitch = (float)-Math.toDegrees(Math.atan2(dy,horizontal));
        float yawDelta = MathHelper.wrapDegrees(desiredYaw-player.getYaw());
        float pitchDelta = MathHelper.wrapDegrees(desiredPitch-player.getPitch());
        double length = Math.sqrt(yawDelta*yawDelta + pitchDelta*pitchDelta);
        double maxStep = Math.max(0, FeatureSettings.number("particle.break_speed")) * dt;
        if (length > maxStep && length > 0) {
            float scale = (float)(maxStep/length);
            yawDelta *= scale;
            pitchDelta *= scale;
        }
        player.setYaw(player.getYaw()+yawDelta);
        player.setPitch(MathHelper.clamp(player.getPitch()+pitchDelta,-90.0F,90.0F));
    }

    static void cancel(MinecraftClient client) {
        if (breakingPos != null && client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        breakingPos = null;
        breakingSide = null;
        lastAimNanos = 0;
    }

    static void reset(MinecraftClient client) { cancel(client); }
}
