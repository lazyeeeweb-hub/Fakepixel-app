package dev.zacktills.feature;

import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Bounded spatial buckets of observed spawn positions, timestamped with monotonic time. */
final class ParticleTracker {
    static final double MAX_RADIUS_SQUARED = 64.0 * 64.0;
    private static final int MAX_TOTAL = 4096;
    private static final int MAX_PER_BUCKET = 128;
    private static final int MAX_PER_TICK = 1024;
    private static final int MAX_CANDIDATES = 32768;

    private final ArrayDeque<Point> ordered = new ArrayDeque<>();
    private final Map<BlockPos, ArrayDeque<Point>> buckets = new HashMap<>();
    private int addedThisTick;

    void beginTick() { addedThisTick = 0; }

    void add(Identifier type, double x, double y, double z, long timeNanos) {
        if (addedThisTick >= MAX_PER_TICK || ordered.size() >= MAX_TOTAL) return;
        BlockPos bucket = BlockPos.ofFloored(x, y, z);
        ArrayDeque<Point> inBucket = buckets.computeIfAbsent(bucket, ignored -> new ArrayDeque<>());
        if (inBucket.size() >= MAX_PER_BUCKET) return;
        Point point = new Point(type, x, y, z, timeNanos, bucket);
        ordered.addLast(point);
        inBucket.addLast(point);
        addedThisTick++;
    }

    List<BlockPos> findTargets(ClientWorld world, PlayerEntity player,
                               int minimum, int maximum, double windowSeconds) {
        long now = System.nanoTime();
        long window = (long)(Math.max(.1, Math.min(5.0, windowSeconds)) * 1_000_000_000L);
        expire(now, window);
        if (ordered.isEmpty() || player == null) return List.of();
        int required = Math.max(1, Math.min(128, minimum));
        int maxTargets = Math.max(1, Math.min(3, maximum));
        Map<BlockPos, Integer> hits = new HashMap<>();
        outer:
        for (Point point : ordered) {
            int minX = BlockPos.ofFloored(point.x - 2, 0, 0).getX();
            int maxX = BlockPos.ofFloored(point.x + 1, 0, 0).getX();
            int minY = BlockPos.ofFloored(0, point.y - 2, 0).getY();
            int maxY = BlockPos.ofFloored(0, point.y + 1, 0).getY();
            int minZ = BlockPos.ofFloored(0, 0, point.z - 2).getZ();
            int maxZ = BlockPos.ofFloored(0, 0, point.z + 1).getZ();
            for (int x=minX; x<=maxX; x++) for (int y=minY; y<=maxY; y++) for (int z=minZ; z<=maxZ; z++) {
                double dx = x + .5 - point.x, dy = y + .5 - point.y, dz = z + .5 - point.z;
                if (dx*dx + dy*dy + dz*dz > 2.25) continue;
                BlockPos candidate = new BlockPos(x,y,z);
                Integer old = hits.get(candidate);
                if (old == null) {
                    if (hits.size() >= MAX_CANDIDATES) continue;
                    hits.put(candidate, 1);
                } else hits.put(candidate, old + 1);
            }
        }
        Vec3d playerPos = player.getPos();
        List<BlockPos> result = new ArrayList<>();
        for (Map.Entry<BlockPos,Integer> entry : hits.entrySet()) {
            BlockPos pos = entry.getKey();
            if (entry.getValue() < required || playerPos.squaredDistanceTo(Vec3d.ofCenter(pos)) > MAX_RADIUS_SQUARED
                    || !world.isChunkLoaded(pos)) continue;
            BlockState state = world.getBlockState(pos);
            if (!state.isAir() && !state.getCollisionShape(world, pos).isEmpty()) result.add(pos);
        }
        result.sort(Comparator.comparingDouble(pos -> playerPos.squaredDistanceTo(Vec3d.ofCenter(pos))));
        if (result.size() > maxTargets) return List.copyOf(result.subList(0,maxTargets));
        return List.copyOf(result);
    }

    private void expire(long now, long windowNanos) {
        while (!ordered.isEmpty() && now - ordered.peekFirst().timeNanos > windowNanos) {
            Point expired = ordered.removeFirst();
            ArrayDeque<Point> bucket = buckets.get(expired.bucket);
            if (bucket != null) {
                bucket.removeFirstOccurrence(expired);
                if (bucket.isEmpty()) buckets.remove(expired.bucket);
            }
        }
    }

    void reset() {
        ordered.clear();
        buckets.clear();
        addedThisTick = 0;
    }

    private record Point(Identifier type, double x, double y, double z, long timeNanos, BlockPos bucket) { }
}
