# Zacktills Client (Minecraft 1.20.1 / Fabric)

This is an experimental client-side source update to the provided config-menu prototype. It contains settings and rendering hooks for configurable HUD elements, clean scoreboard, slot locks, flat dropped-item icons, tooltip scrolling, custom crosshair/viewmodel, swing-through, opt-in chat-triggered login, third-person wall fade.

## Build
Open the project with a Java 17 Gradle environment and run `gradle build`. The resulting mod JAR is expected under `build/libs/`. The source targets Fabric Loom 1.6.12, Yarn 1.20.1+build.10, Fabric API 0.92.2+1.20.1 and Java 17. Verify the in-game controls and visuals in a test profile before use.

## Notes / limitations
- Sodium donation-prompt hiding is controlled by the existing menu setting. A separate opt-in setting, “Hide Sodium driver warning (may hide compatibility problems),” suppresses Sodium 0.5.x early and context-time driver-warning checks. It is off by default; enabling it can conceal real driver compatibility problems. Hooks are optional when Sodium is absent.
- Wall fade is experimental, uses a vanilla core-shader dither effect, and is disabled when Sodium or Iris is detected.
- Autologin is off by default and requires an exact server address. The password is kept in memory only until disconnect; only enable it for a trusted server. Chat prompts on unsigned/custom servers may be spoofed.
- Slot lock is a client-side guard for local inventory interactions, not protection against server/plugin changes. Multi-slot inventory operations are conservatively blocked when any local slot is locked.
- Mod Menu 7.2.2 already restores the mod-list scroll position when returning to the same ModsScreen instance; recent mods are not reordered. Other Mod Menu versions or screens that create a fresh ModsScreen are unverified.

Controls: Right Shift opens configuration; L toggles lock for the hovered player-inventory slot. All settings are configurable in the Zacktills menu.

## ZUI-style hub
- Right Shift still opens settings. Pick a named tab on the left. Search, filters, tooltips, keyboard navigation, and unrelated setting IDs are retained.
- Drag the title bar to move the hub or the dotted lower-right grip to resize it. `−` collapses the hub; `+` expands it. `X` or Escape closes it and saves settings. Window placement and collapse state are not written to the config.
- Under **Tooltips & crosshair**, **Crosshair thickness** (1–9) and **Crosshair arm length** (1–20) work independently, in scaled GUI pixels. Arm length is measured outward from the center square. The preview uses the same geometry as the HUD. The 1/4 defaults reproduce the old 9×9 crosshair. Turning off the custom crosshair leaves the vanilla renderer in control.

## Touch controls and HUD additions
- Tap **Zacktills** on the pause or title screen to open the hub. The persistent-tab keybind is unbound by default; under **Tab list**, tap **Show tab list (toggle)** instead. It changes only the vanilla tab-key check and resets on disconnect; vanilla still controls singleplayer eligibility and HUD visibility.
- Tap **Pick tab parts**, swipe to scroll, and tap a row to add or remove it. A check means the part is saved. The **Mode** button switches between a single line and its whole section. A nonblank line with no colon or a bold first visible character starts a section; a blank line ends it. Parts follow the current text by name; duplicates are distinguished by occurrence in vanilla tab order. Missing parts are hidden. Parts also hide when the vanilla tab list is visible or F1 hides the HUD.
- In **Manage tab parts**, tap **On/Off**, **Edit**, or **Remove**. In the shared HUD editor, drag the solid element, tap a dim tab-part preview to select it, tap **- / +** to scale, **Reset** to center and restore 100% scale, or **Save / Back** to exit. Other overlays are drawn at half opacity. Missing live content gets a preview in the editor only.
- **Auto click** starts off. Enable it only on trusted servers. It uses vanilla's `RUN_COMMAND` rules and ignores overlay/action-bar messages and other click actions. The default trigger is `[OPEN MENU]` (case-insensitive), with a four-tick delay and two-second cooldown. **Enter trigger text (touch keyboard)** works without a launcher keyboard. Debug messages are written to the game log.
- **Playtime** counts real time with a world loaded, including while paused. The pause menu shows it by default. Use **Enter exact days / hours / minutes** to set the draft with a tap keypad, then **Apply (overwrite playtime)**. **Reset playtime to zero** clears the total; changing draft fields alone leaves the counter untouched.
- Tab parts and playtime are saved in `config/zacktills/tab_parts.json` and `config/zacktills/playtime.json`. Playtime saves every minute while playing, on disconnect, and on normal client shutdown. Legacy unknown settings are ignored.

- Hidden vanilla menu controls are removed and surviving controls are re-centered/repacked into compact rows to avoid empty button slots.

- In-game HUD text (scoreboard, tab-part boxes, and item stack counts) uses the bundled Google Fonts Inter typeface with a TrueType font provider; the settings/menu UI keeps the vanilla font. Inter is distributed under the SIL Open Font License; its license is included beside the font resource.
