package dev.zacktills.feature;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.zacktills.config.FeatureSettings;
import dev.zacktills.mixin.PlayerListHudAccess;
import dev.zacktills.ui.HudEditorScreen;
import dev.zacktills.ui.TabPartsScreen;
import dev.zacktills.ui.TabPickerScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class TabParts {
    public enum Kind { LINE, SECTION }
    // The first occurrence is stored without an index. Later occurrences have a zero-based index.
    public record Ref(Kind kind, String key, Integer occurrence) {
        public String elementId() {
            return "tab:" + kind + ":" + key.toLowerCase(Locale.ROOT) + ":" + (occurrence == null ? 0 : occurrence);
        }
    }
    public record Row(Text text, Ref line, Ref section) {}
    private record Snapshot(List<Row> rows, Map<String, List<Text>> matches) {
        private static final Snapshot EMPTY = new Snapshot(List.of(), Map.of());
    }

    private static final Logger LOG = LoggerFactory.getLogger("zacktills/tab-parts");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zacktills/tab_parts.json");
    private static final Map<String, Part> PARTS = new LinkedHashMap<>();
    private static Snapshot snapshot = Snapshot.EMPTY;
    private static ClientPlayNetworkHandler connection;
    private static int ticksUntilRefresh;
    private static boolean persistentTab;

    private TabParts() {}

    public static boolean showVanillaTab() { return persistentTab; }
    public static void toggleVanillaTab() { persistentTab = !persistentTab; }
    public static List<Row> rows() { return snapshot.rows(); }
    public static List<Part> parts() { return List.copyOf(PARTS.values()); }
    public static boolean contains(Ref ref) { return ref != null && PARTS.containsKey(ref.elementId()); }

    public static void openPicker() {
        var client = MinecraftClient.getInstance();
        FeatureSettings.save();
        client.setScreen(new TabPickerScreen(client.currentScreen));
    }

    public static void openManager() {
        var client = MinecraftClient.getInstance();
        FeatureSettings.save();
        client.setScreen(new TabPartsScreen(client.currentScreen));
    }

    public static void tick(MinecraftClient client) {
        var current = client.getNetworkHandler();
        if (client.world == null || current == null) {
            snapshot = Snapshot.EMPTY;
            connection = null;
            return;
        }
        if (current != connection || --ticksUntilRefresh <= 0) {
            connection = current;
            ticksUntilRefresh = 10;
            var hud = client.inGameHud.getPlayerListHud();
            var entries = ((PlayerListHudAccess) hud).zacktills$collectPlayerEntries();
            snapshot = buildSnapshot(entries.stream().map(hud::getPlayerName).toList());
        }
    }

    public static void disconnect() {
        connection = null;
        snapshot = Snapshot.EMPTY;
        persistentTab = false;
    }

    static Snapshot buildSnapshot(List<Text> entries) {
        var rows = new ArrayList<Row>();
        var matches = new HashMap<String, List<Text>>();
        var lineCounts = new HashMap<String, Integer>();
        var sectionCounts = new HashMap<String, Integer>();
        Ref section = null;
        for (Text text : entries) {
            String plain = Formatting.strip(text.getString()).strip();
            if (plain.isEmpty()) {
                rows.add(new Row(text, null, null));
                section = null;
                continue;
            }
            int colon = plain.indexOf(':');
            String label = colon > 0 ? plain.substring(0, colon).strip() : plain;
            Ref line = ref(Kind.LINE, label, lineCounts);
            matches.put(line.elementId(), List.of(text));
            if (colon < 0 || startsBold(text)) {
                section = ref(Kind.SECTION, plain, sectionCounts);
                matches.put(section.elementId(), new ArrayList<>());
            }
            if (section != null) matches.get(section.elementId()).add(text);
            rows.add(new Row(text, line, section));
        }
        matches.replaceAll((id, lines) -> List.copyOf(lines));
        return new Snapshot(List.copyOf(rows), Map.copyOf(matches));
    }

    private static Ref ref(Kind kind, String key, Map<String, Integer> counts) {
        int index = counts.merge(key.toLowerCase(Locale.ROOT), 1, Integer::sum) - 1;
        return new Ref(kind, key, index == 0 ? null : index);
    }

    private static boolean startsBold(Text text) {
        // OrderedText exposes effective style, including legacy §l codes in server-supplied text.
        boolean[] bold = {false};
        text.asOrderedText().accept((i, style, cp) -> {
            if (Character.isWhitespace(cp) || Character.isSpaceChar(cp)) return true;
            bold[0] = style.isBold();
            return false;
        });
        return bold[0];
    }

    public static void toggle(Ref ref) {
        if (ref == null) return;
        String id = ref.elementId();
        Part present = PARTS.get(id);
        if (present != null) {
            remove(present);
        } else if (snapshot.matches().containsKey(id)) {
            Part part = new Part();
            part.kind = ref.kind(); part.key = ref.key(); part.occurrence = ref.occurrence();
            part.x = .15 + .07 * (PARTS.size() % 9);
            part.y = .2 + .08 * (PARTS.size() % 8);
            register(part);
            save();
        }
    }

    public static void remove(Part part) {
        if (PARTS.remove(part.id(), part)) {
            HudElements.unregister(part.id());
            save();
        }
    }

    private static void register(Part part) {
        if (PARTS.putIfAbsent(part.id(), part) == null) HudElements.register(part);
    }

    public static void render(DrawContext context, PlayerListHud hud) {
        var client = MinecraftClient.getInstance();
        if (client.world == null || client.options.hudHidden || client.currentScreen instanceof HudEditorScreen
                || ((PlayerListHudAccess) hud).zacktills$isVisible()) return;
        for (Part part : PARTS.values()) {
            List<Text> lines = part.live();
            if (part.enabled && !lines.isEmpty()) part.draw(context, lines, 1);
        }
    }

    public static void load() {
        if (!Files.isRegularFile(FILE)) return;
        try (var reader = Files.newBufferedReader(FILE)) {
            Part[] loaded = GSON.fromJson(reader, Part[].class);
            if (loaded == null) return;
            for (Part part : loaded) {
                if (part == null || part.kind == null || part.key == null || part.key.isBlank()
                        || part.occurrence != null && part.occurrence < 0) continue;
                part.key = part.key.strip();
                if (Integer.valueOf(0).equals(part.occurrence)) part.occurrence = null;
                part.position(part.position());
                register(part);
            }
        } catch (IOException | RuntimeException e) {
            LOG.warn("Could not read {}", FILE, e);
        }
    }

    private static void save() {
        Path tmp = FILE.resolveSibling("tab_parts.json.tmp");
        try {
            Files.createDirectories(FILE.getParent());
            try (var writer = Files.newBufferedWriter(tmp)) { GSON.toJson(parts(), writer); }
            try {
                Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Could not save {}", FILE, e);
        }
    }

    public static final class Part implements HudElement {
        private Kind kind;
        private String key;
        private Integer occurrence;
        private double x = .5, y = .5, scale = 1;
        private boolean enabled = true;

        private Part() {}

        @Override public String id() { return new Ref(kind, key, occurrence).elementId(); }
        @Override public String label() {
            return key + (occurrence == null ? "" : " #" + ((long) occurrence + 1));
        }
        public Kind kind() { return kind; }
        public boolean enabled() { return enabled; }
        public void toggleEnabled() { enabled = !enabled; save(); }
        @Override public int defaultWidth() { return 100; }
        @Override public int defaultHeight() { return kind == Kind.LINE ? 20 : 40; }
        @Override public Position position() { return new Position(x, y, scale); }
        @Override public void position(Position p) { x = p.x(); y = p.y(); scale = p.scale(); }
        @Override public void savePosition() { save(); }
        @Override public Size size() { return measure(display()); }
        @Override public void render(DrawContext context, float alpha) { draw(context, display(), alpha); }

        private List<Text> live() { return snapshot.matches().getOrDefault(id(), List.of()); }
        private List<Text> display() {
            List<Text> lines = live();
            if (!lines.isEmpty()) return lines;
            return kind == Kind.LINE ? List.of(Text.literal(label() + ": preview"))
                    : List.of(Text.literal(label()).formatted(Formatting.BOLD), Text.literal("Tab part preview"));
        }

        private Size measure(List<Text> lines) {
            var font = MinecraftClient.getInstance().textRenderer;
            int width = lines.stream().map(HudFonts::apply).mapToInt(font::getWidth).max().orElse(0) + 12;
            return new Size(Math.max(24, width), 8 + lines.size() * (font.fontHeight + 2));
        }

        private void draw(DrawContext context, List<Text> lines, float alpha) {
            var font = MinecraftClient.getInstance().textRenderer;
            Size size = measure(lines);
            HudFeatures.begin(context, this, size);
            HudFeatures.drawBox(context, size, alpha);
            for (int i = 0; i < lines.size(); i++) {
                context.drawTextWithShadow(font, HudFonts.apply(lines.get(i)), 6, 4 + i * (font.fontHeight + 2),
                        HudFeatures.textColor(0xFFFFFF, alpha));
            }
            context.getMatrices().pop();
        }
    }
}
