package dev.zacktills.feature;
import dev.zacktills.ZacktillsClient;
import dev.zacktills.config.FeatureSettings;
import net.fabricmc.fabric.api.client.screen.v1.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.*;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import java.util.*;
public final class MenuFeatures {
    private static final Set<String> EXTRA = Set.of("menu.sendFeedback", "menu.reportBugs", "gui.advancements", "gui.stats");
    private MenuFeatures() {}

    public static void initialize(MinecraftClient mc, Screen screen, int width, int height) {
        if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
            Screens.getButtons(screen).removeIf(button -> {
                if (!(button.getMessage().getContent() instanceof TranslatableTextContent t)) return false;
                String key = t.getKey();
                return FeatureSettings.on("interface.realms") && (key.equals("menu.online") || key.equals("menu.realms"))
                    || FeatureSettings.on("interface.extras") && EXTRA.contains(key);
            });
            Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Zacktills"), b -> mc.setScreen(ZacktillsClient.config(screen))).dimensions(4, 4, 90, 20).build());
            compactMenuRows(screen, width);
        }
        if (screen instanceof GameMenuScreen) {
            ScreenEvents.afterRender(screen).register((s, c, x, y, delta) -> Playtime.render(mc, s, c));
        }
        if (screen instanceof HandledScreen<?>) {
            ItemFeatures.clearHovered();
            ScreenEvents.afterRender(screen).register((s, c, x, y, delta) -> ItemFeatures.trackHovered(s));
        }
    }

    /** Repack the surviving menu controls into centered, gap-free rows after optional controls are removed. */
    private static void compactMenuRows(Screen screen, int screenWidth) {
        List<ClickableWidget> controls = new ArrayList<>();
        for (ClickableWidget button : Screens.getButtons(screen)) {
            if ("Zacktills".equals(button.getMessage().getString())) continue;
            String key = button.getMessage().getContent() instanceof TranslatableTextContent t ? t.getKey() : "";
            String label = button.getMessage().getString().toLowerCase(Locale.ROOT);
            boolean menuControl = key.startsWith("menu.") || key.equals("gui.stats") || key.equals("gui.advancements")
                    || key.startsWith("modmenu.") || label.equals("mods") || label.equals("mod menu");
            if (menuControl) controls.add(button);
        }
        if (controls.isEmpty()) return;
        controls.sort(Comparator.comparingInt(ClickableWidget::getY).thenComparingInt(ClickableWidget::getX));
        List<List<ClickableWidget>> rows = new ArrayList<>();
        for (ClickableWidget button : controls) {
            if (rows.isEmpty() || Math.abs(rows.get(rows.size() - 1).get(0).getY() - button.getY()) > 2) {
                rows.add(new ArrayList<>());
            }
            rows.get(rows.size() - 1).add(button);
        }
        int y = rows.get(0).stream().mapToInt(ButtonWidget::getY).min().orElse(0);
        for (List<ClickableWidget> row : rows) {
            int rowHeight = row.stream().mapToInt(ClickableWidget::getHeight).max().orElse(20);
            int gap = row.size() > 1 ? 4 : 0;
            int totalWidth = row.stream().mapToInt(ClickableWidget::getWidth).sum() + gap * (row.size() - 1);
            int x = Math.max(0, (screenWidth - totalWidth) / 2);
            for (ClickableWidget button : row) {
                button.setX(x);
                button.setY(y);
                x += button.getWidth() + gap;
            }
            y += rowHeight + 4;
        }
    }
}
