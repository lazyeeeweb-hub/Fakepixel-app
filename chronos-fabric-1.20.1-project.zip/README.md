# Chronos Client - Minecraft 1.20.1 Fabric Mod

A modular sandbox automation & solver client for Minecraft 1.20.1 Fabric.

## Key Features
- **Keybind GUI**: Default keybinds `Right Shift` and `R` (configured in Minecraft Controls)
- **Cloth Config v11**: Full graphical configuration screen (also accessible via Mod Menu)
- **Auto-Solvers**:
  - Terminal Solvers (Click in numerical order, Select color panes, Starts with letter, Panes/Lights)
  - Simon Says / Chronomatron Solver (sound pitch & packet tracking)
  - Tic-Tac-Toe Minimax Solver (unbeatable optimal moves)
  - Water Board 5-Lever Flow Solver
  - Trivia Chat Parser
- **No-API Workaround**: Intercepts S2C network packets (`ScreenHandlerSlotUpdateS2CPacket`, `PlaySoundS2CPacket`) using Fabric Mixins.
- **Asynchronous Click Scheduler**: Paced with humanized Gaussian jitter to eliminate sandbox rate-limiting.

## Building the Mod
To compile the .jar:
```bash
./gradlew build
```
The compiled mod JAR will be located at:
`build/libs/chronos-1.20.1-1.0.0.jar`
Drop it into your `.minecraft/mods` folder along with Fabric Loader 0.15+, Fabric API, and Cloth Config.
