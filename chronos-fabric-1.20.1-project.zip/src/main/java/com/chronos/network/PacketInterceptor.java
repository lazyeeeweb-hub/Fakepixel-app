package com.chronos.network;

import com.chronos.config.ChronosConfig;
import com.chronos.solvers.SimonSaysSolver;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;

/**
 * Workaround Engine for Servers with No API.
 * Intercepts low-level Minecraft network packets to trigger solvers automatically.
 */
public class PacketInterceptor {

    public static void init() {
        // Registered via Mixins
    }

    public static void handleSlotUpdate(ScreenHandlerSlotUpdateS2CPacket packet) {
        if (ChronosConfig.logIncomingPackets) {
            System.out.println("[Chronos Packet] Slot update: " + packet.getSlot() + " item: " + packet.getItemStack());
        }
    }

    public static void handleSound(PlaySoundS2CPacket packet) {
        String soundId = packet.getSound().value().getId().toString();

        // Simon Says note block tone detection
        if (soundId.contains("note_block")) {
            float pitch = packet.getPitch();
            // Maps pitch to glass index 0-4
            int index = (int) Math.round(pitch * 4.0);
            SimonSaysSolver.recordServerFlash(index);
        }
    }

    public static void handleChatMessage(GameMessageS2CPacket packet) {
        String message = packet.content().getString();

        // Trivia / Quiz chat detection
        if (message.contains("[Trivia]") || message.contains("Quiz:")) {
            // Auto-answer logic or highlights
        }
    }
}