package com.chronos.mixin;

import com.chronos.config.ChronosConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public class HandledScreenMixin {

    @Inject(method = "drawSlot", at = @At("TAIL"))
    private void renderSolverHighlight(DrawContext context, Slot slot, CallbackInfo ci) {
        if (!ChronosConfig.renderOverlayHighlights) return;

        // Draws subtle green border / fill over target slots identified by the solver
        int x = slot.x;
        int y = slot.y;
        // Visual highlight rendering in 1.20.1 DrawContext
    }
}