package com.chronos.automation;

import com.chronos.config.ChronosConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.screen.slot.SlotActionType;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Random;

/**
 * Click Scheduler:
 * Prevents server kicks or desyncs by queuing clicks and executing them with
 * humanized jitter variance (baseDelayMs + gaussianOffset).
 */
public class ClickQueueManager {
    private static final ClickQueueManager INSTANCE = new ClickQueueManager();
    private final Queue<Integer> queue = new ArrayDeque<>();
    private final Random random = new Random();
    private long lastClickTime = 0;
    private long nextDelay = 0;

    public static ClickQueueManager getInstance() {
        return INSTANCE;
    }

    public void queueClick(int slotId) {
        if (!queue.contains(slotId)) {
            queue.add(slotId);
        }
    }

    public void clearQueue() {
        queue.clear();
    }

    public void onClientTick(MinecraftClient client) {
        if (!ChronosConfig.autoSolveEnabled || queue.isEmpty()) return;
        if (client.player == null || client.interactionManager == null) return;
        if (client.currentScreen == null) {
            queue.clear();
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastClickTime < nextDelay) {
            return;
        }

        int slot = queue.poll();
        int syncId = client.player.currentScreenHandler.syncId;

        // Perform click packet via interactionManager
        client.interactionManager.clickSlot(
            syncId,
            slot,
            0,
            SlotActionType.PICKUP,
            client.player
        );

        lastClickTime = now;
        // Compute next delay with humanized Box-Muller jitter
        double gaussian = random.nextGaussian();
        int jitter = (int) (gaussian * (ChronosConfig.clickJitterMs / 2.0));
        nextDelay = Math.max(25, ChronosConfig.clickDelayMs + jitter);
    }
}