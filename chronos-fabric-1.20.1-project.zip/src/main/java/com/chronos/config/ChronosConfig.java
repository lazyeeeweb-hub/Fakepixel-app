package com.chronos.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Cloth Config v11 Integration for Minecraft 1.20.1.
 * Provides granular settings for solvers, automation jitter, render overlays, and packet workarounds.
 */
public class ChronosConfig {

    // Solvers Category
    public static boolean enableTerminalNumbers = true;
    public static boolean enableTerminalColors = true;
    public static boolean enableTerminalLetter = true;
    public static boolean enableSimonSays = true;
    public static boolean enableTicTacToe = true;
    public static boolean enableWaterBoard = true;
    public static boolean enableTriviaChat = true;

    // Automation & Pacing Category
    public static boolean autoSolveEnabled = true;
    public static int clickDelayMs = 70;      // Base delay between clicks in ms
    public static int clickJitterMs = 25;     // Humanized randomized Gaussian variance
    public static boolean autoCloseOnFinish = true;
    public static int maxClicksPerTick = 1;   // Prevents server kick/rate limit desync

    // Render & HUD Category
    public static boolean renderOverlayHighlights = true;
    public static int highlightColorHex = 0x5500FF00; // Semi-transparent bright green
    public static boolean showClickOrderNumbers = true;
    public static boolean showPacketSnooperHud = true;

    // Packet Workarounds Category
    public static boolean packetInterceptionEnabled = true;
    public static boolean soundAnalysisWorkaround = true;
    public static boolean logIncomingPackets = false;

    public static void load() {
        // Loads config from .minecraft/config/chronos.json
    }

    public static void save() {
        // Saves preferences to .minecraft/config/chronos.json
    }

    public static Screen createClothConfigScreen(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(Text.literal("Chronos Client Configuration"));

        ConfigEntryBuilder entryBuilder = builder.entryBuilder();

        // 1. Solvers Category
        ConfigCategory solvers = builder.getOrCreateCategory(Text.literal("Auto Solvers"));
        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Numbers Order Solver"), enableTerminalNumbers)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableTerminalNumbers = val)
            .build());

        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Color Panes Solver"), enableTerminalColors)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableTerminalColors = val)
            .build());

        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Letter Match Solver"), enableTerminalLetter)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableTerminalLetter = val)
            .build());

        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Simon Says / Chronomatron"), enableSimonSays)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableSimonSays = val)
            .build());

        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Tic-Tac-Toe Minimax Solver"), enableTicTacToe)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableTicTacToe = val)
            .build());

        solvers.addEntry(entryBuilder.startBooleanToggle(Text.literal("Water Board 5-Lever Solver"), enableWaterBoard)
            .setDefaultValue(true)
            .setSaveConsumer(val -> enableWaterBoard = val)
            .build());

        // 2. Automation & Pacing
        ConfigCategory automation = builder.getOrCreateCategory(Text.literal("Automation & Safety"));
        automation.addEntry(entryBuilder.startBooleanToggle(Text.literal("Auto-Solve Active (Clicks automatically)"), autoSolveEnabled)
            .setDefaultValue(true)
            .setSaveConsumer(val -> autoSolveEnabled = val)
            .build());

        automation.addEntry(entryBuilder.startIntSlider(Text.literal("Click Delay (ms)"), clickDelayMs, 20, 300)
            .setDefaultValue(70)
            .setSaveConsumer(val -> clickDelayMs = val)
            .build());

        automation.addEntry(entryBuilder.startIntSlider(Text.literal("Humanized Jitter Variance (±ms)"), clickJitterMs, 0, 80)
            .setDefaultValue(25)
            .setSaveConsumer(val -> clickJitterMs = val)
            .build());

        automation.addEntry(entryBuilder.startBooleanToggle(Text.literal("Auto-Close Screen when Solved"), autoCloseOnFinish)
            .setDefaultValue(true)
            .setSaveConsumer(val -> autoCloseOnFinish = val)
            .build());

        // 3. Render
        ConfigCategory render = builder.getOrCreateCategory(Text.literal("Visual Overlays"));
        render.addEntry(entryBuilder.startBooleanToggle(Text.literal("Highlight Target Slots"), renderOverlayHighlights)
            .setDefaultValue(true)
            .setSaveConsumer(val -> renderOverlayHighlights = val)
            .build());

        render.addEntry(entryBuilder.startBooleanToggle(Text.literal("Draw Click Order Sequence Numbers"), showClickOrderNumbers)
            .setDefaultValue(true)
            .setSaveConsumer(val -> showClickOrderNumbers = val)
            .build());

        builder.setSavingRunnable(ChronosConfig::save);
        return builder.build();
    }
}