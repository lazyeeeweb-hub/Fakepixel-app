package com.chronos.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Connects Chronos to ModMenu so clicking 'Configure' in the mods list opens Cloth Config.
 */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ChronosConfig::createClothConfigScreen;
    }
}