package com.chronos;

import com.chronos.automation.ClickQueueManager;
import com.chronos.config.ChronosConfig;
import com.chronos.gui.ChronosCustomScreen;
import com.chronos.network.PacketInterceptor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Chronos 1.20.1 Fabric Client Initializer.
 * Registers custom keybinds, initializes config, packet interceptor, and tick scheduler.
 */
public class ChronosMod implements ClientModInitializer {
    public static final String MOD_ID = "chronos";
    public static final Logger LOGGER = LoggerFactory.getLogger("Chronos");

    public static KeyBinding openGuiKeybind;
    public static KeyBinding openClothConfigKeybind;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Chronos] Initializing Fabric 1.20.1 modular sandbox client...");

        // Load configuration
        ChronosConfig.load();

        // Register Keybindings
        openGuiKeybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.chronos.open_gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, // Default: Right Shift
            "category.chronos.main"
        ));

        openClothConfigKeybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.chronos.open_cloth_config",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R, // Alternative keybind: R
            "category.chronos.main"
        ));

        // Register client tick events for GUI opening and click queue processing
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKeybind.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ChronosCustomScreen());
                }
            }

            if (openClothConfigKeybind.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(ChronosConfig.createClothConfigScreen(null));
                }
            }

            // Process asynchronous queued clicks with humanized pacing
            ClickQueueManager.getInstance().onClientTick(client);
        });

        // Initialize no-API packet listener & solvers
        PacketInterceptor.init();
        LOGGER.info("[Chronos] Ready! Press Right Shift or R to open the GUI.");
    }
}