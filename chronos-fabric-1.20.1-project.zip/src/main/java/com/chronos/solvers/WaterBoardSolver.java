package com.chronos.solvers;

/**
 * 5-Lever Water Board flow solver.
 * Levers represent powers of 2: [16, 8, 4, 2, 1] to reach target flow sum.
 */
public class WaterBoardSolver {
    private static final int[] LEVER_WEIGHTS = {16, 8, 4, 2, 1};

    public static boolean[] computeTargetLeverStates(int targetSum) {
        boolean[] states = new boolean[5];
        int remainder = Math.max(0, Math.min(31, targetSum));

        for (int i = 0; i < 5; i++) {
            if (remainder >= LEVER_WEIGHTS[i]) {
                states[i] = true;
                remainder -= LEVER_WEIGHTS[i];
            } else {
                states[i] = false;
            }
        }
        return states;
    }
}