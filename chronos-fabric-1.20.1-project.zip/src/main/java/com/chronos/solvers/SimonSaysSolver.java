package com.chronos.solvers;

import com.chronos.automation.ClickQueueManager;
import com.chronos.config.ChronosConfig;
import java.util.ArrayList;
import java.util.List;

/**
 * Simon Says / Chronomatron Solver.
 * Workaround: Since the server provides no API, it listens to block state changes
 * (e.g. Sea Lantern or Stained Glass illumination) and note block sounds.
 */
public class SimonSaysSolver {
    private static final List<Integer> observedSequence = new ArrayList<>();
    private static int currentStep = 0;
    private static boolean isPlayerTurn = false;

    public static void recordServerFlash(int slotOrBlockId) {
        if (!ChronosConfig.enableSimonSays) return;
        observedSequence.add(slotOrBlockId);
    }

    public static void onPlayerTurnStart() {
        if (!ChronosConfig.enableSimonSays) return;
        isPlayerTurn = true;
        currentStep = 0;

        if (ChronosConfig.autoSolveEnabled) {
            // Queue playback clicks with humanized pacing
            for (int slot : observedSequence) {
                ClickQueueManager.getInstance().queueClick(slot);
            }
        }
    }

    public static void reset() {
        observedSequence.clear();
        currentStep = 0;
        isPlayerTurn = false;
    }
}