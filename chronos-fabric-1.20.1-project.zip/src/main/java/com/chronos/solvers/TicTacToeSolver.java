package com.chronos.solvers;

/**
 * Optimal Minimax algorithm for Tic-Tac-Toe sandbox minigames.
 */
public class TicTacToeSolver {

    public static int findBestMove(char[] board, char botSymbol) {
        char opponent = (botSymbol == 'X') ? 'O' : 'X';

        // 1. Check immediate win
        for (int i = 0; i < 9; i++) {
            if (board[i] == ' ') {
                board[i] = botSymbol;
                if (checkWinner(board) == botSymbol) {
                    board[i] = ' ';
                    return i;
                }
                board[i] = ' ';
            }
        }

        // 2. Block immediate opponent win
        for (int i = 0; i < 9; i++) {
            if (board[i] == ' ') {
                board[i] = opponent;
                if (checkWinner(board) == opponent) {
                    board[i] = ' ';
                    return i;
                }
                board[i] = ' ';
            }
        }

        // 3. Take center slot if open
        if (board[4] == ' ') return 4;

        // 4. Corners
        int[] corners = {0, 2, 6, 8};
        for (int c : corners) {
            if (board[c] == ' ') return c;
        }

        // 5. Open edge
        for (int i = 0; i < 9; i++) {
            if (board[i] == ' ') return i;
        }
        return -1;
    }

    private static char checkWinner(char[] b) {
        int[][] lines = {
            {0,1,2}, {3,4,5}, {6,7,8},
            {0,3,6}, {1,4,7}, {2,5,8},
            {0,4,8}, {2,4,6}
        };
        for (int[] line : lines) {
            if (b[line[0]] != ' ' && b[line[0]] == b[line[1]] && b[line[0]] == b[line[2]]) {
                return b[line[0]];
            }
        }
        return ' ';
    }
}