package com.chronos.solvers;

import com.chronos.automation.ClickQueueManager;
import com.chronos.config.ChronosConfig;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Universal Terminal Solvers for 1.20.1 sandbox minigames.
 */
public class TerminalSolver {

    public static void solveNumericalOrder(GenericContainerScreenHandler handler) {
        if (!ChronosConfig.enableTerminalNumbers) return;

        List<SlotTarget> targets = new ArrayList<>();
        for (int i = 0; i < handler.getInventory().size(); i++) {
            Slot slot = handler.getSlot(i);
            ItemStack stack = slot.getStack();
            if (stack.isEmpty()) continue;

            // In sandbox servers, panes contain stack count or lore value
            int count = stack.getCount();
            String name = stack.getName().getString();
            if (count > 0 && !name.contains("Clicked")) {
                targets.add(new SlotTarget(i, count));
            }
        }

        targets.sort(Comparator.comparingInt(a -> a.order));
        for (SlotTarget target : targets) {
            ClickQueueManager.getInstance().queueClick(target.slotId);
        }
    }

    public static void solveColorPanes(GenericContainerScreenHandler handler, String targetColor) {
        if (!ChronosConfig.enableTerminalColors) return;

        for (int i = 0; i < handler.getInventory().size(); i++) {
            Slot slot = handler.getSlot(i);
            ItemStack stack = slot.getStack();
            if (stack.isEmpty()) continue;

            String name = stack.getName().getString().toLowerCase();
            if (name.contains(targetColor.toLowerCase()) && !name.contains("already")) {
                ClickQueueManager.getInstance().queueClick(i);
            }
        }
    }

    private record SlotTarget(int slotId, int order) {}
}