package com.chronos.gui;

import com.chronos.config.ChronosConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Clean Custom In-Game GUI opened via the user's keybind (Right Shift or R).
 * Provides immediate toggles, HUD adjustments, and a bridge to the Cloth Config screen.
 */
public class ChronosCustomScreen extends Screen {

    private int activeTab = 0; // 0 = Solvers, 1 = Automation, 2 = Overlays, 3 = Workarounds

    public ChronosCustomScreen() {
        super(Text.literal("Chronos Client"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // Tab buttons
        int tabWidth = 90;
        int startX = centerX - (tabWidth * 4) / 2;
        int topY = 32;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Solvers"), btn -> activeTab = 0)
            .dimensions(startX, topY, tabWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Automation"), btn -> activeTab = 1)
            .dimensions(startX + tabWidth, topY, tabWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Visuals"), btn -> activeTab = 2)
            .dimensions(startX + tabWidth * 2, topY, tabWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Workarounds"), btn -> activeTab = 3)
            .dimensions(startX + tabWidth * 3, topY, tabWidth, 20).build());

        // Quick toggle buttons
        int contentY = topY + 40;
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Auto-Solve: " + (ChronosConfig.autoSolveEnabled ? "ENABLED" : "DISABLED")),
            btn -> {
                ChronosConfig.autoSolveEnabled = !ChronosConfig.autoSolveEnabled;
                btn.setMessage(Text.literal("Auto-Solve: " + (ChronosConfig.autoSolveEnabled ? "ENABLED" : "DISABLED")));
            }
        ).dimensions(centerX - 120, contentY, 240, 24).build());

        // Open Cloth Config Screen directly
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Open Cloth Config Options..."),
            btn -> this.client.setScreen(ChronosConfig.createClothConfigScreen(this))
        ).dimensions(centerX - 120, this.height - 38, 240, 22).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Modern translucent dark gradient backdrop
        this.renderBackground(context);
        context.fillGradient(0, 0, this.width, this.height, 0xAA0B0F19, 0xEE090D16);

        // Header
        context.drawCenteredTextWithShadow(this.textRenderer, "CHRONOS MODULAR SANDBOX CLIENT", this.width / 2, 14, 0x00FFCC);
        context.drawCenteredTextWithShadow(this.textRenderer, "Fabric 1.20.1 - Zero API Workaround Engine", this.width / 2, 24, 0x778899);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // Does not pause multiplayer server
    }
}