package dev.zacktills.feature;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Applies the bundled smooth Inter font to the mod's in-game HUD text. */
public final class HudFonts {
    public static final Identifier HUD_FONT = new Identifier("zacktills", "hud");

    private HudFonts() {}

    /** Copies a formatted text tree and sets the HUD font without losing its other root formatting. */
    public static Text apply(Text text) {
        return text.copy().setStyle(text.getStyle().withFont(HUD_FONT));
    }

    public static Text literal(String value) {
        return Text.literal(value).setStyle(Style.EMPTY.withFont(HUD_FONT));
    }
}
