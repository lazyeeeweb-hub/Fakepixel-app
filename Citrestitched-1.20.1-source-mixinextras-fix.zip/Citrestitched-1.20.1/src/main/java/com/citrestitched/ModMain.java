package com.citrestitched;

import com.citrestitched.cit.CITManager;
import com.citrestitched.overlay.ChestOverlayReloadListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.resource.ResourceType;

/** Client entry point for the fork and its two resource reload listeners. */
public final class ModMain implements ClientModInitializer {
    /** Constructs the Fabric client entry point. */
    public ModMain() {}

    /** Registers the inherited CIT API before any resource discovery starts. */
    @Override
    public void onInitializeClient() {
        ResourceManagerHelper helper = ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES);
        helper.registerReloadListener(CITManager.INSTANCE);
        helper.registerReloadListener(new ChestOverlayReloadListener());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CITManager.INSTANCE.close());
    }
}
