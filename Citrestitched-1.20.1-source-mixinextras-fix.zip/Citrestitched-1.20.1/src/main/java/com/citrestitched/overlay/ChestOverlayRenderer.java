package com.citrestitched.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

/** Draws a composited overlay independently of the slot render pass. */
public final class ChestOverlayRenderer {
    private ChestOverlayRenderer() {}

    /** Blits the atlas region at the vanilla background origin, preserving blend state. */
    public static void render(DrawContext context, ChestOverlayDefinition definition, int screenX, int screenY) {
        boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
        int srcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        int dstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int srcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        int dstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        try {
            RenderSystem.setShaderTexture(0, definition.texture());
            context.drawTexture(definition.texture(), screenX, screenY, (float) definition.u(), (float) definition.v(),
                    definition.w(), definition.h(), definition.textureWidth(), definition.textureHeight());
        } finally {
            RenderSystem.blendFuncSeparate(srcRgb, dstRgb, srcAlpha, dstAlpha);
            if (!blend) RenderSystem.disableBlend();
        }
    }
}
