package com.citrestitched.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Packs standalone chest PNGs into a single dynamically registered GUI texture. */
public final class ChestAtlasPacker {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChestAtlasPacker.class);
    private static final int MAX_SIDE = 4096;
    private static final int CELL_WIDTH = 178;

    private ChestAtlasPacker() {}

    /** Packs valid images on the render thread; the caller owns the returned registration. */
    public static Optional<PackedAtlas> pack(ResourceManager resources, List<ChestOverlayDefinition> standalone) {
        if (standalone.isEmpty()) return Optional.empty();
        int limit = Math.min(MAX_SIDE, RenderSystem.maxSupportedTextureSize());
        Map<Identifier, ChestOverlayDefinition> unique = new LinkedHashMap<>();
        for (var definition : standalone) unique.putIfAbsent(definition.texture(), definition);
        var images = new ArrayList<>(unique.values());
        images.sort(Comparator.comparingInt(ChestOverlayDefinition::h).reversed().thenComparing(ChestOverlayDefinition::texture));
        Layout layout = layout(images, limit);
        if (layout == null) {
            LOGGER.warn("{} standalone overlay images do not fit in a single {}x{} atlas", images.size(), limit, limit);
            return Optional.empty();
        }

        NativeImage pixels = new NativeImage(layout.width, layout.height, true);
        NativeImageBackedTexture texture = null;
        boolean registered = false;
        try {
            Map<Identifier, Point> copied = new HashMap<>();
            for (var image : images) {
                Point point = layout.points.get(image.texture());
                try (var stream = resources.open(image.texture()); NativeImage source = NativeImage.read(stream)) {
                    if (source.getWidth() != image.w() || source.getHeight() != image.h()) {
                        LOGGER.warn("Decoded dimensions did not match chest overlay {}", image.texture());
                        continue;
                    }
                    copyWithBorder(source, pixels, point);
                    copied.put(image.texture(), point);
                } catch (IOException | IllegalArgumentException malformed) {
                    LOGGER.warn("Unable to decode chest overlay {}", image.texture(), malformed);
                }
            }
            if (copied.isEmpty()) return Optional.empty();
            texture = new NativeImageBackedTexture(pixels);
            Identifier id = MinecraftClient.getInstance().getTextureManager().registerDynamicTexture("citrestitched_chest", texture);
            registered = true;
            Map<ChestOverlayDefinition, ChestOverlayDefinition> remapped = new HashMap<>();
            for (var definition : standalone) {
                Point point = copied.get(definition.texture());
                if (point != null) remapped.put(definition, definition.remap(id, point.x, point.y, layout.width, layout.height));
            }
            return Optional.of(new PackedAtlas(id, remapped, texture));
        } finally {
            if (!registered) {
                if (texture == null) pixels.close();
                else texture.close();
            }
        }
    }

    private static void copyWithBorder(NativeImage source, NativeImage atlas, Point target) {
        int width = source.getWidth();
        int height = source.getHeight();
        for (int y = -1; y <= height; y++) {
            int sy = Math.max(0, Math.min(y, height - 1));
            for (int x = -1; x <= width; x++) {
                int sx = Math.max(0, Math.min(x, width - 1));
                atlas.setColor(target.x + x, target.y + y, source.getColor(sx, sy));
            }
        }
    }

    private static Layout layout(List<ChestOverlayDefinition> images, int limit) {
        Layout best = null;
        for (int columns = 1; columns <= Math.min(images.size(), limit / CELL_WIDTH); columns++) {
            int width = columns * CELL_WIDTH;
            int y = 0;
            int rowHeight = 0;
            Map<Identifier, Point> points = new HashMap<>();
            for (int i = 0; i < images.size(); i++) {
                int column = i % columns;
                if (i != 0 && column == 0) {
                    y += rowHeight;
                    rowHeight = 0;
                }
                var image = images.get(i);
                rowHeight = Math.max(rowHeight, image.h() + 2);
                if (y + rowHeight > limit) break;
                points.put(image.texture(), new Point(column * CELL_WIDTH + 1, y + 1));
            }
            int height = y + rowHeight;
            if (points.size() == images.size() && (best == null || width * height < best.width * best.height
                    || width * height == best.width * best.height && Math.max(width, height) < Math.max(best.width, best.height))) {
                best = new Layout(width, height, points);
            }
        }
        return best;
    }

    /** Registration and UV remaps for the generated atlas. */
    public record PackedAtlas(Identifier identifier, Map<ChestOverlayDefinition, ChestOverlayDefinition> remapped,
                              NativeImageBackedTexture texture) {
        /** Copies the immutable source-to-atlas mapping. */
        public PackedAtlas {
            remapped = Map.copyOf(remapped);
        }

        /** Unregisters the texture and frees its native pixels. */
        public void release() {
            MinecraftClient.getInstance().getTextureManager().destroyTexture(identifier);
        }
    }

    private record Point(int x, int y) {}
    private record Layout(int width, int height, Map<Identifier, Point> points) {}
}
