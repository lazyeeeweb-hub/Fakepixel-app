package com.citrestitched.overlay;

import net.minecraft.util.Identifier;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * A compiled title pattern and an immutable pixel-space region on a GUI texture.
 * @param namePattern literal name, or regex source without the {@code regex:} prefix
 * @param texture full identifier of the PNG, including {@code textures/} and {@code .png}
 * @param u source x-coordinate
 * @param v source y-coordinate
 * @param w overlay width
 * @param h overlay height
 * @param isRegex whether the name is interpreted as a regular expression
 * @param compiledPattern compiled regex, or null for literal names
 * @param textureWidth full texture width in pixels
 * @param textureHeight full texture height in pixels
 */
public record ChestOverlayDefinition(String namePattern, Identifier texture, int u, int v, int w, int h,
                                     boolean isRegex, Pattern compiledPattern, int textureWidth, int textureHeight) {
    /** Validates the overlay size and requires its region to lie inside the texture. */
    public ChestOverlayDefinition {
        Objects.requireNonNull(namePattern, "namePattern");
        Objects.requireNonNull(texture, "texture");
        if (namePattern.isEmpty() || isRegex != (compiledPattern != null)
                || isRegex && !namePattern.equals(compiledPattern.pattern())) {
            throw new IllegalArgumentException("Invalid overlay name pattern");
        }
        if (w != 176 || h != 166 && h != 222 || u < 0 || v < 0
                || textureWidth <= 0 || textureHeight <= 0
                || (long) u + w > textureWidth || (long) v + h > textureHeight) {
            throw new IllegalArgumentException("Invalid chest overlay rectangle");
        }
    }

    /** Returns the same title and overlay size mapped to a different texture region. */
    public ChestOverlayDefinition remap(Identifier atlas, int x, int y, int atlasWidth, int atlasHeight) {
        return new ChestOverlayDefinition(namePattern, atlas, x, y, w, h, isRegex, compiledPattern,
                atlasWidth, atlasHeight);
    }
}
