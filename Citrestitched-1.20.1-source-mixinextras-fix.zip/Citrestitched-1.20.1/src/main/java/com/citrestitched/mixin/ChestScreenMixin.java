package com.citrestitched.mixin;

import com.citrestitched.overlay.ChestOverlayManager;
import com.citrestitched.overlay.ChestOverlayRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the overlay between the generic chest background and vanilla slots. */
@Mixin(GenericContainerScreen.class)
public abstract class ChestScreenMixin extends HandledScreen<GenericContainerScreenHandler> {
    protected ChestScreenMixin(GenericContainerScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
    }

    @Inject(method = "drawBackground(Lnet/minecraft/client/gui/DrawContext;FII)V", at = @At("RETURN"))
    private void citrestitched$drawOverlay(DrawContext context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        ChestOverlayManager.INSTANCE.getMatch(title, backgroundWidth, backgroundHeight)
                .ifPresent(overlay -> ChestOverlayRenderer.render(context, overlay, x, y));
    }
}

@Mixin(ShulkerBoxScreen.class)
abstract class ShulkerScreenMixin extends HandledScreen<ShulkerBoxScreenHandler> {
    protected ShulkerScreenMixin(ShulkerBoxScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
    }

    @Inject(method = "drawBackground(Lnet/minecraft/client/gui/DrawContext;FII)V", at = @At("RETURN"))
    private void citrestitched$drawOverlay(DrawContext context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        ChestOverlayManager.INSTANCE.getMatch(title, backgroundWidth, backgroundHeight)
                .ifPresent(overlay -> ChestOverlayRenderer.render(context, overlay, x, y));
    }
}

@Mixin(HandledScreen.class)
abstract class HandledScreenMixin {
    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;

    @Inject(method = "init()V", at = @At("RETURN"))
    private void citrestitched$resolveTitle(CallbackInfo ci) {
        Object screen = this;
        if (screen instanceof GenericContainerScreen chest) {
            ChestOverlayManager.INSTANCE.getMatch(chest.getTitle(), backgroundWidth, backgroundHeight);
        } else if (screen instanceof ShulkerBoxScreen shulker) {
            ChestOverlayManager.INSTANCE.getMatch(shulker.getTitle(), backgroundWidth, backgroundHeight);
        }
    }
}
