package com.citrestitched.mixin;

import com.citrestitched.cit.CITManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemModels;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import shcm.shsupercm.fabric.citresewn.cit.CITContext;
import shcm.shsupercm.fabric.citresewn.defaults.cit.types.TypeItem;

/** Bridges vanilla item rendering to resource-pack model selection. */
@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @Shadow @Final private ItemModels models;
    @Unique private ItemStack citrestitched$pendingStack;
    @Unique private BakedModel citrestitched$pendingSpecial;

    @Inject(method = "getModel(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)Lnet/minecraft/client/render/model/BakedModel;",
            at = @At("RETURN"), cancellable = true)
    private void citrestitched$replaceModel(ItemStack stack, World world, LivingEntity entity, int seed,
                                           CallbackInfoReturnable<BakedModel> cir) {
        citrestitched$pendingStack = null;
        citrestitched$pendingSpecial = null;
        BakedModel candidate = CITManager.INSTANCE.itemModel(new CITContext(stack, world, entity), seed).orElse(null);
        if (candidate == null) return;
        if (stack.isOf(Items.TRIDENT) || stack.isOf(Items.SPYGLASS)) {
            citrestitched$pendingStack = stack;
            citrestitched$pendingSpecial = candidate;
        } else {
            cir.setReturnValue(candidate);
        }
    }

    @Inject(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/model/BakedModelManager;getModel(Lnet/minecraft/client/util/ModelIdentifier;)Lnet/minecraft/client/render/model/BakedModel;"))
    private void citrestitched$replaceSpecialModel(ItemStack stack, ModelTransformationMode mode, boolean leftHanded,
                                                  MatrixStack matrices, VertexConsumerProvider buffers, int light,
                                                  int overlay, BakedModel model, CallbackInfo ci) {
        if (stack == citrestitched$pendingStack && citrestitched$pendingSpecial != null) {
            ((TypeItem.BakedModelManagerMixinAccess) models.getModelManager())
                    .citresewn$forceMojankModel(citrestitched$pendingSpecial);
        }
        citrestitched$pendingStack = null;
        citrestitched$pendingSpecial = null;
    }
}

@Mixin(MinecraftClient.class)
abstract class ClientScreenLifecycleMixin {
    @Inject(method = "setScreen(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("RETURN"))
    private void citrestitched$afterScreenChange(Screen screen, CallbackInfo ci) {
        CITManager.INSTANCE.clearScreenCache();
    }
}
