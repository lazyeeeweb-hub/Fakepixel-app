package com.citrestitched.cit.loader;

import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import net.minecraft.resource.InputSupplier;
import net.minecraft.util.Identifier;
import net.minecraft.util.InvalidIdentifierException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/** An immutable diff snapshot for one scope of uniquely identified property files. */
public final class CITReloadDiffer<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(CITReloadDiffer.class);
    private static final int MAX_PROPERTIES_BYTES = 4 * 1024 * 1024;
    private final HashMap<Identifier, HashCode> hashes = new HashMap<>();
    private final HashMap<Identifier, Entry<T>> decoded = new HashMap<>();
    private final List<Value<T>> values;

    /** Constructs an empty snapshot for the initial reload. */
    public CITReloadDiffer() {
        values = List.of();
    }

    private CITReloadDiffer(List<Result<T>> results) {
        for (Result<T> result : results) {
            hashes.put(result.id, result.hash);
            decoded.put(result.id, result.entry);
        }
        values = results.stream().flatMap(result -> result.entry.data.stream()
                .map(data -> new Value<>(result.id, result.entry.pack, data))).toList();
    }

    /** Reads and hashes the current sources in parallel; only new or changed bytes are parsed. */
    public CompletableFuture<CITReloadDiffer<T>> reload(List<Source> sources, Parser<T> parser, Executor executor) {
        List<CompletableFuture<Optional<Result<T>>>> futures = sources.stream()
                .map(source -> CompletableFuture.supplyAsync(() -> read(source, parser), executor)).toList();
        return CompletableFuture.allOf(futures.toArray(CompletableFuture<?>[]::new)).thenApply(ignored ->
                new CITReloadDiffer<>(futures.stream().flatMap(future -> future.join().stream()).toList()));
    }

    /** Returns the successfully decoded files in discovery order. */
    public List<Value<T>> values() {
        return values;
    }

    private Optional<Result<T>> read(Source source, Parser<T> parser) {
        try (InputStream stream = source.open.get()) {
            byte[] bytes = stream.readNBytes(MAX_PROPERTIES_BYTES + 1);
            if (bytes.length > MAX_PROPERTIES_BYTES) throw new IOException("Property file exceeds 4 MiB");
            HashCode hash = Hashing.sha256().hashBytes(bytes);
            Entry<T> previous = decoded.get(source.id);
            if (previous != null && hash.equals(hashes.get(source.id)) && previous.pack.equals(source.pack))
                return Optional.of(new Result<>(source.id, hash, previous));
            Optional<T> data;
            try {
                data = Optional.of(parser.parse(source, bytes));
            } catch (IOException | InvalidIdentifierException | IllegalArgumentException malformed) {
                LOGGER.warn("Ignoring malformed properties {} from {}", source.id, source.pack, malformed);
                data = Optional.empty();
            }
            return Optional.of(new Result<>(source.id, hash, new Entry<>(source.pack, data)));
        } catch (IOException unreadable) {
            LOGGER.warn("Unable to read properties {} from {}", source.id, source.pack, unreadable);
            return Optional.empty();
        }
    }

    /** A discovered resource, with its pack origin and a fresh stream supplier. */
    public record Source(Identifier id, String pack, InputSupplier<InputStream> open) {}

    /** A successfully decoded property file with its source identity. */
    public record Value<T>(Identifier id, String pack, T data) {}

    /** Functional decoder; invoked on a loader thread for a changed resource. */
    @FunctionalInterface
    public interface Parser<T> {
        /** Decodes the exact bytes that were hashed. */
        T parse(Source source, byte[] bytes) throws IOException;
    }

    private record Entry<T>(String pack, Optional<T> data) {}
    private record Result<T>(Identifier id, HashCode hash, Entry<T> entry) {}
}
