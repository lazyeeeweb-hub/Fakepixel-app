package com.citrestitched.cit.cache;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Objects;
import java.util.function.Supplier;

/** Bounded client-render-thread cache for context-independent CIT selection results. */
public final class CITResultCache {
    private final int capacity;
    private final HashMap<Long, CITMatch> matches;

    /** Creates a cache with the specified positive maximum number of stack fingerprints. */
    public CITResultCache(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
        this.capacity = capacity;
        this.matches = new HashMap<>(Math.min(capacity, 256));
    }

    /**
     * Gets or computes a non-null selection result (including a negative result). Each lane is
     * one immutable matcher instance and must always return the same result type. The compound
     * hash is verified against an NBT snapshot so collisions never produce a wrong match.
     */
    public <T> T get(ItemStack stack, Object lane, Supplier<? extends T> selection) {
        Item item = stack.getItem();
        NbtCompound nbt = stack.getNbt();
        long key = ((long) Item.getRawId(item) << 32) | Integer.toUnsignedLong(nbt == null ? 0 : nbt.hashCode());
        CITMatch match = matches.get(key);
        if (match == null || match.item != item || match.count != stack.getCount() || !Objects.equals(match.nbt, nbt)) {
            if (match == null && matches.size() >= capacity) matches.clear();
            match = new CITMatch(item, stack.getCount(), nbt == null ? null : nbt.copy(), new IdentityHashMap<>());
            matches.put(key, match);
        }
        @SuppressWarnings("unchecked") // A matcher identity determines the result type.
        T result = (T) match.results.computeIfAbsent(lane, ignored -> Objects.requireNonNull(selection.get()));
        return result;
    }

    /** Discards all positive and negative selection results. */
    public void clear() {
        matches.clear();
    }

    private record CITMatch(Item item, int count, NbtCompound nbt, IdentityHashMap<Object, Object> results) {}
}
