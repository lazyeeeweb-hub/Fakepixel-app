package com.citrestitched.cit;

import com.citrestitched.cit.cache.CITResultCache;
import com.citrestitched.cit.loader.AsyncCITLoader;
import com.citrestitched.cit.matching.IndexedConditionMatcher;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import shcm.shsupercm.fabric.citresewn.cit.CIT;
import shcm.shsupercm.fabric.citresewn.cit.CITContext;
import shcm.shsupercm.fabric.citresewn.cit.CITType;
import shcm.shsupercm.fabric.citresewn.defaults.cit.types.TypeItem;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;

/** Coordinates the two reload phases and client-thread CIT selection. */
public final class CITManager implements IdentifiableResourceReloadListener, AutoCloseable {
    /** Shared client CIT coordinator. */
    public static final CITManager INSTANCE = new CITManager();
    private final AsyncCITLoader loader = new AsyncCITLoader();
    private final CITResultCache cache = new CITResultCache(4096);
    private final AtomicLong generation = new AtomicLong();
    private long cacheGeneration;
    private volatile CompletableFuture<AsyncCITLoader.Prepared> modelPreparation;
    private volatile ResourceManager modelResources;

    private CITManager() {}

    /** Returns this listener's stable reload identifier. */
    @Override
    public Identifier getFabricId() {
        return new Identifier("citrestitched", "cit");
    }

    /** Joins the shared preparation stage before the Fabric apply barrier. */
    @Override
    public CompletableFuture<Void> reload(Synchronizer synchronizer, ResourceManager manager, Profiler prepareProfiler,
                                          Profiler applyProfiler, Executor prepareExecutor, Executor applyExecutor) {
        return prepare(manager).thenCompose(synchronizer::whenPrepared).thenRunAsync(this::clearScreenCache, applyExecutor);
    }

    /** Returns this reload's immutable inputs, scheduling preparation if necessary. */
    public CompletableFuture<AsyncCITLoader.Prepared> prepare(ResourceManager manager) {
        return loader.prepare(manager);
    }

    /** Starts the shared parse before vanilla schedules the model and block-atlas preparations. */
    public void startModelPreparation(ResourceManager manager) {
        modelResources = manager;
        modelPreparation = prepare(manager);
    }

    /** Returns the exact resource manager supplied to the current vanilla model reload. */
    public ResourceManager modelResources() {
        if (modelResources == null) throw new IllegalStateException("CIT model reload was not started");
        return modelResources;
    }

    /** Joins all property workers before the model loader links resource-dependent CIT assets. */
    public AsyncCITLoader.Prepared preparedForModels() {
        CompletableFuture<AsyncCITLoader.Prepared> future = modelPreparation;
        if (future == null) throw new IllegalStateException("CIT model reload was not started");
        CompletableFuture.allOf(future).join();
        return future.join();
    }

    /** Invalidates all cached matchers when the upstream CIT containers are rebuilt. */
    public void invalidateMatches() {
        generation.incrementAndGet();
    }

    /** Clears the render cache after a client screen transition or resource reload. */
    public void clearScreenCache() {
        cache.clear();
        cacheGeneration = generation.get();
    }

    /** Uses the bounded cache on the client thread; off-thread callers only read the immutable index. */
    public <T extends CITType> Optional<CIT<T>> select(IndexedConditionMatcher<T> matcher, CITContext context) {
        if (!MinecraftClient.getInstance().isOnThread()) return matcher.select(context, null);
        if (cacheGeneration != generation.get()) clearScreenCache();
        return matcher.select(context, cache);
    }

    /** Selects a CIT rule and resolves its baked model with the current rendering seed and context. */
    public Optional<BakedModel> itemModel(CITContext context, int seed) {
        if (!TypeItem.CONTAINER.active() || context.stack.isEmpty()) return Optional.empty();
        return Optional.ofNullable(TypeItem.CONTAINER.getCIT(context, seed)).map(cit -> cit.type.getItemModel(context, seed));
    }

    /** Shuts down the dedicated property loader. */
    @Override
    public void close() {
        clearScreenCache();
        loader.close();
    }
}
