package com.citrestitched.cit.matching;

import com.citrestitched.cit.cache.CITResultCache;
import net.minecraft.item.Item;
import shcm.shsupercm.fabric.citresewn.cit.CIT;
import shcm.shsupercm.fabric.citresewn.cit.CITCondition;
import shcm.shsupercm.fabric.citresewn.cit.CITContext;
import shcm.shsupercm.fabric.citresewn.cit.CITType;
import shcm.shsupercm.fabric.citresewn.defaults.cit.conditions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/** Immutable item index over ordered CIT condition groups for one type or glint layer. */
public final class IndexedConditionMatcher<T extends CITType> {
    private static final Set<Class<?>> STACK_ONLY = Set.of(ConditionItems.class, ConditionNBT.class,
            ConditionDamage.class, ConditionDamageMask.class, ConditionStackSize.class,
            ConditionEnchantments.class, ConditionEnchantmentLevels.class);
    private final HashMap<Item, Bucket<T>> byItem = new HashMap<>();
    private final Bucket<T> global;

    /** Builds item buckets in the upstream priority order; multiple item predicates intersect. */
    public IndexedConditionMatcher(List<CIT<T>> orderedRules) {
        MapBuilder<T> builder = new MapBuilder<>();
        List<Rule<T>> unrestricted = new ArrayList<>();
        int ordinal = 0;
        for (CIT<T> cit : orderedRules) {
            Set<Item> allowed = null;
            boolean stackOnly = true;
            for (CITCondition condition : cit.conditions) {
                stackOnly &= STACK_ONLY.contains(condition.getClass());
                if (condition.getClass() == ConditionItems.class) {
                    List<Item> items = Arrays.asList(((ConditionItems) condition).items);
                    if (allowed == null) allowed = new HashSet<>(items);
                    else allowed.retainAll(items);
                }
            }
            Rule<T> rule = new Rule<>(cit, ordinal++, stackOnly);
            if (allowed == null) unrestricted.add(rule);
            else for (Item item : allowed) builder.rules.computeIfAbsent(item, ignored -> new ArrayList<>()).add(rule);
        }
        global = bucket(unrestricted);
        builder.rules.forEach((item, rules) -> byItem.put(item, bucket(rules)));
    }

    /** Finds the first matching rule, caching the winner only when all candidates are stack-only. */
    public Optional<CIT<T>> select(CITContext context, CITResultCache cache) {
        Bucket<T> local = byItem.get(context.stack.getItem());
        if (cache != null && global.stackOnly && (local == null || local.stackOnly)) {
            return cache.get(context.stack, this, () -> selectUncached(local, context));
        }
        return selectUncached(local, context);
    }

    private Optional<CIT<T>> selectUncached(Bucket<T> local, CITContext context) {
        Iterator<Rule<T>> itemRules = local == null ? List.<Rule<T>>of().iterator() : local.rules.iterator();
        Iterator<Rule<T>> globals = global.rules.iterator();
        Rule<T> a = itemRules.hasNext() ? itemRules.next() : null;
        Rule<T> b = globals.hasNext() ? globals.next() : null;
        while (a != null || b != null) {
            Rule<T> candidate;
            if (b == null || a != null && a.ordinal < b.ordinal) {
                candidate = a;
                a = itemRules.hasNext() ? itemRules.next() : null;
            } else {
                candidate = b;
                b = globals.hasNext() ? globals.next() : null;
            }
            if (candidate.cit.test(context)) return Optional.of(candidate.cit);
        }
        return Optional.empty();
    }

    private static <T extends CITType> Bucket<T> bucket(List<Rule<T>> rules) {
        return new Bucket<>(List.copyOf(rules), rules.stream().allMatch(Rule::stackOnly));
    }

    private static final class MapBuilder<T extends CITType> {
        private final HashMap<Item, List<Rule<T>>> rules = new HashMap<>();
    }
    private record Rule<T extends CITType>(CIT<T> cit, int ordinal, boolean stackOnly) {}
    private record Bucket<T extends CITType>(List<Rule<T>> rules, boolean stackOnly) {}
}
