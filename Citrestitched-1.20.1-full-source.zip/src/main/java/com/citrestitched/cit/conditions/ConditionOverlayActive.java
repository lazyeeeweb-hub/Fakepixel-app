package com.citrestitched.cit.conditions;

import com.citrestitched.overlay.ActiveOverlayContext;
import shcm.shsupercm.fabric.citresewn.api.CITConditionContainer;
import shcm.shsupercm.fabric.citresewn.cit.CITContext;
import shcm.shsupercm.fabric.citresewn.cit.builtin.conditions.BooleanCondition;

/**
 * {@code overlay_active=true} matches during an overlay chest or shulker render;
 * {@code overlay_active=false} matches outside those render passes.
 */
public class ConditionOverlayActive extends BooleanCondition {
    public static final CITConditionContainer<ConditionOverlayActive> CONTAINER =
            new CITConditionContainer<>(ConditionOverlayActive.class, ConditionOverlayActive::new, "overlay_active");

    @Override
    public boolean test(CITContext context) {
        return ActiveOverlayContext.isActive() == this.value;
    }
}
