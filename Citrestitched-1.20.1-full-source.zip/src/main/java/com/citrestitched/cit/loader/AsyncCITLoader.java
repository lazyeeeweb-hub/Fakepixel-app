package com.citrestitched.cit.loader;

import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import shcm.shsupercm.fabric.citresewn.pack.PackParser;
import shcm.shsupercm.fabric.citresewn.pack.format.PropertyGroup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Shared prepare stage for CIT rule, global CIT, and chest overlay property files. */
public final class AsyncCITLoader implements AutoCloseable {
    private static final List<String> OVERLAY_ROOTS = List.of(
            "mcpatcher/gui/chest_overlays",
            "citresewn/gui/chest_overlays"
    );
    private final ExecutorService executor;
    private CompletableFuture<Prepared> tail = CompletableFuture.completedFuture(null);
    private ResourceManager latestManager;
    private CITReloadDiffer<PropertyGroup> rules = new CITReloadDiffer<>();
    private Map<Layer, CITReloadDiffer<PropertyGroup>> globals = Map.of();
    private CITReloadDiffer<Map<String, String>> overlays = new CITReloadDiffer<>();
    private boolean closed;

    /** Creates a dedicated four-thread daemon executor for resource discovery and parsing. */
    public AsyncCITLoader() {
        AtomicInteger number = new AtomicInteger();
        executor = Executors.newFixedThreadPool(4, task -> {
            Thread thread = new Thread(task, "cit-loader-" + number.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        });
    }

    /**
     * Starts or reuses a prepare future for the exact resource manager of a reload.
     * The atlas and model hooks share this work with both Fabric listeners.
     */
    public synchronized CompletableFuture<Prepared> prepare(ResourceManager resources) {
        Objects.requireNonNull(resources, "resources");
        if (closed) return CompletableFuture.failedFuture(new IllegalStateException("CIT loader closed"));
        if (latestManager == resources) return tail;
        latestManager = resources;
        tail = tail.handle((prepared, failure) -> null).thenCompose(ignored ->
                CompletableFuture.supplyAsync(() -> discover(resources), executor).thenCompose(this::parse));
        return tail;
    }

    /** Stops accepting reloads and releases idle loader threads. */
    @Override
    public synchronized void close() {
        closed = true;
        latestManager = null;
        tail.whenComplete((ignored, failure) -> executor.shutdown());
    }

    private static Discovered discover(ResourceManager resources) {
        List<CITReloadDiffer.Source> rules = new ArrayList<>();
        for (String root : PackParser.ROOTS) rules.addAll(discoverEffective(resources, root + "/cit"));
        Map<Layer, List<CITReloadDiffer.Source>> globals = new LinkedHashMap<>();
        Map<String, Integer> occurrences = new HashMap<>();
        for (ResourcePack pack : resources.streamResourcePacks().toList()) {
            String packName = pack.getName();
            Layer layer = new Layer(packName, occurrences.merge(packName, 1, Integer::sum));
            List<CITReloadDiffer.Source> files = new ArrayList<>();
            for (String namespace : pack.getNamespaces(ResourceType.CLIENT_RESOURCES).stream().sorted().toList()) {
                for (String root : PackParser.ROOTS) {
                    Identifier id = new Identifier(namespace, root + "/cit.properties");
                    InputSupplier<InputStream> open = pack.open(ResourceType.CLIENT_RESOURCES, id);
                    if (open != null) files.add(new CITReloadDiffer.Source(id, packName, open));
                }
            }
            if (!files.isEmpty()) globals.put(layer, List.copyOf(files));
        }
        List<CITReloadDiffer.Source> overlays = new ArrayList<>();
        for (String root : OVERLAY_ROOTS) overlays.addAll(discoverEffective(resources, root));
        return new Discovered(rules, globals, overlays);
    }

    private static List<CITReloadDiffer.Source> discoverEffective(ResourceManager resources, String prefix) {
        return resources.findResources(prefix, id -> id.getPath().endsWith(".properties")).entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.naturalOrder()))
                .map(entry -> {
                    Resource resource = entry.getValue();
                    return new CITReloadDiffer.Source(entry.getKey(), resource.getPack().getName(), resource::getInputStream);
                }).toList();
    }

    private CompletableFuture<Prepared> parse(Discovered files) {
        var nextRules = rules.reload(files.rules, AsyncCITLoader::parseCIT, executor);
        var nextOverlays = overlays.reload(files.overlays, AsyncCITLoader::parseOverlay, executor);
        Map<Layer, CompletableFuture<CITReloadDiffer<PropertyGroup>>> nextGlobals = new LinkedHashMap<>();
        files.globals.forEach((layer, sources) -> nextGlobals.put(layer,
                globals.getOrDefault(layer, new CITReloadDiffer<>()).reload(sources, AsyncCITLoader::parseCIT, executor)));
        List<CompletableFuture<?>> jobs = new ArrayList<>(nextGlobals.values());
        jobs.add(nextRules);
        jobs.add(nextOverlays);
        return CompletableFuture.allOf(jobs.toArray(CompletableFuture<?>[]::new)).thenApply(ignored -> {
            Map<Layer, CITReloadDiffer<PropertyGroup>> updated = new LinkedHashMap<>();
            nextGlobals.forEach((layer, future) -> updated.put(layer, future.join()));
            CompletableFuture.allOf(jobs.toArray(CompletableFuture<?>[]::new)).join();
            rules = nextRules.join();
            overlays = nextOverlays.join();
            globals = updated;
            return new Prepared(rules.values(), updated.values().stream().flatMap(diff -> diff.values().stream()).toList(),
                    overlays.values());
        });
    }

    private static PropertyGroup parseCIT(CITReloadDiffer.Source source, byte[] bytes) throws IOException {
        try (InputStream stream = new ByteArrayInputStream(bytes)) {
            PropertyGroup group = PropertyGroup.tryParseGroup(source.pack(), source.id(), stream);
            if (group == null) throw new IOException("No property parser registered for " + source.id());
            return group;
        }
    }

    private static Map<String, String> parseOverlay(CITReloadDiffer.Source source, byte[] bytes) throws IOException {
        Properties properties = new Properties();
        try (var reader = new InputStreamReader(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8)) {
            properties.load(reader);
        }
        HashMap<String, String> values = new HashMap<>();
        for (String key : properties.stringPropertyNames()) values.put(key, properties.getProperty(key));
        return Map.copyOf(values);
    }

    /**
     * Parsed inputs for one reload, in deterministic precedence order.
     * @param rules effective CIT rules, one per identifier
     * @param globals global properties in low-to-high pack order
     * @param overlays effective overlay property files
     */
    public record Prepared(List<CITReloadDiffer.Value<PropertyGroup>> rules,
                           List<CITReloadDiffer.Value<PropertyGroup>> globals,
                           List<CITReloadDiffer.Value<Map<String, String>>> overlays) {
        /** Takes immutable copies of the three input lists. */
        public Prepared {
            rules = List.copyOf(rules);
            globals = List.copyOf(globals);
            overlays = List.copyOf(overlays);
        }
    }

    private record Layer(String pack, int occurrence) {}
    private record Discovered(List<CITReloadDiffer.Source> rules, Map<Layer, List<CITReloadDiffer.Source>> globals,
                              List<CITReloadDiffer.Source> overlays) {}
}
