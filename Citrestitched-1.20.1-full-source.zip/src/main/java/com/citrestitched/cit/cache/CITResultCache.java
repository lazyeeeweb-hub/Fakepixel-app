package com.citrestitched.cit.cache;

import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

import java.util.IdentityHashMap;
import java.util.Objects;
import java.util.function.Supplier;

/** Bounded client-render-thread cache for context-independent CIT selection results. */
public final class CITResultCache {
    private final int capacity;
    private final Long2ObjectLinkedOpenHashMap<CITMatch> matches;

    /** Creates a cache with the specified positive maximum number of stack fingerprints. */
    public CITResultCache(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
        this.capacity = capacity;
        this.matches = new Long2ObjectLinkedOpenHashMap<>(Math.min(capacity, 256));
    }

    /**
     * Gets or computes a non-null selection result (including a negative result). Each lane is
     * one immutable matcher instance and must always return the same result type. The compound
     * hash is verified against an NBT snapshot so collisions never produce a wrong match.
     */
    public <T> T get(ItemStack stack, Object lane, Supplier<? extends T> selection) {
        Item item = stack.getItem();
        NbtCompound nbt = stack.getNbt();
        int count = stack.getCount();
        long itemAndNbt = ((long) Item.getRawId(item) << 32) | Integer.toUnsignedLong(nbt == null ? 0 : nbt.hashCode());
        long key = itemAndNbt ^ (0x9e3779b97f4a7c15L * count);
        CITMatch match = matches.getAndMoveToLast(key);
        if (match == null || match.item != item || match.count != count || !Objects.equals(match.nbt, nbt)) {
            if (match == null && matches.size() >= capacity) matches.removeFirst();
            match = new CITMatch(item, count, nbt == null ? null : nbt.copy(), new IdentityHashMap<>());
            matches.putAndMoveToLast(key, match);
        }
        Object cached = match.results.get(lane);
        if (cached == null) {
            cached = Objects.requireNonNull(selection.get());
            match.results.put(lane, cached);
        }
        @SuppressWarnings("unchecked") // A matcher identity determines the result type.
        T result = (T) cached;
        return result;
    }

    /** Discards all positive and negative selection results. */
    public void clear() {
        matches.clear();
    }

    private record CITMatch(Item item, int count, NbtCompound nbt, IdentityHashMap<Object, Object> results) {}
}
