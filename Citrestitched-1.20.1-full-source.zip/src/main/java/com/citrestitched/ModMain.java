package com.citrestitched;

import com.citrestitched.cit.CITManager;
import com.citrestitched.cit.conditions.ConditionOverlayActive;
import com.citrestitched.overlay.ChestOverlayReloadListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.resource.ResourceType;
import shcm.shsupercm.fabric.citresewn.cit.CITRegistry;
import shcm.shsupercm.fabric.citresewn.pack.format.PropertyKey;

/** Client entry point for the fork and its two resource reload listeners. */
public final class ModMain implements ClientModInitializer {
    /** Constructs the Fabric client entry point. */
    public ModMain() {}

    /** Registers the overlay condition before attaching the resource reload listeners. */
    @Override
    public void onInitializeClient() {
        for (String alias : ConditionOverlayActive.CONTAINER.aliases) {
            CITRegistry.CONDITIONS.put(PropertyKey.of(alias), ConditionOverlayActive.CONTAINER);
        }
        ResourceManagerHelper helper = ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES);
        helper.registerReloadListener(CITManager.INSTANCE);
        helper.registerReloadListener(new ChestOverlayReloadListener());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CITManager.INSTANCE.close());
    }
}
