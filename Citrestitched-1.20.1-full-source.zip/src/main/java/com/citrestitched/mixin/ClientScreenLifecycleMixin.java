package com.citrestitched.mixin;

import com.citrestitched.cit.CITManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
abstract class ClientScreenLifecycleMixin {
    @Inject(method = "setScreen(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("RETURN"))
    private void citrestitched$afterScreenChange(Screen screen, CallbackInfo ci) {
        CITManager.INSTANCE.clearScreenCache();
    }
}
