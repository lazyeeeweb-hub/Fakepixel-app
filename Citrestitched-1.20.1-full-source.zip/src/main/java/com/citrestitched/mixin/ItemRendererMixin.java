package com.citrestitched.mixin;

import com.citrestitched.cit.CITManager;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Resolves CIT models once, without modifying the global model manager. */
@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @Unique private ItemStack citrestitched$pendingStack;
    @Unique private BakedModel citrestitched$pendingModel;

    @Inject(method = "getModel(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)Lnet/minecraft/client/render/model/BakedModel;",
            at = @At("HEAD"), cancellable = true)
    private void citrestitched$replaceModel(ItemStack stack, World world, LivingEntity entity, int seed,
                                           CallbackInfoReturnable<BakedModel> cir) {
        citrestitched$pendingStack = null;
        citrestitched$pendingModel = null;
        BakedModel candidate = CITManager.INSTANCE.itemModel(stack, world, entity, seed);
        if (candidate == null) return;

        if (stack.isOf(Items.TRIDENT) || stack.isOf(Items.SPYGLASS)) {
            // Vanilla chooses a separate flat model for GUI, ground and item frames.
            citrestitched$pendingStack = stack;
            citrestitched$pendingModel = candidate;
        } else {
            cir.setReturnValue(candidate);
        }
    }

    // First load of the model argument, after both vanilla special-item stores and
    // before applying the transformation. This also consumes the candidate in hand modes.
    @ModifyVariable(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
            at = @At(value = "LOAD", ordinal = 0), argsOnly = true, index = 8, require = 1, allow = 1)
    private BakedModel citrestitched$replaceFlatSpecialModel(BakedModel vanilla, ItemStack stack, ModelTransformationMode mode) {
        if (citrestitched$pendingStack == null) return vanilla;
        BakedModel replacement = citrestitched$pendingStack == stack ? citrestitched$pendingModel : null;
        citrestitched$pendingStack = null;
        citrestitched$pendingModel = null;
        if (replacement != null && (mode == ModelTransformationMode.GUI || mode == ModelTransformationMode.GROUND
                || mode == ModelTransformationMode.FIXED)) return replacement;
        return vanilla;
    }
}
