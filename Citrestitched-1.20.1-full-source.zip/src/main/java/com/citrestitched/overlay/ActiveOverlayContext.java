package com.citrestitched.overlay;

/** The current thread's overlay state during a chest or shulker screen render. */
public final class ActiveOverlayContext {
    private static final ThreadLocal<Boolean> OVERLAY_ACTIVE = ThreadLocal.withInitial(() -> false);

    private ActiveOverlayContext() {}

    public static void set(boolean active) {
        OVERLAY_ACTIVE.set(active);
    }

    public static boolean isActive() {
        return OVERLAY_ACTIVE.get();
    }
}
