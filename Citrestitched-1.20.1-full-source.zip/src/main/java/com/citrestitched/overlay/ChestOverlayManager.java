package com.citrestitched.overlay;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Client-thread title index for the current resource reload. */
public final class ChestOverlayManager {
    /** Shared title index used by the reload and screen hooks. */
    public static final ChestOverlayManager INSTANCE = new ChestOverlayManager();
    private static final int MEMO_LIMIT = 256;
    private List<ChestOverlayDefinition> definitions = List.of();
    private Map<String, List<ChestOverlayDefinition>> exact = Map.of();
    private List<ChestOverlayDefinition> patterns = List.of();
    private final Map<Query, Optional<ChestOverlayDefinition>> cachedTitles = new HashMap<>();

    private ChestOverlayManager() {}

    /** Replaces the definitions and clears memoized title lookups. */
    public void rebuild(List<ChestOverlayDefinition> loaded) {
        List<ChestOverlayDefinition> nextDefinitions = List.copyOf(loaded);
        Map<String, List<ChestOverlayDefinition>> nextExact = new HashMap<>();
        List<ChestOverlayDefinition> nextRegex = new ArrayList<>();
        for (ChestOverlayDefinition definition : nextDefinitions) {
            if (definition.isRegex()) nextRegex.add(definition);
            else nextExact.computeIfAbsent(fold(Formatting.strip(definition.namePattern())), key -> new ArrayList<>()).add(definition);
        }
        definitions = nextDefinitions;
        exact = nextExact;
        patterns = List.copyOf(nextRegex);
        cachedTitles.clear();
    }

    /** Finds a title match without a GUI size restriction; exact names take precedence. */
    public Optional<ChestOverlayDefinition> getMatch(Text containerTitle) {
        return getMatch(containerTitle, 0, 0);
    }

    /** Finds a title match compatible with the actual vanilla background dimensions. */
    public Optional<ChestOverlayDefinition> getMatch(Text containerTitle, int width, int height) {
        if (definitions.isEmpty()) return Optional.empty();
        String plain = Formatting.strip(containerTitle.getString());
        Query query = new Query(plain, width, height);
        Optional<ChestOverlayDefinition> cached = cachedTitles.get(query);
        if (cached != null) return cached;
        if (cachedTitles.size() >= MEMO_LIMIT) cachedTitles.clear();
        return cachedTitles.computeIfAbsent(query, this::resolve);
    }

    private Optional<ChestOverlayDefinition> resolve(Query query) {
        for (ChestOverlayDefinition literal : exact.getOrDefault(fold(query.title), List.of())) {
            if (fits(query, literal)) return Optional.of(literal);
        }
        for (ChestOverlayDefinition regex : patterns) {
            if (fits(query, regex) && regex.compiledPattern().matcher(query.title).find()) return Optional.of(regex);
        }
        return Optional.empty();
    }

    private static boolean fits(Query query, ChestOverlayDefinition definition) {
        return query.width == 0 && query.height == 0 || query.width == definition.w() && query.height == definition.h();
    }

    private static String fold(String raw) {
        StringBuilder result = new StringBuilder(raw.length());
        raw.codePoints().map(Character::toUpperCase).map(Character::toLowerCase).forEach(result::appendCodePoint);
        return result.toString();
    }

    private record Query(String title, int width, int height) {}
}
