package com.citrestitched.overlay;

import net.minecraft.util.Identifier;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * A compiled title pattern and an immutable pixel-space region on a GUI texture.
 * @param namePattern literal name, or regex source without the {@code regex:} prefix
 * @param texture identifier of the source PNG or generated atlas
 * @param u source x-coordinate
 * @param v source y-coordinate
 * @param w overlay width
 * @param h overlay height
 * @param isRegex whether the name is interpreted as a regular expression
 * @param compiledPattern compiled regex, or null for literal names
 * @param atlasWidth full texture width in pixels
 * @param atlasHeight full texture height in pixels
 * @param hideTitle whether to suppress the container title
 */
public record ChestOverlayDefinition(String namePattern, Identifier texture, int u, int v, int w, int h,
                                     boolean isRegex, Pattern compiledPattern, int atlasWidth, int atlasHeight,
                                     boolean hideTitle) {
    /** Validates the overlay size and requires its region to lie inside the texture. */
    public ChestOverlayDefinition {
        Objects.requireNonNull(namePattern, "namePattern");
        Objects.requireNonNull(texture, "texture");
        if (namePattern.isEmpty() || isRegex != (compiledPattern != null)
                || isRegex && !namePattern.equals(compiledPattern.pattern())) {
            throw new IllegalArgumentException("Invalid overlay name pattern");
        }
        if (w <= 0 || h <= 0 || u < 0 || v < 0
                || atlasWidth <= 0 || atlasHeight <= 0
                || (long) u + w > atlasWidth || (long) v + h > atlasHeight) {
            throw new IllegalArgumentException("Invalid chest overlay rectangle");
        }
    }

    /** Returns the full texture width for the overlay renderer. */
    public int textureWidth() {
        return atlasWidth;
    }

    /** Returns the full texture height for the overlay renderer. */
    public int textureHeight() {
        return atlasHeight;
    }

    /** Returns the same title and overlay size mapped to a different texture region. */
    public ChestOverlayDefinition remap(Identifier atlas, int x, int y, int atlasWidth, int atlasHeight) {
        return new ChestOverlayDefinition(namePattern, atlas, x, y, w, h, isRegex, compiledPattern,
                atlasWidth, atlasHeight, hideTitle);
    }
}
