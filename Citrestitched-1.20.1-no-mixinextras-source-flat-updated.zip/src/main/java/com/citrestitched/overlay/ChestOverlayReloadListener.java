package com.citrestitched.overlay;

import com.citrestitched.cit.CITManager;
import com.citrestitched.cit.loader.CITReloadDiffer;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

/** Applies the worker-prepared overlay properties and replaces their atlas on the client thread. */
public final class ChestOverlayReloadListener implements SimpleSynchronousResourceReloadListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChestOverlayReloadListener.class);
    private static final Identifier ID = new Identifier("citrestitched", "chest_overlay");
    private Optional<ChestAtlasPacker.PackedAtlas> generated = Optional.empty();

    /** Creates the render-thread listener. */
    public ChestOverlayReloadListener() {}

    /** Returns the listener's Fabric reload identifier. */
    @Override
    public Identifier getFabricId() {
        return ID;
    }

    /** Resolves images, rebuilds the title index, and releases the superseded generated texture. */
    @Override
    public void reload(ResourceManager manager) {
        var files = CITManager.INSTANCE.prepare(manager).join().overlays();
        int max = RenderSystem.maxSupportedTextureSize();
        Map<Identifier, Optional<Dimensions>> sizes = new HashMap<>();
        List<Overlay> regions = new ArrayList<>();
        List<ChestOverlayDefinition> standalone = new ArrayList<>();
        for (var file : files) {
            try {
                if (!"chest_overlay".equals(file.data().get("type"))) continue;
                Overlay region = definition(file, manager, sizes, max);
                regions.add(region);
                if (region.standalone) standalone.add(region.definition);
            } catch (IllegalArgumentException invalid) {
                LOGGER.warn("Ignoring chest overlay {} from {}: {}", file.id(), file.pack(), invalid.getMessage());
            }
        }
        Optional<ChestAtlasPacker.PackedAtlas> next = ChestAtlasPacker.pack(manager, standalone);
        try {
            Map<ChestOverlayDefinition, ChestOverlayDefinition> remapped = next.map(ChestAtlasPacker.PackedAtlas::remapped).orElseGet(Map::of);
            List<ChestOverlayDefinition> definitions = new ArrayList<>();
            for (Overlay region : regions) {
                if (!region.standalone) definitions.add(region.definition);
                else if (remapped.containsKey(region.definition)) definitions.add(remapped.get(region.definition));
            }
            ChestOverlayManager.INSTANCE.rebuild(definitions);
        } catch (IllegalArgumentException | IllegalStateException failure) {
            next.ifPresent(ChestAtlasPacker.PackedAtlas::release);
            throw failure;
        }
        Optional<ChestAtlasPacker.PackedAtlas> previous = generated;
        generated = next;
        previous.ifPresent(ChestAtlasPacker.PackedAtlas::release);
    }

    private static Overlay definition(CITReloadDiffer.Value<Map<String, String>> file, ResourceManager resources,
                                      Map<Identifier, Optional<Dimensions>> sizes, int max) {
        Map<String, String> properties = file.data();
        String name = required(properties, "name");
        boolean regex = name.startsWith("regex:");
        String pattern = regex ? name.substring(6) : name;
        if (pattern.isEmpty()) throw new IllegalArgumentException("Empty regex");
        Pattern compiled = regex ? Pattern.compile(pattern) : null;
        boolean atlas = properties.containsKey("atlas");
        if (atlas && properties.containsKey("texture")) throw new IllegalArgumentException("Specify texture or atlas, not both");
        String path;
        if (atlas) {
            path = required(properties, "atlas").strip();
        } else if (properties.containsKey("texture")) {
            path = properties.get("texture").strip();
        } else {
            // Use the PNG beside the properties file when no texture is specified.
            String propertiesPath = file.id().getPath();
            String pngPath = propertiesPath.substring(0, propertiesPath.length() - ".properties".length()) + ".png";
            path = file.id().getNamespace() + ":" + pngPath;
        }
        Identifier texture = Identifier.tryParse(path.contains(":") ? path : file.id().getNamespace() + ":" + path);
        if (texture == null || !texture.getPath().endsWith(".png")) {
            throw new IllegalArgumentException("Expected a texture path ending in .png");
        }
        Dimensions size = sizes.computeIfAbsent(texture, id -> pngSize(resources, id, max))
                .orElseThrow(() -> new IllegalArgumentException("Unreadable PNG " + texture));
        int u = atlas ? coordinate(properties, "atlas.x") : 0;
        int v = atlas ? coordinate(properties, "atlas.y") : 0;
        int w = atlas ? coordinate(properties, "atlas.w") : size.width;
        int h = atlas ? coordinate(properties, "atlas.h") : size.height;
        return new Overlay(new ChestOverlayDefinition(pattern, texture, u, v, w, h, regex, compiled, size.width, size.height), !atlas);
    }

    private static String required(Map<String, String> values, String key) {
        String value = values.get(key);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing " + key);
        return value;
    }

    private static int coordinate(Map<String, String> values, String key) {
        try {
            return Integer.parseInt(required(values, key).strip());
        } catch (NumberFormatException malformed) {
            throw new IllegalArgumentException("Invalid integer in " + key, malformed);
        }
    }

    private static Optional<Dimensions> pngSize(ResourceManager manager, Identifier id, int max) {
        try (var raw = new BufferedInputStream(manager.open(id)); var stream = new DataInputStream(raw)) {
            if (stream.readLong() != 0x89504e470d0a1a0aL || stream.readInt() != 13 || stream.readInt() != 0x49484452) {
                throw new IOException("Missing PNG signature or IHDR");
            }
            int width = stream.readInt();
            int height = stream.readInt();
            if (width <= 0 || height <= 0 || width > max || height > max || (long) width * height > 16_777_216L) {
                throw new IOException("PNG exceeds supported texture dimensions or 16-megapixel limit");
            }
            return Optional.of(new Dimensions(width, height));
        } catch (IOException | IllegalArgumentException unreadable) {
            LOGGER.warn("Unable to read chest overlay texture {}: {}", id, unreadable.getMessage());
            return Optional.empty();
        }
    }

    private record Dimensions(int width, int height) {}
    private record Overlay(ChestOverlayDefinition definition, boolean standalone) {}
}
