package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Immutable, reload-time compiled server-message rules. Never used by a render callback. */
public final class ServerMessages {
    public enum Signal { NONE, OFFLINE, SLOW_DOWN }
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern SLOW_DOWN = Pattern.compile("^\\s*Slow down!", FLAGS);
    private final List<Pattern> hidden = new ArrayList<>(), offline = new ArrayList<>();
    private final boolean enabled, always;

    public ServerMessages(Config config) {
        enabled = config.hideServerMessages;
        always = config.hideServerMode == Config.HideServerMode.ALWAYS;
        if (config.hiddenServerPatterns != null) for (Config.ServerMessagePattern rule : config.hiddenServerPatterns) {
            if (hidden.size() >= 64) break;
            if (rule == null || !rule.enabled || rule.text == null || rule.text.isBlank() || rule.text.length() > 1024) continue;
            compile(hidden, rule.regex ? rule.text : Pattern.quote(rule.text));
        }
        if (config.notFoundRegex != null) for (String expression : config.notFoundRegex) {
            if (offline.size() >= 32) break;
            if (expression != null && expression.length() <= 1024) compile(offline, expression);
        }
    }
    private static void compile(List<Pattern> into, String expression) {
        try { into.add(Pattern.compile(expression, FLAGS)); }
        catch (PatternSyntaxException invalid) {
            FriendLink.LOG.warn("Ignored invalid FriendLink server-message regex: {}", expression);
        }
    }
    /** Caller supplies colour-stripped text. find(), rather than matches(), permits trailing server detail. */
    public boolean hide(String clean, boolean recentFriendLinkSend) {
        if (!enabled || !always && !recentFriendLinkSend) return false;
        for (int i = 0; i < hidden.size(); i++) if (hidden.get(i).matcher(clean).find()) return true;
        return false;
    }
    /** Signal handling is deliberately independent of the visibility toggle and per-pattern checkboxes. */
    public Signal signal(String clean) {
        if (SLOW_DOWN.matcher(clean).find()) return Signal.SLOW_DOWN;
        for (int i = 0; i < offline.size(); i++) if (offline.get(i).matcher(clean).find()) return Signal.OFFLINE;
        return Signal.NONE;
    }
}
