package dev.friendlink.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Accesses ONLY PlayerEntityRenderer's pose/transform helpers. No render injection,
 * tracked flags, team colours, status effects or vanilla glow hooks are involved.
 * FriendGlow invokes these in WorldRenderEvents.LAST to reproduce the player pose
 * without re-rendering equipment, names, shadows or invoking the entity dispatcher.
 */
@Mixin(PlayerEntityRenderer.class)
public interface PlayerGlowPoseAccessor {
    // Invokes PlayerEntityRenderer.setModelPose to prepare model visibility and arm poses.
    @Invoker("setModelPose")
    void friendlink$setModelPose(AbstractClientPlayerEntity player);
    // Invokes PlayerEntityRenderer.setupTransforms for the player's vanilla pose rotations.
    @Invoker("setupTransforms")
    void friendlink$setupTransforms(AbstractClientPlayerEntity player, MatrixStack matrices,
                                    float animationProgress, float bodyYaw, float tickDelta);
    // Invokes PlayerEntityRenderer.scale on the overlay matrix stack, not a full entity render.
    @Invoker("scale")
    void friendlink$scale(AbstractClientPlayerEntity player, MatrixStack matrices, float tickDelta);
}
