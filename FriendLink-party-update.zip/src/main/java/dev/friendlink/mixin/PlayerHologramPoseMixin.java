package dev.friendlink.mixin;

import dev.friendlink.Config;
import dev.friendlink.FriendLink;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hooks PlayerEntityModel.setAngles at TAIL: only the flagged player's right arm and its sleeve. */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerHologramPoseMixin<T extends LivingEntity> extends BipedEntityModel<T> {
    @Shadow public ModelPart rightSleeve;
    protected PlayerHologramPoseMixin(ModelPart root) { super(root); }

    // TAIL preserves vanilla/mod walking, sprinting, body and all other limbs. No tracked entity data is changed.
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void friendlink$pointAtPanel(T entity, float limbAngle, float limbDistance, float animationProgress,
                                       float headYaw, float headPitch, CallbackInfo ci) {
        FriendLink mod = FriendLink.INSTANCE;
        if (!(entity instanceof PlayerEntity player) || mod == null || mod.presence == null || !mod.presence.poses(player)) return;
        Config config = mod.config;
        float delta = MathHelper.clamp(animationProgress - player.age, 0, 1);
        double yaw = Math.toRadians(MathHelper.wrapDegrees(
            MathHelper.lerpAngleDegrees(delta, player.prevHeadYaw, player.headYaw)
            - MathHelper.lerpAngleDegrees(delta, player.prevBodyYaw, player.bodyYaw)));
        // Model units are 1/16 block; model Y points down and forward is model -Z.
        double dx = -Math.sin(yaw) * config.hologramDistance - rightArm.pivotX / 16.0;
        double dy = (24 - rightArm.pivotY) / 16.0 - (player.getEyeHeight(player.getPose()) + config.hologramHeightOffset);
        double dz = -Math.cos(yaw) * config.hologramDistance;
        rightArm.pitch = (float) -Math.atan2(Math.sqrt(dx * dx + dz * dz), dy);
        rightArm.yaw = (float) Math.atan2(-dx, -dz);
        rightArm.roll = 0;
        rightSleeve.copyTransform(rightArm);
    }
}
