package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Static, privacy-safe panel only. Never reads chat, text fields, messages or screenshots. */
public final class ChatHologramRenderer {
    private static final Identifier TEXTURE = new Identifier("friendlink", "textures/gui/hologram.png");
    private static final Identifier FALLBACK = new Identifier("friendlink", "generated/hologram");
    private static final Identifier RELOAD = new Identifier("friendlink", "hologram_reload");
    private static final Supplier<ShaderProgram> SHADER = GameRenderer::getPositionTexColorProgram;
    private Identifier texture = FALLBACK;
    private boolean placeholderCreated;

    public void init() {
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override public Identifier getFabricId() { return RELOAD; }
            @Override public void reload(ResourceManager manager) {
                // Resource reload, never the frame loop, owns resource lookup and texture allocation.
                if (!placeholderCreated) {
                    NativeImage image = new NativeImage(512, 256, true);
                    for (int y = 0; y < 256; y++) for (int x = 0; x < 512; x++) {
                        // NativeImage uses ABGR, not ARGB. Deliberately no readable text.
                        int color = 0xFF28231E;
                        if (x < 3 || x >= 509 || y < 3 || y >= 253 || x >= 175 && x < 179) color = 0xFFD5B879;
                        else if (y < 27 || y > 224) color = 0xFF443B2A;
                        else if (x < 166 && y % 39 > 8 && y % 39 < 30) color = 0xFF68533B;
                        else if (x > 196 && x < 485 && y % 51 > 14 && y % 51 < 34) color = 0xFF8B623C;
                        image.setColor(x, y, color);
                    }
                    MinecraftClient.getInstance().getTextureManager().registerTexture(FALLBACK, new NativeImageBackedTexture(image));
                    placeholderCreated = true;
                }
                texture = manager.getResource(TEXTURE).isPresent() ? TEXTURE : FALLBACK;
            }
        });
    }

    public void render(WorldRenderContext context, PlayerEntity[] players, int count, Config config) {
        if (config.hologramOpacity == 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Vec3d camera = context.camera().getPos();
        Matrix4f matrix = context.matrixStack().peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        int alpha = Math.round(config.hologramOpacity * 2.55f);
        float delta = context.tickDelta();
        // No push/pop, new vectors, quaternions, arrays, streams or resource lookups in the frame loop.
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.depthMask(false);
        if (config.hologramThroughWalls) RenderSystem.disableDepthTest(); else RenderSystem.enableDepthTest();
        RenderSystem.setShader(SHADER); RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        for (int i = 0; i < count; i++) {
            PlayerEntity player = players[i];
            if (player == null || player.isRemoved() || player == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            double px = MathHelper.lerp(delta, player.prevX, player.getX());
            double py = MathHelper.lerp(delta, player.prevY, player.getY());
            double pz = MathHelper.lerp(delta, player.prevZ, player.getZ());
            double dx = px - camera.x, dy = py - camera.y, dz = pz - camera.z;
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distance > config.hologramMaxDistance) continue;
            double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(delta, player.prevHeadYaw, player.headYaw));
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            float cx = (float) (dx - sin * config.hologramDistance);
            float cy = (float) (dy + player.getEyeHeight(player.getPose()) + config.hologramHeightOffset);
            float cz = (float) (dz + cos * config.hologramDistance);
            double scale = DistanceScaling.multiplier(distance, config.hologramScaleWithDistance,
                config.hologramScaleFactor, config.hologramMaxScale);
            float half = (float) (config.hologramSize * scale * .5);
            float height = half * .5f;
            float rx = (float) (-cos * half), rz = (float) (-sin * half);
            // Front faces the subject, not the viewing camera. Width:height is always 2:1.
            v(buffer, matrix, cx - rx, cy - height, cz - rz, 0, 1, alpha);
            v(buffer, matrix, cx + rx, cy - height, cz + rz, 1, 1, alpha);
            v(buffer, matrix, cx + rx, cy + height, cz + rz, 1, 0, alpha);
            v(buffer, matrix, cx - rx, cy + height, cz - rz, 0, 0, alpha);
            // Reverse winding AND UV orientation. Culling draws exactly one face (no doubled alpha).
            v(buffer, matrix, cx + rx, cy - height, cz + rz, 0, 1, alpha);
            v(buffer, matrix, cx - rx, cy - height, cz - rz, 1, 1, alpha);
            v(buffer, matrix, cx - rx, cy + height, cz - rz, 1, 0, alpha);
            v(buffer, matrix, cx + rx, cy + height, cz + rz, 0, 0, alpha);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.depthMask(true); RenderSystem.enableDepthTest();
        RenderSystem.enableCull(); RenderSystem.disableBlend(); RenderSystem.setShaderColor(1, 1, 1, 1);
    }
    private static void v(BufferBuilder b, Matrix4f matrix, float x, float y, float z, float u, float v, int alpha) {
        b.vertex(matrix, x, y, z).texture(u, v).color(255, 255, 255, alpha).next();
    }
}
