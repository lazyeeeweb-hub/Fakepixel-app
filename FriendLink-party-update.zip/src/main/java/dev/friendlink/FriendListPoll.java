package dev.friendlink;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Client-thread, connection-scoped reader for both packet-per-page and packet-per-line servers. */
final class FriendListPoll {
    enum Chat { UNRELATED, MANUAL, AUTOMATED }
    static final String OFFLINE = "Offline";
    private static final long PERIOD_MS = 60_000, RESPONSE_MS = 10_000, PAGE_IDLE_MS = 750;
    private static final int MAX_PENDING = 64, MAX_PAGES = 1000;
    private static final int NO_PAGE = 0;
    private static final Pattern COMMAND = Pattern.compile("^/?friends\\h+list(?:\\h+([0-9]{1,9}))?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEADER = Pattern.compile("^Friend list \\(Page (\\d{1,9}) of (\\d{1,9})\\)$", Pattern.CASE_INSENSITIVE);
    private static final String USER = "(?:[-•]\\h*)?(?:\\[[^\\]\\r\\n]+]\\h*)*([A-Za-z0-9_]{1,16})";
    private static final Pattern ONLINE = Pattern.compile("^" + USER + " is playing on (.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern DISCONNECTED = Pattern.compile("^" + USER + " is currently offline$", Pattern.CASE_INSENSITIVE);
    private static final Pattern EMPTY = Pattern.compile("^You (?:do not|don't) have any friends(?: yet)?[.!]?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern DIVIDER = Pattern.compile("^[-─━]{5,}$");

    private record Request(int page, boolean automated, long sent) {}
    private record Page(boolean automated, int number, int count) {}
    private final ArrayDeque<Request> waiting = new ArrayDeque<>();
    private final Map<String, String> staged = new HashMap<>();
    private Map<String, String> locations = Map.of();
    private boolean joined;
    private int continuation;
    private long nextRun, lastRow, version;
    private boolean sawRow;
    private Page page;

    void join(long now) {
        clear();
        joined = true;
        nextRun = now;
    }

    void clear() {
        joined = false;
        waiting.clear(); staged.clear(); page = null; continuation = NO_PAGE;
        publish(Map.of());
    }

    void manualCommand(String command, long now) {
        if (!joined || waiting.size() >= MAX_PENDING) return;
        Matcher m = COMMAND.matcher(command.strip());
        if (!m.matches()) return;
        int requested = m.group(1) == null ? 1 : Integer.parseInt(m.group(1));
        if (requested > 0) waiting.addLast(new Request(requested, false, now));
    }

    void tick(long now, IntConsumer send) {
        if (!joined) return;
        expire(now);
        // One in-flight automation page, with user requests taking precedence over continuations/new polls.
        if (page != null || !waiting.isEmpty()) return;
        int next = continuation;
        if (next != NO_PAGE) continuation = NO_PAGE;
        else if (now >= nextRun) {
            staged.clear();
            nextRun = now + PERIOD_MS;
            next = 1;
        }
        if (next != NO_PAGE) {
            waiting.addLast(new Request(next, true, now));
            send.accept(next);
        }
    }

    Chat receive(String message, long now) {
        if (!joined || (page == null && waiting.isEmpty())) return Chat.UNRELATED;
        expire(now);
        String[] lines = message.split("\\R");
        Chat found = Chat.UNRELATED;
        boolean unrelated = false;
        for (String raw : lines) {
            String line = raw.strip();
            if (line.isEmpty()) continue;
            if (DIVIDER.matcher(line).matches()) {
                if (page != null) {
                    found = visibility(found, page.automated);
                    // A separate rule can occur immediately after the heading, before any rows.
                    if (sawRow) finish();
                    else lastRow = now;
                }
                continue;
            }
            Matcher header = HEADER.matcher(line);
            if (header.matches()) {
                if (page != null) finish();
                int number = Integer.parseInt(header.group(1)), count = Integer.parseInt(header.group(2));
                Request next = take(number);
                // An unmatched heading must never take ownership of a later manual-list response.
                if (next == null) { unrelated = true; continue; }
                page = new Page(next.automated, number, Math.max(number, Math.min(count, MAX_PAGES)));
                lastRow = now; sawRow = false;
                found = visibility(found, page.automated);
                continue;
            }
            if (EMPTY.matcher(line).matches()) {
                if (page != null) {
                    found = visibility(found, page.automated);
                    finish();
                } else {
                    Request req = take(1);
                    if (req == null) unrelated = true;
                    else {
                        found = visibility(found, req.automated);
                        if (req.automated) publish(Map.of());
                    }
                }
                continue;
            }
            if (page == null) { unrelated = true; continue; }
            Matcher row = ONLINE.matcher(line);
            boolean connected = row.matches();
            if (!connected && !row.usePattern(DISCONNECTED).matches()) { unrelated = true; continue; }
            found = visibility(found, page.automated);
            if (page.automated) {
                staged.put(row.group(1).toLowerCase(Locale.ROOT), connected ? row.group(2).strip() : OFFLINE);
            }
            lastRow = now; sawRow = true;
        }
        // ALLOW_GAME/ALLOW_CHAT are packet-level: never hide an unrelated line or a manual page
        // if a server packs it into the same packet as an automatic page.
        return unrelated && found == Chat.AUTOMATED ? Chat.UNRELATED : found;
    }

    private static Chat visibility(Chat previous, boolean automated) {
        return previous == Chat.MANUAL || !automated ? Chat.MANUAL : Chat.AUTOMATED;
    }

    private Request take(int number) {
        for (Iterator<Request> it = waiting.iterator(); it.hasNext();) {
            Request req = it.next();
            if (req.page == number) { it.remove(); return req; }
        }
        return null;
    }

    private void expire(long now) {
        while (!waiting.isEmpty() && now - waiting.peekFirst().sent >= RESPONSE_MS) {
            if (waiting.removeFirst().automated) staged.clear();
        }
        if (page != null && now - lastRow >= PAGE_IDLE_MS) finish();
    }

    private void finish() {
        if (page.automated) {
            if (page.number < page.count) continuation = page.number + 1;
            else { publish(Map.copyOf(staged)); staged.clear(); }
        }
        page = null;
    }

    private void publish(Map<String, String> newLocations) {
        if (!locations.equals(newLocations)) { locations = newLocations; version++; }
    }

    String location(String name) { return locations.get(name.toLowerCase(Locale.ROOT)); }
    long version() { return version; }
}
