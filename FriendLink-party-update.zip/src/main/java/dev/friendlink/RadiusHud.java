package dev.friendlink;

import java.util.Arrays;
import java.util.Comparator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Reuses row objects. Entity filtering, sorting, strings and font measurements happen on ticks only. */
public final class RadiusHud {
    private final FriendLink mod;
    private final Row[] rows = new Row[512];
    private int count;
    private final Badges.Counter total = new Badges.Counter();
    private static final Comparator<Row> BY_DISTANCE = Comparator.comparingDouble(r -> r.distance);
    private static final class Row {
        Identifier face;
        String label = "";
        int labelWidth;
        double distance;
        float health;
        final Badges.Counter unread = new Badges.Counter();
    }
    public RadiusHud(FriendLink mod) { this.mod = mod; for (int i = 0; i < rows.length; i++) rows[i] = new Row(); }
    public void clear() { count = 0; total.update(MinecraftClient.getInstance().textRenderer, 0); }
    public void update() {
        count = 0;
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = mod.config;
        total.update(mc.textRenderer, mod.totalUnread());
        if (!c.hudEnabled || mc.world == null || mc.player == null) return;
        var players = mc.world.getPlayers();
        double maxSquared = (double) c.radius * c.radius;
        int viewDistance = mc.options.getViewDistance().getValue();
        var playerChunk = mc.player.getChunkPos();
        for (int i = 0; i < players.size() && count < rows.length; i++) {
            var p = players.get(i);
            if (p == mc.player || p.isRemoved()) continue;
            String name = p.getGameProfile().getName();
            var friend = mod.friend(name);
            if (friend == null) continue;
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            double dy = c.distance3d ? p.getY() - mc.player.getY() : 0;
            double squared = dx * dx + dy * dy + dz * dz;
            if (squared > maxSquared) continue;
            Row r = rows[count++]; r.distance = Math.sqrt(squared); r.face = mod.skins.face(name);
            r.health = -1f;
            // The HUD can have a much larger configured radius than the client view distance.
            // Keep existing head visibility, but sample health only for a nearby, rendered-world player.
            var chunk = p.getChunkPos();
            if (Math.abs(chunk.x - playerChunk.x) <= viewDistance && Math.abs(chunk.z - playerChunk.z) <= viewDistance) {
                float health = p.getHealth(), maxHealth = p.getMaxHealth();
                if (maxHealth > 0 && Float.isFinite(maxHealth) && Float.isFinite(health))
                    r.health = Math.max(0f, Math.min(1f, health / maxHealth));
            }
            r.label = (c.showName ? name : "") + (c.showName && c.showDistance ? " · " : "")
                + (c.showDistance ? Math.round(r.distance) + "m" : "");
            r.labelWidth = mc.textRenderer.getWidth(r.label);
            r.unread.update(mc.textRenderer, friend.unread);
        }
        if (c.sortByDistance) Arrays.sort(rows, 0, count, BY_DISTANCE);
    }
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = mod.config;
        boolean showTotal = c.unreadTotalBadge && total.visible();
        if (!c.hudEnabled || (count == 0 && !showTotal) || mc.options.hudHidden || mc.world == null) return;
        float scale = (float) c.scale;
        int w = (int) (mc.getWindow().getScaledWidth() / scale), h = (int) (mc.getWindow().getScaledHeight() / scale);
        int barHeight = Math.max(2, c.iconSize / 8);
        int step = c.iconSize + 5 + barHeight;
        int slots = Math.max(0, (h - c.offsetY) / step);
        int extra = showTotal && slots > 0 ? 1 : 0;
        int shown = Math.min(Math.min(count, c.maxIcons), Math.max(0, slots - extra));
        boolean right = c.anchor == Config.Anchor.TOP_RIGHT || c.anchor == Config.Anchor.BOTTOM_RIGHT;
        boolean bottom = c.anchor == Config.Anchor.BOTTOM_LEFT || c.anchor == Config.Anchor.BOTTOM_RIGHT;
        // MatrixStack internals and Minecraft's draw calls are engine-owned, not FriendLink cache allocations.
        context.getMatrices().push(); context.getMatrices().scale(scale, scale, 1);
        int y = bottom ? h - c.offsetY - (shown + extra) * step : c.offsetY;
        int totalX = right ? w - c.offsetX - c.iconSize : c.offsetX;
        if (!bottom && extra != 0) { renderTotal(context, mc, totalX, y, c.iconSize); y += step; }
        for (int i = 0; i < shown; i++) {
            Row r = rows[i];
            int rowWidth = c.iconSize + (r.label.isEmpty() ? 0 : 5 + r.labelWidth);
            int x = right ? w - c.offsetX - rowWidth : c.offsetX;
            context.fill(x - 2, y - 2, x + rowWidth + 2,
                y + c.iconSize + (r.health < 0 ? 2 : barHeight + 3), 0x880C1018);
            Faces.draw(context, r.face, x, y, c.iconSize);
            if (r.health >= 0f) {
                int barY = y + c.iconSize + 1;
                int filled = Math.round(c.iconSize * r.health);
                int color = r.health > .5f ? 0xFF53D769 : r.health >= .25f ? 0xFFFFD44D : 0xFFFF5252;
                context.fill(x, barY, x + c.iconSize, barY + barHeight, 0xFF262C36);
                if (filled != 0) context.fill(x, barY, x + filled, barY + barHeight, color);
            }
            if (c.unreadFriendBadges) r.unread.draw(context, mc.textRenderer, x + c.iconSize - 3, y + c.iconSize - 3);
            if (!r.label.isEmpty()) context.drawText(mc.textRenderer, r.label, x + c.iconSize + 5,
                y + (c.iconSize - 8) / 2, 0xFFFFFFFF, true);
            y += step;
        }
        if (bottom && extra != 0) renderTotal(context, mc, totalX, y, c.iconSize);
        context.getMatrices().pop();
    }
    private void renderTotal(DrawContext context, MinecraftClient mc, int x, int y, int size) {
        context.fill(x - 2, y - 2, x + size + 2, y + size + 2, 0x880C1018);
        Badges.speech(context, x + (size - 12) / 2, y + (size - 11) / 2, 0xFFE4E8FF);
        total.draw(context, mc.textRenderer, x + size - 3, y + size - 3);
    }
}
