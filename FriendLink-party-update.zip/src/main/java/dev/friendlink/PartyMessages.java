package dev.friendlink;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parsers for server announcements only, after stripping legacy formatting. */
final class PartyMessages {
    private static final String PLAYER = "(?:\\[[^\\]\\r\\n]+]\\s*)*([A-Za-z0-9_]{1,16})";
    private static final Pattern INVITE = Pattern.compile("^" + PLAYER
        + " has invited you to join their Party!\\h*\\R\\h*You have 60 seconds to accept\\. Click here to join!$",
        Pattern.CASE_INSENSITIVE);
    private static final Pattern DECORATION = Pattern.compile("(?m)^\\h*[-─━]{5,}\\h*$(?:\\R)?");
    private static final Pattern LEGACY_COLOR = Pattern.compile("(?i)§[0-9A-FK-ORX]");
    private static final Pattern PROMOTED = Pattern.compile("^(?:The party was transferred to " + PLAYER
        + "(?: by " + PLAYER + ")?(?: because .+)?|" + PLAYER + " has been promoted to Party Leader|"
        + PLAYER + " (?:has )?promoted " + PLAYER + " to Party Leader|Party Leader: " + PLAYER + ")[.!]?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern LEADER = Pattern.compile("^You (?:are (?:now )?(?:the )?Party Leader|"
        + "(?:have )?(?:been promoted to (?:the )?Party Leader|created (?:a|the|your) party)|"
        + "(?:have )?formed (?:a|the|your) party)[.!]?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern NOT_LEADER = Pattern.compile("^(?:You (?:have )?(?:left the party|"
        + "(?:been|were) (?:kicked|removed) from the party|are (?:not|no longer) (?:in a party|(?:the )?Party Leader)|"
        + "(?:joined|have joined) (?:the party of " + PLAYER + "|" + PLAYER + "(?:'|’)s party)|disbanded the party)|"
        + "(?:The|Your) party (?:(?:was|has been) )?disbanded(?: because .+)?|"
        + PLAYER + " has disbanded the party|You must be (?:the )?Party Leader to .+)[.!]?$", Pattern.CASE_INSENSITIVE);

    private PartyMessages() {}

    static String clean(String raw) {
        return raw.indexOf('§') < 0 ? raw : LEGACY_COLOR.matcher(raw).replaceAll("");
    }

    static String inviter(String clean) {
        if (!clean.contains("Click here to join!")) return null;
        Matcher matcher = INVITE.matcher(DECORATION.matcher(clean).replaceAll("").strip());
        return matcher.matches() ? matcher.group(1) : null;
    }

    static boolean leader(String clean, String self, boolean current) {
        for (String line : clean.split("\\R")) {
            line = line.strip();
            if (line.regionMatches(true, 0, "Party >", 0, 7)) continue;
            if (NOT_LEADER.matcher(line).matches()) current = false;
            else if (LEADER.matcher(line).matches()) current = true;
            else {
                Matcher m = PROMOTED.matcher(line);
                if (!m.matches()) continue;
                // Transfer recipient, promoted player, named recipient of a promotion, or party-list leader.
                String recipient = m.group(1) != null ? m.group(1) : m.group(3) != null ? m.group(3)
                    : m.group(5) != null ? m.group(5) : m.group(6);
                current = self.equalsIgnoreCase(recipient);
            }
        }
        return current;
    }
}
