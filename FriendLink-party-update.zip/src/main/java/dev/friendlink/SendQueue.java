package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;

/** One in-flight command correlates otherwise nameless offline errors; never consults the tab list. */
public final class SendQueue {
    public record Job(String target, String body, String conversation, Message message) {}
    public static final class Entry {
        public String target = "", body = "", conversation = "", messageId = "", wireId = "";
        public long created, nextAt;
        public int attempts, stage;
        public boolean confirmed;
        transient Message message;
        transient boolean ready;
        transient long lastSentAt;
        transient boolean feedbackApplied;
        boolean control() { return messageId.isEmpty(); }
        boolean receipt() { return body.startsWith("[FLC:D:") || body.startsWith("[FLC:R:"); }
        boolean presence() { return body.equals("[FLC:O]") || body.equals("[FLC:C]"); }
    }
    public static final class PendingData { public List<Entry> entries = new ArrayList<>(); }
    private static final int CAPACITY = 512, HISTORY = 8192;
    private final FriendLink mod;
    private final List<Entry> entries = new ArrayList<>();
    private final ArrayDeque<Entry> recentControls = new ArrayDeque<>();
    private Entry active, lastSent;
    private long deadline, nextSend, nextReceipt, nextPresence;
    private final SendPacing pacing = new SendPacing();
    private boolean dirty;
    public SendQueue(FriendLink mod) { this.mod = mod; }

    public boolean offer(List<Job> jobs) {
        int pending = 0;
        for (Entry e : entries) if (!e.confirmed && e.stage != 4) pending++;
        if (pending + jobs.size() > CAPACITY || entries.size() + jobs.size() > HISTORY) return false;
        for (Job j : jobs) if (!Protocol.validName(j.target()) || j.body() == null
            || j.body().length() > Protocol.bodyLimit(j.target())) return false;
        long now = System.currentTimeMillis();
        for (Job j : jobs) {
            if (j.message() == null && coalesceControl(j)) continue;
            Entry e = new Entry();
            e.target = j.target(); e.body = j.body(); e.conversation = j.conversation();
            e.created = now; e.nextAt = now; e.message = j.message(); e.ready = true;
            if (j.message() != null) {
                if (j.message().id == null || j.message().id.isEmpty()) j.message().id = ReliableProtocol.newId();
                e.messageId = j.message().id;
                ReliableProtocol.Tagged tag = ReliableProtocol.tagged(j.body());
                e.wireId = tag == null ? ReliableProtocol.newId() : tag.id();
                Delivery d = j.message().delivery.computeIfAbsent(e.target, n -> new Delivery());
                d.total++; d.parts.put(e.wireId, 0);
            }
            entries.add(e);
        }
        changed(); return true;
    }
    /** Replace unsent presence edges with the latest desired state, and deduplicate controls. */
    private boolean coalesceControl(Job job) {
        boolean presence = job.body().equals("[FLC:O]") || job.body().equals("[FLC:C]");
        if (presence) for (int i = entries.size() - 1; i >= 0; i--) {
            Entry e = entries.get(i);
            if (e != active && e.control() && e.presence() && e.target.equalsIgnoreCase(job.target())) entries.remove(i);
        }
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            if (e.control() && e.target.equalsIgnoreCase(job.target()) && e.body.equals(job.body())) return true;
        }
        return false;
    }
    /** Discard only unsent presence opens, leaving receipts, closes and user messages alone. */
    public void cancelPresenceOpens(String target) {
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry e = entries.get(i);
            if (e != active && e.control() && e.body.equals("[FLC:O]")
                && (target == null || e.target.equalsIgnoreCase(target))) entries.remove(i);
        }
    }
    /** Called only after metadata startup; all log loads and queue reads run on the storage worker. */
    public void restore(PendingData saved) {
        if (saved == null || saved.entries == null) return;
        long now = System.currentTimeMillis();
        for (Entry e : saved.entries) {
            if (entries.size() >= HISTORY) break;
            if (e == null || !Protocol.validName(e.target) || e.body == null
                || e.body.length() > Protocol.bodyLimit(e.target) || !ReliableProtocol.validId(e.messageId)
                || !ReliableProtocol.validId(e.wireId) || !ConversationSelection.exists(mod.state, e.conversation)) continue;
            e.stage = Config.clamp(e.stage, 0, 4); e.attempts = Math.max(0, e.attempts);
            e.nextAt = Math.max(now, e.nextAt); entries.add(e);
            mod.ensureConversation(e.conversation, () -> {
                for (Message m : mod.messages(e.conversation)) if (e.messageId.equals(m.id)) { e.message = m; break; }
                if (e.message == null) { entries.remove(e); changed(); return; }
                e.ready = true; update(e, e.stage); changed();
            });
        }
    }
    public PendingData snapshot() {
        PendingData data = new PendingData();
        for (Entry e : entries) if (!e.control()) data.entries.add(e);
        return data;
    }
    public void save() {
        if (!dirty) return;
        mod.storage.write("pending.json", snapshot()); dirty = false;
    }
    private void changed() { dirty = true; mod.touch(); }
    public void tick(long now) {
        pacing.tick(now, mod.config.sendDelayMs);
        while (!recentControls.isEmpty() && now - recentControls.peek().created > 30000) recentControls.remove();
        if (active != null && now >= deadline) defer(active, now);
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry e = entries.get(i);
            long age = now - e.created;
            if (e.control() && e != active && age > 60000) { entries.remove(i); continue; }
            if (!e.control() && e.ready && !e.confirmed && e.stage != 4
                && (age >= maxAge() || e.attempts >= mod.config.retryMaxAttempts && e != active
                    && now >= e.nextAt && !inFeedbackWindow(e, now))) {
                update(e, 4); changed();
            }
            if (!e.control() && e != active && (e.stage == 3 || e.confirmed && age > maxAge())) {
                entries.remove(i); dirty = true;
            }
        }
        if (active != null || now < nextSend) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null || mc.player == null) return;
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            if (!e.ready || e.confirmed || e.stage == 4 || now < e.nextAt
                || !e.control() && e.attempts >= mod.config.retryMaxAttempts && inFeedbackWindow(e, now)
                || e.receipt() && now < nextReceipt || e.presence() && now < nextPresence) continue;
            if (e.control() && e.presence() && mod.presence != null
                && !mod.presence.maySend(e.target, e.body.equals("[FLC:O]"))) {
                entries.remove(i--); continue;
            }
            beginSend(e, now);
            try { mc.getNetworkHandler().sendChatCommand("msg " + e.target + " " + e.body); }
            catch (RuntimeException ex) {
                FriendLink.LOG.warn("Could not send FriendLink command; retaining pending message", ex);
                defer(e, now);
            }
            return;
        }
    }
    /** Shared scheduling seam: tests arm the actual Entry, not a removed queue field or a Job. */
    void beginSend(Entry entry, long now) {
        active = entry; lastSent = entry; entry.attempts++;
        entry.lastSentAt = now;
        entry.feedbackApplied = false;
        deadline = now + mod.config.echoTimeoutMs;
        pacing.sent(now);
        nextSend = now + pacing.delay(mod.config.sendDelayMs);
        if (entry.receipt()) nextReceipt = now + SendPacing.CONTROL_INTERVAL_MS;
        if (entry.presence()) nextPresence = now + SendPacing.CONTROL_INTERVAL_MS;
        dirty = true;
    }
    public boolean recentWhisper(long now) { return pacing.recent(now); }
    private static boolean inFeedbackWindow(Entry entry, long now) {
        return entry.lastSentAt != 0L && now >= entry.lastSentAt
            && now - entry.lastSentAt <= SendPacing.CAUSE_WINDOW_MS;
    }
    private Entry feedbackEntry(long now) {
        Entry entry = lastSent;
        if (entry == null || !entries.contains(entry) || entry.confirmed || entry.stage == 4
            || entry.feedbackApplied || !pacing.recent(now) || !inFeedbackWindow(entry, now)) return null;
        return entry;
    }
    /** A server throttle is not a delivery failure and does not consume a retry attempt. */
    public boolean slowDown() {
        long now = System.currentTimeMillis();
        if (!pacing.recent(now)) return false;
        Entry e = feedbackEntry(now);
        int delay = pacing.slowDown(now, mod.config.sendDelayMs);
        nextSend = Math.max(nextSend, now + delay);
        if (e != null) {
            e.feedbackApplied = true;
            if (active == e) active = null;
            e.attempts = Math.max(0, e.attempts - 1);
            e.nextAt = Math.max(e.nextAt, now + delay);
        }
        changed();
        return true;
    }
    private long maxAge() { return mod.config.retryMaxAgeHours * 3600000L; }
    private void defer(Entry e, long now) {
        if (active == e) active = null;
        if (!entries.contains(e)) return;
        if (!e.control()) {
            boolean expired = now - e.created >= maxAge();
            boolean exhausted = e.attempts >= mod.config.retryMaxAttempts && !inFeedbackWindow(e, now);
            update(e, expired || exhausted ? 4 : Math.max(1, e.stage));
            long delay = Math.min(mod.config.retryMaxDelayMs,
                (long)mod.config.retryDelayMs << Math.min(10, Math.max(0, e.attempts - 1)));
            e.nextAt = now + delay;
        } else {
            if (e.body.equals("[FLC:O]") || e.body.equals("[FLC:C]") || e.body.equals("[FLC:H]")
                || e.body.equals("[FLC:A]")) {
                entries.remove(e); rememberControl(e, now);
            } else e.nextAt = now + mod.config.retryDelayMs;
        }
        changed();
    }
    public boolean echo(String name, String body) {
        // Newest first handles deliberate retry of identical legacy text after an older echo.
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry e = entries.get(i);
            if (!e.target.equalsIgnoreCase(name) || !e.body.equals(body)) continue;
            if (active == e) active = null;
            e.confirmed = true;
            if (e.control()) { entries.remove(i); rememberControl(e, System.currentTimeMillis()); }
            else update(e, e.stage == 4 ? 1 : Math.max(1, e.stage));
            changed(); return true;
        }
        for (Entry e : recentControls) if (e.target.equalsIgnoreCase(name) && e.body.equals(body)) return true;
        return false;
    }
    private void rememberControl(Entry e, long now) {
        e.created = now; recentControls.add(e);
        while (recentControls.size() > 512) recentControls.remove();
    }
    public boolean notFound() {
        long now = System.currentTimeMillis();
        Entry e = feedbackEntry(now);
        if (e == null) return false;
        e.feedbackApplied = true;
        if (active == e) active = null;
        if (e.control()) {
            e.attempts = Math.max(0, e.attempts - 1);
            defer(e, now);
        } else {
            e.attempts = Math.max(0, e.attempts - 1);
            update(e, 1); // Waiting, not failed; retry logic remains active.
            long delay = Math.min(mod.config.retryMaxDelayMs,
                (long)mod.config.retryDelayMs << Math.min(10, Math.max(0, e.attempts - 1)));
            e.nextAt = now + delay;
            changed();
        }
        return true;
    }
    /** A receipt is authorized only for the target of this exact random wire id. */
    public void receipt(String peer, String id, boolean read) {
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            if (e.control() || !e.target.equalsIgnoreCase(peer) || !e.wireId.equals(id)) continue;
            if (active == e) active = null;
            e.confirmed = true;
            update(e, Math.max(e.stage == 4 ? 1 : e.stage, read ? 3 : 2));
            changed(); return;
        }
    }
    private void update(Entry e, int stage) {
        e.stage = stage;
        if (e.message == null) return;
        Delivery d = e.message.delivery.computeIfAbsent(e.target, n -> new Delivery());
        d.parts.put(e.wireId, stage);
        d.completed = 0; d.failed = 0; d.unconfirmed = 0;
        for (int s : d.parts.values()) {
            if (s != 0) d.completed++;
            if (s == 4) d.failed++;
            if (s == 1 && !e.confirmed) d.unconfirmed++;
        }
    }
    public void nearby(String name) {
        long now = System.currentTimeMillis();
        for (Entry e : entries) if (!e.confirmed && e.stage != 4 && e.target.equalsIgnoreCase(name)) e.nextAt = now;
    }
    public void retry(String conversation, Message message) {
        long now = System.currentTimeMillis();
        for (Entry e : entries) if (e.conversation.equals(conversation) && e.messageId.equals(message.id) && e.stage == 4) {
            e.created = now; e.attempts = 0; e.nextAt = now; e.confirmed = false; update(e, 0);
        }
        changed(); save();
    }
    public void clearEchoes() { recentControls.clear(); }
    /** Disconnect is suspension, not failure: pending user messages survive reconnect/restart. */
    public void cancel(String reason) {
        if (active != null && !active.control()) defer(active, System.currentTimeMillis());
        active = null;
        entries.removeIf(Entry::control); nextSend = nextReceipt = nextPresence = 0; pacing.clear(); changed();
    }
    public void cancelConversation(String key) {
        if (active != null && active.conversation.equals(key)) active = null;
        entries.removeIf(e -> e.conversation.equals(key)); changed();
    }
}
