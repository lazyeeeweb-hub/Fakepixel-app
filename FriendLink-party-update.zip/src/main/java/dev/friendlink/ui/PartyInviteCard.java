package dev.friendlink.ui;

import dev.friendlink.PartyService;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/** Shared virtual-pixel drawing and hitboxes for the chat card and its native-toast presentation. */
public final class PartyInviteCard {
    public static final int HEIGHT = 20, MIN_WIDTH = 62;
    private static final OrderedText YES = Text.literal("✓").asOrderedText(), NO = Text.literal("✗").asOrderedText();
    private PartyService.Invite displayed;
    private OrderedText label;
    private int labelWidth, x, y, width;

    public void draw(DrawContext c, TextRenderer tr, PartyService.Invite invite, int x, int y, int width, double mx, double my) {
        if (invite == null || width < MIN_WIDTH) { clear(); return; }
        if (displayed != invite || labelWidth != width) {
            label = Text.literal(tr.trimToWidth(invite.label(), width - 48)).asOrderedText();
            labelWidth = width;
        }
        this.x = x; this.y = y; this.width = width; displayed = invite;
        c.fill(x, y, x + width, y + HEIGHT, 0xFF212938);
        c.fill(x, y, x + 2, y + HEIGHT, 0xFFE5B945);
        c.drawText(tr, label, x + 6, y + 6, 0xFFFFE5AB, false);
        button(c, tr, YES, x + width - 39, invite.click() == null ? 0xFF8190A4 : 0xFF88F2AA, mx, my);
        button(c, tr, NO, x + width - 20, 0xFFFF8C9C, mx, my);
    }

    private void button(DrawContext c, TextRenderer tr, OrderedText text, int left, int color, double mx, double my) {
        c.fill(left, y + 2, left + 17, y + 18, hit(left, mx, my) ? 0xFF4A5972 : 0xFF323D50);
        c.drawText(tr, text, left + (17 - tr.getWidth(text)) / 2, y + 6, color, false);
    }

    private boolean hit(int left, double mx, double my) {
        return mx >= left && mx < left + 17 && my >= y + 2 && my < y + 18;
    }

    public void clear() { displayed = null; }

    public boolean click(PartyService party, double mx, double my) {
        if (displayed == null) return false;
        if (hit(x + width - 39, mx, my)) return party.respond(displayed, true);
        if (hit(x + width - 20, mx, my)) return party.respond(displayed, false);
        return false;
    }
}
