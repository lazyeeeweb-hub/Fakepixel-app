package dev.friendlink.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Flat social-menu button. Text is prepared on changes, never in renderButton (Yarn 1.20.1). */
public final class SocialButton extends ClickableWidget {
    private final Runnable action;
    private OrderedText label;
    private int labelWidth;
    private boolean accent, pressed;
    private final boolean sendIcon;
    private final boolean searchIcon;

    public SocialButton(int x, int y, int width, int height, String label, Runnable action) {
        super(x, y, width, height, Text.literal(label));
        this.action = action;
        searchIcon = label.equals("?");
        sendIcon = label.equals(">");
        label(label);
    }
    public SocialButton accent(boolean value) { accent = value; return this; }
    public void label(String value) {
        Text text = Text.literal(value);
        setMessage(text);
        label = Text.literal(MinecraftClient.getInstance().textRenderer.trimToWidth(value, Math.max(1, width - 4))).asOrderedText();
        labelWidth = MinecraftClient.getInstance().textRenderer.getWidth(label);
    }
    @Override public void onClick(double x, double y) { pressed = true; action.run(); }
    @Override public void onRelease(double x, double y) { releasePress(); }
    /** The screen calls this even when release occurs outside the button's hit box. */
    public void releasePress() { pressed = false; }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (active && visible && isFocused() && (key == GLFW.GLFW_KEY_ENTER
            || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE)) {
            playDownSound(MinecraftClient.getInstance().getSoundManager());
            action.run(); return true;
        }
        return false;
    }
    @Override public void renderButton(DrawContext c, int mouseX, int mouseY, float delta) {
        boolean hover = isHovered() || isFocused();
        int color = !active ? 0xFF252B34 : accent ? (pressed ? 0xFF18569D : hover ? 0xFF408FE7 : 0xFF2879D5)
            : pressed ? 0xFF202936 : hover ? 0xFF3B4554 : 0xFF29313D;
        c.fill(getX(), getY(), getX() + width, getY() + height, color);
        if (sendIcon) {
            // A centered 5x9 chevron avoids font bearings and stays inside the padded composer button.
            int x = getX() + (width - 5) / 2, y = getY() + (height - 9) / 2;
            int ink = active ? 0xFFF0F3FA : 0xFF727C8E;
            for (int i = 0; i < 9; i++) {
                int dx = i <= 4 ? i : 8 - i;
                c.fill(x + dx, y + i, x + dx + 1, y + i + 1, ink);
            }
        } else if (searchIcon) {
            int x = getX() + (width - 11) / 2, y = getY() + (height - 11) / 2, ink = 0xFFE5EDFA;
            c.fill(x + 1, y, x + 7, y + 1, ink); c.fill(x + 1, y + 6, x + 7, y + 7, ink);
            c.fill(x, y + 1, x + 1, y + 6, ink); c.fill(x + 7, y + 1, x + 8, y + 6, ink);
            c.fill(x + 7, y + 7, x + 9, y + 9, ink); c.fill(x + 9, y + 9, x + 11, y + 11, ink);
        } else c.drawText(MinecraftClient.getInstance().textRenderer, label,
            getX() + Math.max(2, (width - labelWidth) / 2), getY() + (height - MinecraftClient.getInstance().textRenderer.fontHeight) / 2,
            active ? 0xFFF0F3FA : 0xFF727C8E, false);
    }
    @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
