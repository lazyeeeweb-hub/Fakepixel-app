package dev.friendlink.ui;

import dev.friendlink.Config;
import dev.friendlink.FriendLink;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Vanilla-only editor for FriendLink's server-message suppression rules. */
public final class HideServerMessagesScreen extends Screen {
    private static final int ROW_HEIGHT = 40;
    private int rowTop = 62;
    private int descriptionY = 56;
    private static final int MAX_VISIBLE_ROWS = 8;
    private static final Text EMPTY_LIST = Text.literal("No patterns. Add a rule below.");

    private final Screen parent;
    private final HideServerMessagesDraft draft;
    private final List<RuleWidgets> visibleRules = new ArrayList<>();
    private int page;
    private int pageSize = 1;
    private int panelX;
    private int panelWidth;
    private Text pageLabel = Text.empty();
    private Text modeDescription = Text.empty();
    private TextFieldWidget initialFocus;

    public HideServerMessagesScreen(Screen parent) {
        this(parent, new HideServerMessagesDraft(FriendLink.INSTANCE.config));
    }

    private HideServerMessagesScreen(Screen parent, HideServerMessagesDraft draft) {
        super(Text.literal("Hide server messages"));
        this.parent = parent;
        this.draft = draft;
    }

    @Override
    protected void init() {
        panelWidth = Math.max(232, Math.min(560, width - 24));
        panelX = (width - panelWidth) / 2;
        boolean compact = panelWidth < 400;
        rowTop = compact ? 100 : 62;
        descriptionY = compact ? 80 : 56;
        pageSize = Math.max(1, Math.min(MAX_VISIBLE_ROWS,
            (height - 78 - rowTop - 5) / ROW_HEIGHT));
        int pageCount = Math.max(1, (draft.rules.size() + pageSize - 1) / pageSize);
        page = Math.max(0, Math.min(page, pageCount - 1));
        pageLabel = Text.literal("Page " + (page + 1) + " / " + pageCount);
        modeDescription = Text.literal(draft.mode == Config.HideServerMode.ALWAYS
            ? "Always: apply rules to all server/system messages."
            : "FriendLink only: apply rules to FriendLink server messages.");
        visibleRules.clear();
        initialFocus = null;

        int modeWidth = compact ? panelWidth : Math.min(250, panelWidth / 2);
        int modeX = compact ? panelX : panelX + panelWidth - modeWidth;
        int modeY = compact ? 56 : 34;
        int masterWidth = compact ? panelWidth : panelWidth - modeWidth - 8;
        CheckboxWidget master = new CheckboxWidget(panelX, 34, masterWidth, 20,
            Text.literal("Hide server messages"), draft.enabled) {
            @Override
            public void onPress() {
                super.onPress();
                draft.enabled = isChecked();
            }
        };
        addDrawableChild(master);

        addDrawableChild(ButtonWidget.builder(modeLabel(), button -> {
            draft.mode = draft.mode == Config.HideServerMode.ALWAYS
                ? Config.HideServerMode.FRIENDLINK_ONLY : Config.HideServerMode.ALWAYS;
            button.setMessage(modeLabel());
            modeDescription = Text.literal(draft.mode == Config.HideServerMode.ALWAYS
                ? "Always: apply rules to all server/system messages."
                : "FriendLink only: apply rules to FriendLink server messages.");
        }).dimensions(modeX, modeY, modeWidth, 20).build());

        int start = page * pageSize;
        int end = Math.min(draft.rules.size(), start + pageSize);
        int rowY = rowTop;
        for (int i = start; i < end; i++) {
            HideServerMessagesDraft.Rule rule = draft.rules.get(i);
            RuleWidgets row = createRuleWidgets(rule, i, rowY);
            visibleRules.add(row);
            rowY += ROW_HEIGHT;
        }

        int footerY = height - 78;
        addDrawableChild(ButtonWidget.builder(Text.literal("+ Rule"), button -> {
            draft.addRule();
            page = Math.max(0, (draft.rules.size() - 1) / pageSize);
            clearAndInit();
        }).dimensions(panelX, footerY, 80, 20).build());
        ButtonWidget previous = ButtonWidget.builder(Text.literal("<"), button -> {
            page--;
            clearAndInit();
        }).dimensions(panelX + 84, footerY, 30, 20).build();
        previous.active = page > 0;
        addDrawableChild(previous);
        ButtonWidget next = ButtonWidget.builder(Text.literal(">"), button -> {
            page++;
            clearAndInit();
        }).dimensions(panelX + 118, footerY, 30, 20).build();
        next.active = page + 1 < pageCount;
        addDrawableChild(next);
        ButtonWidget reset = ButtonWidget.builder(Text.literal("Defaults"), button -> {
            draft.resetPatterns();
            page = 0;
            clearAndInit();
        }).dimensions(panelX + panelWidth - 82, footerY, 82, 20).build();
        addDrawableChild(reset);

        int buttonX = width / 2 - 114;
        addDrawableChild(ButtonWidget.builder(Text.literal("Save & Back"), button -> save())
            .dimensions(buttonX, height - 27, 112, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), button -> close())
            .dimensions(buttonX + 116, height - 27, 112, 20).build());
        if (initialFocus != null) setInitialFocus(initialFocus);
    }

    private RuleWidgets createRuleWidgets(HideServerMessagesDraft.Rule rule, int index, int y) {
        CheckboxWidget enabled = new CheckboxWidget(panelX, y, 78, 20,
            Text.literal("Enabled"), rule.enabled) {
            @Override
            public void onPress() {
                super.onPress();
                rule.enabled = isChecked();
            }
        };
        addDrawableChild(enabled);

        int typeX = panelX + 80;
        ButtonWidget type = ButtonWidget.builder(typeLabel(rule), button -> {
            rule.setRegex(!rule.regex);
            button.setMessage(typeLabel(rule));
        }).dimensions(typeX, y, 70, 20).build();
        addDrawableChild(type);

        int fieldX = panelX + 154;
        int removeX = panelX + panelWidth - 58;
        int fieldWidth = Math.max(40, removeX - fieldX - 4);
        TextFieldWidget field = new TextFieldWidget(textRenderer, fieldX, y,
            fieldWidth, 20, Text.literal("Pattern"));
        field.setMaxLength(Math.max(4096, rule.text.length()));
        field.setText(rule.text);
        field.setChangedListener(rule::setText);
        addDrawableChild(field);
        if (initialFocus == null && !rule.valid) initialFocus = field;

        ButtonWidget remove = ButtonWidget.builder(Text.literal("Remove"), button -> {
            draft.removeRule(index);
            page = Math.min(page, Math.max(0, (draft.rules.size() - 1) / pageSize));
            clearAndInit();
        }).dimensions(removeX, y, 56, 20).build();
        addDrawableChild(remove);
        return new RuleWidgets(rule, y, fieldX, field);
    }

    private Text modeLabel() {
        return Text.literal(draft.mode == Config.HideServerMode.ALWAYS
            ? "Scope: Always" : "Scope: FriendLink only");
    }

    private static Text typeLabel(HideServerMessagesDraft.Rule rule) {
        return Text.literal(rule.regex ? "Regex" : "Literal");
    }

    private void save() {
        int invalid = draft.firstInvalidIndex();
        if (invalid >= 0) {
            page = invalid / pageSize;
            clearAndInit();
            return;
        }
        draft.applyTo(FriendLink.INSTANCE.config);
        FriendLink.INSTANCE.saveConfig();
        close();
    }

    @Override
    public void tick() {
        for (RuleWidgets row : visibleRules) row.field.tick();
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        context.drawText(textRenderer, modeDescription, panelX, descriptionY, 0xB6BFD6, false);
        if (draft.rules.isEmpty()) {
            context.drawText(textRenderer, EMPTY_LIST, panelX, rowTop + 4, 0xB6BFD6, false);
        }
        for (RuleWidgets row : visibleRules) {
            if (!row.rule.valid) {
                context.drawText(textRenderer, row.rule.error, row.fieldX, row.y + 22, 0xFF7777, false);
            }
        }
        context.drawCenteredTextWithShadow(textRenderer, pageLabel, width / 2, height - 54, 0xB6BFD6);
    }

    private static final class RuleWidgets {
        final HideServerMessagesDraft.Rule rule;
        final int y;
        final int fieldX;
        final TextFieldWidget field;

        RuleWidgets(HideServerMessagesDraft.Rule rule, int y, int fieldX, TextFieldWidget field) {
            this.rule = rule;
            this.y = y;
            this.fieldX = fieldX;
            this.field = field;
        }
    }
}
