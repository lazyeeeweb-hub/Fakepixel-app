package dev.friendlink.ui;

import dev.friendlink.Config;
import dev.friendlink.FriendLink;
import dev.friendlink.IndicatorStyle;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/** Paginated built-in settings: no dependency on Cloth Config and no frame-local label creation. */
public final class HologramSettingsScreen extends Screen {
    private static final int OPTIONS = 14;
    private final Screen parent;
    private final FriendLink mod = FriendLink.INSTANCE;
    private int page;
    public HologramSettingsScreen(Screen parent) { super(Text.literal("Hologram and presence")); this.parent = parent; }
    @Override protected void init() {
        int rows = Math.max(1, (height - 72) / 24), capacity = rows * 2;
        int pages = (OPTIONS + capacity - 1) / capacity;
        page = Math.min(page, pages - 1);
        int w = Math.min(240, (width - 26) / 2), x = (width - w * 2 - 6) / 2;
        for (int slot = 0; slot < capacity && page * capacity + slot < OPTIONS; slot++)
            option(page * capacity + slot, x + slot % 2 * (w + 6), 32 + slot / 2 * 24, w);
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { page--; clearAndInit(); }).dimensions(x, height - 28, 30, 20).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(x + 34, height - 28, w * 2 - 62, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { page++; clearAndInit(); }).dimensions(x + w * 2 - 24, height - 28, 30, 20).build()).active = page + 1 < pages;
    }
    private void option(int option, int x, int y, int w) {
        Config c = mod.config;
        switch (option) {
            case 0 -> button(x, y, w, "Indicator style: " + c.indicatorStyle, () -> c.indicatorStyle = c.indicatorStyle.next());
            case 1 -> button(x, y, w, "Share my chat-open status: " + on(c.shareChatOpen), () -> c.shareChatOpen = !c.shareChatOpen);
            case 2 -> button(x, y, w, "Preview on myself (F5): " + on(c.hologramPreviewSelf), () -> c.hologramPreviewSelf = !c.hologramPreviewSelf);
            case 3 -> slider(x, y, w, c.hologramOpacity, 0, 100, "Opacity: %.0f%%", v -> c.hologramOpacity = (int) Math.round(v));
            case 4 -> slider(x, y, w, c.hologramSize, .25, 4, "Width: %.2f blocks", v -> c.hologramSize = v);
            case 5 -> slider(x, y, w, c.hologramDistance, .25, 4, "In front: %.2f blocks", v -> c.hologramDistance = v);
            case 6 -> slider(x, y, w, c.hologramHeightOffset, -2, 2, "Eye offset: %.2f blocks", v -> c.hologramHeightOffset = v);
            case 7 -> button(x, y, w, "Through walls: " + on(c.hologramThroughWalls), () -> c.hologramThroughWalls = !c.hologramThroughWalls);
            case 8 -> slider(x, y, w, c.hologramMaxDistance, 1, 256, "Max distance: %.0f blocks", v -> c.hologramMaxDistance = (int) Math.round(v));
            case 9 -> button(x, y, w, "Scale with distance: " + on(c.hologramScaleWithDistance), () -> c.hologramScaleWithDistance = !c.hologramScaleWithDistance);
            case 10 -> slider(x, y, w, c.hologramScaleFactor * 100, 0, 5, "Scale strength: %.2f%%/block", v -> c.hologramScaleFactor = v / 100);
            case 11 -> slider(x, y, w, c.hologramMaxScale, 1, 6, "Max scale: %.2fx", v -> c.hologramMaxScale = v);
            case 12 -> slider(x, y, w, c.chatOpenTimeoutMs / 1000.0, 1, 3600, "Failsafe: %.0f seconds", v -> c.chatOpenTimeoutMs = (int) Math.round(v * 1000));
            case 13 -> slider(x, y, w, c.chatBubbleSize, .25, 4, "Legacy bubble size: %.2fx", v -> c.chatBubbleSize = v);
            default -> throw new IllegalArgumentException("Unknown presence setting");
        }
    }
    private static String on(boolean value) { return value ? "ON" : "OFF"; }
    private void button(int x, int y, int w, String label, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> { action.run(); mod.touch(); clearAndInit(); }).dimensions(x, y, w, 20).build());
    }
    private void slider(int x, int y, int w, double current, double min, double max, String format, DoubleConsumer save) {
        addDrawableChild(new ValueSlider(x, y, w, current, min, max, format, save));
    }
    @Override public void removed() { mod.saveConfig(); }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
    private final class ValueSlider extends SliderWidget {
        private final double min, max;
        private final String format;
        private final DoubleConsumer save;
        ValueSlider(int x, int y, int w, double current, double min, double max, String format, DoubleConsumer save) {
            super(x, y, w, 20, Text.empty(), Math.max(0, Math.min(1, (current - min) / (max - min))));
            this.min = min; this.max = max; this.format = format; this.save = save; updateMessage();
        }
        @Override protected void updateMessage() { setMessage(Text.literal(String.format(Locale.ROOT, format, min + value * (max - min)))); }
        @Override protected void applyValue() { save.accept(min + value * (max - min)); mod.touch(); }
    }
}
