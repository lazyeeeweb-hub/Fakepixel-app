package dev.friendlink.ui;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Pure helpers. Call when rebuilding/ticking, not from the render loop. */
public final class SocialFormat {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MMM d", Locale.ENGLISH);
    private static final DateTimeFormatter OLD_DATE = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH);
    private SocialFormat() {}
    public static String clock(long time, ZoneId zone) { return CLOCK.format(Instant.ofEpochMilli(time).atZone(zone)); }
    public static String date(long time, long now, ZoneId zone) {
        var value = Instant.ofEpochMilli(time).atZone(zone);
        int year = Instant.ofEpochMilli(now).atZone(zone).getYear();
        return (value.getYear() == year ? DATE : OLD_DATE).format(value);
    }
    public static String activity(long time, long now, ZoneId zone) {
        if (time <= 0) return "";
        LocalDate day = Instant.ofEpochMilli(time).atZone(zone).toLocalDate();
        LocalDate today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        if (day.equals(today)) return clock(time, zone);
        if (day.equals(today.minusDays(1))) return "Yesterday";
        return date(time, now, zone);
    }
    public static String preview(String sender, String text, boolean system) {
        if (text == null) return "";
        String oneLine = text.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
        if (oneLine.length() > 160) oneLine = oneLine.substring(0, 160);
        return system || sender == null || sender.isEmpty() ? oneLine : sender + ": " + oneLine;
    }
    public static double clampScroll(double value, int content, int viewport) {
        return Math.max(0, Math.min(Math.max(0, content - viewport), value));
    }
}
