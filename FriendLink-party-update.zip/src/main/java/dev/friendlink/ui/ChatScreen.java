package dev.friendlink.ui;

import dev.friendlink.ConversationSelection;
import dev.friendlink.Faces;
import dev.friendlink.FriendLink;
import dev.friendlink.GlowStyle;
import dev.friendlink.Models.*;
import dev.friendlink.PartyService;
import dev.friendlink.Protocol;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Client-only social window. Layout, wrapping, dates, skin lookups and labels are cached in tick/init.
 * render() only draws prepared data and interpolates primitive scroll values: no new render-loop objects.
 */
public final class ChatScreen extends Screen {
    private static final int ROW = 46, FRIEND_ROW = 73, BLUE = 0xFF539FF5, DIM = 0xFF8793A5;
    private static final OrderedText SOCIAL = text("Social"), CHAT = text("Chat"), FRIENDS = text("Friends"),
        EMPTY = text("No conversations"), SEARCH_EMPTY = text("No matches"), SELECT = text("Select a friend or group"),
        GLOW = text("Glow"), CROSS = text("x"), GROUP = text("#"),
        LOADING = text("Loading conversation..."), OFFLINE = text("Offline"), ONLINE = text("Online"),
        QUEUED_HINT = text("Queued"), SENT_HINT = text("Sent / pending"), DELIVERED_HINT = text("Delivered"),
        READ_HINT = text("Read"), FAILED_HINT = text("Left-click: retry | Right-click: details"),
        GROUP_HINT = text("Click for per-member delivery details"), UI_SCALE = text("FriendLink UI scale");
    private static final OrderedText PARTY_PLUS = text("+");
    private static final int PARTY_CONTROLS_Y = 49;
    private static final Comparator<Row> RECENT = Comparator.comparingLong((Row r) -> r.activity).reversed()
        .thenComparing(r -> r.name, String.CASE_INSENSITIVE_ORDER).thenComparing(r -> r.key);
    private static final Comparator<Row> NAMES = Comparator.comparing((Row r) -> r.name, String.CASE_INSENSITIVE_ORDER);
    private final FriendLink mod = FriendLink.INSTANCE;
    private final Screen parent;
    private final ZoneId zone = ZoneId.systemDefault();
    private final List<Row> rows = new ArrayList<>();
    private final List<Bubble> bubbles = new ArrayList<>();
    private final List<SocialButton> buttons = new ArrayList<>();
    private final Set<String> summaryRequests = new HashSet<>();
    private String selected, draft = "", filter = "";
    private OrderedText heading = SELECT, error = text("");
    private boolean transientScreen, ready, friendsTab, searching, snapMessages = true, scaleMenuOpen;
    private double uiScale = 1;
    private int virtualWidth, virtualHeight, appliedScalePercent, appliedSidebarPercent;
    private boolean appliedAuto;
    private int menuX, menuY, menuWidth;
    private OrderedText scaleLabel = text("100%");
    private List<OrderedText> styleHint = Collections.emptyList();
    private final List<SocialButton> menuButtons = new ArrayList<>();
    private SocialButton scaleDown, scaleUp, scaleAuto, conversationOptions;
    private int draggingScrollbar; // 0 = none, 1 = sidebar, 2 = messages
    private double scrollbarGrab;
    private long selectionGeneration, cachedVersion = -1, nextRefresh, lastFrame;
    private int left, right, panelTop, panelBottom, split, listTop, listBottom, messageTop, messageBottom, contentHeight;
    private double sidebarScroll, sidebarTarget, messageScroll, messageTarget;
    private TextFieldWidget input, search;
    private SocialButton send, glowButton, manage, glowAll, unglowAll, cfg, view, back, bringAll;
    private final PartyInviteCard partyCard = new PartyInviteCard();
    private PartyService.Invite partyInvite;
    private long locationsVersion = -1;
    private GlowStyleDropdown styleMenu;
    private Friend styleTarget;
    private Row activeRow;

    private static final class Row {
        String key, name;
        Friend friend;
        Group group;
        Identifier[] faces;
        long activity;
        OrderedText title, preview, time, badge, style, location;
        boolean locationOffline;
        int timeWidth, badgeWidth;
        boolean online;
    }
    private static final class Bubble {
        Message message;
        Identifier face;
        List<OrderedText> lines, hintLines;
        OrderedText stamp, date, hint;
        boolean outbound, system;
        int y, height, width, textWidth, stage, dateWidth, hintWidth;
    }
    private static OrderedText text(String value) { return Text.literal(value).asOrderedText(); }
    public ChatScreen(String selected) { this(selected, null); }
    public ChatScreen(String selected, Screen parent) {
        super(Text.literal("FriendLink")); this.parent = parent;
        this.selected = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
    }
    public String conversation() { return selected; }

    // Screen init/reinit retains the caller, draft, selection, filters and logical presence session.
    @Override protected void init() {
        boolean firstLayout = input == null;
        boolean inputFocused = firstLayout || input.isFocused(), searchFocused = search != null && search.isFocused();
        if (input != null) draft = input.getText();
        String choice = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
        boolean selectionChanged = !Objects.equals(choice, selected); selected = choice;
        appliedScalePercent = mod.config.friendLinkUiScale; appliedAuto = mod.config.friendLinkUiAutoScale;
        appliedSidebarPercent = mod.config.sidebarWidthPercent;
        uiScale = SocialLayout.scale(width, height, appliedScalePercent, appliedAuto);
        virtualWidth = SocialLayout.virtualExtent(width, uiScale); virtualHeight = SocialLayout.virtualExtent(height, uiScale);
        int w = SocialLayout.panelExtent(virtualWidth, SocialLayout.FIT_WIDTH, 720, .85);
        int h = SocialLayout.panelExtent(virtualHeight, SocialLayout.FIT_HEIGHT, 480, .75);
        left = (virtualWidth - w) / 2; right = left + w; panelTop = (virtualHeight - h) / 2; panelBottom = panelTop + h;
        int side = SocialLayout.sidebarWidth(w, appliedSidebarPercent);
        split = left + side; listTop = panelTop + 56; listBottom = panelBottom - 28;
        messageTop = panelTop + 38; messageBottom = panelBottom - 37;
        buttons.clear(); menuButtons.clear(); draggingScrollbar = 0;
        int icon = Math.max(14, Math.min(18, side * 18 / 150)), gap = 2;
        int iconsX = split - 4 - 3 * icon - 2 * gap;
        headerIcon(iconsX, icon, "+", () -> openSubscreen(new PromptScreen(this,
            "Add friend (Java username)", "", mod::addFriend))).accent(true);
        headerIcon(iconsX + icon + gap, icon, "#", () -> openSubscreen(new GroupScreen(this, null)));
        headerIcon(iconsX + (icon + gap) * 2, icon, "?", () -> {
            searching = !searching; search.setVisible(searching);
            search.setFocused(searching); setFocused(searching ? search : input);
            if (!searching) { filter = ""; search.setText(""); }
            sidebarTarget = sidebarScroll = 0; refresh();
        });
        // Composer row: both controls are 18px tall with 3px inset inside the same 24px bar.
        int sendWidth = 24, controlY = panelBottom - 26, sendX = right - 9 - sendWidth;
        if (input == null) {
            input = new TextFieldWidget(textRenderer, split + 11, controlY, 16, 18, Text.literal("Message"));
            input.setMaxLength(4096); input.setDrawsBackground(false); input.setText(draft);
        }
        // Reuse the field on live zoom: draft, selection, horizontal text scroll and caret are retained.
        input.setX(split + 11); input.setY(controlY); input.setWidth(Math.max(8, sendX - input.getX() - 4));
        addDrawableChild(input);
        send = button(sendX, controlY, sendWidth, ">", this::send).accent(true);
        glowButton = button(right - 75, panelTop + 9, 43, "Glow", this::toggleGlow).accent(true);
        manage = button(right - 26, panelTop + 9, 18, "≡", () -> {
            scaleMenuOpen = !scaleMenuOpen; updateScaleMenu();
        });
        menuWidth = Math.max(100, Math.min(208, w - 8)); menuX = right - menuWidth - 4;
        menuY = Math.max(panelTop + 2, Math.min(panelTop + 32, panelBottom - 92));
        scaleDown = menuButton(menuX + 6, menuY + 20, 20, "-", () -> changeScale(-5));
        scaleUp = menuButton(menuX + menuWidth - 26, menuY + 20, 20, "+", () -> changeScale(5));
        scaleAuto = menuButton(menuX + 6, menuY + 42, menuWidth - 12, "Auto (fit screen)", () -> {
            mod.config.friendLinkUiAutoScale = !mod.config.friendLinkUiAutoScale; saveUiLayout();
        });
        conversationOptions = menuButton(menuX + 6, menuY + 64, menuWidth - 12, "Conversation options", () -> {
            if (selected != null) openSubscreen(new ConversationOptionsScreen(this, selected));
        });
        scaleLabel = text((int) Math.round(uiScale * 100) + "%");
        updateScaleMenu();
        bringAll = button(left + 6, panelTop + 57, Math.min(78, side - 12), "Bring All", mod.party::warp);
        bringAll.visible = false;
        glowAll = button(left + 6, panelBottom - 24, Math.max(24, (side - 16) / 2), "Glow all", () -> { mod.setAllGlow(true); refresh(); });
        unglowAll = button(left + 10 + (side - 16) / 2, panelBottom - 24, Math.max(24, (side - 16) / 2), "Unglow all", () -> { mod.setAllGlow(false); refresh(); });
        int footerWidth = Math.max(20, (side - 24) / 3);
        cfg = button(left + 6, panelBottom - 24, footerWidth, "Cfg", () -> { transientScreen = true; mod.openConfig(this); });
        view = button(left + 12 + footerWidth, panelBottom - 24, footerWidth, "View", () -> openSubscreen(new ViewSettingsScreen(this)));
        back = button(left + 18 + footerWidth * 2, panelBottom - 24, footerWidth, "Back", this::close);
        if (search == null) {
            search = new TextFieldWidget(textRenderer, left + 7, panelTop + 34, Math.max(20, side - 14), 18, Text.literal("Search conversations"));
            search.setMaxLength(64); search.setPlaceholder(Text.literal("Search...")); search.setText(filter);
        }
        search.setX(left + 7); search.setY(panelTop + 34); search.setWidth(Math.max(20, side - 14));
        search.setChangedListener(value -> { filter = value.toLowerCase(Locale.ROOT); sidebarScroll = sidebarTarget = 0; refresh(); });
        search.setVisible(searching); addDrawableChild(search);
        styleMenu = addDrawableChild(new GlowStyleDropdown(left + 5, listTop, Math.max(50, side - 10), value -> {
            if (styleTarget != null) { styleTarget.glowStyle = value; mod.touch(); }
            styleMenu.visible = false; refresh();
        }));
        styleMenu.visible = false;
        // Screen's deferred vanilla tooltip renderer runs after our matrix is popped. Draw this hint
        // locally instead, so its text, position and viewport clamping use the same virtual space.
        styleMenu.setTooltip(null);
        styleHint = textRenderer.wrapLines(Text.literal("Glow style. Default follows the global style. Marker is the shader-pack fallback."), Math.max(40, Math.min(210, virtualWidth - 20)));
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(true);
        mod.skins.request(mod.self());
        if (firstLayout || selectionChanged) select(selected); else refresh();
        setFocused(searchFocused && searching ? search : inputFocused ? input : null);
    }
    private SocialButton button(int x, int y, int w, String label, Runnable action) {
        SocialButton button = addDrawableChild(new SocialButton(x, y, w, 18, label, action));
        buttons.add(button); return button;
    }
    private SocialButton headerIcon(int x, int size, String label, Runnable action) {
        SocialButton b = addDrawableChild(new SocialButton(x, panelTop + 8 + (18 - size) / 2, size, size, label, action));
        buttons.add(b); return b;
    }
    private SocialButton menuButton(int x, int y, int width, String label, Runnable action) {
        SocialButton b = addDrawableChild(new SocialButton(x, y, width, 18, label, action));
        menuButtons.add(b); return b;
    }
    private void updateScaleMenu() {
        for (SocialButton b : menuButtons) b.visible = scaleMenuOpen;
        if (scaleDown == null) return;
        int percent = (int) Math.round(uiScale * 100);
        scaleDown.active = percent > 50; scaleUp.active = percent < 150;
        scaleAuto.accent(mod.config.friendLinkUiAutoScale);
        conversationOptions.active = selected != null;
    }
    private void changeScale(int delta) {
        mod.config.friendLinkUiScale = SocialLayout.snapPercent((int) Math.round(uiScale * 100) + delta);
        mod.config.friendLinkUiAutoScale = false; saveUiLayout();
    }
    /** Local relayout hook: never touches GameOptions.guiScale or the window's global scale. */
    private void saveUiLayout() { mod.saveConfig(); rebuildUiLayout(); }
    private void rebuildUiLayout() {
        boolean focusInput = input != null && input.isFocused(), focusSearch = search != null && search.isFocused();
        clearChildren(); init();
        if (focusSearch && searching) setFocused(search);
        else if (focusInput) setFocused(input);
    }
    @Override public void tick() {
        if (appliedScalePercent != mod.config.friendLinkUiScale || appliedAuto != mod.config.friendLinkUiAutoScale
            || appliedSidebarPercent != mod.config.sidebarWidthPercent) rebuildUiLayout();
        input.tick(); if (searching) search.tick();
        if (ready) mod.read(selected);
        long now = System.currentTimeMillis();
        if (cachedVersion != mod.version || locationsVersion != mod.party.locationsVersion()
            || partyInvite != visiblePartyInvite() || bringAll.visible != (friendsTab && mod.party.isLeader())
            || now >= nextRefresh) {
            String choice = ConversationSelection.choose(mod.state, selected, mod.config.reopenLastConversation);
            if (!Objects.equals(choice, selected)) select(choice); else refresh();
            nextRefresh = now + 1000;
        }
    }
    private void select(String key) {
        selected = key; ready = key == null; snapMessages = true; messageScroll = messageTarget = 0;
        error = text(""); long generation = ++selectionGeneration; refresh();
        if (key == null) return;
        mod.ensureConversation(key, () -> {
            if (generation != selectionGeneration || !key.equals(selected)) return;
            ready = true; snapMessages = true;
            if (client.currentScreen == this) { mod.read(key); refresh(); setFocused(input); input.setFocused(true); }
        }).exceptionally(failure -> {
            client.execute(() -> { if (generation == selectionGeneration) error = text("Could not load chat log; reopen to retry."); });
            return null;
        });
    }
    private void openSubscreen(Screen screen) { transientScreen = true; client.setScreen(screen); }
    @Override public void removed() {
        draft = input == null ? draft : input.getText();
        if (!transientScreen && mod.presence != null) mod.presence.screenOpen(false);
        super.removed();
    }
    @Override public void close() {
        transientScreen = false;
        if (mod.presence != null) mod.presence.screenOpen(false);
        client.setScreen(parent);
    }
    private void toggleGlow() {
        if (activeRow != null && activeRow.friend != null) activeRow.friend.glow = !activeRow.friend.glow;
        else if (activeRow != null && activeRow.group != null) {
            boolean enable = !groupGlow(activeRow.group);
            for (int i = 0; i < activeRow.group.members.size(); i++) {
                Friend f = mod.friend(activeRow.group.members.get(i)); if (f != null) f.glow = enable;
            }
        } else { mod.config.glowEnabled = !mod.config.glowEnabled; mod.saveConfig(); }
        mod.touch(); refresh();
    }
    private boolean groupGlow(Group group) {
        boolean any = false;
        for (int i = 0; i < group.members.size(); i++) {
            Friend friend = mod.friend(group.members.get(i));
            if (friend != null) { any = true; if (!friend.glow) return false; }
        }
        return any;
    }
    private void refresh() {
        if (input == null) return;
        bringAll.visible = friendsTab && mod.party.isLeader();
        listTop = panelTop + 56 + (bringAll.visible ? 22 : 0);
        PartyService.Invite newInvite = visiblePartyInvite();
        if (partyInvite != newInvite) partyCard.clear();
        partyInvite = newInvite;
        messageTop = panelTop + 38 + (partyInvite == null ? 0 : PartyInviteCard.HEIGHT + 3);
        locationsVersion = mod.party.locationsVersion();
        rows.clear(); activeRow = null;
        long now = System.currentTimeMillis();
        for (Friend f : mod.state.friends.values()) {
            Row row = row("f:" + Protocol.key(f.name), f.name, f.lastActivity, f.lastPreview, f.messages, f.unread, now);
            row.friend = f; row.faces = new Identifier[] { mod.skins.face(f.name) };
            row.online = client.getNetworkHandler() != null && client.getNetworkHandler().getPlayerListEntry(f.name) != null;
            row.style = text(textRenderer.trimToWidth((f.glowStyle == null ? GlowStyle.DEFAULT : f.glowStyle).name().toLowerCase(Locale.ROOT), Math.max(20, split - left - 87)));
            if (friendsTab) {
                String location = mod.party.location(f.name);
                if (location != null) {
                    row.location = text(ellipsis(location, split - left - 48));
                    row.locationOffline = "Offline".equals(location);
                }
            }
            if (!f.logLoaded) summary(row, f);
            addRow(row);
        }
        for (Group g : mod.state.groups.values()) {
            if (g.left) continue;
            Row row = row("g:" + g.id, g.name, g.lastActivity, g.lastPreview, g.messages, g.unread, now);
            row.group = g; row.faces = new Identifier[Math.min(4, g.members.size())];
            for (int i = 0; i < row.faces.length; i++) row.faces[i] = mod.skins.face(g.members.get(i));
            if (!g.logLoaded) summary(row, g);
            addRow(row);
        }
        rows.sort(friendsTab ? NAMES : RECENT);
        mod.rememberConversation(selected);
        int headingSpace = right - split - (right - split >= 150 ? 118 : 91);
        heading = text(ellipsis(activeRow == null ? "Select a friend or group" : activeRow.name, headingSpace));
        boolean enabled = activeRow == null ? mod.config.glowEnabled : activeRow.friend != null
            ? activeRow.friend.glow : groupGlow(activeRow.group);
        glowButton.label(enabled ? "Glow ✓" : "Glow"); glowButton.accent(enabled);
        manage.active = true; updateScaleMenu();
        send.active = ready && activeRow != null && (activeRow.group == null || !activeRow.group.pending);
        input.setEditable(send.active);
        input.setPlaceholder(Text.literal(activeRow == null ? "Select a conversation" : "Message " + activeRow.name));
        glowAll.visible = unglowAll.visible = friendsTab;
        cfg.visible = view.visible = back.visible = !friendsTab;
        sidebarTarget = SocialFormat.clampScroll(sidebarTarget, rows.size() * rowHeight(), listBottom - listTop);
        sidebarScroll = SocialFormat.clampScroll(sidebarScroll, rows.size() * rowHeight(), listBottom - listTop);
        layoutMessages(now);
        cachedVersion = mod.version;
    }
    private Row row(String key, String name, long activity, String preview, List<Message> messages, int unread, long now) {
        Row row = new Row(); row.key = key; row.name = name; row.activity = activity;
        if (messages != null && !messages.isEmpty()) {
            Message last = messages.get(messages.size() - 1); row.activity = Math.max(activity, last.time);
            preview = SocialFormat.preview(last.sender, last.text, last.system);
        }
        String time = SocialFormat.activity(row.activity, now, zone); row.time = text(time); row.timeWidth = textRenderer.getWidth(row.time) * 3 / 4;
        row.badge = unread <= 0 ? null : text(unread > 99 ? "99+" : Integer.toString(unread));
        row.badgeWidth = row.badge == null || !mod.config.unreadFriendBadges ? 0 : Math.max(12, textRenderer.getWidth(row.badge) + 6);
        row.title = text(ellipsis(name, split - left - 50 - (friendsTab ? 18 : row.timeWidth)));
        row.preview = text(ellipsis(preview == null || preview.isEmpty() ? "No messages yet" : preview,
            split - left - 49 - (row.badgeWidth == 0 ? 0 : row.badgeWidth + 3)));
        return row;
    }
    public boolean hasRoomForPartyCard() {
        return right - split - 16 >= PartyInviteCard.MIN_WIDTH && messageBottom >= panelTop + 61;
    }
    private PartyService.Invite visiblePartyInvite() { return hasRoomForPartyCard() ? mod.party.invitation() : null; }
    private String ellipsis(String value, int available) {
        if (available <= 0) return "";
        if (textRenderer.getWidth(value) <= available) return value;
        String suffix = "…";
        if (textRenderer.getWidth(suffix) > available) return "";
        return textRenderer.trimToWidth(value, available - textRenderer.getWidth(suffix)) + suffix;
    }
    private void addRow(Row row) {
        if (row.key.equals(selected)) activeRow = row;
        if ((!friendsTab || row.friend != null) && row.name.toLowerCase(Locale.ROOT).contains(filter)) rows.add(row);
    }
    /** Backfill legacy metadata on the ordered IO worker without publishing/marking a whole log read. */
    private void summary(Row row, Object owner) {
        String preview = owner instanceof Friend f ? f.lastPreview : ((Group) owner).lastPreview;
        if (preview != null && !preview.isEmpty() || !summaryRequests.add(row.key)) return;
        long expected = row.activity;
        mod.storage.loadLogAsync(row.key, 1).whenComplete((messages, failure) -> client.execute(() -> {
            if (failure != null) { FriendLink.LOG.warn("Could not read sidebar summary for {}", row.key, failure); return; }
            if (messages.isEmpty()) return;
            Object current = row.key.startsWith("f:") ? mod.state.friends.get(row.key.substring(2)) : mod.state.groups.get(row.key.substring(2));
            if (owner != current) return;
            if (owner instanceof Friend f && f.logLoaded && f.messages.isEmpty()) return;
            if (owner instanceof Group g && g.logLoaded && g.messages.isEmpty()) return;
            Message last = messages.get(messages.size() - 1);
            String value = SocialFormat.preview(last.sender, last.text, last.system);
            if (owner instanceof Friend f && f.lastActivity == expected) { f.lastPreview = value; f.lastActivity = Math.max(f.lastActivity, last.time); mod.touch(); }
            else if (owner instanceof Group g && g.lastActivity == expected) { g.lastPreview = value; g.lastActivity = Math.max(g.lastActivity, last.time); mod.touch(); }
        }));
    }
    private void layoutMessages(long now) {
        int previous = contentHeight; contentHeight = 0; bubbles.clear();
        List<Message> messages = ready ? mod.messages(selected) : Collections.emptyList();
        long previousDay = Long.MIN_VALUE;
        int chatWidth = right - split - 20;
        int maxWidth = Math.max(24, Math.min(chatWidth * 70 / 100, chatWidth - 24));
        for (int i = 0; i < messages.size(); i++) {
            Message message = messages.get(i); Bubble b = new Bubble(); b.message = message;
            long day = java.time.Instant.ofEpochMilli(message.time).atZone(zone).toLocalDate().toEpochDay();
            if (day != previousDay) {
                b.date = text(SocialFormat.date(message.time, now, zone)); b.dateWidth = textRenderer.getWidth(b.date);
                contentHeight += 23; previousDay = day;
            }
            b.outbound = !message.system && message.sender.equalsIgnoreCase(mod.self()); b.system = message.system;
            b.stage = b.outbound ? Math.max(0, Math.min(4, message.stage())) : -1;
            b.stamp = text(ellipsis((activeRow != null && activeRow.group != null && !b.outbound && !b.system ? message.sender + " · " : "")
                + SocialFormat.clock(message.time, zone), maxWidth * 4 / 3 - 4));
            if (!b.system) {
                mod.skins.request(message.sender);
                b.face = b.outbound && client.player != null ? client.player.getSkinTexture() : mod.skins.face(message.sender);
            }
            b.lines = textRenderer.wrapLines(Text.literal(message.text), Math.max(8, maxWidth - 14));
            b.textWidth = 0; for (int j = 0; j < b.lines.size(); j++) b.textWidth = Math.max(b.textWidth, textRenderer.getWidth(b.lines.get(j)));
            b.width = Math.min(maxWidth, Math.max(b.outbound ? 35 : 20,
                Math.max(b.textWidth + 14, textRenderer.getWidth(b.stamp) * 3 / 4 + 4)));
            b.height = b.lines.size() * 11 + (b.outbound ? 19 : 12); b.y = contentHeight;
            b.hint = b.stage == 4 ? FAILED_HINT : selected != null && selected.startsWith("g:") ? GROUP_HINT
                : b.stage == 0 ? QUEUED_HINT : b.stage == 1 ? SENT_HINT : b.stage == 2 ? DELIVERED_HINT : READ_HINT;
            b.hintLines = textRenderer.wrapLines(Text.literal(b.stage == 4 ? "Left-click: retry | Right-click: details"
                : selected != null && selected.startsWith("g:") ? "Click for per-member delivery details"
                : b.stage == 0 ? "Queued" : b.stage == 1 ? "Sent / pending" : b.stage == 2 ? "Delivered" : "Read"),
                Math.max(24, virtualWidth - 16));
            b.hintWidth = 0;
            for (OrderedText line : b.hintLines) b.hintWidth = Math.max(b.hintWidth, textRenderer.getWidth(line));
            bubbles.add(b); contentHeight += b.height + 21;
        }
        if (snapMessages) { messageScroll = messageTarget = 0; snapMessages = false; }
        else if (messageTarget > 2 && contentHeight > previous) { messageTarget += contentHeight - previous; messageScroll += contentHeight - previous; }
        messageTarget = SocialFormat.clampScroll(messageTarget, contentHeight, messageBottom - messageTop);
        messageScroll = SocialFormat.clampScroll(messageScroll, contentHeight, messageBottom - messageTop);
    }
    private int rowHeight() { return friendsTab ? FRIEND_ROW : ROW; }
    private void send() {
        if (!send.active) return;
        String result = mod.send(selected, input.getText());
        if (result == null) { input.setText(""); draft = ""; error = text(""); snapMessages = true; refresh(); }
        else error = text(textRenderer.trimToWidth(result, Math.max(12, right - split - 12)));
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE && scaleMenuOpen) { scaleMenuOpen = false; updateScaleMenu(); return true; }
        if (styleMenu.visible && styleMenu.isFocused() && styleMenu.keyPressed(key, scan, modifiers)) return true;
        if (key == GLFW.GLFW_KEY_ESCAPE && styleMenu.visible) { styleMenu.dismiss(); styleMenu.visible = false; return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && input.isFocused() && send.active) { send(); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP || key == GLFW.GLFW_KEY_PAGE_DOWN) {
            messageTarget = SocialFormat.clampScroll(messageTarget + (key == GLFW.GLFW_KEY_PAGE_UP ? 1 : -1)
                * Math.max(1, messageBottom - messageTop - 16), contentHeight, messageBottom - messageTop); return true;
        }
        return super.keyPressed(key, scan, modifiers);
    }
    @Override public boolean mouseScrolled(double x, double y, double amount) {
        x /= uiScale; y /= uiScale;
        if (scaleMenuOpen && inside(x, y, menuX, menuY, menuX + menuWidth, menuY + 88)) return true;
        if (inside(x, y, left, listTop, split, listBottom)) {
            sidebarTarget = SocialFormat.clampScroll(sidebarTarget - amount * rowHeight(), rows.size() * rowHeight(), listBottom - listTop); return true;
        }
        if (inside(x, y, split, messageTop, right, messageBottom)) {
            messageTarget = SocialFormat.clampScroll(messageTarget + amount * 32, contentHeight, messageBottom - messageTop); return true;
        }
        return super.mouseScrolled(x, y, amount);
    }
    private static boolean inside(double x, double y, int l, int t, int r, int b) { return x >= l && x < r && y >= t && y < b; }
    @Override public boolean mouseClicked(double x, double y, int button) {
        x /= uiScale; y /= uiScale;
        if (scaleMenuOpen) {
            if (inside(x, y, menuX, menuY, menuX + menuWidth, menuY + 88)) {
                // Modal popup hook: consume its empty background as well as its widgets.
                for (SocialButton b : menuButtons) if (b.mouseClicked(x, y, button)) return true;
                return true;
            }
            scaleMenuOpen = false; updateScaleMenu();
            if (manage.isMouseOver(x, y)) return true;
        }
        if (styleMenu.visible) {
            if (styleMenu.menuClick(x, y, button)) return true;
            styleMenu.visible = false;
        }
        if (button == 0 && partyCard.click(mod.party, x, y)) { refresh(); return true; }
        if (button == 0 && beginScrollbarDrag(x, y)) return true;
        if (!searching && button == 0 && inside(x, y, left, panelTop + 33, split, panelTop + 54)) {
            friendsTab = x >= left + (split - left) / 2; sidebarScroll = sidebarTarget = 0; refresh(); return true;
        }
        if (inside(x, y, left, listTop, split, listBottom)) {
            int index = ((int) y - listTop + (int) sidebarScroll) / rowHeight();
            if (index >= 0 && index < rows.size()) {
                Row row = rows.get(index); int rowY = listTop + index * rowHeight() - (int) sidebarScroll;
                if (button == 1) { openSubscreen(new ConversationOptionsScreen(this, row.key)); return true; }
                if (button == 0 && friendsTab && inside(x, y, split - 25, rowY + 3, split - 8, rowY + 16)) {
                    mod.party.invite(row.friend.name); return true;
                }
                if (button == 0 && friendsTab && y >= rowY + PARTY_CONTROLS_Y - 3) {
                    if (x < left + 39) { row.friend.glow = !row.friend.glow; mod.touch(); refresh(); }
                    else if (x < left + 58) openSubscreen(new ColorScreen(this, row.friend));
                    else if (x >= split - 23) openSubscreen(removalScreen(this, row.key));
                    else {
                        styleTarget = row.friend; styleMenu.setX(left + 58);
                        styleMenu.setY(Math.max(panelTop, Math.min(rowY + PARTY_CONTROLS_Y - 1, panelBottom - 101)));
                        styleMenu.setWidth(Math.max(48, split - left - 64));
                        styleMenu.selection(row.friend.glowStyle, true); styleMenu.visible = true;
                        styleMenu.open(); setFocused(styleMenu); styleMenu.setFocused(true);
                    }
                } else if (button == 0) { select(row.key); setFocused(input); input.setFocused(true); }
                return true;
            }
        }
        if (inside(x, y, split, messageTop, right, messageBottom) && (button == 0 || button == 1)) {
            int offset = messageOffset();
            for (int i = 0; i < bubbles.size(); i++) {
                Bubble b = bubbles.get(i); if (!b.outbound) continue;
                int bx = bubbleX(b), by = messageTop + b.y + offset + 12;
                if (inside(x, y, bx + b.width - 21, by + b.height - 13, bx + b.width - 3, by + b.height)) {
                    if (selected.startsWith("g:") || button == 1) openSubscreen(new DeliveryScreen(this, selected, b.message, b.message.status()));
                    else if (b.stage == 4) { mod.retryMessage(selected, b.message); refresh(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(x, y, button);
    }
    /** Input boundary hooks: Minecraft supplies real GUI coordinates; children only see virtual ones. */
    @Override public void mouseMoved(double x, double y) { super.mouseMoved(x / uiScale, y / uiScale); }
    @Override public boolean isMouseOver(double x, double y) {
        return inside(x / uiScale, y / uiScale, left, panelTop, right, panelBottom);
    }
    @Override public boolean mouseReleased(double x, double y, int button) {
        draggingScrollbar = 0;
        for (SocialButton b : buttons) b.releasePress();
        for (SocialButton b : menuButtons) b.releasePress();
        return super.mouseReleased(x / uiScale, y / uiScale, button);
    }
    @Override public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        x /= uiScale; y /= uiScale;
        if (draggingScrollbar != 0 && button == 0) { dragScrollbar(y); return true; }
        return super.mouseDragged(x, y, button, dx / uiScale, dy / uiScale);
    }
    private boolean beginScrollbarDrag(double x, double y) {
        int which = inside(x, y, split - 6, listTop, split, listBottom) ? 1
            : inside(x, y, right - 6, messageTop, right, messageBottom) ? 2 : 0;
        if (which == 0) return false;
        int top = which == 1 ? listTop : messageTop, bottom = which == 1 ? listBottom : messageBottom;
        int content = which == 1 ? rows.size() * rowHeight() : contentHeight, viewport = bottom - top;
        if (viewport <= 0 || content <= viewport) return false;
        int thumb = Math.min(viewport, Math.max(8, viewport * viewport / content));
        double scroll = which == 1 ? sidebarScroll : content - viewport - messageScroll;
        double thumbY = top + (viewport - thumb) * scroll / (content - viewport);
        draggingScrollbar = which;
        scrollbarGrab = y >= thumbY && y < thumbY + thumb ? y - thumbY : thumb / 2.0;
        dragScrollbar(y); return true;
    }
    private void dragScrollbar(double y) {
        boolean side = draggingScrollbar == 1;
        int top = side ? listTop : messageTop, bottom = side ? listBottom : messageBottom;
        int content = side ? rows.size() * rowHeight() : contentHeight, viewport = bottom - top;
        if (viewport <= 0 || content <= viewport) return;
        int thumb = Math.min(viewport, Math.max(8, viewport * viewport / content));
        double position = Math.max(0, Math.min(1, (y - top - scrollbarGrab) / Math.max(1, viewport - thumb)));
        double scroll = position * (content - viewport);
        if (side) sidebarScroll = sidebarTarget = scroll;
        else messageScroll = messageTarget = content - viewport - scroll;
    }
    private int messageOffset() { return -Math.max(0, contentHeight - (messageBottom - messageTop)) + (int) messageScroll; }
    private int bubbleX(Bubble b) {
        return b.system ? split + (right - split - b.width) / 2
            : b.outbound ? right - b.width - 34 : split + 34;
    }
    private void small(DrawContext c, OrderedText value, int x, int y, int color) {
        c.getMatrices().push();
        c.getMatrices().scale(.75F, .75F, 1F);
        c.drawText(textRenderer, value, Math.round(x / .75F), Math.round(y / .75F), color, false);
        c.getMatrices().pop();
    }
    /** Yarn 1.20.1 DrawContext scissoring does NOT apply the MatrixStack: convert explicitly once.
     * DrawContext then performs Minecraft GUI -> framebuffer conversion, including the inverted Y axis.
     */
    private void clip(DrawContext c, int l, int t, int r, int b) {
        c.enableScissor((int) Math.floor(l * uiScale), (int) Math.floor(t * uiScale),
            (int) Math.ceil(r * uiScale), (int) Math.ceil(b * uiScale));
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        mouseX = (int) Math.floor(mouseX / uiScale); mouseY = (int) Math.floor(mouseY / uiScale);
        c.getMatrices().push();
        c.getMatrices().scale((float) uiScale, (float) uiScale, 1F);
        try {
            renderVirtual(c, mouseX, mouseY, delta);
        } finally {
            // Screen is rendered inside Minecraft's shared DrawContext; never leak our local transform.
            c.getMatrices().pop();
        }
    }
    private void renderVirtual(DrawContext c, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime(); double seconds = lastFrame == 0 ? 1 : Math.min(.1, (now - lastFrame) / 1_000_000_000D); lastFrame = now;
        double blend = 1 - Math.exp(-18 * seconds);
        sidebarScroll += (sidebarTarget - sidebarScroll) * blend; messageScroll += (messageTarget - messageScroll) * blend;
        c.fill(0, 0, virtualWidth, virtualHeight, 0xA6000000);
        c.fill(left - 2, panelTop - 2, right + 2, panelBottom + 2, 0xFF0C1017);
        c.fill(left, panelTop, split, panelBottom, 0xFF171D27); c.fill(split, panelTop, right, panelBottom, 0xFF111720);
        c.fill(split, panelTop, split + 1, panelBottom, 0xFF29313F);
        c.drawText(textRenderer, SOCIAL, left + 9, panelTop + 13, 0xFFF4F6FC, false);
        c.fill(split + 1, panelTop + 35, right, panelTop + 36, 0xFF28303D);
        if (!searching) {
            c.drawText(textRenderer, CHAT, left + 13, panelTop + 39, friendsTab ? DIM : BLUE, false);
            c.drawText(textRenderer, FRIENDS, left + (split - left) / 2 + 5, panelTop + 39, friendsTab ? BLUE : DIM, false);
            int tabX = friendsTab ? left + (split - left) / 2 : left;
            c.fill(tabX + 5, panelTop + 53, tabX + (split - left) / 2 - 5, panelTop + 55, BLUE);
        }
        if (activeRow != null && right - split >= 150) drawFace(c, activeRow, split + 9, panelTop + 8, 20);
        c.drawText(textRenderer, heading, split + (activeRow == null || right - split < 150 ? 9 : 36), panelTop + 14, 0xFFF1F4FA, false);
        renderRows(c, mouseX, mouseY); renderMessages(c, mouseX, mouseY);
        if (partyInvite != null && partyInvite == mod.party.invitation()) {
            partyCard.draw(c, textRenderer, partyInvite, split + 8, panelTop + 38, right - split - 16, mouseX, mouseY);
        } else partyCard.clear();
        c.fill(split + 7, panelBottom - 29, right - 6, panelBottom - 5, 0xFF222B38);
        for (int i = 0; i < buttons.size(); i++) { SocialButton b = buttons.get(i); if (b.visible) b.render(c, mouseX, mouseY, delta); }
        // Backgroundless TextFieldWidget draws its baseline at Y in 1.20.1. Center the whole
        // field render (including selection and blinking caret) inside the shared 18px control row.
        c.getMatrices().push(); c.getMatrices().translate(0, (18 - textRenderer.fontHeight) / 2F, 0);
        input.render(c, mouseX, mouseY, delta); c.getMatrices().pop();
        if (searching) search.render(c, mouseX, mouseY, delta);
        c.drawText(textRenderer, error, split + 8, panelBottom - 36, 0xFFFF697B, false);
        if (styleMenu.visible) {
            styleMenu.render(c, mouseX, mouseY, delta); styleMenu.renderMenu(c, mouseX, mouseY);
            if (styleMenu.isHovered()) renderStyleHint(c, mouseX, mouseY);
        }
        if (scaleMenuOpen) {
            c.fill(menuX - 1, menuY - 1, menuX + menuWidth + 1, menuY + 89, 0xFF53647B);
            c.fill(menuX, menuY, menuX + menuWidth, menuY + 88, 0xFF182130);
            c.drawCenteredTextWithShadow(textRenderer, UI_SCALE, menuX + menuWidth / 2, menuY + 6, 0xFFF1F4FA);
            c.drawCenteredTextWithShadow(textRenderer, scaleLabel, menuX + menuWidth / 2, menuY + 25, 0xFFF1F4FA);
            for (SocialButton b : menuButtons) if (b.visible) b.render(c, mouseX, mouseY, delta);
        }
    }
    private void renderStyleHint(DrawContext c, int mouseX, int mouseY) {
        int w = Math.min(220, virtualWidth - 6), h = styleHint.size() * 11 + 8;
        int x = Math.max(3, Math.min(mouseX + 8, virtualWidth - w - 3));
        int y = Math.max(2, Math.min(mouseY - h - 2, virtualHeight - h - 2));
        c.fill(x, y, x + w, y + h, 0xFF070D18);
        for (int i = 0; i < styleHint.size(); i++) c.drawText(textRenderer, styleHint.get(i), x + 5, y + 4 + i * 11, 0xFFE5EDFB, false);
    }
    private void renderRows(DrawContext c, int mouseX, int mouseY) {
        if (listBottom <= listTop) return;
        clip(c, left, listTop, split, listBottom);
        if (rows.isEmpty()) c.drawText(textRenderer, filter.isEmpty() ? EMPTY : SEARCH_EMPTY, left + 8, listTop + 10, DIM, false);
        for (int i = 0; i < rows.size(); i++) {
            int y = listTop + i * rowHeight() - (int) sidebarScroll; if (y + rowHeight() <= listTop || y >= listBottom) continue;
            Row row = rows.get(i); boolean chosen = row.key.equals(selected);
            if (chosen || inside(mouseX, mouseY, left, y, split, y + rowHeight()))
                c.fill(left + 3, y, split - 3, y + rowHeight() - 2, chosen ? 0xFF293950 : 0xFF222C3A);
            if (chosen) c.fill(left + 3, y, left + 5, y + rowHeight() - 2, BLUE);
            drawFace(c, row, left + 9, y + 5, 24);
            c.drawText(textRenderer, row.title, left + 39, y + 6, 0xFFEDF1F7, false);
            if (friendsTab) {
                c.fill(left + 28, y + 23, left + 34, y + 29, row.online ? 0xFF58D99C : 0xFF697586);
                small(c, row.online ? ONLINE : OFFLINE, left + 39, y + 18, row.online ? 0xFF58D99C : DIM);
                c.fill(split - 25, y + 3, split - 8, y + 16,
                    inside(mouseX, mouseY, split - 25, y + 3, split - 8, y + 16) ? 0xFF37608B : 0xFF27384D);
                c.drawText(textRenderer, PARTY_PLUS, split - 20, y + 5, 0xFFD8EDFF, false);
                c.drawText(textRenderer, row.preview, left + 39, y + 26, DIM, false);
                if (row.location != null) c.drawText(textRenderer, row.location, left + 39, y + 37,
                    row.locationOffline ? 0xFFAAAAAA : 0xFFFFAA00, false);
                int controls = y + PARTY_CONTROLS_Y;
                c.fill(left + 8, controls, left + 36, controls + 17, row.friend.glow ? 0xFF2879D5 : 0xFF313C4B);
                small(c, GLOW, left + 12, controls + 5, 0xFFF0F4FA);
                c.fill(left + 42, controls + 2, left + 54, controls + 15, 0xFF000000 | row.friend.color);
                c.fill(left + 59, controls, split - 25, controls + 17, 0xFF313C4B);
                small(c, row.style, left + 62, controls + 5, 0xFFE7EDF7);
                c.drawText(textRenderer, CROSS, split - 18, controls + 4, 0xFFFF7184, false);
            } else {
                small(c, row.time, split - row.timeWidth - 9, y + 7, DIM);
                c.drawText(textRenderer, row.preview, left + 39, y + 22, DIM, false);
            }
            if (row.badge != null && mod.config.unreadFriendBadges) {
                int by = friendsTab ? y + 17 : y + 23, bx = split - row.badgeWidth - 8;
                c.fill(bx, by, split - 8, by + 13, 0xFFD5475E);
                c.drawText(textRenderer, row.badge, bx + 3, by + 3, 0xFFFFFFFF, false);
            }
        }
        c.disableScissor(); scrollbar(c, split - 2, listTop, listBottom, rows.size() * rowHeight(), sidebarScroll);
    }
    private void drawFace(DrawContext c, Row row, int x, int y, int size) {
        if (row.faces.length == 1) Faces.draw(c, row.faces[0], x, y, size);
        else if (row.faces.length == 0) { c.fill(x, y, x + size, y + size, 0xFF344760); c.drawText(textRenderer, GROUP, x + 8, y + 7, 0xFFDBE9FF, false); }
        else for (int i = 0; i < row.faces.length; i++) Faces.draw(c, row.faces[i], x + i % 2 * (size / 2), y + i / 2 * (size / 2), size / 2);
    }
    private void renderMessages(DrawContext c, int mouseX, int mouseY) {
        if (messageBottom <= messageTop) return;
        clip(c, split + 1, messageTop, right, messageBottom);
        if (!ready) c.drawText(textRenderer, LOADING, split + 10, messageTop + 12, DIM, false);
        int offset = messageOffset(); Bubble hovered = null;
        for (int i = 0; i < bubbles.size(); i++) {
            Bubble b = bubbles.get(i); int y = messageTop + b.y + offset;
            if (y + b.height + 21 < messageTop || y - 23 >= messageBottom) continue;
            if (b.date != null) {
                int center = (split + right) / 2, dy = y - 14;
                c.fill(split + 13, dy + 4, center - b.dateWidth / 2 - 9, dy + 5, 0xFF2C3645);
                c.fill(center + b.dateWidth / 2 + 9, dy + 4, right - 13, dy + 5, 0xFF2C3645);
                c.drawText(textRenderer, b.date, center - b.dateWidth / 2, dy, DIM, false);
            }
            int x = bubbleX(b); small(c, b.stamp, x + 2, y + 3, DIM); y += 12;
            if (!b.system) Faces.draw(c, b.face, b.outbound ? x + b.width + 6 : x - 24, y + 2, 18);
            int color = b.system ? 0xFF1C2532 : b.outbound ? 0xFF235CA4 : 0xFF29323F;
            // Keep the old compact padding with one-pixel clipped corners and a head alongside.
            c.fill(x + 1, y, x + b.width - 1, y + b.height, color);
            c.fill(x, y + 1, x + b.width, y + b.height - 1, color);
            for (int j = 0; j < b.lines.size(); j++) c.drawText(textRenderer, b.lines.get(j), x + 7, y + 6 + j * 11, b.system ? DIM : 0xFFF2F5FC, false);
            if (b.outbound) {
                int rx = x + b.width - 19, ry = y + b.height - 12; receipt(c, rx, ry, b.stage);
                if (inside(mouseX, mouseY, rx - 2, ry - 1, rx + 17, ry + 12)) hovered = b;
            }
        }
        c.disableScissor();
        int maxScroll = Math.max(0, contentHeight - (messageBottom - messageTop));
        scrollbar(c, right - 2, messageTop, messageBottom, contentHeight, maxScroll - messageScroll);
        if (hovered != null && inside(mouseX, mouseY, split, messageTop, right, messageBottom)) {
            int w = hovered.hintWidth + 10, h = hovered.hintLines.size() * 11 + 6;
            int x = Math.max(3, Math.min(mouseX + 8, virtualWidth - w - 3));
            int y = Math.max(2, Math.min(mouseY - h - 2, virtualHeight - h - 2));
            c.fill(x, y, x + w, y + h, 0xFF070D18);
            for (int i = 0; i < hovered.hintLines.size(); i++)
                c.drawText(textRenderer, hovered.hintLines.get(i), x + 5, y + 3 + i * 11, 0xFFE5EDFB, false);
        }
    }
    private void scrollbar(DrawContext c, int x, int top, int bottom, int content, double scroll) {
        int viewport = bottom - top; if (viewport <= 0 || content <= viewport) return;
        int thumb = Math.min(viewport, Math.max(8, viewport * viewport / content));
        int y = top + (int) ((viewport - thumb) * scroll / (content - viewport));
        c.fill(x, y, x + 2, y + thumb, 0xFF4B5A70);
    }
    private void receipt(DrawContext c, int x, int y, int stage) {
        int color = stage == 4 ? 0xFFFF6678 : stage == 3 ? 0xFF000000 | (mod.config.readReceiptColor & 0xFFFFFF) : 0xFFB4C8E2;
        if (stage == 0) {
            c.fill(x + 2, y, x + 8, y + 1, color); c.fill(x + 2, y + 8, x + 8, y + 9, color);
            c.fill(x + 1, y + 1, x + 2, y + 8, color); c.fill(x + 8, y + 1, x + 9, y + 8, color);
            c.fill(x + 4, y + 2, x + 5, y + 5, color); c.fill(x + 4, y + 4, x + 7, y + 5, color);
        } else if (stage == 4) {
            c.fill(x + 4, y, x + 6, y + 6, color); c.fill(x + 4, y + 8, x + 6, y + 10, color);
        } else { tickMark(c, x, y, color); if (stage >= 2) tickMark(c, x + 5, y, color); }
    }
    private static void tickMark(DrawContext c, int x, int y, int color) {
        c.fill(x, y + 4, x + 2, y + 6, color); c.fill(x + 2, y + 6, x + 4, y + 8, color);
        c.fill(x + 4, y + 4, x + 6, y + 6, color); c.fill(x + 6, y + 2, x + 8, y + 4, color);
    }
    /** Also called by Cloth Config; preserving a log remains a separate explicit choice. */
    public static Screen removalScreen(Screen parent, String key) { return new RemovalScreen(parent, key); }
    private static final class RemovalScreen extends Screen {
        private final Screen parent;
        private final String key;
        private List<OrderedText> explanation = Collections.emptyList();
        RemovalScreen(Screen parent, String key) {
            super(Text.literal(key.startsWith("g:") ? "Delete group?" : "Remove friend?")); this.parent = parent; this.key = key;
        }
        @Override protected void init() {
            explanation = textRenderer.wrapLines(Text.literal("Keep log preserves the local conversation. Delete log permanently removes it. Group memberships of a removed friend are unchanged."), Math.max(40, Math.min(340, width - 24)));
            int w = Math.min(330, width - 16), x = (width - w) / 2, y = Math.max(80, height / 2 + 24);
            addDrawableChild(ButtonWidget.builder(Text.literal("Keep log"), b -> remove(false)).dimensions(x, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete log"), b -> remove(true)).dimensions(x + w / 2 + 2, y, w / 2 - 2, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(x, y + 24, w, 20).build());
        }
        private void remove(boolean deleteLog) {
            FriendLink mod = FriendLink.INSTANCE;
            if (key.startsWith("f:")) mod.removeFriend(key.substring(2), deleteLog); else mod.deleteGroup(key.substring(2), deleteLog);
            close();
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
            int x = Math.max(12, (width - 340) / 2);
            for (int i = 0; i < explanation.size(); i++) c.drawText(textRenderer, explanation.get(i), x, 44 + i * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    private static final class DeliveryScreen extends Screen {
        private final Screen parent;
        private final String key, detail;
        private final Message message;
        private List<OrderedText> wrapped = Collections.emptyList();
        private int scroll;
        DeliveryScreen(Screen parent, String key, Message message, String detail) {
            super(Text.literal("Delivery details")); this.parent = parent; this.key = key; this.message = message; this.detail = detail;
        }
        @Override protected void init() {
            wrapped = textRenderer.wrapLines(Text.literal(detail), Math.max(40, width - 32));
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close()).dimensions(width / 2 - 100, height - 30, 96, 20).build());
            ButtonWidget retry = addDrawableChild(ButtonWidget.builder(Text.literal("Retry failed"), b -> {
                FriendLink.INSTANCE.retryMessage(key, message); close();
            }).dimensions(width / 2 + 4, height - 30, 96, 20).build());
            retry.active = message.stage() == 4; scroll = Math.min(scroll, Math.max(0, wrapped.size() - visible()));
        }
        private int visible() { return Math.max(1, (height - 80) / 12); }
        @Override public boolean mouseScrolled(double x, double y, double amount) {
            scroll = Math.max(0, Math.min(Math.max(0, wrapped.size() - visible()), scroll - (int) (amount * 3))); return true;
        }
        @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
            renderBackground(c); c.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
            for (int i = scroll, end = Math.min(wrapped.size(), scroll + visible()); i < end; i++)
                c.drawText(textRenderer, wrapped.get(i), 16, 38 + (i - scroll) * 12, 0xFFE4E7FF, false);
            super.render(c, mouseX, mouseY, delta);
        }
        @Override public void close() { client.setScreen(parent); }
        @Override public boolean shouldPause() { return false; }
    }
    @Override public boolean shouldPause() { return false; }
}
