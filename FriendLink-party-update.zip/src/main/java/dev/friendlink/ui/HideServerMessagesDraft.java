package dev.friendlink.ui;

import dev.friendlink.Config;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Detached, validated working copy. No live Config values are changed before applyTo. */
final class HideServerMessagesDraft {
    static final int MAX_PATTERN_LENGTH = 1024;

    boolean enabled;
    Config.HideServerMode mode;
    final List<Rule> rules = new ArrayList<>();

    HideServerMessagesDraft(Config source) {
        enabled = source.hideServerMessages;
        mode = source.hideServerMode == null
            ? Config.HideServerMode.FRIENDLINK_ONLY : source.hideServerMode;
        List<Config.ServerMessagePattern> configured = source.hiddenServerPatterns;
        if (configured == null) {
            configured = Config.defaultHiddenServerPatterns();
        }
        for (Config.ServerMessagePattern pattern : configured) {
            if (pattern == null) {
                rules.add(new Rule("", false, true));
            } else {
                rules.add(new Rule(pattern.text, pattern.regex, pattern.enabled));
            }
        }
    }

    Rule addRule() {
        Rule rule = new Rule("", false, true);
        rules.add(rule);
        return rule;
    }

    void removeRule(int index) {
        rules.remove(index);
    }

    void resetPatterns() {
        rules.clear();
        for (Config.ServerMessagePattern pattern : Config.defaultHiddenServerPatterns()) {
            if (pattern != null) rules.add(new Rule(pattern.text, pattern.regex, pattern.enabled));
        }
    }

    int firstInvalidIndex() {
        for (int i = 0; i < rules.size(); i++) {
            if (!rules.get(i).valid) return i;
        }
        return -1;
    }

    /** Apply only after all rules pass validation; generated list and entries are detached. */
    void applyTo(Config target) {
        int invalid = firstInvalidIndex();
        if (invalid >= 0) throw new IllegalStateException("Invalid server-message pattern at index " + invalid);
        List<Config.ServerMessagePattern> copy = new ArrayList<>(rules.size());
        for (Rule rule : rules) {
            copy.add(new Config.ServerMessagePattern(rule.text, rule.regex, rule.enabled));
        }
        target.hideServerMessages = enabled;
        target.hideServerMode = mode == null ? Config.HideServerMode.FRIENDLINK_ONLY : mode;
        target.hiddenServerPatterns = copy;
    }

    static final class Rule {
        String text;
        boolean regex;
        boolean enabled;
        boolean valid;
        String error;

        Rule(String text, boolean regex, boolean enabled) {
            this.text = text == null ? "" : text;
            this.regex = regex;
            this.enabled = enabled;
            validate();
        }

        void setText(String value) {
            text = value == null ? "" : value;
            validate();
        }

        void setRegex(boolean value) {
            regex = value;
            validate();
        }

        private void validate() {
            if (text.trim().isEmpty()) {
                valid = false;
                error = "Pattern cannot be empty.";
            } else if (text.length() > MAX_PATTERN_LENGTH) {
                valid = false;
                error = "Pattern is longer than 1024 characters.";
            } else if (regex) {
                try {
                    Pattern.compile(text);
                    valid = true;
                    error = "";
                } catch (PatternSyntaxException ignored) {
                    valid = false;
                    error = "Invalid regular expression.";
                }
            } else {
                valid = true;
                error = "";
            }
        }
    }
}
