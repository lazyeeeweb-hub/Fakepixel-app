package dev.friendlink.ui;

import dev.friendlink.FriendLink;
import dev.friendlink.GlowStyle;
import dev.friendlink.Models.Friend;
import dev.friendlink.Models.Group;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/** The header's ≡ menu. Uses existing colour, group, config and removal screens, not parallel models. */
public final class ConversationOptionsScreen extends Screen {
    private final FriendLink mod = FriendLink.INSTANCE;
    private final ChatScreen parent;
    private final String key;
    private final List<SocialButton> buttons = new ArrayList<>();
    private Friend friend;
    private Group group;
    private GlowStyleDropdown style;
    private OrderedText caption;
    private int x, y, w, h, column, spacing;

    public ConversationOptionsScreen(ChatScreen parent, String key) {
        super(Text.literal("Conversation menu")); this.parent = parent; this.key = key;
    }
    @Override protected void init() {
        friend = key.startsWith("f:") ? mod.state.friends.get(key.substring(2)) : null;
        group = key.startsWith("g:") ? mod.state.groups.get(key.substring(2)) : null;
        if (friend == null && group == null) { close(); return; }
        buttons.clear(); w = Math.min(320, width - 16); spacing = Math.max(18, Math.min(22, (height - 44) / 6));
        h = 43 + spacing * 5 + 18; x = (width - w) / 2; y = Math.max(4, (height - h) / 2); column = (w - 24) / 2;
        caption = Text.literal(textRenderer.trimToWidth(friend != null ? friend.name : group.name, w - 20)).asOrderedText();
        style = addDrawableChild(new GlowStyleDropdown(x + 8, y + 25, column, value -> {
            if (friend != null) friend.glowStyle = value;
            else for (int i = 0; i < group.members.size(); i++) {
                Friend member = mod.friend(group.members.get(i)); if (member != null) member.glowStyle = value;
            }
            mod.touch(); mod.flush();
        }));
        style.selection(friend != null ? friend.glowStyle : mod.config.defaultGlowStyle, true);
        button(1, 0, "Glow colour...", () -> {
            if (friend != null) client.setScreen(new ColorScreen(this, friend));
            else client.setScreen(new ColorScreen(this, "Group members' glow colour", mod.config.defaultGlowColor, color -> {
                for (int i = 0; i < group.members.size(); i++) {
                    Friend member = mod.friend(group.members.get(i)); if (member != null) member.color = color;
                }
                mod.touch(); mod.flush();
            }));
        });
        boolean muted = friend != null ? friend.muted : group.muted;
        button(0, 1, muted ? "Unmute" : "Mute", () -> {
            if (friend != null) friend.muted = !friend.muted; else group.muted = !group.muted;
            mod.touch(); mod.flush(); client.setScreen(new ConversationOptionsScreen(parent, key));
        });
        button(1, 1, "Clear history...", () -> confirmClear(false));
        if (group != null) {
            SocialButton rename = button(0, 2, "Rename group...", () -> client.setScreen(new PromptScreen(this,
                "Rename group", group.name, name -> mod.saveGroup(group, name, group.members))));
            rename.active = !group.pending && group.owner.equalsIgnoreCase(mod.self());
            button(1, 2, "Members...", () -> client.setScreen(new GroupScreen(this, group)));
        } else {
            button(0, 2, "Friend glow settings...", () -> client.setScreen(new ColorScreen(this, friend)));
            button(1, 2, "View settings...", () -> client.setScreen(new ViewSettingsScreen(this)));
        }
        button(0, 3, "Remove...", () -> client.setScreen(ChatScreen.removalScreen(parent, key)));
        button(1, 3, "Delete log...", () -> confirmClear(true));
        if (group != null && group.pending) {
            button(0, 4, "Accept group", () -> { mod.acceptGroup(group.id, true); close(); }).accent(true);
            button(1, 4, "Decline group", () -> { mod.acceptGroup(group.id, false); close(); });
        } else {
            button(0, 4, "Cloth Config...", () -> mod.openConfig(this));
            button(1, 4, group == null ? "View settings..." : "Leave group...", () -> {
                if (group == null) client.setScreen(new ViewSettingsScreen(this));
                else client.setScreen(new ConfirmScreen(confirmed -> {
                    if (confirmed) {
                        String failure = mod.leaveGroup(group);
                        if (failure != null) { client.setScreen(new PromptScreen(this, failure, "", ignored -> null)); return; }
                    }
                    close();
                }, Text.literal("Leave group?"), Text.literal("Notify members and keep the local log.")));
            });
        }
        if (friend != null) button(1, 5, "Share status: " + friend.shareChatOpen, () -> {
            friend.shareChatOpen = switch (friend.shareChatOpen) {
                case DEFAULT -> dev.friendlink.GlowToggle.ON;
                case ON -> dev.friendlink.GlowToggle.OFF;
                case OFF -> dev.friendlink.GlowToggle.DEFAULT;
            };
            mod.touch(); mod.flush(); client.setScreen(new ConversationOptionsScreen(parent, key));
        });
        button(0, 5, "Back", this::close);
    }
    private SocialButton button(int col, int row, String label, Runnable action) {
        SocialButton button = addDrawableChild(new SocialButton(x + 8 + col * (column + 8), y + 25 + row * spacing,
            column, 18, label, action)); buttons.add(button); return button;
    }
    private void confirmClear(boolean deleteLog) {
        client.setScreen(new ConfirmScreen(confirmed -> {
            if (confirmed) mod.clearConversation(key, deleteLog);
            client.setScreen(parent);
        }, Text.literal(deleteLog ? "Delete local log?" : "Clear local history?"),
            Text.literal("This cannot be undone. Membership stays unchanged. Queued messages are cancelled; other players keep their copies.")));
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (style != null && style.menuClick(mx, my, button)) return true;
        return super.mouseClicked(mx, my, button);
    }
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0xB0000000); c.fill(x, y, x + w, y + h, 0xFF171F2C);
        if (caption != null) c.drawText(textRenderer, caption, x + 9, y + 9, 0xFFF2F5FF, false);
        for (int i = 0; i < buttons.size(); i++) buttons.get(i).render(c, mouseX, mouseY, delta);
        if (style != null) { style.render(c, mouseX, mouseY, delta); style.renderMenu(c, mouseX, mouseY); }
    }
    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
