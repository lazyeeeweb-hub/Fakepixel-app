package dev.friendlink.ui;

/** Pure layout arithmetic; all dimensions here are FriendLink virtual GUI pixels, not framebuffer pixels. */
public final class SocialLayout {
    public static final int FIT_WIDTH = 360, FIT_HEIGHT = 220, MARGIN = 8;
    private SocialLayout() {}

    public static int snapPercent(int percent) {
        return Math.max(50, Math.min(150, (int) Math.round(percent / 5.0) * 5));
    }

    public static double scale(int width, int height, int percent, boolean auto) {
        if (!auto) return snapPercent(percent) / 100.0;
        // Largest 5% step whose minimum usable panel and border fit in the real GUI viewport.
        // Auto alone may go below 50% on tiny windows; the manual slider always stays at 50..150%.
        double fit = Math.min(width / (double) (FIT_WIDTH + MARGIN), height / (double) (FIT_HEIGHT + MARGIN));
        double stepped = Math.floor((fit + 1.0E-9) * 20) / 20;
        return Math.min(1.5, stepped > 0 ? stepped : Math.max(.001, fit));
    }

    public static int virtualExtent(int real, double scale) {
        return Math.max(1, (int) Math.floor(real / scale));
    }

    public static int panelExtent(int virtual, int minimum, int maximum, double fraction) {
        // Manual zoom remains responsive instead of putting the composer or footer outside the viewport.
        return Math.max(1, Math.min(virtual - MARGIN, Math.max(minimum, Math.min(maximum, (int) Math.round(virtual * fraction)))));
    }

    public static int sidebarWidth(int panelWidth, int percent) {
        return Math.max(110, Math.min(170, (int) Math.round(panelWidth * Math.max(20, Math.min(40, percent)) / 100.0)));
    }
}
