package dev.friendlink;

/** Local display choice. Sharing is a separate, outgoing-only privacy decision. */
public enum IndicatorStyle {
    HOLOGRAM("Hologram"), BUBBLE("Bubble"), OFF("Off");
    private final String label;
    IndicatorStyle(String label) { this.label = label; }
    public IndicatorStyle next() {
        return switch (this) { case HOLOGRAM -> BUBBLE; case BUBBLE -> OFF; case OFF -> HOLOGRAM; };
    }
    @Override public String toString() { return label; }
}
