package dev.friendlink;

/** Allocation-free client-tick pacing state. Base delay remains the user's configured minimum. */
public final class SendPacing {
    public static final long CAUSE_WINDOW_MS = 3000, CONTROL_INTERVAL_MS = 3000;
    private static final long QUIET_MS = 30000, RECOVERY_STEP_MS = 10000;
    private long lastSend = Long.MIN_VALUE, recoverAt;
    private int adaptiveDelay;
    public void sent(long now) { lastSend = now; }
    public boolean recent(long now) {
        return lastSend != Long.MIN_VALUE && now >= lastSend && now - lastSend <= CAUSE_WINDOW_MS;
    }
    public int delay(int base) { return Math.max(base, adaptiveDelay); }
    public int slowDown(long now, int base) {
        adaptiveDelay = Math.min(30000, Math.max(1000, delay(base) * 2));
        recoverAt = now + QUIET_MS;
        return delay(base);
    }
    public void tick(long now, int base) {
        if (adaptiveDelay <= base || now < recoverAt) return;
        adaptiveDelay = Math.max(base, adaptiveDelay - Math.max(100, (adaptiveDelay - base) / 4));
        recoverAt = now + RECOVERY_STEP_MS;
    }
    public void clear() { lastSend = Long.MIN_VALUE; recoverAt = 0; adaptiveDelay = 0; }
}
