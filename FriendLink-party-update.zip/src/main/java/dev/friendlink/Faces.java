package dev.friendlink;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;

public final class Faces {
    private Faces() {}
    /** Square 8x8 face plus translucent 8x8 hat layer; texture cache is normalized to 64x64. */
    public static void draw(DrawContext context, Identifier skin, int x, int y, int size) {
        if (size <= 0) return;
        if (skin == null) skin = DefaultSkinHelper.getTexture();
        // GUI render boundary: flush buffered fills before clearing tint from glow/hologram passes.
        // drawTexture selects the position/texture shader and binds this skin, not the last world texture.
        context.draw();
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        try {
            context.drawTexture(skin, x, y, size, size, 8F, 8F, 8, 8, 64, 64);
            context.drawTexture(skin, x, y, size, size, 40F, 8F, 8, 8, 64, 64);
        } finally {
            // Leave a neutral GUI state; never propagate a world-pass tint or additive blend function.
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }
}
