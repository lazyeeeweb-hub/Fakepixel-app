package dev.friendlink;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

/** Connection-scoped server party features. Not related to FriendLink's private group protocol. */
public final class PartyService {
    private static final String LINK = "Click here to join!";
    private static final long INVITE_MS = 60_000;
    private static final int MAX_INVITES = 16;
    public record Invite(String label, ClickEvent click, long expires) {}
    private record StyledRun(int end, ClickEvent click) {}

    private final FriendLink mod;
    private final FriendListPoll friends = new FriendListPoll();
    private final ArrayDeque<Invite> invites = new ArrayDeque<>();
    private ClientPlayNetworkHandler connection;
    private boolean leader, polling;

    PartyService(FriendLink mod) { this.mod = mod; }

    void join(ClientPlayNetworkHandler handler) {
        clear();
        connection = handler;
        friends.join(Util.getMeasuringTimeMs());
    }

    void clear() {
        connection = null; leader = false; invites.clear(); friends.clear();
    }

    void tick(MinecraftClient client) {
        if (connection == null || client.getNetworkHandler() != connection || client.player == null) return;
        long now = Util.getMeasuringTimeMs();
        expire(now);
        friends.tick(now, page -> {
            polling = true;
            try { connection.sendChatCommand(page == 1 ? "friends list" : "friends list " + page); }
            finally { polling = false; }
        });
    }

    void sentCommand(String command) {
        // Fabric's COMMAND event also fires for sendChatCommand; do not register our own requests as manual.
        if (!polling) friends.manualCommand(command, Util.getMeasuringTimeMs());
    }

    FriendListPoll.Chat receive(Text message) {
        if (connection == null) return FriendListPoll.Chat.UNRELATED;
        long now = Util.getMeasuringTimeMs();
        String clean = PartyMessages.clean(message.getString());
        String inviter = PartyMessages.inviter(clean);
        if (inviter != null) {
            expire(now);
            if (invites.size() >= MAX_INVITES) invites.removeFirst();
            invites.addLast(new Invite(inviter + " invited you to a party", extractJoinClick(message), now + INVITE_MS));
            mod.notifications.showPartyInvite();
            return FriendListPoll.Chat.AUTOMATED; // Raw invitation is replaced regardless of link availability.
        }
        leader = PartyMessages.leader(clean, mod.self(), leader);
        return friends.receive(clean, now);
    }

    /** Visit the original text with inherited styles; a link may span several Text siblings. */
    static ClickEvent extractJoinClick(Text message) {
        StringBuilder plaintext = new StringBuilder();
        List<StyledRun> runs = new ArrayList<>();
        message.visit((style, visible) -> {
            String plain = PartyMessages.clean(visible);
            if (!plain.isEmpty()) {
                plaintext.append(plain);
                runs.add(new StyledRun(plaintext.length(), style.getClickEvent()));
            }
            return Optional.empty();
        }, Style.EMPTY);
        int start = plaintext.lastIndexOf(LINK);
        if (start < 0) return null;
        int end = start + LINK.length(), previous = 0;
        ClickEvent event = null;
        for (StyledRun run : runs) {
            if (run.end() > start && previous < end) {
                ClickEvent candidate = run.click();
                if (candidate == null || candidate.getAction() != ClickEvent.Action.RUN_COMMAND
                    || !candidate.getValue().startsWith("/") || candidate.getValue().length() < 2
                    || (event != null && !event.equals(candidate))) return null;
                if (event == null) event = candidate;
            }
            previous = run.end();
            if (previous >= end) break;
        }
        return event;
    }

    public Invite invitation() {
        expire(Util.getMeasuringTimeMs());
        return invites.peekFirst();
    }

    private void expire(long now) {
        while (!invites.isEmpty() && now >= invites.peekFirst().expires()) invites.removeFirst();
    }

    public boolean respond(Invite expected, boolean accept) {
        if (expected == null || invitation() != expected) return false;
        if (accept) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (expected.click() == null || connection == null || client.getNetworkHandler() != connection
                || client.player == null || client.currentScreen == null) return true;
            // Use vanilla's actual RUN_COMMAND click path, including its validation and signing rules.
            if (!client.currentScreen.handleTextClick(Style.EMPTY.withClickEvent(expected.click()))) return true;
        }
        invites.removeFirst();
        return true;
    }

    public boolean isLeader() { return connection != null && leader; }
    public void warp() { if (isLeader()) send("p warp"); }
    public void invite(String name) { if (Protocol.validName(name)) send("p invite " + name); }
    public String location(String name) { return friends.location(name); }
    public long locationsVersion() { return friends.version(); }

    private void send(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (connection != null && client.getNetworkHandler() == connection && client.player != null)
            connection.sendChatCommand(command);
    }
}
