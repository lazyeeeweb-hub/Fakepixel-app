package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Plain JSON configuration. No optional UI types may appear in this class. */
public final class Config {
    public enum Anchor { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }
    public enum HideServerMode { FRIENDLINK_ONLY, ALWAYS }
    public static final class ServerMessagePattern {
        public boolean enabled = true, regex;
        public String text = "";
        public ServerMessagePattern() {}
        public ServerMessagePattern(String text, boolean regex, boolean enabled) {
            this.text = text; this.regex = regex; this.enabled = enabled;
        }
    }
    public boolean hideServerMessages = true;
    public HideServerMode hideServerMode = HideServerMode.FRIENDLINK_ONLY;
    public List<ServerMessagePattern> hiddenServerPatterns = defaultHiddenServerPatterns();
    public static List<ServerMessagePattern> defaultHiddenServerPatterns() {
        return new ArrayList<>(List.of(
            new ServerMessagePattern("Slow down! You're executing commands too fast", false, true),
            new ServerMessagePattern("This player is offline", false, true)));
    }
    public boolean reopenLastConversation = true;
    /** FriendLink screen only; unrelated to Minecraft's GUI scale and the radius HUD scale. */
    public int friendLinkUiScale = 100, sidebarWidthPercent = 26;
    public boolean friendLinkUiAutoScale = false;
    public boolean glowScaleWithDistance = true;
    public double glowScaleFactor = 0.01, glowMaxScale = 3.0;
    public boolean glowEnabled = true;
    public boolean glowNewFriends = true;
    public GlowStyle defaultGlowStyle = GlowStyle.MARKER;
    public boolean glowPreviewSelf = false;
    /** Pixels in the mask dilation pass; independent of distance and model size. */
    public int glowOutlinePixels = 2, glowFillOpacity = 0;
    /** Persisted migration versions, not rendering options. */
    public int glowSettingsVersion = 0;
    public boolean glowThroughWalls = true, glowFadeBehindBlocks = false, glowMarkerPulse = true;
    public int glowOpacity = 55, glowMaxDistance = 128, glowOccludedOpacity = 55;
    public double glowThickness = 1.06;
    public boolean hudEnabled = true;
    public int defaultGlowColor = 0xFFFF00;
    public int radius = 100;
    public boolean distance3d = false;
    public Anchor anchor = Anchor.TOP_RIGHT;
    public int offsetX = 8, offsetY = 8, iconSize = 20, maxIcons = 8;
    public double scale = 1.0;
    public boolean showName = true, showDistance = true, sortByDistance = true;
    public boolean notificationSound = true, notificationToast = true;
    public int sendDelayMs = 400, echoTimeoutMs = 3000, maxGroupSize = 8;
    public int readReceiptColor = 0x3498FF;
    public int retryDelayMs = 5000, retryMaxDelayMs = 30000, retryMaxAttempts = 100, retryMaxAgeHours = 24;
    /** Legacy JSON switch; migrated to indicatorStyle by normalize(). */
    public boolean chatBubbles = true, shareChatOpen = true;
    public IndicatorStyle indicatorStyle = IndicatorStyle.HOLOGRAM;
    public int hologramOpacity = 50, hologramMaxDistance = 48;
    public double hologramSize = 1.4, hologramDistance = 1.1, hologramHeightOffset = -.25;
    public boolean hologramThroughWalls = false, hologramPreviewSelf = false;
    public boolean hologramScaleWithDistance = true;
    public double hologramScaleFactor = .01, hologramMaxScale = 3;
    public double chatBubbleSize = 1.0;
    public int chatOpenTimeoutMs = 300000;
    public boolean unreadFriendBadges = true, unreadTotalBadge = true;
    public boolean pauseMenuButton = true, inventoryButton = true;
    public Anchor screenButtonCorner = Anchor.TOP_RIGHT;
    /** Kept for migration of older config.json files; no longer the default offline expression. */
    public static final String OFFLINE_PLACEHOLDER = "^FRIENDLINK_OFFLINE_LINE_PLACEHOLDER$";
    public int maxMessages = 1000;
    public String groupTag = "[FL:%s]";
    public List<String> dialogueRegex = new ArrayList<>(List.of(
        "^From (?<from>.+?) to (?<to>.+?): (?<msg>.*)$"));
    public List<String> incomingRegex = new ArrayList<>(List.of(
        "^<?(?<name>.+?)>? whispers to you: (?<message>.*)$",
        "^<?(?<name>.+?)>? whispers: (?<message>.*)$",
        "^\\[(?<name>.+) -> (?:me|you)\\] (?<message>.*)$",
        "^From (?<name>.+?): (?<message>.*)$"));
    public List<String> outgoingRegex = new ArrayList<>(List.of(
        "^You whisper to <?(?<name>.+?)>?: (?<message>.*)$",
        "^\\[(?:me|you) -> (?<name>.+)\\] (?<message>.*)$",
        "^To (?<name>.+?): (?<message>.*)$"));
    public static final String DEFAULT_OFFLINE_REGEX = "^\\s*This player is offline!";
    public List<String> notFoundRegex = new ArrayList<>(List.of(DEFAULT_OFFLINE_REGEX));

    public void normalize() {
        friendLinkUiScale = clamp((int) Math.round(friendLinkUiScale / 5.0) * 5, 50, 150);
        sidebarWidthPercent = clamp(sidebarWidthPercent, 20, 40);
        if (hideServerMode == null) hideServerMode = HideServerMode.FRIENDLINK_ONLY;
        if (hiddenServerPatterns == null) hiddenServerPatterns = defaultHiddenServerPatterns();
        // Bound edited JSON as well as UI input, without resetting a deliberately empty list.
        List<ServerMessagePattern> normalizedPatterns = new ArrayList<>();
        for (ServerMessagePattern rule : hiddenServerPatterns) {
            if (normalizedPatterns.size() == 64) break;
            if (rule == null || rule.text == null || rule.text.isBlank() || rule.text.length() > 1024) continue;
            normalizedPatterns.add(rule);
        }
        hiddenServerPatterns = normalizedPatterns;
        if (notFoundRegex == null || notFoundRegex.size() == 1 && OFFLINE_PLACEHOLDER.equals(notFoundRegex.get(0)))
            notFoundRegex = new ArrayList<>(List.of(DEFAULT_OFFLINE_REGEX));
        glowScaleFactor = Double.isFinite(glowScaleFactor) ? Math.max(0, Math.min(.05, glowScaleFactor)) : .01;
        glowMaxScale = Double.isFinite(glowMaxScale) ? Math.max(1, Math.min(6, glowMaxScale)) : 3;
        radius = clamp(radius, 1, 4096);
        offsetX = clamp(offsetX, 0, 4096); offsetY = clamp(offsetY, 0, 4096);
        iconSize = clamp(iconSize, 8, 64); maxIcons = clamp(maxIcons, 1, 64);
        scale = Double.isFinite(scale) ? Math.max(.5, Math.min(3, scale)) : 1;
        sendDelayMs = clamp(sendDelayMs, 100, 10000);
        echoTimeoutMs = clamp(echoTimeoutMs, 500, 15000);
        maxGroupSize = clamp(maxGroupSize, 2, 32);
        readReceiptColor &= 0xFFFFFF;
        retryDelayMs = clamp(retryDelayMs, 1000, 30000);
        retryMaxDelayMs = clamp(retryMaxDelayMs, retryDelayMs, 300000);
        retryMaxAttempts = clamp(retryMaxAttempts, 1, 100000);
        retryMaxAgeHours = clamp(retryMaxAgeHours, 1, 720);
        chatOpenTimeoutMs = clamp(chatOpenTimeoutMs, 1000, 3600000);
        if (indicatorStyle == null) indicatorStyle = IndicatorStyle.HOLOGRAM;
        if (!chatBubbles) { indicatorStyle = IndicatorStyle.OFF; chatBubbles = true; }
        hologramOpacity = clamp(hologramOpacity, 0, 100);
        hologramMaxDistance = clamp(hologramMaxDistance, 1, 4096);
        hologramSize = finiteRange(hologramSize, .25, 4, 1.4);
        hologramDistance = finiteRange(hologramDistance, .25, 4, 1.1);
        hologramHeightOffset = finiteRange(hologramHeightOffset, -2, 2, -.25);
        hologramScaleFactor = finiteRange(hologramScaleFactor, 0, .05, .01);
        hologramMaxScale = finiteRange(hologramMaxScale, 1, 6, 3);
        chatBubbleSize = Double.isFinite(chatBubbleSize) ? Math.max(.25, Math.min(4, chatBubbleSize)) : 1;
        if (screenButtonCorner == null) screenButtonCorner = Anchor.TOP_RIGHT;
        maxMessages = clamp(maxMessages, 100, 10000);
        defaultGlowColor &= 0xFFFFFF;
        defaultGlowStyle = GlowStyle.resolve(GlowStyle.DEFAULT, defaultGlowStyle);
        glowOpacity = clamp(glowOpacity, 0, 100);
        glowOutlinePixels = clamp(glowOutlinePixels, 1, 6);
        glowFillOpacity = clamp(glowFillOpacity, 0, 100);
        glowMaxDistance = clamp(glowMaxDistance, 1, 4096);
        glowOccludedOpacity = clamp(glowOccludedOpacity, 10, 100);
        glowThickness = Double.isFinite(glowThickness) ? Math.max(1.04, Math.min(1.08, glowThickness)) : 1.06;
        if (anchor == null) anchor = Anchor.TOP_RIGHT;
        if (!Protocol.validTag(groupTag)) groupTag = "[FL:%s]";
        if (dialogueRegex == null) dialogueRegex = new Config().dialogueRegex;
        if (incomingRegex == null) incomingRegex = new Config().incomingRegex;
        if (outgoingRegex == null) outgoingRegex = new Config().outgoingRegex;
        if (notFoundRegex == null) notFoundRegex = new Config().notFoundRegex;
    }
    private static double finiteRange(double value, double min, double max, double fallback) {
        return Double.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
    }
    public static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    public static boolean validRegex(String regex, boolean whisper) {
        try {
            Pattern.compile(regex);
            return !whisper || ((regex.contains("(?<name>") && regex.contains("(?<message>"))
                || (regex.contains("(?<from>") && regex.contains("(?<to>") && regex.contains("(?<msg>")));
        } catch (RuntimeException e) { return false; }
    }
}
