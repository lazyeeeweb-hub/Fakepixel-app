package dev.friendlink.compat;

import dev.friendlink.ui.HideServerMessagesScreen;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import me.shedaniel.clothconfig2.api.AbstractConfigListEntry;

/** Cloth-only launcher entry; the actual editor has no Cloth dependency. */
final class HideServerMessagesEntry extends AbstractConfigListEntry<Boolean> {
    private final ButtonWidget button;
    private final List<ButtonWidget> children;
    private boolean dragging;

    HideServerMessagesEntry() {
        super(Text.literal("Open the full pattern editor"), false);
        button = ButtonWidget.builder(Text.literal("Edit hide-server-message rules"), widget ->
            MinecraftClient.getInstance().setScreen(new HideServerMessagesScreen(getConfigScreen())))
            .dimensions(0, 0, 240, 20).build();
        children = List.of(button);
    }

    @Override
    public Boolean getValue() {
        return Boolean.FALSE;
    }

    @Override
    public Optional<Boolean> getDefaultValue() {
        return Optional.of(Boolean.FALSE);
    }

    @Override
    public List<? extends Element> children() {
        return children;
    }

    @Override
    public List<? extends Selectable> narratables() {
        return children;
    }

    @Override
    public int getItemHeight() {
        return 24;
    }

    @Override
    public void appendNarrations(NarrationMessageBuilder builder) {
        button.appendNarrations(builder);
    }

    @Override
    public Selectable.SelectionType getType() {
        return button.getType();
    }

    @Override
    public Element getFocused() {
        return button.isFocused() ? button : null;
    }

    @Override
    public void setFocused(Element focused) {
        button.setFocused(focused == button);
    }

    @Override
    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }

    @Override
    public boolean isDragging() {
        return dragging;
    }

    @Override
    public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight,
                       int mouseX, int mouseY, boolean hovered, float delta) {
        button.setX(x + Math.max(0, (entryWidth - 240) / 2));
        button.setY(y + 2);
        button.active = isEditable();
        button.render(context, mouseX, mouseY, delta);
    }
}
