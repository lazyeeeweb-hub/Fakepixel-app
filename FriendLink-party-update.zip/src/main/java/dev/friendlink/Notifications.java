package dev.friendlink;

import dev.friendlink.Models.*;
import dev.friendlink.ui.ChatScreen;
import dev.friendlink.ui.PartyInviteCard;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.sound.SoundEvents;

/** Native toasts are not mouse widgets. Invitations expose rebindable Accept/Decline keys. */
public final class Notifications {
    private final FriendLink mod;
    private Notice activeInvite;
    private PartyToast partyToast;
    private final List<Notice> notices = new ArrayList<>();
    public Notifications(FriendLink mod) { this.mod = mod; }
    public void message(String key, Message message) {
        // Unread bookkeeping belongs to append(); suppress only presentation, for every conversation.
        if (MinecraftClient.getInstance().currentScreen instanceof ChatScreen) return;
        Group group = key.startsWith("g:") ? mod.state.groups.get(key.substring(2)) : null;
        Friend friend = key.startsWith("f:") ? mod.state.friends.get(key.substring(2)) : null;
        if ((group != null && group.muted) || (friend != null && friend.muted)) return;
        if (mod.config.notificationSound && (group == null || group.sound)) sound();
        if (mod.config.notificationToast) {
            String title = group == null ? message.sender : group.name + " · " + message.sender;
            show(new Notice(title, message.text, null, key));
        }
    }
    public void invite(Group group, String sender) {
        if (mod.config.notificationSound) sound();
        // Approval UI always remains available in K -> group -> Manage, even when toasts are disabled.
        if (mod.config.notificationToast) show(new Notice("Invite: " + group.name,
            mod.acceptHint() + " Accept | " + mod.declineHint() + " Decline", group.id, "g:" + group.id));
    }
    private void sound() {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1F));
    }
    private void show(Notice notice) {
        notices.removeIf(n -> n.hidden || n.started && System.currentTimeMillis() > n.deadline);
        if (notices.size() >= 64) notices.remove(0);
        notices.add(notice);
        MinecraftClient.getInstance().getToastManager().add(notice);
    }
    public void showPartyInvite() {
        var manager = MinecraftClient.getInstance().getToastManager();
        if (partyToast == null || manager.getToast(PartyToast.class, Toast.TYPE) != partyToast) {
            partyToast = new PartyToast();
            manager.add(partyToast);
        }
    }
    public boolean click(double x, double y) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!(client.currentScreen instanceof ChatScreen chat && chat.hasRoomForPartyCard())
            && partyToast != null && partyToast.click(x, y)) return true;
        long now = System.currentTimeMillis();
        for (int i = notices.size() - 1; i >= 0; i--) {
            Notice n = notices.get(i);
            if (n.hidden || !n.started || now > n.deadline || now - n.lastDraw > 200
                || x < n.left || x >= n.left + n.getWidth() || y < n.top || y >= n.top + n.getHeight()) continue;
            n.hidden = true;
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new ChatScreen(n.conversation, mc.currentScreen));
            return true;
        }
        return false;
    }
    public void respond(boolean accepted, long now) {
        Notice n = activeInvite;
        if (n == null || n.hidden || now > n.deadline) return;
        mod.acceptGroup(n.groupId, accepted); n.hidden = true; activeInvite = null;
    }
    private final class PartyToast implements Toast {
        private final PartyInviteCard card = new PartyInviteCard();
        private double left, top;
        private long lastDraw;
        @Override public int getWidth() { return 270; }
        @Override public int getHeight() { return 32; }
        @Override public Visibility draw(DrawContext context, ToastManager manager, long elapsed) {
            var invite = mod.party.invitation();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (invite == null || this != partyToast) {
                card.clear();
                if (this == partyToast) partyToast = null;
                return Visibility.HIDE;
            }
            // The Social screen renders this same notice inline rather than over its controls.
            if (mc.currentScreen instanceof ChatScreen chat && chat.hasRoomForPartyCard()) { card.clear(); return Visibility.SHOW; }
            var position = context.getMatrices().peek().getPositionMatrix();
            left = position.m30(); top = position.m31(); lastDraw = System.currentTimeMillis();
            double mx = mc.mouse.getX() * mc.getWindow().getScaledWidth() / mc.getWindow().getWidth() - left;
            double my = mc.mouse.getY() * mc.getWindow().getScaledHeight() / mc.getWindow().getHeight() - top;
            card.draw(context, mc.textRenderer, invite, 0, 0, getWidth(), mx, my);
            if (mc.currentScreen == null)
                context.drawText(mc.textRenderer, "Open chat to use the buttons", 6, 22, 0xFFD3DCE8, true);
            return Visibility.SHOW;
        }
        boolean click(double x, double y) {
            return System.currentTimeMillis() - lastDraw <= 200 && card.click(mod.party, x - left, y - top);
        }
    }
    private final class Notice implements Toast {
        private final String title, detail, groupId, conversation;
        private boolean started, hidden;
        private long deadline, lastDraw;
        private float left, top;
        Notice(String title, String detail, String groupId, String conversation) {
            var tr = MinecraftClient.getInstance().textRenderer;
            this.title = tr.trimToWidth(title, 208); this.detail = tr.trimToWidth(detail, 208); this.groupId = groupId; this.conversation = conversation;
        }
        @Override public int getWidth() { return 224; }
        @Override public int getHeight() { return 40; }
        @Override public Visibility draw(DrawContext context, ToastManager manager, long elapsed) {
            // Existing message toasts must disappear as well when the main chat opens; invites stay actionable.
            if (groupId == null && MinecraftClient.getInstance().currentScreen instanceof ChatScreen) hidden = true;
            if (!started) {
                started = true; deadline = System.currentTimeMillis() + (groupId == null ? 5000 : 10000);
                if (groupId != null) activeInvite = this;
            }
            var position = context.getMatrices().peek().getPositionMatrix();
            left = position.m30(); top = position.m31(); lastDraw = System.currentTimeMillis();
            context.fill(0, 0, 224, 40, 0xF0212430);
            context.fill(0, 0, 3, 40, 0xFF7A8BFF);
            var tr = MinecraftClient.getInstance().textRenderer;
            context.drawText(tr, title, 8, 8, 0xFFE7E9FF, false);
            context.drawText(tr, detail, 8, 23, 0xFFBBBBCC, false);
            return hidden || elapsed >= (groupId == null ? 5000 : 10000) ? Visibility.HIDE : Visibility.SHOW;
        }
    }
}
