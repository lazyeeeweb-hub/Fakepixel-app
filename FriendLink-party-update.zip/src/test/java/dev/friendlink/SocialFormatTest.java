package dev.friendlink;

import dev.friendlink.ui.SocialFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Headless regression checks: these helpers must never need a running Minecraft renderer. */
class SocialFormatTest {
    private static final ZoneId UTC = ZoneId.of("UTC");
    private static long at(String date) { return ZonedDateTime.parse(date).toInstant().toEpochMilli(); }
    @Test void activityUsesClockYesterdayAndCalendarDate() {
        long now = at("2026-07-19T23:00:00Z");
        assertEquals("9:38 PM", SocialFormat.activity(at("2026-07-19T21:38:00Z"), now, UTC));
        assertEquals("Yesterday", SocialFormat.activity(at("2026-07-18T01:00:00Z"), now, UTC));
        assertEquals("Jul 10", SocialFormat.activity(at("2026-07-10T12:00:00Z"), now, UTC));
        assertEquals("Jul 10, 2025", SocialFormat.activity(at("2025-07-10T12:00:00Z"), now, UTC));
        assertEquals("", SocialFormat.activity(0, now, UTC));
    }
    @Test void yesterdayIsCalendarBasedAcrossDaylightSavingAndYearBoundaries() {
        ZoneId zone = ZoneId.of("America/New_York");
        assertEquals("Yesterday", SocialFormat.activity(at("2026-03-08T05:01:00Z"), at("2026-03-09T04:30:00Z"), zone));
        assertEquals("Yesterday", SocialFormat.activity(at("2025-12-31T23:59:00Z"), at("2026-01-01T00:01:00Z"), UTC));
    }
    @Test void previewIsBoundedAndSingleLine() {
        assertEquals("Alex: hello world !", SocialFormat.preview("Alex", "hello\nworld\t!", false));
        assertEquals("Joined", SocialFormat.preview("FriendLink", "Joined", true));
        assertEquals("", SocialFormat.preview("Alex", null, false));
        assertEquals(163, SocialFormat.preview("A", "x".repeat(300), false).length());
    }
    @Test void scrollingClampsBothOverscrollAndShortHistory() {
        assertEquals(0, SocialFormat.clampScroll(-10, 1000, 200));
        assertEquals(800, SocialFormat.clampScroll(900, 1000, 200));
        assertEquals(0, SocialFormat.clampScroll(60, 100, 200));
        assertEquals(123, SocialFormat.clampScroll(123, 1000, 200));
    }
}
