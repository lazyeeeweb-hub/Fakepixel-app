package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ServerMessagesTest {
    @Test void defaultsAreScopedCaseInsensitiveAndTolerateSuffixes() {
        Config c = new Config(); ServerMessages rules = new ServerMessages(c);
        String offline = WhisperText.strip("§x§a§b§c§d§e§f§cTHIS PLAYER IS OFFLINE! (server one)");
        assertFalse(rules.hide(offline, false)); assertTrue(rules.hide(offline, true));
        assertTrue(rules.hide("Slow down! You're executing commands too fast! 2 seconds", true));
        assertEquals(ServerMessages.Signal.OFFLINE, rules.signal(offline));
        assertEquals(ServerMessages.Signal.SLOW_DOWN, rules.signal("Slow down!"));
    }
    @Test void literalRegexDisabledAndMasterSettingsAreIndependent() {
        Config c = new Config(); c.hideServerMode = Config.HideServerMode.ALWAYS;
        c.hiddenServerPatterns = new ArrayList<>(List.of(
            new Config.ServerMessagePattern("a.b", false, true),
            new Config.ServerMessagePattern("^error [0-9]+", true, true),
            new Config.ServerMessagePattern("disabled", false, false),
            new Config.ServerMessagePattern("[", true, true)));
        ServerMessages rules = new ServerMessages(c);
        assertTrue(rules.hide("prefix A.B suffix", false)); assertFalse(rules.hide("axb", true));
        assertTrue(rules.hide("ERROR 12 details", false)); assertFalse(rules.hide("disabled", true));
        c.hideServerMessages = false; rules = new ServerMessages(c);
        assertFalse(rules.hide("a.b", true));
        assertEquals(ServerMessages.Signal.OFFLINE, rules.signal("This player is offline!"));
    }
    @Test void placeholderMigrationPreservesCustomAndDeliberatelyEmptySettings() {
        Config c = new Config(); c.notFoundRegex = new ArrayList<>(List.of(Config.OFFLINE_PLACEHOLDER));
        c.normalize(); assertEquals(List.of(Config.DEFAULT_OFFLINE_REGEX), c.notFoundRegex);
        c.notFoundRegex = new ArrayList<>(List.of("custom offline")); c.hiddenServerPatterns.clear();
        c.normalize(); assertEquals(List.of("custom offline"), c.notFoundRegex); assertTrue(c.hiddenServerPatterns.isEmpty());
        c.hiddenServerPatterns = Config.defaultHiddenServerPatterns();
        assertEquals(2, c.hiddenServerPatterns.size()); assertTrue(c.hiddenServerPatterns.get(0).enabled);
        assertFalse(c.hiddenServerPatterns.get(0).regex);
    }
    @Test void compiledRulesChangeOnlyOnReload() {
        Config c = new Config(); ServerMessages old = new ServerMessages(c);
        c.hiddenServerPatterns.clear();
        assertTrue(old.hide("This player is offline!", true));
        assertFalse(new ServerMessages(c).hide("This player is offline!", true));
    }
}
