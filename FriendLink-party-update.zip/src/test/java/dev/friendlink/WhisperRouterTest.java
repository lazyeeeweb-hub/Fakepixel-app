package dev.friendlink;

import dev.friendlink.Models.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WhisperRouterTest {
    private static final String ID = "00000000-0000-0000-0000-000000000001";
    private record Filed(String key, Message message, boolean incoming) {}
    private static final class TestHost implements WhisperRouter.Host {
        final Config config = new Config();
        final State state = new State();
        final FriendLink mod = new FriendLink();
        final SendQueue queue = new SendQueue(mod);
        final List<Filed> filed = new ArrayList<>();
        final List<Protocol.Invite> invites = new ArrayList<>();
        int notices, errors;
        TestHost() {
            mod.config = config; mod.state = state; mod.queue = queue;
            config.dialogueRegex = new ArrayList<>(List.of(WhisperText.DEFAULT_DIALOGUE_REGEX));
            Friend friend = new Friend(); friend.name = "DyLol"; state.friends.put("dylol", friend);
        }
        public Config config() { return config; }
        public State state() { return state; }
        public Friend friend(String name, UUID uuid) { return FriendIdentity.find(state, name, uuid); }
        public String self() { return "Me"; }
        public void touch() { mod.touch(); }
        public boolean echo(String name, String body) { return queue.echo(name, body); }
        public boolean notFound() { errors++; return queue.notFound(); }
        public boolean recentWhisper(long now) { return queue.recentWhisper(now); }
        public boolean slowDown() { return queue.slowDown(); }
        public void append(String key, Message message, boolean incoming) { filed.add(new Filed(key, message, incoming)); }
        public void inviteNotice(Group group, String sender) { notices++; }
        public void receiveInvite(String sender, Protocol.Invite invite) { invites.add(invite); }
    }
    private SendQueue.Entry arm(SendQueue queue, SendQueue.Job job) {
        int before = queue.snapshot().entries.size();
        assertTrue(queue.offer(List.of(job)));
        List<SendQueue.Entry> pending = queue.snapshot().entries;
        assertEquals(before + 1, pending.size());
        SendQueue.Entry entry = pending.get(before);
        assertSame(job.message(), entry.message);
        assertEquals(job.target(), entry.target);
        assertEquals(job.body(), entry.body);
        assertEquals(job.conversation(), entry.conversation);
        assertEquals(job.message().id, entry.messageId);
        assertTrue(ReliableProtocol.validId(entry.wireId));
        assertEquals(0, entry.attempts); assertEquals(0, entry.stage); assertFalse(entry.confirmed);
        // tick() calls this same scheduling seam; arm the admitted Entry, not a Job
        // or a reflected private field. No Minecraft client or network is needed here.
        long now = System.currentTimeMillis();
        queue.beginSend(entry, now);
        assertEquals(1, entry.attempts); assertEquals(now, entry.lastSentAt);
        assertTrue(queue.recentWhisper(now));
        return entry;
    }
    @Test void routerQueueHelperArmsTheNewEntryInsteadOfTheOldHead() {
        TestHost h = new TestHost();
        Message earlier = new Message("Me", "earlier", false);
        assertTrue(h.queue.offer(List.of(new SendQueue.Job("DyLol", "earlier", "f:dylol", earlier))));
        SendQueue.Entry first = h.queue.snapshot().entries.get(0);
        Message current = new Message("Me", "current", false);
        SendQueue.Entry admitted = arm(h.queue, new SendQueue.Job("DyLol", "current", "f:dylol", current));
        assertNotSame(first, admitted); assertSame(current, admitted.message);
        assertEquals(0, first.attempts); assertEquals(1, admitted.attempts);
        assertEquals(2, h.queue.snapshot().entries.size());
    }

    @Test void offlineErrorIsHiddenAndRetriedWithoutFiling() {
        TestHost h = new TestHost();
        h.config.retryDelayMs = 1500; h.config.retryMaxDelayMs = 6000;
        WhisperRouter r = new WhisperRouter(h);
        Message message = new Message("Me", "hello", false);
        SendQueue.Entry entry = arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        long beforeFeedback = System.currentTimeMillis();
        assertTrue(r.receive("§cThis player is offline! Please try later."));
        long afterFeedback = System.currentTimeMillis();
        assertEquals(1, h.errors); assertTrue(h.filed.isEmpty());
        assertEquals(1, h.queue.snapshot().entries.size());
        assertSame(entry, h.queue.snapshot().entries.get(0));
        assertEquals(1, entry.stage); assertFalse(entry.confirmed);
        assertEquals(0, entry.attempts); assertTrue(entry.feedbackApplied);
        assertTrue(entry.nextAt >= beforeFeedback + h.config.retryDelayMs);
        assertTrue(entry.nextAt <= afterFeedback + h.config.retryDelayMs);
        Delivery delivery = message.delivery.get("DyLol");
        assertEquals(1, delivery.total); assertEquals(1, delivery.completed);
        assertEquals(1, delivery.unconfirmed); assertEquals(0, delivery.failed);
        long retryAt = entry.nextAt;
        assertFalse(h.queue.notFound()); // Duplicate feedback must not consume another attempt or reschedule.
        assertEquals(retryAt, entry.nextAt); assertEquals(0, entry.attempts);

        // A nearby-player hint makes the retained Entry due without sleeps. Exercise the
        // same beginSend path again, then route the real outgoing echo through the router.
        long beforeNearby = System.currentTimeMillis();
        h.queue.nearby("dYlOl");
        long resendAt = System.currentTimeMillis();
        assertTrue(entry.nextAt >= beforeNearby && entry.nextAt <= resendAt);
        h.queue.beginSend(entry, resendAt);
        assertEquals(1, entry.attempts); assertFalse(entry.feedbackApplied);
        assertTrue(r.receive("From Me to DyLol: hello"));
        assertTrue(entry.confirmed); assertEquals(1, entry.stage);
        assertEquals(1, h.queue.snapshot().entries.size());
        assertSame(entry, h.queue.snapshot().entries.get(0));
        assertEquals(1, delivery.parts.size()); assertEquals(1, delivery.completed);
        assertEquals(0, delivery.unconfirmed); assertEquals(0, delivery.failed);
        assertFalse(h.queue.notFound()); assertTrue(h.filed.isEmpty());
    }
    @Test void hideToggleDoesNotDisableOfflineFeedbackAndAlwaysModeDoesNotInventSends() {
        TestHost h = new TestHost(); h.config.hideServerMessages = false;
        WhisperRouter r = new WhisperRouter(h); Message message = new Message("Me", "hello", false);
        arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        assertFalse(r.receive("§cThis player is offline!"));
        assertEquals(1, h.errors); assertTrue(h.filed.isEmpty());
        TestHost other = new TestHost(); other.config.hideServerMode = Config.HideServerMode.ALWAYS;
        WhisperRouter always = new WhisperRouter(other);
        assertTrue(always.receive("§cThis player is offline!"));
        assertEquals(0, other.errors); assertTrue(other.filed.isEmpty());
    }
    @Test void throttleRetainsMessageAndDoesNotConsumeAttempt() {
        TestHost h = new TestHost(); h.config.retryMaxAttempts = 1; h.config.sendDelayMs = 500;
        WhisperRouter r = new WhisperRouter(h); Message message = new Message("Me", "hello", false);
        SendQueue.Entry entry = arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        long beforeFeedback = System.currentTimeMillis();
        assertTrue(r.receive("§cSlow down! You're executing commands too fast!"));
        assertEquals(1, h.queue.snapshot().entries.size());
        assertSame(entry, h.queue.snapshot().entries.get(0));
        assertEquals(0, entry.attempts); assertNotEquals(4, entry.stage);
        assertEquals(0, entry.stage); assertFalse(entry.confirmed); assertTrue(entry.feedbackApplied);
        assertTrue(entry.nextAt >= beforeFeedback + 1000);
        assertEquals(1, message.delivery.get("DyLol").total);
        assertEquals(0, message.delivery.get("DyLol").completed);
        assertEquals(0, message.delivery.get("DyLol").failed);
        assertTrue(h.filed.isEmpty());
        long retryAt = entry.nextAt;
        assertTrue(r.receive("§cSlow down! You're executing commands too fast!"));
        assertEquals(0, entry.attempts); assertEquals(retryAt, entry.nextAt);
    }

    @Test void queuedButUnsentMessageDoesNotClaimServerFeedback() {
        TestHost h = new TestHost(); h.config.hideServerMode = Config.HideServerMode.ALWAYS;
        WhisperRouter r = new WhisperRouter(h); Message message = new Message("Me", "hello", false);
        assertTrue(h.queue.offer(List.of(new SendQueue.Job("DyLol", "hello", "f:dylol", message))));
        assertEquals(1, h.queue.snapshot().entries.size());
        SendQueue.Entry entry = h.queue.snapshot().entries.get(0);
        long queuedAt = entry.nextAt;
        assertFalse(h.queue.recentWhisper(System.currentTimeMillis()));
        assertTrue(r.receive("§cThis player is offline!"));
        assertTrue(r.receive("§cSlow down! You're executing commands too fast!"));
        assertEquals(0, h.errors); assertTrue(h.filed.isEmpty());
        assertEquals(1, h.queue.snapshot().entries.size());
        assertSame(entry, h.queue.snapshot().entries.get(0));
        assertEquals(queuedAt, entry.nextAt); assertEquals(0, entry.attempts);
        assertEquals(0, entry.stage); assertFalse(entry.confirmed); assertFalse(entry.feedbackApplied);
        assertEquals(1, message.delivery.get("DyLol").total);
        assertEquals(0, message.delivery.get("DyLol").completed);
        assertFalse(h.queue.notFound()); assertFalse(h.queue.slowDown());
    }
    @Test void hiddenServerLineCannotFallIntoPermissivePrivateRegex() {
        TestHost h = new TestHost(); h.config.hideServerMode = Config.HideServerMode.ALWAYS;
        h.config.incomingRegex = List.of("^(?<name>DyLol) (?<message>.*)$");
        h.config.hiddenServerPatterns = List.of(new Config.ServerMessagePattern("DyLol server notice", false, true));
        WhisperRouter r = new WhisperRouter(h);
        assertTrue(r.receive("DyLol server notice")); assertTrue(h.filed.isEmpty());
    }
    @Test void exactSamplesAreFiledWithCorrectDirectionAndNoFormatting() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertTrue(r.receive("§dFrom Me §dto §7DyLol§7: §fyou go to end?"));
        assertTrue(r.receive("§dFrom §7DyLol §dto Me§7: §ftes"));
        assertEquals(2, h.filed.size());
        assertEquals("f:dylol", h.filed.get(0).key());
        assertEquals("Me", h.filed.get(0).message().sender); assertFalse(h.filed.get(0).incoming());
        assertEquals("you go to end?", h.filed.get(0).message().text);
        assertEquals("DyLol", h.filed.get(1).message().sender); assertTrue(h.filed.get(1).incoming());
        assertEquals("tes", h.filed.get(1).message().text);
    }
    @Test void onlyFriendsAreSuppressedIncludingProtocolLookingMessages() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        for (String body : List.of("hello", "[FL:" + ID + "] hello", "[FLI:" + ID + ":12345678:1:1] abc")) {
            assertFalse(r.receive("From Stranger to Me: " + body));
            assertFalse(r.receive("From Me to Stranger: " + body));
            assertFalse(r.receiveParticipant("[VIP] Stranger", null, body, false));
        }
        assertTrue(h.filed.isEmpty()); assertTrue(h.state.groups.isEmpty()); assertTrue(h.invites.isEmpty());
    }
    @Test void publicChatNeverRoutesWithPermissiveCustomRegexOrErrorRegex() {
        TestHost h = new TestHost();
        h.config.incomingRegex = List.of("^\\[.*?\\] (?<name>.+?): (?<message>.*)$");
        h.config.notFoundRegex = List.of(".*");
        WhisperRouter r = new WhisperRouter(h);
        assertFalse(r.receive("[78] DyLol: hello"));
        assertFalse(r.receive("§x§a§b§c§d§e§f[78] §7DyLol: hello"));
        assertTrue(h.filed.isEmpty()); assertEquals(0, h.errors);
    }
    @Test void intentionalRepeatedIncomingAndManualOutgoingAreNotDeduplicated() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        for (int i = 0; i < 2; i++) assertTrue(r.receive("From DyLol to Me: same"));
        for (int i = 0; i < 2; i++) assertTrue(r.receive("From Me to DyLol: same"));
        assertEquals(4, h.filed.size());
    }
    @Test void queueEchoIsAcknowledgedBeforeAppendAndDuplicateEchoDoesNotAppend() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        Message message = new Message("Me", "hello", false);
        SendQueue.Entry entry = arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        assertTrue(r.receive("§dFrom Me to §7DyLol: §fhello"));
        assertTrue(entry.confirmed); assertEquals(1, entry.stage);
        assertTrue(r.receive("From Me to DyLol: hello"));
        assertEquals(1, h.queue.snapshot().entries.size());
        assertSame(entry, h.queue.snapshot().entries.get(0));
        assertEquals(1, entry.attempts); assertFalse(h.queue.notFound());
        assertEquals(1, message.delivery.get("DyLol").total);
        assertEquals(1, message.delivery.get("DyLol").parts.size());
        assertEquals(1, message.delivery.get("DyLol").completed);
        assertEquals(0, message.delivery.get("DyLol").unconfirmed);
        assertTrue(h.filed.isEmpty()); assertEquals("DyLol: sent / pending (1/1 sent, 0 delivered, 0 read)", message.status());
    }
    @Test void participantSeamNormalizesTypedAndProfilelessNamesAndBodiesBeforeRouting() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        UUID id = UUID.randomUUID();
        assertTrue(r.receiveParticipant("§x§1§2§3§4§5§6[MVP+] ★ DyLol", id, "§dhello", false));
        assertTrue(r.receiveParticipant("§7[VIP] DyLol", null, "§fhello", true));
        assertEquals(id.toString(), h.state.friends.get("dylol").uuid);
        assertEquals("hello", h.filed.get(0).message().text);
        assertEquals("hello", h.filed.get(1).message().text);
        assertFalse(r.receiveParticipant("abcdefghijklmnopq", null, "hello", false));
        // A real whisper may legitimately contain text looking like public chat.
        assertTrue(r.receiveParticipant("DyLol", null, "[78] DyLol: quoted", false));
        assertEquals("[78] DyLol: quoted", h.filed.get(2).message().text);
    }
    @Test void uuidIdentityCanResolveRenamedFriendAndEchoCanonicalTarget() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        UUID id = UUID.randomUUID(); h.state.friends.get("dylol").uuid = id.toString();
        assertTrue(r.receiveParticipant("Renamed", id, "hi", false));
        assertEquals("DyLol", h.filed.get(0).message().sender);
        h.filed.clear();
        // The wire name differs only by decorations in ordinary outgoing typed/profileless traffic.
        Message message = new Message("Me", "hello", false);
        arm(h.queue, new SendQueue.Job("DyLol", "hello", "f:dylol", message));
        assertTrue(r.receiveParticipant("[VIP] DyLol", null, "§fhello", true));
        assertEquals(1, message.delivery.get("DyLol").completed); assertTrue(h.filed.isEmpty());
    }
    @Test void groupPayloadUsesSameStrippedRouteAndDoesNotBecomeDirectMessage() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertTrue(r.receive("§dFrom DyLol to Me: §x§1§2§3§4§5§6[FL:" + ID + "] §fhello"));
        assertEquals(1, h.notices); assertEquals(1, h.filed.size());
        assertEquals("g:" + ID, h.filed.get(0).key()); assertEquals("hello", h.filed.get(0).message().text);
        assertTrue(r.receiveParticipant("[VIP] DyLol", null, "§a[FL:" + ID + "] §btyped", false));
        assertEquals("typed", h.filed.get(1).message().text); assertEquals(1, h.notices);
    }
    @Test void decoratedMultipartInviteAndMalformedControlShareRouteWithoutFiling() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        Protocol.Invite invite = new Protocol.Invite();
        invite.id = ID; invite.name = "Test group"; invite.owner = "DyLol";
        invite.members = List.of("DyLol", "Me_"); invite.revision = 1;
        List<String> parts = Protocol.inviteParts(invite);
        for (int i = 0; i < parts.size(); i++) {
            String coloured = "§x§A§b§C§d§E§f" + parts.get(i);
            if (i % 2 == 0) assertTrue(r.receive("§dFrom [VIP] DyLol to Me: " + coloured));
            else assertTrue(r.receiveParticipant("§7DyLol", null, coloured, false));
        }
        assertEquals(1, h.invites.size()); assertEquals(ID, h.invites.get(0).id);
        assertTrue(r.receive("From DyLol to Me: §r[FLI:malformed] rubbish"));
        assertEquals(1, h.invites.size()); assertTrue(h.filed.isEmpty());
    }
    @Test void fullyFilteredContentNeverFilesAndMaskedContentDoesNotLeakRawText() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        assertNull(WhisperRouter.visibleBody(true, "secret"));
        String visible = WhisperRouter.visibleBody(false, "s•••••");
        assertEquals("s•••••", visible);
        assertNotEquals("secret", visible);
        // Missing signed payload returns before registry/client/UUID access or routing side effects.
        assertFalse(r.receiveTyped(null, null, null));
        assertTrue(h.filed.isEmpty()); assertTrue(h.invites.isEmpty());
    }

    @Test void cacheChangesOnlyOnReloadAndClearDropsPartialControlAssembly() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        h.config.dialogueRegex.clear(); h.config.incomingRegex.clear(); h.config.outgoingRegex.clear();
        assertTrue(r.receive("From DyLol to Me: before reload"));
        r.reload(); assertFalse(r.receive("From DyLol to Me: after reload"));
        h.config.dialogueRegex.add(WhisperText.DEFAULT_DIALOGUE_REGEX); r.reload();
        assertTrue(r.receiveParticipant("DyLol", null, "[FLI:" + ID + ":12345678:1:2] YQ", false));
        r.clear();
        assertTrue(r.receiveParticipant("DyLol", null, "[FLI:" + ID + ":12345678:2:2] Yg", false));
        assertTrue(h.invites.isEmpty());
    }

    @Test void filteredServerErrorsNeverEnterPrivateChat() {
        TestHost h = new TestHost(); WhisperRouter r = new WhisperRouter(h);
        h.config.hideServerMode = Config.HideServerMode.ALWAYS; r.reload();
        String error = "§cSlow down! You're executing commands too fast!";
        assertTrue(r.receive(error));
        assertTrue(h.filed.isEmpty());
        assertTrue(r.receiveChat("From DyLol to Me: Slow down! You're executing commands too fast!"));
        assertEquals(1, h.filed.size());
        assertEquals("Slow down! You're executing commands too fast!", h.filed.get(0).message().text);
    }
}
