package dev.friendlink;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PartyMessagesTest {
    @Test void recognizesFormattedInviteAndRejectsPublicChat() {
        String invite = "\n§e§7Alice §ehas invited you to join their Party!\n§eYou have §c60 §eseconds to accept. §6Click here to join!\n";
        assertEquals("Alice", PartyMessages.inviter(PartyMessages.clean(invite)));
        assertNull(PartyMessages.inviter("Bob: " + PartyMessages.clean(invite).strip()));
        assertNull(PartyMessages.inviter(PartyMessages.clean(invite).replace("60", "30")));
    }

    @Test void leaderChangesOnlyOnRecognizedServerAnnouncements() {
        assertTrue(PartyMessages.leader("You created a party!", "Local", false));
        assertTrue(PartyMessages.leader("The party was transferred to [MVP+] Local by [VIP] Alice", "Local", false));
        assertTrue(PartyMessages.leader("Party Members (2)\nParty Leader: [MVP+] Local", "Local", false));
        assertTrue(PartyMessages.leader("[VIP] Alice has promoted [MVP+] Local to Party Leader", "Local", false));
        assertFalse(PartyMessages.leader("Local promoted Bob to Party Leader", "Local", true));
        assertFalse(PartyMessages.leader("The party was transferred to Bob by Local", "Local", true));
        assertFalse(PartyMessages.leader("You left the party.", "Local", true));
        assertFalse(PartyMessages.leader("You joined the party of [VIP] Alice!", "Local", true));
        assertFalse(PartyMessages.leader("The party disbanded because all invites expired and the party was empty.", "Local", true));
        assertFalse(PartyMessages.leader("Party > Local: You are now the Party Leader!", "Local", false));
    }
}
