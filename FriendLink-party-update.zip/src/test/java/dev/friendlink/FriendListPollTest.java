package dev.friendlink;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import static dev.friendlink.FriendListPoll.Chat.*;
import static org.junit.jupiter.api.Assertions.*;

class FriendListPollTest {
    private final FriendListPoll poll = new FriendListPoll();
    private final List<Integer> sent = new ArrayList<>();
    private void tick(long now) { poll.tick(now, sent::add); }
    private static String page(int n, int max) { return "Friend list (Page " + n + " of " + max + ")"; }

    @Test void joinAndSixtySecondScheduleReplaceSnapshot() {
        poll.join(50);
        tick(50);
        assertEquals(List.of(1), sent);
        String reply = "§r               §6Friend list (Page 1 of 1)\n§7Alice §fis playing on §6Skyblock End";
        assertEquals(AUTOMATED, poll.receive(PartyMessages.clean(reply), 99));
        tick(849);
        assertEquals("Skyblock End", poll.location("aLiCe"));
        tick(60_049);
        assertEquals(List.of(1), sent);
        tick(60_050);
        assertEquals(List.of(1, 1), sent);
        assertEquals(AUTOMATED, poll.receive(page(1, 1) + "\nBob is currently offline", 60_700));
        tick(61_450);
        assertNull(poll.location("Alice"));
        assertEquals("Offline", poll.location("Bob"));
    }

    @Test void mergesMultilineAndSplitPageWhileIgnoringInterleavedChat() {
        poll.join(0); tick(0);
        assertEquals(AUTOMATED, poll.receive(page(1, 3), 90));
        assertEquals(AUTOMATED, poll.receive("----------------", 91));
        assertEquals(AUTOMATED, poll.receive("Alice is currently offline", 110));
        assertEquals(UNRELATED, poll.receive("Server restarting soon", 120));
        assertEquals(AUTOMATED, poll.receive("[VIP] Cora is playing on Bed Wars", 150));
        tick(900);
        assertEquals(List.of(1, 2), sent);
        assertNull(poll.location("Alice"));
        assertEquals(AUTOMATED, poll.receive("━━━━━━━━\n" + page(2, 3) + "\nBob is playing on Skyblock End\n━━━━━━━━", 1_000));
        tick(1_000);
        assertEquals(List.of(1, 2, 3), sent);
        assertEquals(AUTOMATED, poll.receive(page(3, 3) + "\nDave is currently offline", 1_080));
        tick(1_830);
        assertEquals("Offline", poll.location("Alice"));
        assertEquals("Skyblock End", poll.location("Bob"));
        assertEquals("Bed Wars", poll.location("Cora"));
        assertEquals("Offline", poll.location("Dave"));
    }

    @Test void manualBeforeFirstPollDefersItAndDoesNotPaginate() {
        poll.join(0);
        poll.manualCommand("/friends list", 1);
        tick(2); assertTrue(sent.isEmpty());
        assertEquals(MANUAL, poll.receive(page(1, 3), 45));
        assertEquals(MANUAL, poll.receive("Alice is currently offline", 55));
        tick(805); assertEquals(List.of(1), sent);
        assertNull(poll.location("Alice"));
    }

    @Test void samePageManualDuringAutomaticPollIsVisibleWithoutOverwritingLocation() {
        poll.join(0); tick(0);
        poll.manualCommand("friends list 1", 10);
        assertEquals(AUTOMATED, poll.receive(page(1, 1) + "\nAlice is playing on Skyblock End", 50));
        assertEquals(MANUAL, poll.receive(page(1, 1) + "\nAlice is currently offline", 90));
        tick(840);
        assertEquals("Skyblock End", poll.location("Alice"));
        assertEquals(List.of(1), sent);
    }

    @Test void manualPageReturningFirstDoesNotStealAutomationResponse() {
        poll.join(0); tick(0);
        poll.manualCommand("friends list 2", 10);
        assertEquals(MANUAL, poll.receive(page(2, 3) + "\nBob is currently offline", 50));
        assertEquals(AUTOMATED, poll.receive(page(1, 1) + "\nBob is playing on Skyblock End", 90));
        tick(840);
        assertEquals("Skyblock End", poll.location("Bob"));
        assertEquals(List.of(1), sent);
    }

    @Test void timeoutAndDisconnectDoNotHideUnrelatedTraffic() {
        poll.join(0); tick(0);
        assertEquals(UNRELATED, poll.receive("Alice is currently offline", 100));
        assertEquals(UNRELATED, poll.receive(page(1, 1), 11_000));
        tick(60_000);
        assertEquals(AUTOMATED, poll.receive("You don't have any friends!", 60_100));
        poll.clear(); tick(120_000);
        assertEquals(List.of(1, 1), sent);
        assertEquals(UNRELATED, poll.receive(page(1, 1), 120_001));
        assertNull(poll.location("Alice"));
    }
}
