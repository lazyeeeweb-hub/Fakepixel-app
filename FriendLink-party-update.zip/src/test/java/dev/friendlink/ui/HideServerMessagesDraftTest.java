package dev.friendlink.ui;

import static org.junit.jupiter.api.Assertions.*;

import dev.friendlink.Config;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

final class HideServerMessagesDraftTest {
    @Test
    void editsAreDetachedUntilAppliedAndPreserveModeAndMaster() {
        Config original = new Config();
        original.hideServerMessages = false;
        original.hideServerMode = Config.HideServerMode.ALWAYS;
        original.hiddenServerPatterns = new ArrayList<>(List.of(
            new Config.ServerMessagePattern("old", false, true)));

        HideServerMessagesDraft draft = new HideServerMessagesDraft(original);
        draft.rules.get(0).setText("new");
        assertEquals("old", original.hiddenServerPatterns.get(0).text);

        Config saved = new Config();
        draft.applyTo(saved);
        assertFalse(saved.hideServerMessages);
        assertEquals(Config.HideServerMode.ALWAYS, saved.hideServerMode);
        assertEquals("new", saved.hiddenServerPatterns.get(0).text);
        assertNotSame(draft.rules, saved.hiddenServerPatterns);
    }

    @Test
    void rejectsEmptyMalformedRegexAndOverlongPatternsEvenWhenDisabled() {
        HideServerMessagesDraft draft = new HideServerMessagesDraft(new Config());
        draft.rules.clear();
        draft.rules.add(new HideServerMessagesDraft.Rule("  ", false, true));
        assertEquals(0, draft.firstInvalidIndex());
        draft.rules.set(0, new HideServerMessagesDraft.Rule("(", true, false));
        assertEquals(0, draft.firstInvalidIndex());
        draft.rules.set(0, new HideServerMessagesDraft.Rule("x".repeat(1025), false, true));
        assertEquals(0, draft.firstInvalidIndex());
        draft.rules.set(0, new HideServerMessagesDraft.Rule("x".repeat(1024), false, true));
        assertEquals(-1, draft.firstInvalidIndex());
    }

    @Test
    void defaultsAreDeepCopiedAndResetDoesNotChangeMasterOrScope() {
        Config first = new Config();
        first.hideServerMessages = false;
        first.hideServerMode = Config.HideServerMode.ALWAYS;
        HideServerMessagesDraft draft = new HideServerMessagesDraft(first);
        List<Config.ServerMessagePattern> defaults = Config.defaultHiddenServerPatterns();
        draft.resetPatterns();
        assertFalse(draft.enabled);
        assertEquals(Config.HideServerMode.ALWAYS, draft.mode);
        assertEquals(defaults.size(), draft.rules.size());
        for (int i = 0; i < defaults.size(); i++) {
            assertNotSame(defaults.get(i), draft.rules.get(i));
            assertEquals(defaults.get(i).text, draft.rules.get(i).text);
            assertEquals(defaults.get(i).regex, draft.rules.get(i).regex);
            assertEquals(defaults.get(i).enabled, draft.rules.get(i).enabled);
        }
    }
}
