package dev.friendlink.ui;

import com.google.gson.Gson;
import dev.friendlink.Config;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SocialLayoutTest {
    @Test void manualScaleIsIndependentOfTheViewportAndSnapsToFivePercent() {
        for (int percent = 50; percent <= 150; percent += 5) {
            assertEquals(percent / 100.0, SocialLayout.scale(854, 480, percent, false));
            assertEquals(percent / 100.0, SocialLayout.scale(320, 240, percent, false));
        }
        assertEquals(50, SocialLayout.snapPercent(-100));
        assertEquals(150, SocialLayout.snapPercent(900));
        assertEquals(105, SocialLayout.snapPercent(103));
    }

    @Test void autoChoosesTheLargestFittingFivePercentStep() {
        for (int width : new int[] {160, 320, 427, 640, 854, 1920}) {
            for (int height : new int[] {120, 240, 360, 480, 1080}) {
                double scale = SocialLayout.scale(width, height, 100, true);
                assertTrue(scale <= 1.5);
                assertTrue((SocialLayout.FIT_WIDTH + SocialLayout.MARGIN) * scale <= width + 1E-7);
                assertTrue((SocialLayout.FIT_HEIGHT + SocialLayout.MARGIN) * scale <= height + 1E-7);
                double next = scale + .05;
                assertTrue(next > 1.5 || (SocialLayout.FIT_WIDTH + SocialLayout.MARGIN) * next > width
                    || (SocialLayout.FIT_HEIGHT + SocialLayout.MARGIN) * next > height);
            }
        }
    }

    @Test void sidebarIsTwentySixPercentByDefaultAndAlwaysClamped() {
        assertEquals(110, SocialLayout.sidebarWidth(360, 26));
        assertEquals(130, SocialLayout.sidebarWidth(500, 26));
        assertEquals(170, SocialLayout.sidebarWidth(720, 26));
        for (int width : new int[] {205, 320, 427, 640, 720})
            for (int percent = 20; percent <= 40; percent++) {
                int side = SocialLayout.sidebarWidth(width, percent);
                assertTrue(side >= 110 && side <= 170);
            }
    }

    @Test void composerAndBubbleLanesFitAtFiftyOneHundredAndOneHundredFiftyPercent() {
        for (int percent : new int[] {50, 100, 150}) for (int realWidth : new int[] {320, 427, 854, 1920}) {
            double scale = SocialLayout.scale(realWidth, 480, percent, false);
            int virtual = SocialLayout.virtualExtent(realWidth, scale);
            int panel = SocialLayout.panelExtent(virtual, SocialLayout.FIT_WIDTH, 720, .85);
            assertTrue(panel + SocialLayout.MARGIN <= virtual);
            for (int sidebar : new int[] {20, 26, 40}) {
                int chat = panel - SocialLayout.sidebarWidth(panel, sidebar);
                int sendX = chat - 9 - 24, inputX = 11, inputWidth = sendX - inputX - 4;
                assertTrue(inputWidth >= 8);
                assertEquals(chat - 9, sendX + 24); // three-pixel inset from bar's right edge (chat - 6)
                int maxBubble = Math.max(24, Math.min((chat - 20) * 70 / 100, chat - 20 - 24));
                assertTrue(34 + maxBubble <= chat - 10); // left head lane + bubble
                assertTrue(chat - maxBubble - 34 >= 10); // right bubble + head lane
                double realMouse = (sendX + 12) * scale;
                assertEquals(sendX + 12, realMouse / scale, 1E-8);
                assertEquals(7.0, (7 * scale) / scale, 1E-8); // drag deltas
            }
        }
    }

    @Test void uiSettingsDefaultNormalizeAndSurviveJsonRoundTrip() {
        Config c = new Config();
        assertEquals(100, c.friendLinkUiScale); assertFalse(c.friendLinkUiAutoScale);
        assertEquals(26, c.sidebarWidthPercent);
        c.friendLinkUiScale = 103; c.friendLinkUiAutoScale = true; c.sidebarWidthPercent = 75;
        c.normalize();
        assertEquals(105, c.friendLinkUiScale); assertEquals(40, c.sidebarWidthPercent);
        Config copy = new Gson().fromJson(new Gson().toJson(c), Config.class);
        assertEquals(105, copy.friendLinkUiScale); assertTrue(copy.friendLinkUiAutoScale);
        assertEquals(40, copy.sidebarWidthPercent);
        Config legacy = new Gson().fromJson("{}", Config.class);
        assertEquals(100, legacy.friendLinkUiScale); assertEquals(26, legacy.sidebarWidthPercent);
    }
}
