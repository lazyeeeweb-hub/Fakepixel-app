package dev.friendlink;

import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PartyJoinClickTest {
    @Test void preservesOriginalCommandFromLinkIncludingInheritedStyle() {
        ClickEvent wrong = new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/not-the-link");
        ClickEvent expected = new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/p accept AlreadySelected");
        Text message = Text.literal("Inviter").styled(s -> s.withClickEvent(wrong))
            .append(Text.literal(" §eYou have §c60 §eseconds to accept. ").styled(s -> s.withClickEvent(null)))
            .append(Text.literal("§6Click here ").styled(s -> s.withClickEvent(expected))
                .append(Text.literal("to join!")));
        assertSame(expected, PartyService.extractJoinClick(message));
    }

    @Test void doesNotGuessCommandOrUseUnrelatedActions() {
        assertNull(PartyService.extractJoinClick(Text.literal("Click here to join!")));
        assertNull(PartyService.extractJoinClick(Text.literal("Click here to join!")
            .styled(s -> s.withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/p accept Alice")))));
        assertNull(PartyService.extractJoinClick(Text.empty()
            .append(Text.literal("Click here").styled(s -> s.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/p accept Alice"))))
            .append(Text.literal(" to join!"))));
    }
}
