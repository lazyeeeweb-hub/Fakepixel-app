package dev.friendlink;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SendPacingTest {
    @Test void causalWindowIncludesBoundaryAndClearsOnDisconnect() {
        SendPacing p = new SendPacing(); assertFalse(p.recent(1000));
        p.sent(1000); assertTrue(p.recent(1000)); assertTrue(p.recent(4000));
        assertFalse(p.recent(4001)); assertFalse(p.recent(999));
        p.clear(); assertFalse(p.recent(1000));
    }
    @Test void repeatedThrottleBacksOffThenGraduallyRecoversWithoutChangingBase() {
        SendPacing p = new SendPacing(); assertEquals(400, p.delay(400));
        assertEquals(1000, p.slowDown(1000, 400)); assertEquals(2000, p.slowDown(2000, 400));
        p.tick(31999, 400); assertEquals(2000, p.delay(400));
        p.tick(32000, 400); assertTrue(p.delay(400) < 2000); assertTrue(p.delay(400) > 400);
        for (long t = 42000; t < 1000000; t += 10000) p.tick(t, 400);
        assertEquals(400, p.delay(400));
        for (int i = 0; i < 20; i++) p.slowDown(i, 400);
        assertEquals(30000, p.delay(400)); p.clear(); assertEquals(400, p.delay(400));
    }
}
