package dev.friendlink;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class HologramSettingsTest {
    @Test void defaultsArePrivateStaticPanelAtRequestedSize() {
        Config c = new Config(); c.normalize();
        assertEquals(IndicatorStyle.HOLOGRAM, c.indicatorStyle);
        assertEquals(50, c.hologramOpacity); assertEquals(48, c.hologramMaxDistance);
        assertEquals(1.4, c.hologramSize); assertEquals(1.1, c.hologramDistance);
        assertEquals(-.25, c.hologramHeightOffset); assertEquals(300000, c.chatOpenTimeoutMs);
        assertFalse(c.hologramThroughWalls); assertFalse(c.hologramPreviewSelf);
    }
    @Test void legacyDisabledIndicatorStaysOffWithoutDisablingSharing() {
        Config c = new Config(); c.chatBubbles = false; c.normalize();
        assertEquals(IndicatorStyle.OFF, c.indicatorStyle); assertTrue(c.shareChatOpen);
        c.indicatorStyle = IndicatorStyle.BUBBLE; c.normalize();
        assertEquals(IndicatorStyle.BUBBLE, c.indicatorStyle);
    }
    @Test void editedJsonCannotPoisonRenderMath() {
        Config c = new Config(); c.indicatorStyle = null;
        c.hologramOpacity = 200; c.hologramMaxDistance = -1;
        c.hologramSize = Double.NaN; c.hologramDistance = Double.POSITIVE_INFINITY;
        c.hologramHeightOffset = Double.NEGATIVE_INFINITY;
        c.hologramScaleFactor = Double.NaN; c.hologramMaxScale = Double.NaN; c.normalize();
        assertEquals(IndicatorStyle.HOLOGRAM, c.indicatorStyle);
        assertEquals(100, c.hologramOpacity); assertEquals(1, c.hologramMaxDistance);
        assertEquals(1.4, c.hologramSize); assertEquals(1.1, c.hologramDistance);
        assertEquals(-.25, c.hologramHeightOffset);
        assertEquals(.01, c.hologramScaleFactor); assertEquals(3, c.hologramMaxScale);
    }
    @Test void sharingOverrideAndMarkerScalingAreIndependentOfDisplayStyle() {
        Config c = new Config(); c.indicatorStyle = IndicatorStyle.OFF; c.shareChatOpen = false;
        assertTrue(GlowToggle.ON.resolve(c.shareChatOpen)); assertFalse(GlowToggle.DEFAULT.resolve(c.shareChatOpen));
        assertFalse(GlowToggle.OFF.resolve(true));
        assertEquals(1, DistanceScaling.multiplier(10, true, .01, 3));
        assertEquals(2, DistanceScaling.multiplier(100, true, .01, 3));
        assertEquals(3, DistanceScaling.multiplier(1000, true, .01, 3));
        assertEquals(1, DistanceScaling.multiplier(1000, false, .01, 3));
    }
}
